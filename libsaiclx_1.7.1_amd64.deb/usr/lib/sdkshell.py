r"""Wrapper for clx_acl.h

Generated with:
/usr/local/bin/ctypesgen -I./build -I./clx_sai/inc/sai/sai_1_7_0 -I./clx_system/clx_sdk/include -I./clx_system/clx_sdk/include/cdb -I./clx_system/clx_sdk/include/osal -I./clx_system/clx_sdk/src/inc --runtime-libdir=/usr/lib --include=clnx_sai_version.h --cpp=gcc -E -DCLX_EN_HOST_64_BIT_LITTLE_ENDIAN=1 -L./build -llibsai.so ./clx_system/clx_sdk/include/clx_acl.h ./clx_system/clx_sdk/include/clx_cfg.h ./clx_system/clx_sdk/include/clx_dtel.h ./clx_system/clx_sdk/include/clx_error.h ./clx_system/clx_sdk/include/clx_fcoe.h ./clx_system/clx_sdk/include/clx_ifmap.h ./clx_system/clx_sdk/include/clx_ifmon.h ./clx_system/clx_sdk/include/clx_init.h ./clx_system/clx_sdk/include/clx_l2.h ./clx_system/clx_sdk/include/clx_l3.h ./clx_system/clx_sdk/include/clx_l3t.h ./clx_system/clx_sdk/include/clx_lag.h ./clx_system/clx_sdk/include/clx_meter.h ./clx_system/clx_sdk/include/clx_mir.h ./clx_system/clx_sdk/include/clx_module.h ./clx_system/clx_sdk/include/clx_mpls.h ./clx_system/clx_sdk/include/clx_netif.h ./clx_system/clx_sdk/include/clx_nv.h ./clx_system/clx_sdk/include/clx_pkt.h ./clx_system/clx_sdk/include/clx_port.h ./clx_system/clx_sdk/include/clx_pppoe.h ./clx_system/clx_sdk/include/clx_qos.h ./clx_system/clx_sdk/include/clx_sdn.h ./clx_system/clx_sdk/include/clx_sec.h ./clx_system/clx_sdk/include/clx_sfc.h ./clx_system/clx_sdk/include/clx_stat.h ./clx_system/clx_sdk/include/clx_stk.h ./clx_system/clx_sdk/include/clx_stp.h ./clx_system/clx_sdk/include/clx_swc.h ./clx_system/clx_sdk/include/clx_tm.h ./clx_system/clx_sdk/include/clx_trill.h ./clx_system/clx_sdk/include/clx_types.h ./clx_system/clx_sdk/include/clx_ver.h ./clx_system/clx_sdk/include/clx_vlan.h ./clx_system/clx_sdk/include/clx_vm.h ./clx_system/clx_sdk/include/cdb/cdb.h ./clx_system/clx_sdk/include/osal/osal.h ./clx_system/clx_sdk/include/osal/osal_dma.h ./clx_system/clx_sdk/include/osal/osal_file.h ./clx_system/clx_sdk/include/osal/osal_lib.h ./clx_system/clx_sdk/include/osal/osal_types.h -o sdkshell.py

Do not modify this file.
"""

__docformat__ = "restructuredtext"

# Begin preamble for Python v(2, 7)

import ctypes, os, sys
from ctypes import *

_int_types = (c_int16, c_int32)
if hasattr(ctypes, "c_int64"):
    # Some builds of ctypes apparently do not have c_int64
    # defined; it's a pretty good bet that these builds do not
    # have 64-bit pointers.
    _int_types += (c_int64,)
for t in _int_types:
    if sizeof(t) == sizeof(c_size_t):
        c_ptrdiff_t = t
del t
del _int_types


class UserString:
    def __init__(self, seq):
        if isinstance(seq, basestring):
            self.data = seq
        elif isinstance(seq, UserString):
            self.data = seq.data[:]
        else:
            self.data = str(seq)

    def __str__(self):
        return str(self.data)

    def __repr__(self):
        return repr(self.data)

    def __int__(self):
        return int(self.data)

    def __long__(self):
        return long(self.data)

    def __float__(self):
        return float(self.data)

    def __complex__(self):
        return complex(self.data)

    def __hash__(self):
        return hash(self.data)

    def __cmp__(self, string):
        if isinstance(string, UserString):
            return cmp(self.data, string.data)
        else:
            return cmp(self.data, string)

    def __contains__(self, char):
        return char in self.data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.__class__(self.data[index])

    def __getslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        return self.__class__(self.data[start:end])

    def __add__(self, other):
        if isinstance(other, UserString):
            return self.__class__(self.data + other.data)
        elif isinstance(other, basestring):
            return self.__class__(self.data + other)
        else:
            return self.__class__(self.data + str(other))

    def __radd__(self, other):
        if isinstance(other, basestring):
            return self.__class__(other + self.data)
        else:
            return self.__class__(str(other) + self.data)

    def __mul__(self, n):
        return self.__class__(self.data * n)

    __rmul__ = __mul__

    def __mod__(self, args):
        return self.__class__(self.data % args)

    # the following methods are defined in alphabetical order:
    def capitalize(self):
        return self.__class__(self.data.capitalize())

    def center(self, width, *args):
        return self.__class__(self.data.center(width, *args))

    def count(self, sub, start=0, end=sys.maxint):
        return self.data.count(sub, start, end)

    def decode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.decode(encoding, errors))
            else:
                return self.__class__(self.data.decode(encoding))
        else:
            return self.__class__(self.data.decode())

    def encode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.encode(encoding, errors))
            else:
                return self.__class__(self.data.encode(encoding))
        else:
            return self.__class__(self.data.encode())

    def endswith(self, suffix, start=0, end=sys.maxint):
        return self.data.endswith(suffix, start, end)

    def expandtabs(self, tabsize=8):
        return self.__class__(self.data.expandtabs(tabsize))

    def find(self, sub, start=0, end=sys.maxint):
        return self.data.find(sub, start, end)

    def index(self, sub, start=0, end=sys.maxint):
        return self.data.index(sub, start, end)

    def isalpha(self):
        return self.data.isalpha()

    def isalnum(self):
        return self.data.isalnum()

    def isdecimal(self):
        return self.data.isdecimal()

    def isdigit(self):
        return self.data.isdigit()

    def islower(self):
        return self.data.islower()

    def isnumeric(self):
        return self.data.isnumeric()

    def isspace(self):
        return self.data.isspace()

    def istitle(self):
        return self.data.istitle()

    def isupper(self):
        return self.data.isupper()

    def join(self, seq):
        return self.data.join(seq)

    def ljust(self, width, *args):
        return self.__class__(self.data.ljust(width, *args))

    def lower(self):
        return self.__class__(self.data.lower())

    def lstrip(self, chars=None):
        return self.__class__(self.data.lstrip(chars))

    def partition(self, sep):
        return self.data.partition(sep)

    def replace(self, old, new, maxsplit=-1):
        return self.__class__(self.data.replace(old, new, maxsplit))

    def rfind(self, sub, start=0, end=sys.maxint):
        return self.data.rfind(sub, start, end)

    def rindex(self, sub, start=0, end=sys.maxint):
        return self.data.rindex(sub, start, end)

    def rjust(self, width, *args):
        return self.__class__(self.data.rjust(width, *args))

    def rpartition(self, sep):
        return self.data.rpartition(sep)

    def rstrip(self, chars=None):
        return self.__class__(self.data.rstrip(chars))

    def split(self, sep=None, maxsplit=-1):
        return self.data.split(sep, maxsplit)

    def rsplit(self, sep=None, maxsplit=-1):
        return self.data.rsplit(sep, maxsplit)

    def splitlines(self, keepends=0):
        return self.data.splitlines(keepends)

    def startswith(self, prefix, start=0, end=sys.maxint):
        return self.data.startswith(prefix, start, end)

    def strip(self, chars=None):
        return self.__class__(self.data.strip(chars))

    def swapcase(self):
        return self.__class__(self.data.swapcase())

    def title(self):
        return self.__class__(self.data.title())

    def translate(self, *args):
        return self.__class__(self.data.translate(*args))

    def upper(self):
        return self.__class__(self.data.upper())

    def zfill(self, width):
        return self.__class__(self.data.zfill(width))


class MutableString(UserString):
    """mutable string objects

    Python strings are immutable objects.  This has the advantage, that
    strings may be used as dictionary keys.  If this property isn't needed
    and you insist on changing string values in place instead, you may cheat
    and use MutableString.

    But the purpose of this class is an educational one: to prevent
    people from inventing their own mutable string class derived
    from UserString and than forget thereby to remove (override) the
    __hash__ method inherited from UserString.  This would lead to
    errors that would be very hard to track down.

    A faster and better solution is to rewrite your program using lists."""

    def __init__(self, string=""):
        self.data = string

    def __hash__(self):
        raise TypeError("unhashable type (it is mutable)")

    def __setitem__(self, index, sub):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + sub + self.data[index + 1 :]

    def __delitem__(self, index):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + self.data[index + 1 :]

    def __setslice__(self, start, end, sub):
        start = max(start, 0)
        end = max(end, 0)
        if isinstance(sub, UserString):
            self.data = self.data[:start] + sub.data + self.data[end:]
        elif isinstance(sub, basestring):
            self.data = self.data[:start] + sub + self.data[end:]
        else:
            self.data = self.data[:start] + str(sub) + self.data[end:]

    def __delslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        self.data = self.data[:start] + self.data[end:]

    def immutable(self):
        return UserString(self.data)

    def __iadd__(self, other):
        if isinstance(other, UserString):
            self.data += other.data
        elif isinstance(other, basestring):
            self.data += other
        else:
            self.data += str(other)
        return self

    def __imul__(self, n):
        self.data *= n
        return self


class String(MutableString, Union):

    _fields_ = [("raw", POINTER(c_char)), ("data", c_char_p)]

    def __init__(self, obj=""):
        if isinstance(obj, (str, unicode, UserString)):
            self.data = str(obj)
        else:
            self.raw = obj

    def __len__(self):
        return self.data and len(self.data) or 0

    def from_param(cls, obj):
        # Convert None or 0
        if obj is None or obj == 0:
            return cls(POINTER(c_char)())

        # Convert from String
        elif isinstance(obj, String):
            return obj

        # Convert from str
        elif isinstance(obj, str):
            return cls(obj)

        # Convert from c_char_p
        elif isinstance(obj, c_char_p):
            return obj

        # Convert from POINTER(c_char)
        elif isinstance(obj, POINTER(c_char)):
            return obj

        # Convert from raw pointer
        elif isinstance(obj, int):
            return cls(cast(obj, POINTER(c_char)))

        # Convert from c_char array
        elif isinstance(obj, c_char * len(obj)):
            return obj

        # Convert from object
        else:
            return String.from_param(obj._as_parameter_)

    from_param = classmethod(from_param)


def ReturnString(obj, func=None, arguments=None):
    return String.from_param(obj)


# As of ctypes 1.0, ctypes does not support custom error-checking
# functions on callbacks, nor does it support custom datatypes on
# callbacks, so we must ensure that all callbacks return
# primitive datatypes.
#
# Non-primitive return values wrapped with UNCHECKED won't be
# typechecked, and will be converted to c_void_p.
def UNCHECKED(type):
    if hasattr(type, "_type_") and isinstance(type._type_, str) and type._type_ != "P":
        return type
    else:
        return c_void_p


# ctypes doesn't have direct support for variadic functions, so we have to write
# our own wrapper class
class _variadic_function(object):
    def __init__(self, func, restype, argtypes, errcheck):
        self.func = func
        self.func.restype = restype
        self.argtypes = argtypes
        if errcheck:
            self.func.errcheck = errcheck

    def _as_parameter_(self):
        # So we can pass this variadic function as a function pointer
        return self.func

    def __call__(self, *args):
        fixed_args = []
        i = 0
        for argtype in self.argtypes:
            # Typecheck what we can
            fixed_args.append(argtype.from_param(args[i]))
            i += 1
        return self.func(*fixed_args + list(args[i:]))


def ord_if_char(value):
    """
    Simple helper used for casts to simple builtin types:  if the argument is a
    string type, it will be converted to it's ordinal value.

    This function will raise an exception if the argument is string with more
    than one characters.
    """
    return ord(value) if isinstance(value, str) else value

# End preamble

_libs = {}
_libdirs = ['./build']

# Begin loader

# ----------------------------------------------------------------------------
# Copyright (c) 2008 David James
# Copyright (c) 2006-2008 Alex Holkner
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of pyglet nor the names of its
#    contributors may be used to endorse or promote products
#    derived from this software without specific prior written
#    permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ----------------------------------------------------------------------------

import os.path, re, sys, glob
import platform
import ctypes
import ctypes.util


def _environ_path(name):
    if name in os.environ:
        return os.environ[name].split(":")
    else:
        return []


class LibraryLoader(object):
    # library names formatted specifically for platforms
    name_formats = ["%s"]

    class Lookup(object):
        mode = ctypes.DEFAULT_MODE

        def __init__(self, path):
            super(LibraryLoader.Lookup, self).__init__()
            self.access = dict(cdecl=ctypes.CDLL(path, self.mode))

        def get(self, name, calling_convention="cdecl"):
            if calling_convention not in self.access:
                raise LookupError(
                    "Unknown calling convention '{}' for function '{}'".format(
                        calling_convention, name
                    )
                )
            return getattr(self.access[calling_convention], name)

        def has(self, name, calling_convention="cdecl"):
            if calling_convention not in self.access:
                return False
            return hasattr(self.access[calling_convention], name)

        def __getattr__(self, name):
            return getattr(self.access["cdecl"], name)

    def __init__(self):
        self.other_dirs = []

    def __call__(self, libname):
        """Given the name of a library, load it."""
        paths = self.getpaths(libname)

        for path in paths:
            try:
                return self.Lookup(path)
            except:
                pass

        raise ImportError("Could not load %s." % libname)

    def getpaths(self, libname):
        """Return a list of paths where the library might be found."""
        if os.path.isabs(libname):
            yield libname
        else:
            # search through a prioritized series of locations for the library

            # we first search any specific directories identified by user
            for dir_i in self.other_dirs:
                for fmt in self.name_formats:
                    # dir_i should be absolute already
                    yield os.path.join(dir_i, fmt % libname)

            # then we search the directory where the generated python interface is stored
            for fmt in self.name_formats:
                yield os.path.abspath(os.path.join(os.path.dirname(__file__), fmt % libname))

            # now, use the ctypes tools to try to find the library
            for fmt in self.name_formats:
                path = ctypes.util.find_library(fmt % libname)
                if path:
                    yield path

            # then we search all paths identified as platform-specific lib paths
            for path in self.getplatformpaths(libname):
                yield path

            # Finally, we'll try the users current working directory
            for fmt in self.name_formats:
                yield os.path.abspath(os.path.join(os.path.curdir, fmt % libname))

    def getplatformpaths(self, libname):
        return []


# Darwin (Mac OS X)


class DarwinLibraryLoader(LibraryLoader):
    name_formats = [
        "lib%s.dylib",
        "lib%s.so",
        "lib%s.bundle",
        "%s.dylib",
        "%s.so",
        "%s.bundle",
        "%s",
    ]

    class Lookup(LibraryLoader.Lookup):
        # Darwin requires dlopen to be called with mode RTLD_GLOBAL instead
        # of the default RTLD_LOCAL.  Without this, you end up with
        # libraries not being loadable, resulting in "Symbol not found"
        # errors
        mode = ctypes.RTLD_GLOBAL

    def getplatformpaths(self, libname):
        if os.path.pathsep in libname:
            names = [libname]
        else:
            names = [format % libname for format in self.name_formats]

        for dir in self.getdirs(libname):
            for name in names:
                yield os.path.join(dir, name)

    def getdirs(self, libname):
        """Implements the dylib search as specified in Apple documentation:

        http://developer.apple.com/documentation/DeveloperTools/Conceptual/
            DynamicLibraries/Articles/DynamicLibraryUsageGuidelines.html

        Before commencing the standard search, the method first checks
        the bundle's ``Frameworks`` directory if the application is running
        within a bundle (OS X .app).
        """

        dyld_fallback_library_path = _environ_path("DYLD_FALLBACK_LIBRARY_PATH")
        if not dyld_fallback_library_path:
            dyld_fallback_library_path = [os.path.expanduser("~/lib"), "/usr/local/lib", "/usr/lib"]

        dirs = []

        if "/" in libname:
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))
        else:
            dirs.extend(_environ_path("LD_LIBRARY_PATH"))
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))

        if hasattr(sys, "frozen") and sys.frozen == "macosx_app":
            dirs.append(os.path.join(os.environ["RESOURCEPATH"], "..", "Frameworks"))

        dirs.extend(dyld_fallback_library_path)

        return dirs


# Posix


class PosixLibraryLoader(LibraryLoader):
    _ld_so_cache = None

    _include = re.compile(r"^\s*include\s+(?P<pattern>.*)")

    class _Directories(dict):
        def __init__(self):
            self.order = 0

        def add(self, directory):
            if len(directory) > 1:
                directory = directory.rstrip(os.path.sep)
            # only adds and updates order if exists and not already in set
            if not os.path.exists(directory):
                return
            o = self.setdefault(directory, self.order)
            if o == self.order:
                self.order += 1

        def extend(self, directories):
            for d in directories:
                self.add(d)

        def ordered(self):
            return (i[0] for i in sorted(self.items(), key=lambda D: D[1]))

    def _get_ld_so_conf_dirs(self, conf, dirs):
        """
        Recursive funtion to help parse all ld.so.conf files, including proper
        handling of the `include` directive.
        """

        try:
            with open(conf) as f:
                for D in f:
                    D = D.strip()
                    if not D:
                        continue

                    m = self._include.match(D)
                    if not m:
                        dirs.add(D)
                    else:
                        for D2 in glob.glob(m.group("pattern")):
                            self._get_ld_so_conf_dirs(D2, dirs)
        except IOError:
            pass

    def _create_ld_so_cache(self):
        # Recreate search path followed by ld.so.  This is going to be
        # slow to build, and incorrect (ld.so uses ld.so.cache, which may
        # not be up-to-date).  Used only as fallback for distros without
        # /sbin/ldconfig.
        #
        # We assume the DT_RPATH and DT_RUNPATH binary sections are omitted.

        directories = self._Directories()
        for name in (
            "LD_LIBRARY_PATH",
            "SHLIB_PATH",  # HPUX
            "LIBPATH",  # OS/2, AIX
            "LIBRARY_PATH",  # BE/OS
        ):
            if name in os.environ:
                directories.extend(os.environ[name].split(os.pathsep))

        self._get_ld_so_conf_dirs("/etc/ld.so.conf", directories)

        bitage = platform.architecture()[0]

        unix_lib_dirs_list = []
        if bitage.startswith("64"):
            # prefer 64 bit if that is our arch
            unix_lib_dirs_list += ["/lib64", "/usr/lib64"]

        # must include standard libs, since those paths are also used by 64 bit
        # installs
        unix_lib_dirs_list += ["/lib", "/usr/lib"]
        if sys.platform.startswith("linux"):
            # Try and support multiarch work in Ubuntu
            # https://wiki.ubuntu.com/MultiarchSpec
            if bitage.startswith("32"):
                # Assume Intel/AMD x86 compat
                unix_lib_dirs_list += ["/lib/i386-linux-gnu", "/usr/lib/i386-linux-gnu"]
            elif bitage.startswith("64"):
                # Assume Intel/AMD x86 compat
                unix_lib_dirs_list += ["/lib/x86_64-linux-gnu", "/usr/lib/x86_64-linux-gnu"]
            else:
                # guess...
                unix_lib_dirs_list += glob.glob("/lib/*linux-gnu")
        directories.extend(unix_lib_dirs_list)

        cache = {}
        lib_re = re.compile(r"lib(.*)\.s[ol]")
        ext_re = re.compile(r"\.s[ol]$")
        for dir in directories.ordered():
            try:
                for path in glob.glob("%s/*.s[ol]*" % dir):
                    file = os.path.basename(path)

                    # Index by filename
                    cache_i = cache.setdefault(file, set())
                    cache_i.add(path)

                    # Index by library name
                    match = lib_re.match(file)
                    if match:
                        library = match.group(1)
                        cache_i = cache.setdefault(library, set())
                        cache_i.add(path)
            except OSError:
                pass

        self._ld_so_cache = cache

    def getplatformpaths(self, libname):
        if self._ld_so_cache is None:
            self._create_ld_so_cache()

        result = self._ld_so_cache.get(libname, set())
        for i in result:
            # we iterate through all found paths for library, since we may have
            # actually found multiple architectures or other library types that
            # may not load
            yield i


# Windows


class WindowsLibraryLoader(LibraryLoader):
    name_formats = ["%s.dll", "lib%s.dll", "%slib.dll", "%s"]

    class Lookup(LibraryLoader.Lookup):
        def __init__(self, path):
            super(WindowsLibraryLoader.Lookup, self).__init__(path)
            self.access["stdcall"] = ctypes.windll.LoadLibrary(path)


# Platform switching

# If your value of sys.platform does not appear in this dict, please contact
# the Ctypesgen maintainers.

loaderclass = {
    "darwin": DarwinLibraryLoader,
    "cygwin": WindowsLibraryLoader,
    "win32": WindowsLibraryLoader,
    "msys": WindowsLibraryLoader,
}

load_library = loaderclass.get(sys.platform, PosixLibraryLoader)()


def add_library_search_dirs(other_dirs):
    """
    Add libraries to search paths.
    If library paths are relative, convert them to absolute with respect to this
    file's directory
    """
    for F in other_dirs:
        if not os.path.isabs(F):
            F = os.path.abspath(F)
        load_library.other_dirs.append(F)


del loaderclass

# End loader

add_library_search_dirs(['/usr/lib', './build'])

# Begin libraries
_libs["libsai.so"] = load_library("libsai.so")

# 1 libraries
# End libraries

# No modules

BOOL_T = c_int# ./clx_system/clx_sdk/include/osal/osal_types.h: 76

I8_T = c_char# ./clx_system/clx_sdk/include/osal/osal_types.h: 77

UI8_T = c_ubyte# ./clx_system/clx_sdk/include/osal/osal_types.h: 78

I16_T = c_short# ./clx_system/clx_sdk/include/osal/osal_types.h: 79

UI16_T = c_ushort# ./clx_system/clx_sdk/include/osal/osal_types.h: 80

I32_T = c_int# ./clx_system/clx_sdk/include/osal/osal_types.h: 81

UI32_T = c_uint# ./clx_system/clx_sdk/include/osal/osal_types.h: 82

C8_T = c_char# ./clx_system/clx_sdk/include/osal/osal_types.h: 83

# ./clx_system/clx_sdk/include/osal/osal_types.h: 92
class struct_anon_1(Structure):
    pass

struct_anon_1.__slots__ = [
    'i64',
]
struct_anon_1._fields_ = [
    ('i64', I32_T * int(2)),
]

I64_T = struct_anon_1# ./clx_system/clx_sdk/include/osal/osal_types.h: 92

# ./clx_system/clx_sdk/include/osal/osal_types.h: 97
class struct_anon_2(Structure):
    pass

struct_anon_2.__slots__ = [
    'ui64',
]
struct_anon_2._fields_ = [
    ('ui64', UI32_T * int(2)),
]

UI64_T = struct_anon_2# ./clx_system/clx_sdk/include/osal/osal_types.h: 97

CLX_HUGE_T = c_ulonglong# ./clx_system/clx_sdk/include/clx_types.h: 74

CLX_ADDR_T = c_ulonglong# ./clx_system/clx_sdk/include/clx_types.h: 80

CLX_BIT_MASK_8_T = UI8_T# ./clx_system/clx_sdk/include/clx_types.h: 109

CLX_BIT_MASK_16_T = UI16_T# ./clx_system/clx_sdk/include/clx_types.h: 110

CLX_BIT_MASK_32_T = UI32_T# ./clx_system/clx_sdk/include/clx_types.h: 111

CLX_BIT_MASK_64_T = UI64_T# ./clx_system/clx_sdk/include/clx_types.h: 112

CLX_MAC_T = UI8_T * int(6)# ./clx_system/clx_sdk/include/clx_types.h: 114

CLX_IPV4_T = UI32_T# ./clx_system/clx_sdk/include/clx_types.h: 115

CLX_IPV6_T = UI8_T * int(16)# ./clx_system/clx_sdk/include/clx_types.h: 116

CLX_TIME_T = UI32_T# ./clx_system/clx_sdk/include/clx_types.h: 118

CLX_BRIDGE_DOMAIN_T = UI32_T# ./clx_system/clx_sdk/include/clx_types.h: 121

CLX_TRILL_NICKNAME_T = UI16_T# ./clx_system/clx_sdk/include/clx_types.h: 124

# ./clx_system/clx_sdk/include/clx_types.h: 132
class union_CLX_IP_U(Union):
    pass

union_CLX_IP_U.__slots__ = [
    'ipv4_addr',
    'ipv6_addr',
]
union_CLX_IP_U._fields_ = [
    ('ipv4_addr', CLX_IPV4_T),
    ('ipv6_addr', CLX_IPV6_T),
]

CLX_IP_T = union_CLX_IP_U# ./clx_system/clx_sdk/include/clx_types.h: 132

# ./clx_system/clx_sdk/include/clx_types.h: 138
class struct_CLX_IP_ADDR_S(Structure):
    pass

struct_CLX_IP_ADDR_S.__slots__ = [
    'ip_addr',
    'ipv4',
]
struct_CLX_IP_ADDR_S._fields_ = [
    ('ip_addr', CLX_IP_T),
    ('ipv4', BOOL_T),
]

CLX_IP_ADDR_T = struct_CLX_IP_ADDR_S# ./clx_system/clx_sdk/include/clx_types.h: 138

enum_anon_3 = c_int# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_IPV4INIPV4 = 0# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_IPV4INIPV6 = (CLX_TUNNEL_TYPE_IPV4INIPV4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_IPV6INIPV4 = (CLX_TUNNEL_TYPE_IPV4INIPV6 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_IPV6INIPV6 = (CLX_TUNNEL_TYPE_IPV6INIPV4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_GREIPV4INIPV4 = (CLX_TUNNEL_TYPE_IPV6INIPV6 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_GREIPV6INIPV4 = (CLX_TUNNEL_TYPE_GREIPV4INIPV4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_GREIPV4INIPV6 = (CLX_TUNNEL_TYPE_GREIPV6INIPV4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_GREIPV6INIPV6 = (CLX_TUNNEL_TYPE_GREIPV4INIPV6 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_GRE_NSH = (CLX_TUNNEL_TYPE_GREIPV6INIPV6 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_6TO4 = (CLX_TUNNEL_TYPE_GRE_NSH + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_ISATAP = (CLX_TUNNEL_TYPE_6TO4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_NVGRE_L2 = (CLX_TUNNEL_TYPE_ISATAP + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_NVGRE_V4 = (CLX_TUNNEL_TYPE_NVGRE_L2 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_NVGRE_V6 = (CLX_TUNNEL_TYPE_NVGRE_V4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_NVGRE_NSH = (CLX_TUNNEL_TYPE_NVGRE_V6 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_VXLAN = (CLX_TUNNEL_TYPE_NVGRE_NSH + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_GTP_V4 = (CLX_TUNNEL_TYPE_VXLAN + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_GTP_V6 = (CLX_TUNNEL_TYPE_GTP_V4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_MPLSINGRE = (CLX_TUNNEL_TYPE_GTP_V6 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_VXLANGPE_L2 = (CLX_TUNNEL_TYPE_MPLSINGRE + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_VXLANGPE_V4 = (CLX_TUNNEL_TYPE_VXLANGPE_L2 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_VXLANGPE_V6 = (CLX_TUNNEL_TYPE_VXLANGPE_V4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_VXLANGPE_NSH = (CLX_TUNNEL_TYPE_VXLANGPE_V6 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX0_L2 = (CLX_TUNNEL_TYPE_VXLANGPE_NSH + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX0_V4 = (CLX_TUNNEL_TYPE_FLEX0_L2 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX0_V6 = (CLX_TUNNEL_TYPE_FLEX0_V4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX0_NSH = (CLX_TUNNEL_TYPE_FLEX0_V6 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX1_L2 = (CLX_TUNNEL_TYPE_FLEX0_NSH + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX1_V4 = (CLX_TUNNEL_TYPE_FLEX1_L2 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX1_V6 = (CLX_TUNNEL_TYPE_FLEX1_V4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX1_NSH = (CLX_TUNNEL_TYPE_FLEX1_V6 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX2_L2 = (CLX_TUNNEL_TYPE_FLEX1_NSH + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX2_V4 = (CLX_TUNNEL_TYPE_FLEX2_L2 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX2_V6 = (CLX_TUNNEL_TYPE_FLEX2_V4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX2_NSH = (CLX_TUNNEL_TYPE_FLEX2_V6 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX3_L2 = (CLX_TUNNEL_TYPE_FLEX2_NSH + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX3_V4 = (CLX_TUNNEL_TYPE_FLEX3_L2 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX3_V6 = (CLX_TUNNEL_TYPE_FLEX3_V4 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_FLEX3_NSH = (CLX_TUNNEL_TYPE_FLEX3_V6 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_LAST = (CLX_TUNNEL_TYPE_FLEX3_NSH + 1)# ./clx_system/clx_sdk/include/clx_types.h: 183

CLX_TUNNEL_TYPE_T = enum_anon_3# ./clx_system/clx_sdk/include/clx_types.h: 183

# ./clx_system/clx_sdk/include/clx_types.h: 195
class struct_CLX_TUNNEL_KEY_S(Structure):
    pass

struct_CLX_TUNNEL_KEY_S.__slots__ = [
    'src_ip',
    'dst_ip',
    'tunnel_type',
]
struct_CLX_TUNNEL_KEY_S._fields_ = [
    ('src_ip', CLX_IP_ADDR_T),
    ('dst_ip', CLX_IP_ADDR_T),
    ('tunnel_type', CLX_TUNNEL_TYPE_T),
]

CLX_TUNNEL_KEY_T = struct_CLX_TUNNEL_KEY_S# ./clx_system/clx_sdk/include/clx_types.h: 195

CLX_VLAN_T = UI16_T# ./clx_system/clx_sdk/include/clx_types.h: 197

CLX_PORT_T = UI32_T# ./clx_system/clx_sdk/include/clx_types.h: 198

enum_anon_4 = c_int# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_NORMAL = 0# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_UNIT_PORT = (CLX_PORT_TYPE_NORMAL + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_LAG = (CLX_PORT_TYPE_UNIT_PORT + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_VM_ETAG = (CLX_PORT_TYPE_LAG + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_VM_VNTAG = (CLX_PORT_TYPE_VM_ETAG + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_VM_VEPA = (CLX_PORT_TYPE_VM_VNTAG + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_FCOE = (CLX_PORT_TYPE_VM_VEPA + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_IP_TUNNEL = (CLX_PORT_TYPE_FCOE + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_TRILL = (CLX_PORT_TYPE_IP_TUNNEL + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_MPLS = (CLX_PORT_TYPE_TRILL + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_MPLS_PW = (CLX_PORT_TYPE_MPLS + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_CPU_PORT = (CLX_PORT_TYPE_MPLS_PW + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_SFC = (CLX_PORT_TYPE_CPU_PORT + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_LAST = (CLX_PORT_TYPE_SFC + 1)# ./clx_system/clx_sdk/include/clx_types.h: 215

CLX_PORT_TYPE_T = enum_anon_4# ./clx_system/clx_sdk/include/clx_types.h: 215

enum_anon_5 = c_int# ./clx_system/clx_sdk/include/clx_types.h: 224

CLX_COLOR_GREEN = 0# ./clx_system/clx_sdk/include/clx_types.h: 224

CLX_COLOR_YELLOW = (CLX_COLOR_GREEN + 1)# ./clx_system/clx_sdk/include/clx_types.h: 224

CLX_COLOR_RED = (CLX_COLOR_YELLOW + 1)# ./clx_system/clx_sdk/include/clx_types.h: 224

CLX_COLOR_LAST = (CLX_COLOR_RED + 1)# ./clx_system/clx_sdk/include/clx_types.h: 224

CLX_COLOR_T = enum_anon_5# ./clx_system/clx_sdk/include/clx_types.h: 224

enum_anon_6 = c_int# ./clx_system/clx_sdk/include/clx_types.h: 235

CLX_FWD_ACTION_FLOOD = 0# ./clx_system/clx_sdk/include/clx_types.h: 235

CLX_FWD_ACTION_NORMAL = (CLX_FWD_ACTION_FLOOD + 1)# ./clx_system/clx_sdk/include/clx_types.h: 235

CLX_FWD_ACTION_DROP = (CLX_FWD_ACTION_NORMAL + 1)# ./clx_system/clx_sdk/include/clx_types.h: 235

CLX_FWD_ACTION_COPY_TO_CPU = (CLX_FWD_ACTION_DROP + 1)# ./clx_system/clx_sdk/include/clx_types.h: 235

CLX_FWD_ACTION_REDIRECT_TO_CPU = (CLX_FWD_ACTION_COPY_TO_CPU + 1)# ./clx_system/clx_sdk/include/clx_types.h: 235

CLX_FWD_ACTION_FLOOD_COPY_TO_CPU = (CLX_FWD_ACTION_REDIRECT_TO_CPU + 1)# ./clx_system/clx_sdk/include/clx_types.h: 235

CLX_FWD_ACTION_DROP_COPY_TO_CPU = (CLX_FWD_ACTION_FLOOD_COPY_TO_CPU + 1)# ./clx_system/clx_sdk/include/clx_types.h: 235

CLX_FWD_ACTION_LAST = (CLX_FWD_ACTION_DROP_COPY_TO_CPU + 1)# ./clx_system/clx_sdk/include/clx_types.h: 235

CLX_FWD_ACTION_T = enum_anon_6# ./clx_system/clx_sdk/include/clx_types.h: 235

CLX_THREAD_ID_T = CLX_HUGE_T# ./clx_system/clx_sdk/include/clx_types.h: 237

CLX_SEMAPHORE_ID_T = CLX_HUGE_T# ./clx_system/clx_sdk/include/clx_types.h: 238

CLX_ISRLOCK_ID_T = CLX_HUGE_T# ./clx_system/clx_sdk/include/clx_types.h: 239

CLX_IRQ_FLAGS_T = CLX_HUGE_T# ./clx_system/clx_sdk/include/clx_types.h: 240

enum_anon_7 = c_int# ./clx_system/clx_sdk/include/clx_types.h: 248

CLX_DIR_INGRESS = 0# ./clx_system/clx_sdk/include/clx_types.h: 248

CLX_DIR_EGRESS = (CLX_DIR_INGRESS + 1)# ./clx_system/clx_sdk/include/clx_types.h: 248

CLX_DIR_BOTH = (CLX_DIR_EGRESS + 1)# ./clx_system/clx_sdk/include/clx_types.h: 248

CLX_DIR_LAST = (CLX_DIR_BOTH + 1)# ./clx_system/clx_sdk/include/clx_types.h: 248

CLX_DIR_T = enum_anon_7# ./clx_system/clx_sdk/include/clx_types.h: 248

enum_anon_8 = c_int# ./clx_system/clx_sdk/include/clx_types.h: 256

CLX_VLAN_ACTION_SET = 0# ./clx_system/clx_sdk/include/clx_types.h: 256

CLX_VLAN_ACTION_KEEP = (CLX_VLAN_ACTION_SET + 1)# ./clx_system/clx_sdk/include/clx_types.h: 256

CLX_VLAN_ACTION_REMOVE = (CLX_VLAN_ACTION_KEEP + 1)# ./clx_system/clx_sdk/include/clx_types.h: 256

CLX_VLAN_ACTION_LAST = (CLX_VLAN_ACTION_REMOVE + 1)# ./clx_system/clx_sdk/include/clx_types.h: 256

CLX_VLAN_ACTION_T = enum_anon_8# ./clx_system/clx_sdk/include/clx_types.h: 256

enum_anon_9 = c_int# ./clx_system/clx_sdk/include/clx_types.h: 274

CLX_VLAN_PRECEDENCE_SUBNET_MAC_PROTOCOL_PORT = 1# ./clx_system/clx_sdk/include/clx_types.h: 274

CLX_VLAN_PRECEDENCE_MAC_SUBNET_PROTOCOL_PORT = 4# ./clx_system/clx_sdk/include/clx_types.h: 274

CLX_VLAN_PRECEDENCE_PORT_ONLY = 7# ./clx_system/clx_sdk/include/clx_types.h: 274

CLX_VLAN_PRECEDENCE_FAVOR_TYPE = 8# ./clx_system/clx_sdk/include/clx_types.h: 274

CLX_VLAN_PRECEDENCE_FAVOR_ADDR = 9# ./clx_system/clx_sdk/include/clx_types.h: 274

CLX_VLAN_PRECEDENCE_LAST = (CLX_VLAN_PRECEDENCE_FAVOR_ADDR + 1)# ./clx_system/clx_sdk/include/clx_types.h: 274

CLX_VLAN_PRECEDENCE_T = enum_anon_9# ./clx_system/clx_sdk/include/clx_types.h: 274

enum_anon_10 = c_int# ./clx_system/clx_sdk/include/clx_types.h: 285

CLX_VLAN_TAG_NONE = 0# ./clx_system/clx_sdk/include/clx_types.h: 285

CLX_VLAN_TAG_SINGLE_PRI = (CLX_VLAN_TAG_NONE + 1)# ./clx_system/clx_sdk/include/clx_types.h: 285

CLX_VLAN_TAG_SINGLE = (CLX_VLAN_TAG_SINGLE_PRI + 1)# ./clx_system/clx_sdk/include/clx_types.h: 285

CLX_VLAN_TAG_DOUBLE_PRI = (CLX_VLAN_TAG_SINGLE + 1)# ./clx_system/clx_sdk/include/clx_types.h: 285

CLX_VLAN_TAG_DOUBLE = (CLX_VLAN_TAG_DOUBLE_PRI + 1)# ./clx_system/clx_sdk/include/clx_types.h: 285

CLX_VLAN_TAG_LAST = (CLX_VLAN_TAG_DOUBLE + 1)# ./clx_system/clx_sdk/include/clx_types.h: 285

CLX_VLAN_TAG_T = enum_anon_10# ./clx_system/clx_sdk/include/clx_types.h: 285

# ./clx_system/clx_sdk/include/clx_types.h: 298
class struct_CLX_BUM_INFO_S(Structure):
    pass

struct_CLX_BUM_INFO_S.__slots__ = [
    'mcast_id',
    'group_label',
    'vid',
    'flags',
]
struct_CLX_BUM_INFO_S._fields_ = [
    ('mcast_id', UI32_T),
    ('group_label', UI32_T),
    ('vid', UI32_T),
    ('flags', UI32_T),
]

CLX_BUM_INFO_T = struct_CLX_BUM_INFO_S# ./clx_system/clx_sdk/include/clx_types.h: 298

enum_anon_11 = c_int# ./clx_system/clx_sdk/include/clx_types.h: 305

CLX_PHY_TYPE_INTERNAL = 0# ./clx_system/clx_sdk/include/clx_types.h: 305

CLX_PHY_TYPE_EXTERNAL = (CLX_PHY_TYPE_INTERNAL + 1)# ./clx_system/clx_sdk/include/clx_types.h: 305

CLX_PHY_TYPE_LAST = (CLX_PHY_TYPE_EXTERNAL + 1)# ./clx_system/clx_sdk/include/clx_types.h: 305

CLX_PHY_TYPE_T = enum_anon_11# ./clx_system/clx_sdk/include/clx_types.h: 305

enum_anon_12 = c_int# ./clx_system/clx_sdk/include/clx_types.h: 319

CLX_PHY_DEVICE_ADDR_PMA_PMD = 1# ./clx_system/clx_sdk/include/clx_types.h: 319

CLX_PHY_DEVICE_ADDR_WIS = 2# ./clx_system/clx_sdk/include/clx_types.h: 319

CLX_PHY_DEVICE_ADDR_PCS = 3# ./clx_system/clx_sdk/include/clx_types.h: 319

CLX_PHY_DEVICE_ADDR_PHY_XS = 4# ./clx_system/clx_sdk/include/clx_types.h: 319

CLX_PHY_DEVICE_ADDR_DTE_XS = 5# ./clx_system/clx_sdk/include/clx_types.h: 319

CLX_PHY_DEVICE_ADDR_TC = 6# ./clx_system/clx_sdk/include/clx_types.h: 319

CLX_PHY_DEVICE_ADDR_AN = 7# ./clx_system/clx_sdk/include/clx_types.h: 319

CLX_PHY_DEVICE_ADDR_VENDOR_1 = 30# ./clx_system/clx_sdk/include/clx_types.h: 319

CLX_PHY_DEVICE_ADDR_VENDOR_2 = 31# ./clx_system/clx_sdk/include/clx_types.h: 319

CLX_PHY_DEVICE_ADDR_LAST = (CLX_PHY_DEVICE_ADDR_VENDOR_2 + 1)# ./clx_system/clx_sdk/include/clx_types.h: 319

CLX_PHY_DEVICE_ADDR_T = enum_anon_12# ./clx_system/clx_sdk/include/clx_types.h: 319

enum_anon_13 = c_int# ./clx_system/clx_sdk/include/clx_types.h: 326

CLX_BULK_OP_MODE_ERR_STOP = 0# ./clx_system/clx_sdk/include/clx_types.h: 326

CLX_BULK_OP_MODE_ERR_CONTINUE = (CLX_BULK_OP_MODE_ERR_STOP + 1)# ./clx_system/clx_sdk/include/clx_types.h: 326

CLX_BULK_OP_MODE_LAST = (CLX_BULK_OP_MODE_ERR_CONTINUE + 1)# ./clx_system/clx_sdk/include/clx_types.h: 326

CLX_BULK_OP_MODE_T = enum_anon_13# ./clx_system/clx_sdk/include/clx_types.h: 326

# ./clx_system/clx_sdk/include/clx_types.h: 336
class struct_CLX_RANGE_INFO_S(Structure):
    pass

struct_CLX_RANGE_INFO_S.__slots__ = [
    'min_id',
    'max_id',
    'max_member_cnt',
    'flags',
]
struct_CLX_RANGE_INFO_S._fields_ = [
    ('min_id', UI32_T),
    ('max_id', UI32_T),
    ('max_member_cnt', UI32_T),
    ('flags', UI32_T),
]

CLX_RANGE_INFO_T = struct_CLX_RANGE_INFO_S# ./clx_system/clx_sdk/include/clx_types.h: 336

# ./clx_system/clx_sdk/include/clx_types.h: 342
class struct_CLX_FDL_INFO_S(Structure):
    pass

struct_CLX_FDL_INFO_S.__slots__ = [
    'probability',
    'threshold',
]
struct_CLX_FDL_INFO_S._fields_ = [
    ('probability', UI32_T),
    ('threshold', UI32_T),
]

CLX_FDL_INFO_T = struct_CLX_FDL_INFO_S# ./clx_system/clx_sdk/include/clx_types.h: 342

enum_anon_14 = c_int# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_OK = 0# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_BAD_PARAMETER = (CLX_E_OK + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_NO_MEMORY = (CLX_E_BAD_PARAMETER + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_TABLE_FULL = (CLX_E_NO_MEMORY + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_ENTRY_NOT_FOUND = (CLX_E_TABLE_FULL + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_ENTRY_EXISTS = (CLX_E_ENTRY_NOT_FOUND + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_NOT_SUPPORT = (CLX_E_ENTRY_EXISTS + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_ALREADY_INITED = (CLX_E_NOT_SUPPORT + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_NOT_INITED = (CLX_E_ALREADY_INITED + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_OTHERS = (CLX_E_NOT_INITED + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_ENTRY_IN_USE = (CLX_E_OTHERS + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_TIMEOUT = (CLX_E_ENTRY_IN_USE + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_OP_INVALID = (CLX_E_TIMEOUT + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_OP_STOPPED = (CLX_E_OP_INVALID + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_OP_INCOMPLETE = (CLX_E_OP_STOPPED + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_E_LAST = (CLX_E_OP_INCOMPLETE + 1)# ./clx_system/clx_sdk/include/clx_error.h: 77

CLX_ERROR_NO_T = enum_anon_14# ./clx_system/clx_sdk/include/clx_error.h: 77

# ./clx_system/clx_sdk/include/clx_error.h: 96
if _libs["libsai.so"].has("clx_error_getString", "cdecl"):
    clx_error_getString = _libs["libsai.so"].get("clx_error_getString", "cdecl")
    clx_error_getString.argtypes = [CLX_ERROR_NO_T]
    clx_error_getString.restype = POINTER(C8_T)

enum_anon_15 = c_int# ./clx_system/clx_sdk/include/clx_qos.h: 72

CLX_TRUST_MODE_NONE = 0# ./clx_system/clx_sdk/include/clx_qos.h: 72

CLX_TRUST_MODE_1P = (CLX_TRUST_MODE_NONE + 1)# ./clx_system/clx_sdk/include/clx_qos.h: 72

CLX_TRUST_MODE_DSCP = (CLX_TRUST_MODE_1P + 1)# ./clx_system/clx_sdk/include/clx_qos.h: 72

CLX_TRUST_MODE_1P_DSCP = (CLX_TRUST_MODE_DSCP + 1)# ./clx_system/clx_sdk/include/clx_qos.h: 72

CLX_TRUST_MODE_LAST = (CLX_TRUST_MODE_1P_DSCP + 1)# ./clx_system/clx_sdk/include/clx_qos.h: 72

CLX_TRUST_MODE_T = enum_anon_15# ./clx_system/clx_sdk/include/clx_qos.h: 72

enum_anon_16 = c_int# ./clx_system/clx_sdk/include/clx_qos.h: 84

CLX_QOS_MAPPING_PCP_DEI_TO_PHB = 0# ./clx_system/clx_sdk/include/clx_qos.h: 84

CLX_QOS_MAPPING_DSCP_TO_PHB = (CLX_QOS_MAPPING_PCP_DEI_TO_PHB + 1)# ./clx_system/clx_sdk/include/clx_qos.h: 84

CLX_QOS_MAPPING_EXP_TO_PHB = (CLX_QOS_MAPPING_DSCP_TO_PHB + 1)# ./clx_system/clx_sdk/include/clx_qos.h: 84

CLX_QOS_MAPPING_PHB_TO_PCP_DEI = (CLX_QOS_MAPPING_EXP_TO_PHB + 1)# ./clx_system/clx_sdk/include/clx_qos.h: 84

CLX_QOS_MAPPING_PHB_TO_DSCP = (CLX_QOS_MAPPING_PHB_TO_PCP_DEI + 1)# ./clx_system/clx_sdk/include/clx_qos.h: 84

CLX_QOS_MAPPING_PHB_TO_EXP = (CLX_QOS_MAPPING_PHB_TO_DSCP + 1)# ./clx_system/clx_sdk/include/clx_qos.h: 84

CLX_QOS_MAPPING_LAST = (CLX_QOS_MAPPING_PHB_TO_EXP + 1)# ./clx_system/clx_sdk/include/clx_qos.h: 84

CLX_QOS_MAPPING_TYPE_T = enum_anon_16# ./clx_system/clx_sdk/include/clx_qos.h: 84

# ./clx_system/clx_sdk/include/clx_qos.h: 100
class struct_CLX_QOS_MAPPING_ENTRY_S(Structure):
    pass

struct_CLX_QOS_MAPPING_ENTRY_S.__slots__ = [
    'tc',
    'color',
    'pcp',
    'dei',
    'dscp',
    'exp',
    'exp_l_lsp',
    'flags',
]
struct_CLX_QOS_MAPPING_ENTRY_S._fields_ = [
    ('tc', UI8_T),
    ('color', CLX_COLOR_T),
    ('pcp', UI8_T),
    ('dei', UI8_T),
    ('dscp', UI8_T),
    ('exp', UI8_T),
    ('exp_l_lsp', UI8_T),
    ('flags', UI32_T),
]

CLX_QOS_MAPPING_ENTRY_T = struct_CLX_QOS_MAPPING_ENTRY_S# ./clx_system/clx_sdk/include/clx_qos.h: 100

# ./clx_system/clx_sdk/include/clx_qos.h: 135
if _libs["libsai.so"].has("clx_qos_createProfile", "cdecl"):
    clx_qos_createProfile = _libs["libsai.so"].get("clx_qos_createProfile", "cdecl")
    clx_qos_createProfile.argtypes = [UI32_T, CLX_QOS_MAPPING_TYPE_T, UI32_T]
    clx_qos_createProfile.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_qos.h: 169
if _libs["libsai.so"].has("clx_qos_delProfile", "cdecl"):
    clx_qos_delProfile = _libs["libsai.so"].get("clx_qos_delProfile", "cdecl")
    clx_qos_delProfile.argtypes = [UI32_T, CLX_QOS_MAPPING_TYPE_T, UI32_T]
    clx_qos_delProfile.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_qos.h: 211
if _libs["libsai.so"].has("clx_qos_setProfileEntry", "cdecl"):
    clx_qos_setProfileEntry = _libs["libsai.so"].get("clx_qos_setProfileEntry", "cdecl")
    clx_qos_setProfileEntry.argtypes = [UI32_T, CLX_QOS_MAPPING_TYPE_T, UI32_T, POINTER(CLX_QOS_MAPPING_ENTRY_T)]
    clx_qos_setProfileEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_qos.h: 254
if _libs["libsai.so"].has("clx_qos_getProfileEntry", "cdecl"):
    clx_qos_getProfileEntry = _libs["libsai.so"].get("clx_qos_getProfileEntry", "cdecl")
    clx_qos_getProfileEntry.argtypes = [UI32_T, CLX_QOS_MAPPING_TYPE_T, UI32_T, POINTER(CLX_QOS_MAPPING_ENTRY_T)]
    clx_qos_getProfileEntry.restype = CLX_ERROR_NO_T

enum_anon_17 = c_int# ./clx_system/clx_sdk/include/clx_meter.h: 70

CLX_METER_GROUP_MODE_SERVICE = 0# ./clx_system/clx_sdk/include/clx_meter.h: 70

CLX_METER_GROUP_MODE_FLOW = (CLX_METER_GROUP_MODE_SERVICE + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 70

CLX_METER_GROUP_MODE_SDN = (CLX_METER_GROUP_MODE_FLOW + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 70

CLX_METER_GROUP_MODE_LAST = (CLX_METER_GROUP_MODE_SDN + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 70

CLX_METER_GROUP_MODE_T = enum_anon_17# ./clx_system/clx_sdk/include/clx_meter.h: 70

enum_anon_18 = c_int# ./clx_system/clx_sdk/include/clx_meter.h: 80

CLX_METER_ALGO_SRTCM = 0# ./clx_system/clx_sdk/include/clx_meter.h: 80

CLX_METER_ALGO_TRTCM = (CLX_METER_ALGO_SRTCM + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 80

CLX_METER_ALGO_CLRTCM = (CLX_METER_ALGO_TRTCM + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 80

CLX_METER_ALGO_1R2CM = (CLX_METER_ALGO_CLRTCM + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 80

CLX_METER_ALGO_LAST = (CLX_METER_ALGO_1R2CM + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 80

CLX_METER_ALGO_T = enum_anon_18# ./clx_system/clx_sdk/include/clx_meter.h: 80

# ./clx_system/clx_sdk/include/clx_meter.h: 89
class struct_CLX_METER_PARAMETER_S(Structure):
    pass

struct_CLX_METER_PARAMETER_S.__slots__ = [
    'cir',
    'cbs',
    'pir_eir',
    'pbs_ebs',
]
struct_CLX_METER_PARAMETER_S._fields_ = [
    ('cir', UI32_T),
    ('cbs', UI32_T),
    ('pir_eir', UI32_T),
    ('pbs_ebs', UI32_T),
]

CLX_METER_PARAMETER_T = struct_CLX_METER_PARAMETER_S# ./clx_system/clx_sdk/include/clx_meter.h: 89

# ./clx_system/clx_sdk/include/clx_meter.h: 103
class struct_CLX_METER_CFG_S(Structure):
    pass

struct_CLX_METER_CFG_S.__slots__ = [
    'param',
    'algo_mode',
    'flags',
]
struct_CLX_METER_CFG_S._fields_ = [
    ('param', CLX_METER_PARAMETER_T),
    ('algo_mode', CLX_METER_ALGO_T),
    ('flags', UI32_T),
]

CLX_METER_CFG_T = struct_CLX_METER_CFG_S# ./clx_system/clx_sdk/include/clx_meter.h: 103

enum_anon_19 = c_int# ./clx_system/clx_sdk/include/clx_meter.h: 114

CLX_METER_COLOR_RESOLVE_TYPE_INF_PRECEDENCE = 0# ./clx_system/clx_sdk/include/clx_meter.h: 114

CLX_METER_COLOR_RESOLVE_TYPE_DOMAIN_PRECEDENCE = (CLX_METER_COLOR_RESOLVE_TYPE_INF_PRECEDENCE + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 114

CLX_METER_COLOR_RESOLVE_TYPE_WORST_COLOR = (CLX_METER_COLOR_RESOLVE_TYPE_DOMAIN_PRECEDENCE + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 114

CLX_METER_COLOR_RESOLVE_TYPE_BEST_COLOR = (CLX_METER_COLOR_RESOLVE_TYPE_WORST_COLOR + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 114

CLX_METER_COLOR_RESOLVE_TYPE_CIR_FAVOR = (CLX_METER_COLOR_RESOLVE_TYPE_BEST_COLOR + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 114

CLX_METER_COLOR_RESOLVE_TYPE_LAST = (CLX_METER_COLOR_RESOLVE_TYPE_CIR_FAVOR + 1)# ./clx_system/clx_sdk/include/clx_meter.h: 114

CLX_METER_COLOR_RESOLVE_TYPE_T = enum_anon_19# ./clx_system/clx_sdk/include/clx_meter.h: 114

# ./clx_system/clx_sdk/include/clx_meter.h: 127
class struct_CLX_METER_PORT_CFG_S(Structure):
    pass

struct_CLX_METER_PORT_CFG_S.__slots__ = [
    'rate',
    'burst_size',
    'flags',
]
struct_CLX_METER_PORT_CFG_S._fields_ = [
    ('rate', UI32_T),
    ('burst_size', UI32_T),
    ('flags', UI32_T),
]

CLX_METER_PORT_CFG_T = struct_CLX_METER_PORT_CFG_S# ./clx_system/clx_sdk/include/clx_meter.h: 127

# ./clx_system/clx_sdk/include/clx_meter.h: 159
if _libs["libsai.so"].has("clx_meter_createMeter", "cdecl"):
    clx_meter_createMeter = _libs["libsai.so"].get("clx_meter_createMeter", "cdecl")
    clx_meter_createMeter.argtypes = [UI32_T, POINTER(CLX_METER_CFG_T), POINTER(UI32_T)]
    clx_meter_createMeter.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_meter.h: 181
if _libs["libsai.so"].has("clx_meter_destroyMeter", "cdecl"):
    clx_meter_destroyMeter = _libs["libsai.so"].get("clx_meter_destroyMeter", "cdecl")
    clx_meter_destroyMeter.argtypes = [UI32_T, UI32_T]
    clx_meter_destroyMeter.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_meter.h: 202
if _libs["libsai.so"].has("clx_meter_getMeter", "cdecl"):
    clx_meter_getMeter = _libs["libsai.so"].get("clx_meter_getMeter", "cdecl")
    clx_meter_getMeter.argtypes = [UI32_T, UI32_T, POINTER(CLX_METER_CFG_T)]
    clx_meter_getMeter.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_meter.h: 225
if _libs["libsai.so"].has("clx_meter_setMeterParam", "cdecl"):
    clx_meter_setMeterParam = _libs["libsai.so"].get("clx_meter_setMeterParam", "cdecl")
    clx_meter_setMeterParam.argtypes = [UI32_T, UI32_T, POINTER(CLX_METER_PARAMETER_T)]
    clx_meter_setMeterParam.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_meter.h: 248
if _libs["libsai.so"].has("clx_meter_setIgrPortMeter", "cdecl"):
    clx_meter_setIgrPortMeter = _libs["libsai.so"].get("clx_meter_setIgrPortMeter", "cdecl")
    clx_meter_setIgrPortMeter.argtypes = [UI32_T, UI32_T, POINTER(CLX_METER_PORT_CFG_T)]
    clx_meter_setIgrPortMeter.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_meter.h: 270
if _libs["libsai.so"].has("clx_meter_getIgrPortMeter", "cdecl"):
    clx_meter_getIgrPortMeter = _libs["libsai.so"].get("clx_meter_getIgrPortMeter", "cdecl")
    clx_meter_getIgrPortMeter.argtypes = [UI32_T, UI32_T, POINTER(CLX_METER_PORT_CFG_T)]
    clx_meter_getIgrPortMeter.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_meter.h: 296
if _libs["libsai.so"].has("clx_meter_setFlowGroupMode", "cdecl"):
    clx_meter_setFlowGroupMode = _libs["libsai.so"].get("clx_meter_setFlowGroupMode", "cdecl")
    clx_meter_setFlowGroupMode.argtypes = [UI32_T, CLX_DIR_T, UI32_T, CLX_METER_GROUP_MODE_T]
    clx_meter_setFlowGroupMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_meter.h: 320
if _libs["libsai.so"].has("clx_meter_getFlowGroupMode", "cdecl"):
    clx_meter_getFlowGroupMode = _libs["libsai.so"].get("clx_meter_getFlowGroupMode", "cdecl")
    clx_meter_getFlowGroupMode.argtypes = [UI32_T, CLX_DIR_T, UI32_T, POINTER(CLX_METER_GROUP_MODE_T)]
    clx_meter_getFlowGroupMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_meter.h: 344
if _libs["libsai.so"].has("clx_meter_getFlowGroupCapacity", "cdecl"):
    clx_meter_getFlowGroupCapacity = _libs["libsai.so"].get("clx_meter_getFlowGroupCapacity", "cdecl")
    clx_meter_getFlowGroupCapacity.argtypes = [UI32_T, CLX_DIR_T, UI32_T, POINTER(UI32_T)]
    clx_meter_getFlowGroupCapacity.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_meter.h: 371
if _libs["libsai.so"].has("clx_meter_getMeterIdByFlowGroup", "cdecl"):
    clx_meter_getMeterIdByFlowGroup = _libs["libsai.so"].get("clx_meter_getMeterIdByFlowGroup", "cdecl")
    clx_meter_getMeterIdByFlowGroup.argtypes = [UI32_T, CLX_DIR_T, UI32_T, UI32_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_meter_getMeterIdByFlowGroup.restype = CLX_ERROR_NO_T

enum_anon_20 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 146

CLX_PORT_VLAN_TAG_MODE_1Q = 0# ./clx_system/clx_sdk/include/clx_port.h: 146

CLX_PORT_VLAN_TAG_MODE_1AD = (CLX_PORT_VLAN_TAG_MODE_1Q + 1)# ./clx_system/clx_sdk/include/clx_port.h: 146

CLX_PORT_VLAN_TAG_MODE_EXTVLAN = (CLX_PORT_VLAN_TAG_MODE_1AD + 1)# ./clx_system/clx_sdk/include/clx_port.h: 146

CLX_PORT_VLAN_TAG_MODE_LAST = (CLX_PORT_VLAN_TAG_MODE_EXTVLAN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 146

CLX_PORT_VLAN_TAG_MODE_T = enum_anon_20# ./clx_system/clx_sdk/include/clx_port.h: 146

enum_anon_21 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 156

CLX_PORT_ACCEPTABLE_TYPE_ALL = 0# ./clx_system/clx_sdk/include/clx_port.h: 156

CLX_PORT_ACCEPTABLE_TYPE_NONE = (CLX_PORT_ACCEPTABLE_TYPE_ALL + 1)# ./clx_system/clx_sdk/include/clx_port.h: 156

CLX_PORT_ACCEPTABLE_TYPE_TAGGED = (CLX_PORT_ACCEPTABLE_TYPE_NONE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 156

CLX_PORT_ACCEPTABLE_TYPE_UNTAGGED = (CLX_PORT_ACCEPTABLE_TYPE_TAGGED + 1)# ./clx_system/clx_sdk/include/clx_port.h: 156

CLX_PORT_ACCEPTABLE_TYPE_LAST = (CLX_PORT_ACCEPTABLE_TYPE_UNTAGGED + 1)# ./clx_system/clx_sdk/include/clx_port.h: 156

CLX_PORT_ACCEPTABLE_TYPE_T = enum_anon_21# ./clx_system/clx_sdk/include/clx_port.h: 156

enum_anon_22 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 170

CLX_PORT_SPEED_1G = 1000# ./clx_system/clx_sdk/include/clx_port.h: 170

CLX_PORT_SPEED_10G = 10000# ./clx_system/clx_sdk/include/clx_port.h: 170

CLX_PORT_SPEED_25G = 25000# ./clx_system/clx_sdk/include/clx_port.h: 170

CLX_PORT_SPEED_40G = 40000# ./clx_system/clx_sdk/include/clx_port.h: 170

CLX_PORT_SPEED_50G = 50000# ./clx_system/clx_sdk/include/clx_port.h: 170

CLX_PORT_SPEED_100G = 100000# ./clx_system/clx_sdk/include/clx_port.h: 170

CLX_PORT_SPEED_200G = 200000# ./clx_system/clx_sdk/include/clx_port.h: 170

CLX_PORT_SPEED_400G = 400000# ./clx_system/clx_sdk/include/clx_port.h: 170

CLX_PORT_SPEED_LAST = (CLX_PORT_SPEED_400G + 1)# ./clx_system/clx_sdk/include/clx_port.h: 170

CLX_PORT_SPEED_T = enum_anon_22# ./clx_system/clx_sdk/include/clx_port.h: 170

enum_anon_23 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 180

CLX_PORT_FC_OFF = 0# ./clx_system/clx_sdk/include/clx_port.h: 180

CLX_PORT_FC_TXONLY = (CLX_PORT_FC_OFF + 1)# ./clx_system/clx_sdk/include/clx_port.h: 180

CLX_PORT_FC_RXONLY = (CLX_PORT_FC_TXONLY + 1)# ./clx_system/clx_sdk/include/clx_port.h: 180

CLX_PORT_FC_ON = (CLX_PORT_FC_RXONLY + 1)# ./clx_system/clx_sdk/include/clx_port.h: 180

CLX_PORT_FC_LAST = (CLX_PORT_FC_ON + 1)# ./clx_system/clx_sdk/include/clx_port.h: 180

CLX_PORT_FC_T = enum_anon_23# ./clx_system/clx_sdk/include/clx_port.h: 180

enum_anon_24 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 189

CLX_PORT_EEE_MODE_DISABLE = 0# ./clx_system/clx_sdk/include/clx_port.h: 189

CLX_PORT_EEE_MODE_FASTWAKEUP = (CLX_PORT_EEE_MODE_DISABLE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 189

CLX_PORT_EEE_MODE_DEEPSLEEP = (CLX_PORT_EEE_MODE_FASTWAKEUP + 1)# ./clx_system/clx_sdk/include/clx_port.h: 189

CLX_PORT_EEE_MODE_LAST = (CLX_PORT_EEE_MODE_DEEPSLEEP + 1)# ./clx_system/clx_sdk/include/clx_port.h: 189

CLX_PORT_EEE_MODE_T = enum_anon_24# ./clx_system/clx_sdk/include/clx_port.h: 189

enum_anon_25 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_1000BASE_X = (1 << 0)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_10GBASE_KR = (1 << 1)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_40GBASE_KR4 = (1 << 2)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_40GBASE_CR4 = (1 << 3)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_100GBASE_CR10 = (1 << 4)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_100GBASE_KR4 = (1 << 5)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_100GBASE_CR4 = (1 << 6)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_25GBASE_KR_CR_S = (1 << 7)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_25GBASE_KR_CR = (1 << 8)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_50GBASE_KR2_CR2 = (1 << 9)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_50GBASE_KR_CR = (1 << 10)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_100GBASE_KR2_CR2 = (1 << 11)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_200GBASE_KR4_CR4 = (1 << 12)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_400GBASE_CONSORTIUM = (1 << 13)# ./clx_system/clx_sdk/include/clx_port.h: 208

CLX_PORT_ABILITY_SPEED_T = enum_anon_25# ./clx_system/clx_sdk/include/clx_port.h: 208

enum_anon_26 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 217

CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE = (1 << 0)# ./clx_system/clx_sdk/include/clx_port.h: 217

CLX_PORT_ABILITY_PAUSE_SYM_PAUSE = (1 << 1)# ./clx_system/clx_sdk/include/clx_port.h: 217

CLX_PORT_ABILITY_PAUSE_T = enum_anon_26# ./clx_system/clx_sdk/include/clx_port.h: 217

enum_anon_27 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 229

CLX_PORT_ABILITY_EEE_10GBASE_KR = (1 << 0)# ./clx_system/clx_sdk/include/clx_port.h: 229

CLX_PORT_ABILITY_EEE_40GBASE_KR4 = (1 << 1)# ./clx_system/clx_sdk/include/clx_port.h: 229

CLX_PORT_ABILITY_EEE_40GBASE_CR4 = (1 << 2)# ./clx_system/clx_sdk/include/clx_port.h: 229

CLX_PORT_ABILITY_EEE_100GBASE_CR10 = (1 << 3)# ./clx_system/clx_sdk/include/clx_port.h: 229

CLX_PORT_ABILITY_EEE_100GBASE_KR4 = (1 << 4)# ./clx_system/clx_sdk/include/clx_port.h: 229

CLX_PORT_ABILITY_EEE_100GBASE_CR4 = (1 << 5)# ./clx_system/clx_sdk/include/clx_port.h: 229

CLX_PORT_ABILITY_EEE_25GBASE_R = (1 << 6)# ./clx_system/clx_sdk/include/clx_port.h: 229

CLX_PORT_ABILITY_EEE_T = enum_anon_27# ./clx_system/clx_sdk/include/clx_port.h: 229

enum_anon_28 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 238

CLX_PORT_ABILITY_FEC_ABILITY = (1 << 0)# ./clx_system/clx_sdk/include/clx_port.h: 238

CLX_PORT_ABILITY_FEC_REQUEST = (1 << 1)# ./clx_system/clx_sdk/include/clx_port.h: 238

CLX_PORT_ABILITY_FEC_RS_REQUEST = (1 << 2)# ./clx_system/clx_sdk/include/clx_port.h: 238

CLX_PORT_ABILITY_FEC_BASE_R_REQUEST = (1 << 3)# ./clx_system/clx_sdk/include/clx_port.h: 238

CLX_PORT_ABILITY_FEC_T = enum_anon_28# ./clx_system/clx_sdk/include/clx_port.h: 238

enum_anon_29 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 252

CLX_PORT_ABILITY_INTERFACE_GMII = (1 << 0)# ./clx_system/clx_sdk/include/clx_port.h: 252

CLX_PORT_ABILITY_INTERFACE_XGMII = (1 << 1)# ./clx_system/clx_sdk/include/clx_port.h: 252

CLX_PORT_ABILITY_INTERFACE_XLGMII = (1 << 2)# ./clx_system/clx_sdk/include/clx_port.h: 252

CLX_PORT_ABILITY_INTERFACE_CGMII = (1 << 3)# ./clx_system/clx_sdk/include/clx_port.h: 252

CLX_PORT_ABILITY_INTERFACE_25GMII = (1 << 4)# ./clx_system/clx_sdk/include/clx_port.h: 252

CLX_PORT_ABILITY_INTERFACE_50GMII = (1 << 5)# ./clx_system/clx_sdk/include/clx_port.h: 252

CLX_PORT_ABILITY_INTERFACE_200GMII = (1 << 6)# ./clx_system/clx_sdk/include/clx_port.h: 252

CLX_PORT_ABILITY_INTERFACE_400GMII = (1 << 7)# ./clx_system/clx_sdk/include/clx_port.h: 252

CLX_PORT_ABILITY_INTERFACE_LAST = (CLX_PORT_ABILITY_INTERFACE_400GMII + 1)# ./clx_system/clx_sdk/include/clx_port.h: 252

CLX_PORT_ABILITY_INTERFACE_T = enum_anon_29# ./clx_system/clx_sdk/include/clx_port.h: 252

enum_anon_30 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 260

CLX_PORT_ABILITY_MEDIUM_FIBER = (1 << 0)# ./clx_system/clx_sdk/include/clx_port.h: 260

CLX_PORT_ABILITY_MEDIUM_COPPER = (1 << 1)# ./clx_system/clx_sdk/include/clx_port.h: 260

CLX_PORT_ABILITY_MEDIUM_LAST = (CLX_PORT_ABILITY_MEDIUM_COPPER + 1)# ./clx_system/clx_sdk/include/clx_port.h: 260

CLX_PORT_ABILITY_MEDIUM_T = enum_anon_30# ./clx_system/clx_sdk/include/clx_port.h: 260

enum_anon_31 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 270

CLX_PORT_LOOPBACK_DISABLE = 0# ./clx_system/clx_sdk/include/clx_port.h: 270

CLX_PORT_LOOPBACK_MAC = (CLX_PORT_LOOPBACK_DISABLE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 270

CLX_PORT_LOOPBACK_PHY = (CLX_PORT_LOOPBACK_MAC + 1)# ./clx_system/clx_sdk/include/clx_port.h: 270

CLX_PORT_LOOPBACK_EXTERNAL_PHY = (CLX_PORT_LOOPBACK_PHY + 1)# ./clx_system/clx_sdk/include/clx_port.h: 270

CLX_PORT_LOOPBACK_LAST = (CLX_PORT_LOOPBACK_EXTERNAL_PHY + 1)# ./clx_system/clx_sdk/include/clx_port.h: 270

CLX_PORT_LOOPBACK_T = enum_anon_31# ./clx_system/clx_sdk/include/clx_port.h: 270

enum_anon_32 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 279

CLX_PORT_PHY_LOCATION_INT = 0# ./clx_system/clx_sdk/include/clx_port.h: 279

CLX_PORT_PHY_LOCATION_EXT_SS = (CLX_PORT_PHY_LOCATION_INT + 1)# ./clx_system/clx_sdk/include/clx_port.h: 279

CLX_PORT_PHY_LOCATION_EXT_LS = (CLX_PORT_PHY_LOCATION_EXT_SS + 1)# ./clx_system/clx_sdk/include/clx_port.h: 279

CLX_PORT_PHY_LOCATION_LAST = (CLX_PORT_PHY_LOCATION_EXT_LS + 1)# ./clx_system/clx_sdk/include/clx_port.h: 279

CLX_PORT_PHY_LOCATION_T = enum_anon_32# ./clx_system/clx_sdk/include/clx_port.h: 279

enum_anon_33 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_SGMII = 0# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_1000BASE_X = (CLX_PORT_MEDIUM_TYPE_SGMII + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_10GBASE_CR = (CLX_PORT_MEDIUM_TYPE_1000BASE_X + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_10GBASE_KR = (CLX_PORT_MEDIUM_TYPE_10GBASE_CR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_10GBASE_SR = (CLX_PORT_MEDIUM_TYPE_10GBASE_KR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_10GBASE_LR = (CLX_PORT_MEDIUM_TYPE_10GBASE_SR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_10GBASE_ER = (CLX_PORT_MEDIUM_TYPE_10GBASE_LR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_40GBASE_CR4 = (CLX_PORT_MEDIUM_TYPE_10GBASE_ER + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_40GBASE_KR4 = (CLX_PORT_MEDIUM_TYPE_40GBASE_CR4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_40GBASE_SR4 = (CLX_PORT_MEDIUM_TYPE_40GBASE_KR4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_40GBASE_LR4 = (CLX_PORT_MEDIUM_TYPE_40GBASE_SR4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_40GBASE_ER4 = (CLX_PORT_MEDIUM_TYPE_40GBASE_LR4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_100GBASE_CR10 = (CLX_PORT_MEDIUM_TYPE_40GBASE_ER4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_100GBASE_SR10 = (CLX_PORT_MEDIUM_TYPE_100GBASE_CR10 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_100GBASE_CR4 = (CLX_PORT_MEDIUM_TYPE_100GBASE_SR10 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_100GBASE_KR4 = (CLX_PORT_MEDIUM_TYPE_100GBASE_CR4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_100GBASE_SR4 = (CLX_PORT_MEDIUM_TYPE_100GBASE_KR4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_100GBASE_LR4 = (CLX_PORT_MEDIUM_TYPE_100GBASE_SR4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_100GBASE_ER4 = (CLX_PORT_MEDIUM_TYPE_100GBASE_LR4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_25GBASE_CR = (CLX_PORT_MEDIUM_TYPE_100GBASE_ER4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_25GBASE_KR = (CLX_PORT_MEDIUM_TYPE_25GBASE_CR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_25GBASE_SR = (CLX_PORT_MEDIUM_TYPE_25GBASE_KR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_25GBASE_LR = (CLX_PORT_MEDIUM_TYPE_25GBASE_SR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_25GBASE_ER = (CLX_PORT_MEDIUM_TYPE_25GBASE_LR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_50GBASE_CR2 = (CLX_PORT_MEDIUM_TYPE_25GBASE_ER + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_50GBASE_SR2 = (CLX_PORT_MEDIUM_TYPE_50GBASE_CR2 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_50GBASE_CR = (CLX_PORT_MEDIUM_TYPE_50GBASE_SR2 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_50GBASE_KR = (CLX_PORT_MEDIUM_TYPE_50GBASE_CR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_50GBASE_SR = (CLX_PORT_MEDIUM_TYPE_50GBASE_KR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_100GBASE_CR2 = (CLX_PORT_MEDIUM_TYPE_50GBASE_SR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_100GBASE_KR2 = (CLX_PORT_MEDIUM_TYPE_100GBASE_CR2 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_100GBASE_SR2 = (CLX_PORT_MEDIUM_TYPE_100GBASE_KR2 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_200GBASE_CR4 = (CLX_PORT_MEDIUM_TYPE_100GBASE_SR2 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_200GBASE_KR4 = (CLX_PORT_MEDIUM_TYPE_200GBASE_CR4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_200GBASE_SR4 = (CLX_PORT_MEDIUM_TYPE_200GBASE_KR4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_400GBASE_LR8 = (CLX_PORT_MEDIUM_TYPE_200GBASE_SR4 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_400GBASE_CR8 = (CLX_PORT_MEDIUM_TYPE_400GBASE_LR8 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_LAST = (CLX_PORT_MEDIUM_TYPE_400GBASE_CR8 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 322

CLX_PORT_MEDIUM_TYPE_T = enum_anon_33# ./clx_system/clx_sdk/include/clx_port.h: 322

enum_anon_34 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 337

CLX_PORT_PHY_PROPERTY_LANE_SWAP_TX = 0# ./clx_system/clx_sdk/include/clx_port.h: 337

CLX_PORT_PHY_PROPERTY_LANE_SWAP_RX = (CLX_PORT_PHY_PROPERTY_LANE_SWAP_TX + 1)# ./clx_system/clx_sdk/include/clx_port.h: 337

CLX_PORT_PHY_PROPERTY_POL_REV_TX = (CLX_PORT_PHY_PROPERTY_LANE_SWAP_RX + 1)# ./clx_system/clx_sdk/include/clx_port.h: 337

CLX_PORT_PHY_PROPERTY_POL_REV_RX = (CLX_PORT_PHY_PROPERTY_POL_REV_TX + 1)# ./clx_system/clx_sdk/include/clx_port.h: 337

CLX_PORT_PHY_PROPERTY_TX_COEF_CN1 = (CLX_PORT_PHY_PROPERTY_POL_REV_RX + 1)# ./clx_system/clx_sdk/include/clx_port.h: 337

CLX_PORT_PHY_PROPERTY_TX_COEF_C0 = (CLX_PORT_PHY_PROPERTY_TX_COEF_CN1 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 337

CLX_PORT_PHY_PROPERTY_TX_COEF_C1 = (CLX_PORT_PHY_PROPERTY_TX_COEF_C0 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 337

CLX_PORT_PHY_PROPERTY_TX_COEF_C2 = (CLX_PORT_PHY_PROPERTY_TX_COEF_C1 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 337

CLX_PORT_PHY_PROPERTY_TX_COEF_CN2 = (CLX_PORT_PHY_PROPERTY_TX_COEF_C2 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 337

CLX_PORT_PHY_PROPERTY_LAST = (CLX_PORT_PHY_PROPERTY_TX_COEF_CN2 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 337

CLX_PORT_PHY_PROPERTY_T = enum_anon_34# ./clx_system/clx_sdk/include/clx_port.h: 337

enum_anon_35 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_ADMIN_STATE = 0# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_AUTONEG_STATUS = (CLX_PORT_PROPERTY_ADMIN_STATE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_BD_LABEL = (CLX_PORT_PROPERTY_AUTONEG_STATUS + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_BYPASS_STP = (CLX_PORT_PROPERTY_BD_LABEL + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_ECN = (CLX_PORT_PROPERTY_BYPASS_STP + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_FEC = (CLX_PORT_PROPERTY_ECN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_GROUP_LABEL = (CLX_PORT_PROPERTY_FEC + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_LEARNING = (CLX_PORT_PROPERTY_GROUP_LABEL + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_NVGRE_UPLINK = (CLX_PORT_PROPERTY_LEARNING + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_PORT_BRIDGING = (CLX_PORT_PROPERTY_NVGRE_UPLINK + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_LANE_CNT = (CLX_PORT_PROPERTY_PORT_BRIDGING + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_VXLAN_UPLINK = (CLX_PORT_PROPERTY_LANE_CNT + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_CUT_THROUGH = (CLX_PORT_PROPERTY_VXLAN_UPLINK + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_UNI_PORT = (CLX_PORT_PROPERTY_CUT_THROUGH + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_BYPASS_VLAN2FDID = (CLX_PORT_PROPERTY_UNI_PORT + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_LEARN_FAIL_ACTION = (CLX_PORT_PROPERTY_BYPASS_VLAN2FDID + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_SA_MISS_ACTION = (CLX_PORT_PROPERTY_LEARN_FAIL_ACTION + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_VLAN_MISS_ACTION = (CLX_PORT_PROPERTY_SA_MISS_ACTION + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_IGR_MIR_SESSION_BITMAP = (CLX_PORT_PROPERTY_VLAN_MISS_ACTION + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_EGR_MIR_SESSION_BITMAP = (CLX_PORT_PROPERTY_IGR_MIR_SESSION_BITMAP + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_TS_EN = (CLX_PORT_PROPERTY_EGR_MIR_SESSION_BITMAP + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_IGR_SAMPLING_RATE = (CLX_PORT_PROPERTY_TS_EN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_IGR_SAMPLE_TO_MIR_SESSION = (CLX_PORT_PROPERTY_IGR_SAMPLING_RATE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_EGR_SAMPLING_RATE = (CLX_PORT_PROPERTY_IGR_SAMPLE_TO_MIR_SESSION + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_EGR_SAMPLE_TO_MIR_SESSION = (CLX_PORT_PROPERTY_EGR_SAMPLING_RATE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_EGR_SAMPLE_HIGH_LATENCY = (CLX_PORT_PROPERTY_EGR_SAMPLE_TO_MIR_SESSION + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_IGR_VLAN_FILTER_EN = (CLX_PORT_PROPERTY_EGR_SAMPLE_HIGH_LATENCY + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_EGR_VLAN_FILTER_EN = (CLX_PORT_PROPERTY_IGR_VLAN_FILTER_EN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_UNIDIRECTIONAL_LINK = (CLX_PORT_PROPERTY_EGR_VLAN_FILTER_EN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_1G_MEDIUM_AUTO = (CLX_PORT_PROPERTY_UNIDIRECTIONAL_LINK + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_TX_EN = (CLX_PORT_PROPERTY_1G_MEDIUM_AUTO + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_RX_EN = (CLX_PORT_PROPERTY_TX_EN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_MXLINK_EN = (CLX_PORT_PROPERTY_RX_EN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_MIB_MAX_LEN = (CLX_PORT_PROPERTY_MXLINK_EN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_SKIP_MPLS = (CLX_PORT_PROPERTY_MIB_MAX_LEN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_DEL_MPLS = (CLX_PORT_PROPERTY_SKIP_MPLS + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_TRUNC_MASK = (CLX_PORT_PROPERTY_DEL_MPLS + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_CRC_REPLACE = (CLX_PORT_PROPERTY_TRUNC_MASK + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_PPPOE_EN = (CLX_PORT_PROPERTY_CRC_REPLACE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_PPPOE_VLAN_NUM = (CLX_PORT_PROPERTY_PPPOE_EN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_DTEL_IOAM_TRANSIT = (CLX_PORT_PROPERTY_PPPOE_VLAN_NUM + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_DTEL_IOAM_DECAP = (CLX_PORT_PROPERTY_DTEL_IOAM_TRANSIT + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_DTEL_IFA_SAMPLE_SUPP_EN = (CLX_PORT_PROPERTY_DTEL_IOAM_DECAP + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_SYNCE_MODE = (CLX_PORT_PROPERTY_DTEL_IFA_SAMPLE_SUPP_EN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_ACL_MATCH_TUNNEL_INNER = (CLX_PORT_PROPERTY_SYNCE_MODE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_ACL_MATCH_PACKET_VLAN = (CLX_PORT_PROPERTY_ACL_MATCH_TUNNEL_INNER + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_TS_INSERT_EOF_IGR = (CLX_PORT_PROPERTY_ACL_MATCH_PACKET_VLAN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_TS_INSERT_EOF_EGR = (CLX_PORT_PROPERTY_TS_INSERT_EOF_IGR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_TS_REPLACE_TYPE = (CLX_PORT_PROPERTY_TS_INSERT_EOF_EGR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_TS_REPLACE_MAC = (CLX_PORT_PROPERTY_TS_REPLACE_TYPE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_MXHDR_EN = (CLX_PORT_PROPERTY_TS_REPLACE_MAC + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_DTEL_IFA_DECAP = (CLX_PORT_PROPERTY_MXHDR_EN + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_DTEL_IFA_TRANSIT = (CLX_PORT_PROPERTY_DTEL_IFA_DECAP + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_LAST = (CLX_PORT_PROPERTY_DTEL_IFA_TRANSIT + 1)# ./clx_system/clx_sdk/include/clx_port.h: 398

CLX_PORT_PROPERTY_T = enum_anon_35# ./clx_system/clx_sdk/include/clx_port.h: 398

enum_anon_36 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 408

CLX_PORT_PRBS_PATTERN_DISABLE = 0# ./clx_system/clx_sdk/include/clx_port.h: 408

CLX_PORT_PRBS_PATTERN_9 = (CLX_PORT_PRBS_PATTERN_DISABLE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 408

CLX_PORT_PRBS_PATTERN_13 = (CLX_PORT_PRBS_PATTERN_9 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 408

CLX_PORT_PRBS_PATTERN_31 = (CLX_PORT_PRBS_PATTERN_13 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 408

CLX_PORT_PRBS_PATTERN_SQUARE = (CLX_PORT_PRBS_PATTERN_31 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 408

CLX_PORT_PRBS_PATTERN_LAST = (CLX_PORT_PRBS_PATTERN_SQUARE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 408

CLX_PORT_PRBS_PATTERN_T = enum_anon_36# ./clx_system/clx_sdk/include/clx_port.h: 408

enum_anon_37 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 415

CLX_PORT_PRBS_CHECKER_DISABLE = 0# ./clx_system/clx_sdk/include/clx_port.h: 415

CLX_PORT_PRBS_CHECKER_ENABLE = (CLX_PORT_PRBS_CHECKER_DISABLE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 415

CLX_PORT_PRBS_CHECKER_LAST = (CLX_PORT_PRBS_CHECKER_ENABLE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 415

CLX_PORT_PRBS_CHECKER_T = enum_anon_37# ./clx_system/clx_sdk/include/clx_port.h: 415

enum_anon_38 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 423

CLX_PORT_FEC_CNT_TYPE_CERR = 0# ./clx_system/clx_sdk/include/clx_port.h: 423

CLX_PORT_FEC_CNT_TYPE_UCERR = (CLX_PORT_FEC_CNT_TYPE_CERR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 423

CLX_PORT_FEC_CNT_TYPE_LANE_SERR = (CLX_PORT_FEC_CNT_TYPE_UCERR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 423

CLX_PORT_FEC_CNT_TYPE_LAST = (CLX_PORT_FEC_CNT_TYPE_LANE_SERR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 423

CLX_PORT_FEC_CNT_TYPE_T = enum_anon_38# ./clx_system/clx_sdk/include/clx_port.h: 423

enum_anon_39 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 430

CLX_PORT_LINK_TRAINING_DISABLE = 0# ./clx_system/clx_sdk/include/clx_port.h: 430

CLX_PORT_LINK_TRAINING_ENABLE = (CLX_PORT_LINK_TRAINING_DISABLE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 430

CLX_PORT_LINK_TRAINING_LAST = (CLX_PORT_LINK_TRAINING_ENABLE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 430

CLX_PORT_LINK_TRAINING_T = enum_anon_39# ./clx_system/clx_sdk/include/clx_port.h: 430

enum_anon_40 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 446

CLX_PORT_LINK_TRAINING_FAIL_NO_ERROR = 0# ./clx_system/clx_sdk/include/clx_port.h: 446

CLX_PORT_LINK_TRAINING_FAIL_FRAME_LOCK_ERROR = (CLX_PORT_LINK_TRAINING_FAIL_NO_ERROR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 446

CLX_PORT_LINK_TRAINING_FAIL_SNR_LOWER_THRESHOLD = (CLX_PORT_LINK_TRAINING_FAIL_FRAME_LOCK_ERROR + 1)# ./clx_system/clx_sdk/include/clx_port.h: 446

CLX_PORT_LINK_TRAINING_FAIL_TIME_OUT = (CLX_PORT_LINK_TRAINING_FAIL_SNR_LOWER_THRESHOLD + 1)# ./clx_system/clx_sdk/include/clx_port.h: 446

CLX_PORT_LINK_TRAINING_FAIL_LAST = (CLX_PORT_LINK_TRAINING_FAIL_TIME_OUT + 1)# ./clx_system/clx_sdk/include/clx_port.h: 446

CLX_PORT_LINK_TRAINING_FAIL_T = enum_anon_40# ./clx_system/clx_sdk/include/clx_port.h: 446

enum_anon_41 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 453

CLX_PORT_EYE_SCAN_DIAGRAM = 0# ./clx_system/clx_sdk/include/clx_port.h: 453

CLX_PORT_EYE_SCAN_BER = (CLX_PORT_EYE_SCAN_DIAGRAM + 1)# ./clx_system/clx_sdk/include/clx_port.h: 453

CLX_PORT_EYE_SCAN_LAST = (CLX_PORT_EYE_SCAN_BER + 1)# ./clx_system/clx_sdk/include/clx_port.h: 453

CLX_PORT_EYE_SCAN_T = enum_anon_41# ./clx_system/clx_sdk/include/clx_port.h: 453

enum_anon_42 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 462

CLX_PORT_SYNCE_MODE_DISABLE = 0# ./clx_system/clx_sdk/include/clx_port.h: 462

CLX_PORT_SYNCE_MODE_0 = (CLX_PORT_SYNCE_MODE_DISABLE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 462

CLX_PORT_SYNCE_MODE_1 = (CLX_PORT_SYNCE_MODE_0 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 462

CLX_PORT_SYNCE_MODE_LAST = (CLX_PORT_SYNCE_MODE_1 + 1)# ./clx_system/clx_sdk/include/clx_port.h: 462

CLX_PORT_SYNCE_MODE_T = enum_anon_42# ./clx_system/clx_sdk/include/clx_port.h: 462

CLX_PORT_BITMAP_T = UI32_T * int((((288 - 1) / 32) + 1))# ./clx_system/clx_sdk/include/clx_port.h: 465

# ./clx_system/clx_sdk/include/clx_port.h: 472
class struct_CLX_PORT_VLAN_TAG_S(Structure):
    pass

struct_CLX_PORT_VLAN_TAG_S.__slots__ = [
    's_tpid',
    'c_tpid',
    'mode',
]
struct_CLX_PORT_VLAN_TAG_S._fields_ = [
    ('s_tpid', UI16_T),
    ('c_tpid', UI16_T),
    ('mode', CLX_PORT_VLAN_TAG_MODE_T),
]

CLX_PORT_VLAN_TAG_T = struct_CLX_PORT_VLAN_TAG_S# ./clx_system/clx_sdk/include/clx_port.h: 472

# ./clx_system/clx_sdk/include/clx_port.h: 485
class struct_CLX_PORT_ABILITY_S(Structure):
    pass

struct_CLX_PORT_ABILITY_S.__slots__ = [
    'speed',
    'pause',
    'fec',
    'eee',
    'interface',
    'medium',
    'flags',
]
struct_CLX_PORT_ABILITY_S._fields_ = [
    ('speed', CLX_PORT_ABILITY_SPEED_T),
    ('pause', CLX_PORT_ABILITY_PAUSE_T),
    ('fec', CLX_PORT_ABILITY_FEC_T),
    ('eee', CLX_PORT_ABILITY_EEE_T),
    ('interface', CLX_PORT_ABILITY_INTERFACE_T),
    ('medium', CLX_PORT_ABILITY_MEDIUM_T),
    ('flags', UI32_T),
]

CLX_PORT_ABILITY_T = struct_CLX_PORT_ABILITY_S# ./clx_system/clx_sdk/include/clx_port.h: 485

# ./clx_system/clx_sdk/include/clx_port.h: 492
class struct_CLX_PORT_PROFILE_ID_S(Structure):
    pass

struct_CLX_PORT_PROFILE_ID_S.__slots__ = [
    'ingress_id',
    'egress_id',
    'dir',
]
struct_CLX_PORT_PROFILE_ID_S._fields_ = [
    ('ingress_id', UI32_T),
    ('egress_id', UI32_T),
    ('dir', CLX_DIR_T),
]

CLX_PORT_PROFILE_ID_T = struct_CLX_PORT_PROFILE_ID_S# ./clx_system/clx_sdk/include/clx_port.h: 492

CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, UI32_T, UI32_T, UI32_T, POINTER(None))# ./clx_system/clx_sdk/include/clx_port.h: 495

# ./clx_system/clx_sdk/include/clx_port.h: 556
class struct_CLX_PORT_SEG_SRV_S(Structure):
    pass

struct_CLX_PORT_SEG_SRV_S.__slots__ = [
    'bdid',
    'l3_intf_id',
    'bc_info',
    'umc_info',
    'uuc_info',
    'igr_group_label',
    'egr_group_label',
    'igr_sampling_rate',
    'igr_sample_to_mir_session_id',
    'egr_sampling_rate',
    'egr_sample_to_mir_session_id',
    'igr_mir_session_bitmap',
    'egr_mir_session_bitmap',
    'pcp_dei_to_phb_profile_id',
    'dscp_to_phb_profile_id',
    'phb_to_pcp_dei_profile_id',
    'phb_to_dscp_profile_id',
    'mstp_id',
    'igr_meter_id',
    'egr_meter_id',
    'igr_counter_id',
    'egr_counter_id',
    'igr_dist_counter_id',
    'egr_dist_counter_id',
    'dtel_profile_id',
    'flags',
]
struct_CLX_PORT_SEG_SRV_S._fields_ = [
    ('bdid', CLX_BRIDGE_DOMAIN_T),
    ('l3_intf_id', UI32_T),
    ('bc_info', CLX_BUM_INFO_T),
    ('umc_info', CLX_BUM_INFO_T),
    ('uuc_info', CLX_BUM_INFO_T),
    ('igr_group_label', UI32_T),
    ('egr_group_label', UI32_T),
    ('igr_sampling_rate', UI32_T),
    ('igr_sample_to_mir_session_id', UI32_T),
    ('egr_sampling_rate', UI32_T),
    ('egr_sample_to_mir_session_id', UI32_T),
    ('igr_mir_session_bitmap', UI32_T),
    ('egr_mir_session_bitmap', UI32_T),
    ('pcp_dei_to_phb_profile_id', UI32_T),
    ('dscp_to_phb_profile_id', UI32_T),
    ('phb_to_pcp_dei_profile_id', UI32_T),
    ('phb_to_dscp_profile_id', UI32_T),
    ('mstp_id', UI32_T),
    ('igr_meter_id', UI32_T),
    ('egr_meter_id', UI32_T),
    ('igr_counter_id', UI32_T),
    ('egr_counter_id', UI32_T),
    ('igr_dist_counter_id', UI32_T),
    ('egr_dist_counter_id', UI32_T),
    ('dtel_profile_id', UI32_T),
    ('flags', UI32_T),
]

CLX_PORT_SEG_SRV_T = struct_CLX_PORT_SEG_SRV_S# ./clx_system/clx_sdk/include/clx_port.h: 556

# ./clx_system/clx_sdk/include/clx_port.h: 606
class struct_CLX_PORT_INTF_PROPERTY_S(Structure):
    pass

struct_CLX_PORT_INTF_PROPERTY_S.__slots__ = [
    'accept_type',
    'tag_mode',
    'precedence',
    's_tpid',
    'c_tpid',
    'dflt_pcp',
    'dflt_dei',
    'dflt_vid',
    'mtu',
    'igr_sampling_rate',
    'igr_sample_to_mir_session_id',
    'egr_sampling_rate',
    'egr_sample_to_mir_session_id',
    'igr_meter_id',
    'egr_meter_id',
    'igr_counter_id',
    'egr_counter_id',
    'igr_dist_counter_id',
    'egr_dist_counter_id',
    'pcp_dei_to_phb_profile_id',
    'phb_to_pcp_dei_profile_id',
    'dscp_to_phb_profile_id',
    'phb_to_dscp_profile_id',
    'exp_to_phb_profile_id',
    'phb_to_exp_profile_id',
    'igr_group_label',
    'egr_group_label',
    'flags',
]
struct_CLX_PORT_INTF_PROPERTY_S._fields_ = [
    ('accept_type', CLX_PORT_ACCEPTABLE_TYPE_T),
    ('tag_mode', CLX_PORT_VLAN_TAG_MODE_T),
    ('precedence', CLX_VLAN_PRECEDENCE_T),
    ('s_tpid', UI16_T),
    ('c_tpid', UI16_T),
    ('dflt_pcp', UI32_T),
    ('dflt_dei', UI32_T),
    ('dflt_vid', UI32_T),
    ('mtu', UI32_T),
    ('igr_sampling_rate', UI32_T),
    ('igr_sample_to_mir_session_id', UI32_T),
    ('egr_sampling_rate', UI32_T),
    ('egr_sample_to_mir_session_id', UI32_T),
    ('igr_meter_id', UI32_T),
    ('egr_meter_id', UI32_T),
    ('igr_counter_id', UI32_T),
    ('egr_counter_id', UI32_T),
    ('igr_dist_counter_id', UI32_T),
    ('egr_dist_counter_id', UI32_T),
    ('pcp_dei_to_phb_profile_id', UI32_T),
    ('phb_to_pcp_dei_profile_id', UI32_T),
    ('dscp_to_phb_profile_id', UI32_T),
    ('phb_to_dscp_profile_id', UI32_T),
    ('exp_to_phb_profile_id', UI32_T),
    ('phb_to_exp_profile_id', UI32_T),
    ('igr_group_label', UI32_T),
    ('egr_group_label', UI32_T),
    ('flags', UI32_T),
]

CLX_PORT_INTF_PROPERTY_T = struct_CLX_PORT_INTF_PROPERTY_S# ./clx_system/clx_sdk/include/clx_port.h: 606

enum_anon_43 = c_int# ./clx_system/clx_sdk/include/clx_port.h: 618

CLX_PORT_PRBS_CONFIG_DISABLE = 0# ./clx_system/clx_sdk/include/clx_port.h: 618

CLX_PORT_PRBS_CONFIG_ENABLE_TX_RX = (CLX_PORT_PRBS_CONFIG_DISABLE + 1)# ./clx_system/clx_sdk/include/clx_port.h: 618

CLX_PORT_PRBS_CONFIG_ENABLE_RX = (CLX_PORT_PRBS_CONFIG_ENABLE_TX_RX + 1)# ./clx_system/clx_sdk/include/clx_port.h: 618

CLX_PORT_PRBS_CONFIG_ENABLE_TX = (CLX_PORT_PRBS_CONFIG_ENABLE_RX + 1)# ./clx_system/clx_sdk/include/clx_port.h: 618

CLX_PORT_PRBS_LAST = (CLX_PORT_PRBS_CONFIG_ENABLE_TX + 1)# ./clx_system/clx_sdk/include/clx_port.h: 618

CLX_PORT_PRBS_CONFIG_T = enum_anon_43# ./clx_system/clx_sdk/include/clx_port.h: 618

# ./clx_system/clx_sdk/include/clx_port.h: 626
class struct_CLX_PORT_TS_ENTRY_S(Structure):
    pass

struct_CLX_PORT_TS_ENTRY_S.__slots__ = [
    'seq_num',
    'sec_hi',
    'sec_low',
    'nsec',
]
struct_CLX_PORT_TS_ENTRY_S._fields_ = [
    ('seq_num', UI16_T),
    ('sec_hi', UI16_T),
    ('sec_low', UI32_T),
    ('nsec', UI32_T),
]

CLX_PORT_TS_ENTRY_T = struct_CLX_PORT_TS_ENTRY_S# ./clx_system/clx_sdk/include/clx_port.h: 626

# ./clx_system/clx_sdk/include/clx_port.h: 635
class struct_CLX_PORT_STATUS_S(Structure):
    pass

struct_CLX_PORT_STATUS_S.__slots__ = [
    'speed',
    'link',
    'fault',
    'rx_fc',
    'rx_pfc',
]
struct_CLX_PORT_STATUS_S._fields_ = [
    ('speed', CLX_PORT_SPEED_T),
    ('link', UI32_T),
    ('fault', UI32_T),
    ('rx_fc', UI32_T),
    ('rx_pfc', UI32_T),
]

CLX_PORT_STATUS_T = struct_CLX_PORT_STATUS_S# ./clx_system/clx_sdk/include/clx_port.h: 635

# ./clx_system/clx_sdk/include/clx_port.h: 650
class struct_CLX_PORT_TX_COEF_S(Structure):
    pass

struct_CLX_PORT_TX_COEF_S.__slots__ = [
    'flags',
    'cn2',
    'cn1',
    'c0',
    'c1',
    'c2',
]
struct_CLX_PORT_TX_COEF_S._fields_ = [
    ('flags', UI32_T),
    ('cn2', UI32_T),
    ('cn1', UI32_T),
    ('c0', UI32_T),
    ('c1', UI32_T),
    ('c2', UI32_T),
]

CLX_PORT_TX_COEF_T = struct_CLX_PORT_TX_COEF_S# ./clx_system/clx_sdk/include/clx_port.h: 650

# ./clx_system/clx_sdk/include/clx_port.h: 671
if _libs["libsai.so"].has("clx_port_setMediumType", "cdecl"):
    clx_port_setMediumType = _libs["libsai.so"].get("clx_port_setMediumType", "cdecl")
    clx_port_setMediumType.argtypes = [UI32_T, UI32_T, CLX_PORT_MEDIUM_TYPE_T]
    clx_port_setMediumType.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 692
if _libs["libsai.so"].has("clx_port_getMediumType", "cdecl"):
    clx_port_getMediumType = _libs["libsai.so"].get("clx_port_getMediumType", "cdecl")
    clx_port_getMediumType.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_MEDIUM_TYPE_T)]
    clx_port_getMediumType.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 718
if _libs["libsai.so"].has("clx_port_setSpeed", "cdecl"):
    clx_port_setSpeed = _libs["libsai.so"].get("clx_port_setSpeed", "cdecl")
    clx_port_setSpeed.argtypes = [UI32_T, UI32_T, CLX_PORT_SPEED_T]
    clx_port_setSpeed.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 739
if _libs["libsai.so"].has("clx_port_getSpeed", "cdecl"):
    clx_port_getSpeed = _libs["libsai.so"].get("clx_port_getSpeed", "cdecl")
    clx_port_getSpeed.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_SPEED_T)]
    clx_port_getSpeed.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 765
if _libs["libsai.so"].has("clx_port_setFlowCtrl", "cdecl"):
    clx_port_setFlowCtrl = _libs["libsai.so"].get("clx_port_setFlowCtrl", "cdecl")
    clx_port_setFlowCtrl.argtypes = [UI32_T, UI32_T, CLX_PORT_FC_T]
    clx_port_setFlowCtrl.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 786
if _libs["libsai.so"].has("clx_port_getFlowCtrl", "cdecl"):
    clx_port_getFlowCtrl = _libs["libsai.so"].get("clx_port_getFlowCtrl", "cdecl")
    clx_port_getFlowCtrl.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_FC_T)]
    clx_port_getFlowCtrl.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 809
if _libs["libsai.so"].has("clx_port_setPriFlowCtrl", "cdecl"):
    clx_port_setPriFlowCtrl = _libs["libsai.so"].get("clx_port_setPriFlowCtrl", "cdecl")
    clx_port_setPriFlowCtrl.argtypes = [UI32_T, UI32_T, UI8_T, CLX_PORT_FC_T]
    clx_port_setPriFlowCtrl.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 832
if _libs["libsai.so"].has("clx_port_getPriFlowCtrl", "cdecl"):
    clx_port_getPriFlowCtrl = _libs["libsai.so"].get("clx_port_getPriFlowCtrl", "cdecl")
    clx_port_getPriFlowCtrl.argtypes = [UI32_T, UI32_T, UI8_T, POINTER(CLX_PORT_FC_T)]
    clx_port_getPriFlowCtrl.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 854
if _libs["libsai.so"].has("clx_port_setEeeMode", "cdecl"):
    clx_port_setEeeMode = _libs["libsai.so"].get("clx_port_setEeeMode", "cdecl")
    clx_port_setEeeMode.argtypes = [UI32_T, UI32_T, CLX_PORT_EEE_MODE_T]
    clx_port_setEeeMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 875
if _libs["libsai.so"].has("clx_port_getEeeMode", "cdecl"):
    clx_port_getEeeMode = _libs["libsai.so"].get("clx_port_getEeeMode", "cdecl")
    clx_port_getEeeMode.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_EEE_MODE_T)]
    clx_port_getEeeMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 897
if _libs["libsai.so"].has("clx_port_setLocalAdvAbility", "cdecl"):
    clx_port_setLocalAdvAbility = _libs["libsai.so"].get("clx_port_setLocalAdvAbility", "cdecl")
    clx_port_setLocalAdvAbility.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_ABILITY_T)]
    clx_port_setLocalAdvAbility.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 918
if _libs["libsai.so"].has("clx_port_getLocalAdvAbility", "cdecl"):
    clx_port_getLocalAdvAbility = _libs["libsai.so"].get("clx_port_getLocalAdvAbility", "cdecl")
    clx_port_getLocalAdvAbility.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_ABILITY_T)]
    clx_port_getLocalAdvAbility.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 939
if _libs["libsai.so"].has("clx_port_getRemoteAdvAbility", "cdecl"):
    clx_port_getRemoteAdvAbility = _libs["libsai.so"].get("clx_port_getRemoteAdvAbility", "cdecl")
    clx_port_getRemoteAdvAbility.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_ABILITY_T)]
    clx_port_getRemoteAdvAbility.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 960
if _libs["libsai.so"].has("clx_port_getAbility", "cdecl"):
    clx_port_getAbility = _libs["libsai.so"].get("clx_port_getAbility", "cdecl")
    clx_port_getAbility.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_ABILITY_T)]
    clx_port_getAbility.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 984
if _libs["libsai.so"].has("clx_port_setLoopback", "cdecl"):
    clx_port_setLoopback = _libs["libsai.so"].get("clx_port_setLoopback", "cdecl")
    clx_port_setLoopback.argtypes = [UI32_T, UI32_T, CLX_PORT_LOOPBACK_T]
    clx_port_setLoopback.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1008
if _libs["libsai.so"].has("clx_port_getLoopback", "cdecl"):
    clx_port_getLoopback = _libs["libsai.so"].get("clx_port_getLoopback", "cdecl")
    clx_port_getLoopback.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_LOOPBACK_T)]
    clx_port_getLoopback.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1028
if _libs["libsai.so"].has("clx_port_probe", "cdecl"):
    clx_port_probe = _libs["libsai.so"].get("clx_port_probe", "cdecl")
    clx_port_probe.argtypes = [UI32_T, UI32_T]
    clx_port_probe.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1047
if _libs["libsai.so"].has("clx_port_initPort", "cdecl"):
    clx_port_initPort = _libs["libsai.so"].get("clx_port_initPort", "cdecl")
    clx_port_initPort.argtypes = [UI32_T, UI32_T]
    clx_port_initPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1066
if _libs["libsai.so"].has("clx_port_deinitPort", "cdecl"):
    clx_port_deinitPort = _libs["libsai.so"].get("clx_port_deinitPort", "cdecl")
    clx_port_deinitPort.argtypes = [UI32_T, UI32_T]
    clx_port_deinitPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1086
if _libs["libsai.so"].has("clx_port_setMacAddr", "cdecl"):
    clx_port_setMacAddr = _libs["libsai.so"].get("clx_port_setMacAddr", "cdecl")
    clx_port_setMacAddr.argtypes = [UI32_T, UI32_T, CLX_MAC_T]
    clx_port_setMacAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1107
if _libs["libsai.so"].has("clx_port_getMacAddr", "cdecl"):
    clx_port_getMacAddr = _libs["libsai.so"].get("clx_port_getMacAddr", "cdecl")
    clx_port_getMacAddr.argtypes = [UI32_T, UI32_T, POINTER(CLX_MAC_T)]
    clx_port_getMacAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1128
if _libs["libsai.so"].has("clx_port_getLink", "cdecl"):
    clx_port_getLink = _libs["libsai.so"].get("clx_port_getLink", "cdecl")
    clx_port_getLink.argtypes = [UI32_T, UI32_T, POINTER(UI32_T)]
    clx_port_getLink.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1149
if _libs["libsai.so"].has("clx_port_getFault", "cdecl"):
    clx_port_getFault = _libs["libsai.so"].get("clx_port_getFault", "cdecl")
    clx_port_getFault.argtypes = [UI32_T, UI32_T, POINTER(UI32_T)]
    clx_port_getFault.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1173
if _libs["libsai.so"].has("clx_port_setPhyProperty", "cdecl"):
    clx_port_setPhyProperty = _libs["libsai.so"].get("clx_port_setPhyProperty", "cdecl")
    clx_port_setPhyProperty.argtypes = [UI32_T, UI32_T, CLX_PORT_PHY_LOCATION_T, CLX_PORT_PHY_PROPERTY_T, UI32_T, POINTER(UI32_T)]
    clx_port_setPhyProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1200
if _libs["libsai.so"].has("clx_port_getPhyProperty", "cdecl"):
    clx_port_getPhyProperty = _libs["libsai.so"].get("clx_port_getPhyProperty", "cdecl")
    clx_port_getPhyProperty.argtypes = [UI32_T, UI32_T, CLX_PORT_PHY_LOCATION_T, CLX_PORT_PHY_PROPERTY_T, UI32_T, POINTER(UI32_T)]
    clx_port_getPhyProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1225
if _libs["libsai.so"].has("clx_port_addSegServiceGroup", "cdecl"):
    clx_port_addSegServiceGroup = _libs["libsai.so"].get("clx_port_addSegServiceGroup", "cdecl")
    clx_port_addSegServiceGroup.argtypes = [UI32_T, UI32_T, CLX_VLAN_T, CLX_VLAN_T]
    clx_port_addSegServiceGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1248
if _libs["libsai.so"].has("clx_port_delSegServiceGroup", "cdecl"):
    clx_port_delSegServiceGroup = _libs["libsai.so"].get("clx_port_delSegServiceGroup", "cdecl")
    clx_port_delSegServiceGroup.argtypes = [UI32_T, UI32_T, CLX_VLAN_T, CLX_VLAN_T]
    clx_port_delSegServiceGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1272
if _libs["libsai.so"].has("clx_port_getSegServiceGroup", "cdecl"):
    clx_port_getSegServiceGroup = _libs["libsai.so"].get("clx_port_getSegServiceGroup", "cdecl")
    clx_port_getSegServiceGroup.argtypes = [UI32_T, UI32_T, CLX_VLAN_T, CLX_VLAN_T]
    clx_port_getSegServiceGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1295
if _libs["libsai.so"].has("clx_port_traverseSegServiceGroup", "cdecl"):
    clx_port_traverseSegServiceGroup = _libs["libsai.so"].get("clx_port_traverseSegServiceGroup", "cdecl")
    clx_port_traverseSegServiceGroup.argtypes = [UI32_T, CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T, POINTER(None)]
    clx_port_traverseSegServiceGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1321
if _libs["libsai.so"].has("clx_port_addSegService", "cdecl"):
    clx_port_addSegService = _libs["libsai.so"].get("clx_port_addSegService", "cdecl")
    clx_port_addSegService.argtypes = [UI32_T, CLX_PORT_T, UI32_T, UI32_T, POINTER(CLX_PORT_SEG_SRV_T)]
    clx_port_addSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1348
if _libs["libsai.so"].has("clx_port_delSegService", "cdecl"):
    clx_port_delSegService = _libs["libsai.so"].get("clx_port_delSegService", "cdecl")
    clx_port_delSegService.argtypes = [UI32_T, CLX_PORT_T, UI32_T, UI32_T]
    clx_port_delSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1375
if _libs["libsai.so"].has("clx_port_getSegService", "cdecl"):
    clx_port_getSegService = _libs["libsai.so"].get("clx_port_getSegService", "cdecl")
    clx_port_getSegService.argtypes = [UI32_T, CLX_PORT_T, UI32_T, UI32_T, POINTER(CLX_PORT_SEG_SRV_T)]
    clx_port_getSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1400
if _libs["libsai.so"].has("clx_port_setProperty", "cdecl"):
    clx_port_setProperty = _libs["libsai.so"].get("clx_port_setProperty", "cdecl")
    clx_port_setProperty.argtypes = [UI32_T, UI32_T, CLX_PORT_PROPERTY_T, UI32_T, UI32_T]
    clx_port_setProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1425
if _libs["libsai.so"].has("clx_port_getProperty", "cdecl"):
    clx_port_getProperty = _libs["libsai.so"].get("clx_port_getProperty", "cdecl")
    clx_port_getProperty.argtypes = [UI32_T, UI32_T, CLX_PORT_PROPERTY_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_port_getProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1453
if _libs["libsai.so"].has("clx_port_setLaneMap", "cdecl"):
    clx_port_setLaneMap = _libs["libsai.so"].get("clx_port_setLaneMap", "cdecl")
    clx_port_setLaneMap.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, CLX_PORT_SPEED_T, UI32_T]
    clx_port_setLaneMap.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1481
if _libs["libsai.so"].has("clx_port_getLaneMap", "cdecl"):
    clx_port_getLaneMap = _libs["libsai.so"].get("clx_port_getLaneMap", "cdecl")
    clx_port_getLaneMap.argtypes = [UI32_T, UI32_T, POINTER(UI32_T), POINTER(UI32_T), POINTER(CLX_PORT_SPEED_T), POINTER(UI32_T)]
    clx_port_getLaneMap.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1504
if _libs["libsai.so"].has("clx_port_createPort", "cdecl"):
    clx_port_createPort = _libs["libsai.so"].get("clx_port_createPort", "cdecl")
    clx_port_createPort.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_T)]
    clx_port_createPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1523
if _libs["libsai.so"].has("clx_port_destroyPort", "cdecl"):
    clx_port_destroyPort = _libs["libsai.so"].get("clx_port_destroyPort", "cdecl")
    clx_port_destroyPort.argtypes = [UI32_T, CLX_PORT_T]
    clx_port_destroyPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1542
if _libs["libsai.so"].has("clx_port_getPort", "cdecl"):
    clx_port_getPort = _libs["libsai.so"].get("clx_port_getPort", "cdecl")
    clx_port_getPort.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_T)]
    clx_port_getPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1563
if _libs["libsai.so"].has("clx_port_setIntfProperty", "cdecl"):
    clx_port_setIntfProperty = _libs["libsai.so"].get("clx_port_setIntfProperty", "cdecl")
    clx_port_setIntfProperty.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_PORT_INTF_PROPERTY_T)]
    clx_port_setIntfProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1583
if _libs["libsai.so"].has("clx_port_getIntfProperty", "cdecl"):
    clx_port_getIntfProperty = _libs["libsai.so"].get("clx_port_getIntfProperty", "cdecl")
    clx_port_getIntfProperty.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_PORT_INTF_PROPERTY_T)]
    clx_port_getIntfProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1603
if _libs["libsai.so"].has("clx_port_getTsTxEntry", "cdecl"):
    clx_port_getTsTxEntry = _libs["libsai.so"].get("clx_port_getTsTxEntry", "cdecl")
    clx_port_getTsTxEntry.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_TS_ENTRY_T)]
    clx_port_getTsTxEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1623
if _libs["libsai.so"].has("clx_port_getTsRxEntry", "cdecl"):
    clx_port_getTsRxEntry = _libs["libsai.so"].get("clx_port_getTsRxEntry", "cdecl")
    clx_port_getTsRxEntry.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_TS_ENTRY_T)]
    clx_port_getTsRxEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1644
if _libs["libsai.so"].has("clx_port_getPortType", "cdecl"):
    clx_port_getPortType = _libs["libsai.so"].get("clx_port_getPortType", "cdecl")
    clx_port_getPortType.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_PORT_TYPE_T)]
    clx_port_getPortType.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1665
if _libs["libsai.so"].has("clx_port_setPrbsPattern", "cdecl"):
    clx_port_setPrbsPattern = _libs["libsai.so"].get("clx_port_setPrbsPattern", "cdecl")
    clx_port_setPrbsPattern.argtypes = [UI32_T, UI32_T, CLX_PORT_PRBS_PATTERN_T]
    clx_port_setPrbsPattern.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1684
if _libs["libsai.so"].has("clx_port_getPrbsPattern", "cdecl"):
    clx_port_getPrbsPattern = _libs["libsai.so"].get("clx_port_getPrbsPattern", "cdecl")
    clx_port_getPrbsPattern.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_PRBS_PATTERN_T)]
    clx_port_getPrbsPattern.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1704
if _libs["libsai.so"].has("clx_port_setPrbsChecker", "cdecl"):
    clx_port_setPrbsChecker = _libs["libsai.so"].get("clx_port_setPrbsChecker", "cdecl")
    clx_port_setPrbsChecker.argtypes = [UI32_T, UI32_T, CLX_PORT_PRBS_CHECKER_T]
    clx_port_setPrbsChecker.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1723
if _libs["libsai.so"].has("clx_port_getPrbsChecker", "cdecl"):
    clx_port_getPrbsChecker = _libs["libsai.so"].get("clx_port_getPrbsChecker", "cdecl")
    clx_port_getPrbsChecker.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_PRBS_CHECKER_T)]
    clx_port_getPrbsChecker.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1742
if _libs["libsai.so"].has("clx_port_getPrbsErrorCnt", "cdecl"):
    clx_port_getPrbsErrorCnt = _libs["libsai.so"].get("clx_port_getPrbsErrorCnt", "cdecl")
    clx_port_getPrbsErrorCnt.argtypes = [UI32_T, UI32_T, POINTER(UI32_T)]
    clx_port_getPrbsErrorCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1764
if _libs["libsai.so"].has("clx_port_dumpEyeScan", "cdecl"):
    clx_port_dumpEyeScan = _libs["libsai.so"].get("clx_port_dumpEyeScan", "cdecl")
    clx_port_dumpEyeScan.argtypes = [UI32_T, UI32_T, UI32_T, CLX_PORT_EYE_SCAN_T]
    clx_port_dumpEyeScan.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1789
if _libs["libsai.so"].has("clx_port_setMdioReg", "cdecl"):
    clx_port_setMdioReg = _libs["libsai.so"].get("clx_port_setMdioReg", "cdecl")
    clx_port_setMdioReg.argtypes = [UI32_T, UI32_T, CLX_PHY_TYPE_T, UI32_T, UI32_T, UI32_T]
    clx_port_setMdioReg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1815
if _libs["libsai.so"].has("clx_port_getMdioReg", "cdecl"):
    clx_port_getMdioReg = _libs["libsai.so"].get("clx_port_getMdioReg", "cdecl")
    clx_port_getMdioReg.argtypes = [UI32_T, UI32_T, CLX_PHY_TYPE_T, UI32_T, UI32_T, POINTER(UI32_T)]
    clx_port_getMdioReg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1845
if _libs["libsai.so"].has("clx_port_getStatus", "cdecl"):
    clx_port_getStatus = _libs["libsai.so"].get("clx_port_getStatus", "cdecl")
    clx_port_getStatus.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_STATUS_T)]
    clx_port_getStatus.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1868
if _libs["libsai.so"].has("clx_port_setTxCoef", "cdecl"):
    clx_port_setTxCoef = _libs["libsai.so"].get("clx_port_setTxCoef", "cdecl")
    clx_port_setTxCoef.argtypes = [UI32_T, UI32_T, UI32_T, CLX_PORT_PHY_LOCATION_T, POINTER(CLX_PORT_TX_COEF_T)]
    clx_port_setTxCoef.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1892
if _libs["libsai.so"].has("clx_port_getTxCoef", "cdecl"):
    clx_port_getTxCoef = _libs["libsai.so"].get("clx_port_getTxCoef", "cdecl")
    clx_port_getTxCoef.argtypes = [UI32_T, UI32_T, UI32_T, CLX_PORT_PHY_LOCATION_T, POINTER(CLX_PORT_TX_COEF_T)]
    clx_port_getTxCoef.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1900
if _libs["libsai.so"].has("clx_port_getLinkTrngEn", "cdecl"):
    clx_port_getLinkTrngEn = _libs["libsai.so"].get("clx_port_getLinkTrngEn", "cdecl")
    clx_port_getLinkTrngEn.argtypes = [UI32_T, UI32_T, POINTER(UI8_T)]
    clx_port_getLinkTrngEn.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1906
if _libs["libsai.so"].has("clx_port_setLinkTrngEn", "cdecl"):
    clx_port_setLinkTrngEn = _libs["libsai.so"].get("clx_port_setLinkTrngEn", "cdecl")
    clx_port_setLinkTrngEn.argtypes = [UI32_T, UI32_T, UI8_T]
    clx_port_setLinkTrngEn.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1912
if _libs["libsai.so"].has("clx_port_getLinkTrngFailStatus", "cdecl"):
    clx_port_getLinkTrngFailStatus = _libs["libsai.so"].get("clx_port_getLinkTrngFailStatus", "cdecl")
    clx_port_getLinkTrngFailStatus.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_LINK_TRAINING_FAIL_T)]
    clx_port_getLinkTrngFailStatus.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1918
if _libs["libsai.so"].has("clx_port_setPrbsEn", "cdecl"):
    clx_port_setPrbsEn = _libs["libsai.so"].get("clx_port_setPrbsEn", "cdecl")
    clx_port_setPrbsEn.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_port_setPrbsEn.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_port.h: 1924
if _libs["libsai.so"].has("clx_port_getFecCnt", "cdecl"):
    clx_port_getFecCnt = _libs["libsai.so"].get("clx_port_getFecCnt", "cdecl")
    clx_port_getFecCnt.argtypes = [UI32_T, UI32_T, CLX_PORT_FEC_CNT_TYPE_T, POINTER(UI32_T)]
    clx_port_getFecCnt.restype = CLX_ERROR_NO_T

enum_anon_44 = c_int# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_LEARNING = 0# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_QOS_SA_OVERWRITE_DA = (CLX_VLAN_PROPERTY_LEARNING + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_GROUP_LABEL = (CLX_VLAN_PROPERTY_QOS_SA_OVERWRITE_DA + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_ROUTING = (CLX_VLAN_PROPERTY_GROUP_LABEL + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_IPMC = (CLX_VLAN_PROPERTY_ROUTING + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_QOS_MAPPING_PCP_DEI_TO_PHB = (CLX_VLAN_PROPERTY_IPMC + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_QOS_MAPPING_DSCP_TO_PHB = (CLX_VLAN_PROPERTY_QOS_MAPPING_PCP_DEI_TO_PHB + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_QOS_MAPPING_PHB_TO_PCP_DEI = (CLX_VLAN_PROPERTY_QOS_MAPPING_DSCP_TO_PHB + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_QOS_MAPPING_PHB_TO_DSCP = (CLX_VLAN_PROPERTY_QOS_MAPPING_PHB_TO_PCP_DEI + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_IGR_SFLOW_SAMPLING_RATE = (CLX_VLAN_PROPERTY_QOS_MAPPING_PHB_TO_DSCP + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_EGR_SFLOW_SAMPLING_RATE = (CLX_VLAN_PROPERTY_IGR_SFLOW_SAMPLING_RATE + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_METER_ID = (CLX_VLAN_PROPERTY_EGR_SFLOW_SAMPLING_RATE + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_METER_COLOR_RESOLVE_TYPE = (CLX_VLAN_PROPERTY_METER_ID + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_SERVICE_COUNTER_ID = (CLX_VLAN_PROPERTY_METER_COLOR_RESOLVE_TYPE + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_DIST_COUNTER_ID = (CLX_VLAN_PROPERTY_SERVICE_COUNTER_ID + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_UNKNOWN_UNICAST = (CLX_VLAN_PROPERTY_DIST_COUNTER_ID + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_UNKNOWN_MULTICAST = (CLX_VLAN_PROPERTY_UNKNOWN_UNICAST + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_BROADCAST = (CLX_VLAN_PROPERTY_UNKNOWN_MULTICAST + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_IGR_MIR_SESSION_BITMAP = (CLX_VLAN_PROPERTY_BROADCAST + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_RSPAN_TERM_SESSION_BITMAP = (CLX_VLAN_PROPERTY_IGR_MIR_SESSION_BITMAP + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_LAST = (CLX_VLAN_PROPERTY_RSPAN_TERM_SESSION_BITMAP + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_PROPERTY_T = enum_anon_44# ./clx_system/clx_sdk/include/clx_vlan.h: 85

CLX_VLAN_FTV_T = UI8_T * int(5)# ./clx_system/clx_sdk/include/clx_vlan.h: 88

enum_anon_45 = c_int# ./clx_system/clx_sdk/include/clx_vlan.h: 98

CLX_VLAN_PVLAN_TYPE_NORMAL = 0# ./clx_system/clx_sdk/include/clx_vlan.h: 98

CLX_VLAN_PVLAN_TYPE_PRIMARY = (CLX_VLAN_PVLAN_TYPE_NORMAL + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 98

CLX_VLAN_PVLAN_TYPE_COMMUNITY = (CLX_VLAN_PVLAN_TYPE_PRIMARY + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 98

CLX_VLAN_PVLAN_TYPE_ISOLATED = (CLX_VLAN_PVLAN_TYPE_COMMUNITY + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 98

CLX_VLAN_PVLAN_TYPE_LAST = (CLX_VLAN_PVLAN_TYPE_ISOLATED + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 98

CLX_VLAN_PVLAN_TYPE_T = enum_anon_45# ./clx_system/clx_sdk/include/clx_vlan.h: 98

# ./clx_system/clx_sdk/include/clx_vlan.h: 106
class struct_CLX_VLAN_ENTRY_S(Structure):
    pass

struct_CLX_VLAN_ENTRY_S.__slots__ = [
    'vlan',
    'port_bitmap',
    'ut_port_bitmap',
]
struct_CLX_VLAN_ENTRY_S._fields_ = [
    ('vlan', CLX_VLAN_T),
    ('port_bitmap', CLX_PORT_BITMAP_T),
    ('ut_port_bitmap', CLX_PORT_BITMAP_T),
]

CLX_VLAN_ENTRY_T = struct_CLX_VLAN_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 106

# ./clx_system/clx_sdk/include/clx_vlan.h: 118
class struct_CLX_VLAN_MAC_VLAN_ENTRY_S(Structure):
    pass

struct_CLX_VLAN_MAC_VLAN_ENTRY_S.__slots__ = [
    'port',
    'mac',
    'vlan',
    'pcp',
    'dei',
]
struct_CLX_VLAN_MAC_VLAN_ENTRY_S._fields_ = [
    ('port', UI32_T),
    ('mac', CLX_MAC_T),
    ('vlan', CLX_VLAN_T),
    ('pcp', UI8_T),
    ('dei', UI8_T),
]

CLX_VLAN_MAC_VLAN_ENTRY_T = struct_CLX_VLAN_MAC_VLAN_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 118

CLX_VLAN_MAC_VLAN_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_VLAN_MAC_VLAN_ENTRY_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_vlan.h: 121

enum_anon_46 = c_int# ./clx_system/clx_sdk/include/clx_vlan.h: 139

CLX_VLAN_FRAME_TYPE_ETHERNET = 0# ./clx_system/clx_sdk/include/clx_vlan.h: 139

CLX_VLAN_FRAME_TYPE_RFC1042 = (CLX_VLAN_FRAME_TYPE_ETHERNET + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 139

CLX_VLAN_FRAME_TYPE_SNAP_OTHER = (CLX_VLAN_FRAME_TYPE_RFC1042 + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 139

CLX_VLAN_FRAME_TYPE_LLC_OTHER = (CLX_VLAN_FRAME_TYPE_SNAP_OTHER + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 139

CLX_VLAN_FRAME_TYPE_LAST = (CLX_VLAN_FRAME_TYPE_LLC_OTHER + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 139

CLX_VLAN_FRAME_TYPE_T = enum_anon_46# ./clx_system/clx_sdk/include/clx_vlan.h: 139

# ./clx_system/clx_sdk/include/clx_vlan.h: 160
class struct_CLX_VLAN_PROTOCOL_GRP_ENTRY_S(Structure):
    pass

struct_CLX_VLAN_PROTOCOL_GRP_ENTRY_S.__slots__ = [
    'frame_type',
    'frame_type_mask',
    'ftv',
    'ftv_mask',
    'grp_id',
]
struct_CLX_VLAN_PROTOCOL_GRP_ENTRY_S._fields_ = [
    ('frame_type', UI32_T),
    ('frame_type_mask', CLX_BIT_MASK_32_T),
    ('ftv', CLX_VLAN_FTV_T),
    ('ftv_mask', CLX_VLAN_FTV_T),
    ('grp_id', UI8_T),
]

CLX_VLAN_PROTOCOL_GRP_ENTRY_T = struct_CLX_VLAN_PROTOCOL_GRP_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 160

# ./clx_system/clx_sdk/include/clx_vlan.h: 172
class struct_CLX_VLAN_PROTOCOL_GRP_VLAN_ENTRY_S(Structure):
    pass

struct_CLX_VLAN_PROTOCOL_GRP_VLAN_ENTRY_S.__slots__ = [
    'port',
    'grp_id',
    'vlan',
    'pcp',
    'dei',
]
struct_CLX_VLAN_PROTOCOL_GRP_VLAN_ENTRY_S._fields_ = [
    ('port', UI32_T),
    ('grp_id', UI8_T),
    ('vlan', CLX_VLAN_T),
    ('pcp', UI8_T),
    ('dei', UI8_T),
]

CLX_VLAN_PROTOCOL_GRP_VLAN_ENTRY_T = struct_CLX_VLAN_PROTOCOL_GRP_VLAN_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 172

# ./clx_system/clx_sdk/include/clx_vlan.h: 192
class struct_CLX_VLAN_SUBNET_VLAN_ENTRY_S(Structure):
    pass

struct_CLX_VLAN_SUBNET_VLAN_ENTRY_S.__slots__ = [
    'port_lag_id',
    'ip_addr',
    'ip_addr_mask',
    'vlan',
    'pcp',
    'dei',
    'flags',
]
struct_CLX_VLAN_SUBNET_VLAN_ENTRY_S._fields_ = [
    ('port_lag_id', CLX_PORT_T),
    ('ip_addr', CLX_IP_T),
    ('ip_addr_mask', CLX_IP_T),
    ('vlan', CLX_VLAN_T),
    ('pcp', UI8_T),
    ('dei', UI8_T),
    ('flags', UI32_T),
]

CLX_VLAN_SUBNET_VLAN_ENTRY_T = struct_CLX_VLAN_SUBNET_VLAN_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 192

# ./clx_system/clx_sdk/include/clx_vlan.h: 230
class struct_CLX_VLAN_CLASSIFY_TYPE_S(Structure):
    pass

struct_CLX_VLAN_CLASSIFY_TYPE_S.__slots__ = [
    'port',
    'pcp',
    'pcp_mask',
    'dei',
    'dei_mask',
    'svid',
    'svid_mask',
    'cvid',
    'cvid_mask',
    'frame_type',
    'ethertype',
    'ethertype_mask',
    'ip_protocol',
    'ip_protocol_mask',
    'src_port',
    'src_port_mask',
    'dst_port',
    'dst_port_mask',
    'flags',
]
struct_CLX_VLAN_CLASSIFY_TYPE_S._fields_ = [
    ('port', UI32_T),
    ('pcp', UI8_T),
    ('pcp_mask', UI8_T),
    ('dei', UI8_T),
    ('dei_mask', UI8_T),
    ('svid', CLX_VLAN_T),
    ('svid_mask', CLX_VLAN_T),
    ('cvid', CLX_VLAN_T),
    ('cvid_mask', CLX_VLAN_T),
    ('frame_type', CLX_VLAN_FRAME_TYPE_T),
    ('ethertype', UI16_T),
    ('ethertype_mask', UI16_T),
    ('ip_protocol', UI8_T),
    ('ip_protocol_mask', UI8_T),
    ('src_port', UI16_T),
    ('src_port_mask', UI16_T),
    ('dst_port', UI16_T),
    ('dst_port_mask', UI16_T),
    ('flags', UI32_T),
]

CLX_VLAN_CLASSIFY_TYPE_T = struct_CLX_VLAN_CLASSIFY_TYPE_S# ./clx_system/clx_sdk/include/clx_vlan.h: 230

# ./clx_system/clx_sdk/include/clx_vlan.h: 272
class struct_CLX_VLAN_CLASSIFY_ADDR_S(Structure):
    pass

struct_CLX_VLAN_CLASSIFY_ADDR_S.__slots__ = [
    'port',
    'pcp',
    'pcp_mask',
    'dei',
    'dei_mask',
    'svid',
    'svid_mask',
    'cvid',
    'cvid_mask',
    'dmac',
    'dmac_mask',
    'smac',
    'smac_mask',
    'dip',
    'dip_mask',
    'sip',
    'sip_mask',
    'tos',
    'tos_mask',
    'flow_label',
    'flow_label_mask',
    'flags',
]
struct_CLX_VLAN_CLASSIFY_ADDR_S._fields_ = [
    ('port', UI32_T),
    ('pcp', UI8_T),
    ('pcp_mask', UI8_T),
    ('dei', UI8_T),
    ('dei_mask', UI8_T),
    ('svid', CLX_VLAN_T),
    ('svid_mask', CLX_VLAN_T),
    ('cvid', CLX_VLAN_T),
    ('cvid_mask', CLX_VLAN_T),
    ('dmac', CLX_MAC_T),
    ('dmac_mask', CLX_MAC_T),
    ('smac', CLX_MAC_T),
    ('smac_mask', CLX_MAC_T),
    ('dip', CLX_IP_T),
    ('dip_mask', CLX_IP_T),
    ('sip', CLX_IP_T),
    ('sip_mask', CLX_IP_T),
    ('tos', UI8_T),
    ('tos_mask', UI8_T),
    ('flow_label', UI32_T),
    ('flow_label_mask', UI32_T),
    ('flags', UI32_T),
]

CLX_VLAN_CLASSIFY_ADDR_T = struct_CLX_VLAN_CLASSIFY_ADDR_S# ./clx_system/clx_sdk/include/clx_vlan.h: 272

# ./clx_system/clx_sdk/include/clx_vlan.h: 285
class struct_CLX_VLAN_TAG_ACTION_S(Structure):
    pass

struct_CLX_VLAN_TAG_ACTION_S.__slots__ = [
    'svid',
    'cvid',
    'pcp',
    'dei',
    'flags',
]
struct_CLX_VLAN_TAG_ACTION_S._fields_ = [
    ('svid', CLX_VLAN_T),
    ('cvid', CLX_VLAN_T),
    ('pcp', UI8_T),
    ('dei', UI8_T),
    ('flags', UI32_T),
]

CLX_VLAN_TAG_ACTION_T = struct_CLX_VLAN_TAG_ACTION_S# ./clx_system/clx_sdk/include/clx_vlan.h: 285

# ./clx_system/clx_sdk/include/clx_vlan.h: 293
class struct_CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_S(Structure):
    pass

struct_CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_S.__slots__ = [
    'vlan_id',
    'primary_port_bitmap',
    'trunk_port_bitmap',
]
struct_CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_S._fields_ = [
    ('vlan_id', CLX_VLAN_T),
    ('primary_port_bitmap', CLX_PORT_BITMAP_T),
    ('trunk_port_bitmap', CLX_PORT_BITMAP_T),
]

CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_T = struct_CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_S# ./clx_system/clx_sdk/include/clx_vlan.h: 293

# ./clx_system/clx_sdk/include/clx_vlan.h: 300
class struct_CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_S(Structure):
    pass

struct_CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_S.__slots__ = [
    'vlan_id',
    'port_bitmap',
]
struct_CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_S._fields_ = [
    ('vlan_id', CLX_VLAN_T),
    ('port_bitmap', CLX_PORT_BITMAP_T),
]

CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_T = struct_CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_S# ./clx_system/clx_sdk/include/clx_vlan.h: 300

# ./clx_system/clx_sdk/include/clx_vlan.h: 311
class struct_CLX_VLAN_PVLAN_ENTRY_S(Structure):
    pass

struct_CLX_VLAN_PVLAN_ENTRY_S.__slots__ = [
    'primary_vlan',
    'isolated_vlan',
    'ptr_community_vlan_list',
    'community_vlan_num',
    'mcast_id',
    'bdid',
]
struct_CLX_VLAN_PVLAN_ENTRY_S._fields_ = [
    ('primary_vlan', CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_T),
    ('isolated_vlan', CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_T),
    ('ptr_community_vlan_list', POINTER(CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_T)),
    ('community_vlan_num', UI16_T),
    ('mcast_id', UI32_T),
    ('bdid', CLX_BRIDGE_DOMAIN_T),
]

CLX_VLAN_PVLAN_ENTRY_T = struct_CLX_VLAN_PVLAN_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 311

# ./clx_system/clx_sdk/include/clx_vlan.h: 319
class struct_CLX_VLAN_ISOLATION_ENTRY_S(Structure):
    pass

struct_CLX_VLAN_ISOLATION_ENTRY_S.__slots__ = [
    'vlan',
    'egr_port_mask',
]
struct_CLX_VLAN_ISOLATION_ENTRY_S._fields_ = [
    ('vlan', CLX_VLAN_T),
    ('egr_port_mask', CLX_PORT_BITMAP_T),
]

CLX_VLAN_ISOLATION_ENTRY_T = struct_CLX_VLAN_ISOLATION_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 319

enum_anon_47 = c_int# ./clx_system/clx_sdk/include/clx_vlan.h: 334

CLX_VLAN_PROTOCOL_VLAN_FRAME_TYPE_ETHERNET = 1# ./clx_system/clx_sdk/include/clx_vlan.h: 334

CLX_VLAN_PROTOCOL_VLAN_FRAME_TYPE_RFC1042 = 2# ./clx_system/clx_sdk/include/clx_vlan.h: 334

CLX_VLAN_PROTOCOL_VLAN_FRAME_TYPE_SNAP_OTHER = 4# ./clx_system/clx_sdk/include/clx_vlan.h: 334

CLX_VLAN_PROTOCOL_VLAN_FRAME_TYPE_LLC_OTHER = 8# ./clx_system/clx_sdk/include/clx_vlan.h: 334

CLX_VLAN_PROTOCOL_VLAN_FRAME_TYPE_LAST = (CLX_VLAN_PROTOCOL_VLAN_FRAME_TYPE_LLC_OTHER + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 334

CLX_VLAN_PROTOCOL_VLAN_FRAME_TYPE_T = enum_anon_47# ./clx_system/clx_sdk/include/clx_vlan.h: 334

enum_anon_48 = c_int# ./clx_system/clx_sdk/include/clx_vlan.h: 342

CLX_VLAN_TAG_TYPE_DOUBLE = 0# ./clx_system/clx_sdk/include/clx_vlan.h: 342

CLX_VLAN_TAG_TYPE_SINGLE = (CLX_VLAN_TAG_TYPE_DOUBLE + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 342

CLX_VLAN_TAG_TYPE_LAST = (CLX_VLAN_TAG_TYPE_SINGLE + 1)# ./clx_system/clx_sdk/include/clx_vlan.h: 342

CLX_VLAN_TAG_TYPE_T = enum_anon_48# ./clx_system/clx_sdk/include/clx_vlan.h: 342

CLX_VLAN_ENTRY_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_VLAN_ENTRY_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_vlan.h: 346

# ./clx_system/clx_sdk/include/clx_vlan.h: 373
if _libs["libsai.so"].has("clx_vlan_setProperty", "cdecl"):
    clx_vlan_setProperty = _libs["libsai.so"].get("clx_vlan_setProperty", "cdecl")
    clx_vlan_setProperty.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, CLX_VLAN_PROPERTY_T, UI32_T, UI32_T]
    clx_vlan_setProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 398
if _libs["libsai.so"].has("clx_vlan_getProperty", "cdecl"):
    clx_vlan_getProperty = _libs["libsai.so"].get("clx_vlan_getProperty", "cdecl")
    clx_vlan_getProperty.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, CLX_VLAN_PROPERTY_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_vlan_getProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 421
if _libs["libsai.so"].has("clx_vlan_createVlan", "cdecl"):
    clx_vlan_createVlan = _libs["libsai.so"].get("clx_vlan_createVlan", "cdecl")
    clx_vlan_createVlan.argtypes = [UI32_T, CLX_VLAN_T]
    clx_vlan_createVlan.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 441
if _libs["libsai.so"].has("clx_vlan_delVlan", "cdecl"):
    clx_vlan_delVlan = _libs["libsai.so"].get("clx_vlan_delVlan", "cdecl")
    clx_vlan_delVlan.argtypes = [UI32_T, CLX_VLAN_T]
    clx_vlan_delVlan.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 461
if _libs["libsai.so"].has("clx_vlan_setPort", "cdecl"):
    clx_vlan_setPort = _libs["libsai.so"].get("clx_vlan_setPort", "cdecl")
    clx_vlan_setPort.argtypes = [UI32_T, POINTER(CLX_VLAN_ENTRY_T)]
    clx_vlan_setPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 480
if _libs["libsai.so"].has("clx_vlan_getPort", "cdecl"):
    clx_vlan_getPort = _libs["libsai.so"].get("clx_vlan_getPort", "cdecl")
    clx_vlan_getPort.argtypes = [UI32_T, POINTER(CLX_VLAN_ENTRY_T)]
    clx_vlan_getPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 500
if _libs["libsai.so"].has("clx_vlan_traverseEntry", "cdecl"):
    clx_vlan_traverseEntry = _libs["libsai.so"].get("clx_vlan_traverseEntry", "cdecl")
    clx_vlan_traverseEntry.argtypes = [UI32_T, CLX_VLAN_ENTRY_TRAVERSE_FUNC_T, POINTER(None)]
    clx_vlan_traverseEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 520
if _libs["libsai.so"].has("clx_vlan_createBridgeDomain", "cdecl"):
    clx_vlan_createBridgeDomain = _libs["libsai.so"].get("clx_vlan_createBridgeDomain", "cdecl")
    clx_vlan_createBridgeDomain.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_vlan_createBridgeDomain.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 539
if _libs["libsai.so"].has("clx_vlan_destroyBridgeDomain", "cdecl"):
    clx_vlan_destroyBridgeDomain = _libs["libsai.so"].get("clx_vlan_destroyBridgeDomain", "cdecl")
    clx_vlan_destroyBridgeDomain.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_vlan_destroyBridgeDomain.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 563
if _libs["libsai.so"].has("clx_vlan_setService", "cdecl"):
    clx_vlan_setService = _libs["libsai.so"].get("clx_vlan_setService", "cdecl")
    clx_vlan_setService.argtypes = [UI32_T, CLX_VLAN_T, POINTER(CLX_PORT_SEG_SRV_T)]
    clx_vlan_setService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 587
if _libs["libsai.so"].has("clx_vlan_getService", "cdecl"):
    clx_vlan_getService = _libs["libsai.so"].get("clx_vlan_getService", "cdecl")
    clx_vlan_getService.argtypes = [UI32_T, CLX_VLAN_T, POINTER(CLX_PORT_SEG_SRV_T)]
    clx_vlan_getService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 609
if _libs["libsai.so"].has("clx_vlan_setVlanIsolation", "cdecl"):
    clx_vlan_setVlanIsolation = _libs["libsai.so"].get("clx_vlan_setVlanIsolation", "cdecl")
    clx_vlan_setVlanIsolation.argtypes = [UI32_T, CLX_VLAN_T, POINTER(CLX_VLAN_ISOLATION_ENTRY_T)]
    clx_vlan_setVlanIsolation.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 630
if _libs["libsai.so"].has("clx_vlan_getVlanIsolation", "cdecl"):
    clx_vlan_getVlanIsolation = _libs["libsai.so"].get("clx_vlan_getVlanIsolation", "cdecl")
    clx_vlan_getVlanIsolation.argtypes = [UI32_T, CLX_VLAN_T, POINTER(CLX_VLAN_ISOLATION_ENTRY_T)]
    clx_vlan_getVlanIsolation.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 651
if _libs["libsai.so"].has("clx_vlan_addMacVlan", "cdecl"):
    clx_vlan_addMacVlan = _libs["libsai.so"].get("clx_vlan_addMacVlan", "cdecl")
    clx_vlan_addMacVlan.argtypes = [UI32_T, POINTER(CLX_VLAN_MAC_VLAN_ENTRY_T)]
    clx_vlan_addMacVlan.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 671
if _libs["libsai.so"].has("clx_vlan_delMacVlan", "cdecl"):
    clx_vlan_delMacVlan = _libs["libsai.so"].get("clx_vlan_delMacVlan", "cdecl")
    clx_vlan_delMacVlan.argtypes = [UI32_T, POINTER(CLX_VLAN_MAC_VLAN_ENTRY_T)]
    clx_vlan_delMacVlan.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 691
if _libs["libsai.so"].has("clx_vlan_getMacVlan", "cdecl"):
    clx_vlan_getMacVlan = _libs["libsai.so"].get("clx_vlan_getMacVlan", "cdecl")
    clx_vlan_getMacVlan.argtypes = [UI32_T, POINTER(CLX_VLAN_MAC_VLAN_ENTRY_T)]
    clx_vlan_getMacVlan.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 713
if _libs["libsai.so"].has("clx_vlan_traverseMacVlanEntry", "cdecl"):
    clx_vlan_traverseMacVlanEntry = _libs["libsai.so"].get("clx_vlan_traverseMacVlanEntry", "cdecl")
    clx_vlan_traverseMacVlanEntry.argtypes = [UI32_T, CLX_VLAN_MAC_VLAN_TRAVERSE_FUNC_T, POINTER(None)]
    clx_vlan_traverseMacVlanEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 735
if _libs["libsai.so"].has("clx_vlan_setProtocolGrp", "cdecl"):
    clx_vlan_setProtocolGrp = _libs["libsai.so"].get("clx_vlan_setProtocolGrp", "cdecl")
    clx_vlan_setProtocolGrp.argtypes = [UI32_T, UI32_T, POINTER(CLX_VLAN_PROTOCOL_GRP_ENTRY_T)]
    clx_vlan_setProtocolGrp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 756
if _libs["libsai.so"].has("clx_vlan_getProtocolGrp", "cdecl"):
    clx_vlan_getProtocolGrp = _libs["libsai.so"].get("clx_vlan_getProtocolGrp", "cdecl")
    clx_vlan_getProtocolGrp.argtypes = [UI32_T, UI32_T, POINTER(CLX_VLAN_PROTOCOL_GRP_ENTRY_T)]
    clx_vlan_getProtocolGrp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 777
if _libs["libsai.so"].has("clx_vlan_setProtocolGrpVlan", "cdecl"):
    clx_vlan_setProtocolGrpVlan = _libs["libsai.so"].get("clx_vlan_setProtocolGrpVlan", "cdecl")
    clx_vlan_setProtocolGrpVlan.argtypes = [UI32_T, POINTER(CLX_VLAN_PROTOCOL_GRP_VLAN_ENTRY_T)]
    clx_vlan_setProtocolGrpVlan.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 797
if _libs["libsai.so"].has("clx_vlan_getProtocolGrpVlan", "cdecl"):
    clx_vlan_getProtocolGrpVlan = _libs["libsai.so"].get("clx_vlan_getProtocolGrpVlan", "cdecl")
    clx_vlan_getProtocolGrpVlan.argtypes = [UI32_T, POINTER(CLX_VLAN_PROTOCOL_GRP_VLAN_ENTRY_T)]
    clx_vlan_getProtocolGrpVlan.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 819
if _libs["libsai.so"].has("clx_vlan_setSubnetVlan", "cdecl"):
    clx_vlan_setSubnetVlan = _libs["libsai.so"].get("clx_vlan_setSubnetVlan", "cdecl")
    clx_vlan_setSubnetVlan.argtypes = [UI32_T, UI32_T, POINTER(CLX_VLAN_SUBNET_VLAN_ENTRY_T)]
    clx_vlan_setSubnetVlan.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 841
if _libs["libsai.so"].has("clx_vlan_getSubnetVlan", "cdecl"):
    clx_vlan_getSubnetVlan = _libs["libsai.so"].get("clx_vlan_getSubnetVlan", "cdecl")
    clx_vlan_getSubnetVlan.argtypes = [UI32_T, UI32_T, POINTER(CLX_VLAN_SUBNET_VLAN_ENTRY_T)]
    clx_vlan_getSubnetVlan.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 863
if _libs["libsai.so"].has("clx_vlan_setTypeEntry", "cdecl"):
    clx_vlan_setTypeEntry = _libs["libsai.so"].get("clx_vlan_setTypeEntry", "cdecl")
    clx_vlan_setTypeEntry.argtypes = [UI32_T, UI32_T, POINTER(CLX_VLAN_CLASSIFY_TYPE_T), POINTER(CLX_VLAN_TAG_ACTION_T)]
    clx_vlan_setTypeEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 886
if _libs["libsai.so"].has("clx_vlan_getTypeEntry", "cdecl"):
    clx_vlan_getTypeEntry = _libs["libsai.so"].get("clx_vlan_getTypeEntry", "cdecl")
    clx_vlan_getTypeEntry.argtypes = [UI32_T, UI32_T, POINTER(CLX_VLAN_CLASSIFY_TYPE_T), POINTER(CLX_VLAN_TAG_ACTION_T)]
    clx_vlan_getTypeEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 910
if _libs["libsai.so"].has("clx_vlan_setAddrEntry", "cdecl"):
    clx_vlan_setAddrEntry = _libs["libsai.so"].get("clx_vlan_setAddrEntry", "cdecl")
    clx_vlan_setAddrEntry.argtypes = [UI32_T, UI32_T, POINTER(CLX_VLAN_CLASSIFY_ADDR_T), POINTER(CLX_VLAN_TAG_ACTION_T)]
    clx_vlan_setAddrEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 933
if _libs["libsai.so"].has("clx_vlan_getAddrEntry", "cdecl"):
    clx_vlan_getAddrEntry = _libs["libsai.so"].get("clx_vlan_getAddrEntry", "cdecl")
    clx_vlan_getAddrEntry.argtypes = [UI32_T, UI32_T, POINTER(CLX_VLAN_CLASSIFY_ADDR_T), POINTER(CLX_VLAN_TAG_ACTION_T)]
    clx_vlan_getAddrEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 956
if _libs["libsai.so"].has("clx_vlan_addPvlanEntry", "cdecl"):
    clx_vlan_addPvlanEntry = _libs["libsai.so"].get("clx_vlan_addPvlanEntry", "cdecl")
    clx_vlan_addPvlanEntry.argtypes = [UI32_T, CLX_VLAN_T, POINTER(CLX_VLAN_PVLAN_ENTRY_T)]
    clx_vlan_addPvlanEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 977
if _libs["libsai.so"].has("clx_vlan_delPvlanEntry", "cdecl"):
    clx_vlan_delPvlanEntry = _libs["libsai.so"].get("clx_vlan_delPvlanEntry", "cdecl")
    clx_vlan_delPvlanEntry.argtypes = [UI32_T, CLX_VLAN_T]
    clx_vlan_delPvlanEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 997
if _libs["libsai.so"].has("clx_vlan_getPvlanEntry", "cdecl"):
    clx_vlan_getPvlanEntry = _libs["libsai.so"].get("clx_vlan_getPvlanEntry", "cdecl")
    clx_vlan_getPvlanEntry.argtypes = [UI32_T, CLX_VLAN_T, POINTER(CLX_VLAN_PVLAN_ENTRY_T)]
    clx_vlan_getPvlanEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 1026
if _libs["libsai.so"].has("clx_vlan_mapBridgeDomain", "cdecl"):
    clx_vlan_mapBridgeDomain = _libs["libsai.so"].get("clx_vlan_mapBridgeDomain", "cdecl")
    clx_vlan_mapBridgeDomain.argtypes = [UI32_T, UI32_T, CLX_BRIDGE_DOMAIN_T, CLX_VLAN_TAG_TYPE_T, CLX_VLAN_T, CLX_VLAN_T]
    clx_vlan_mapBridgeDomain.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 1056
if _libs["libsai.so"].has("clx_vlan_unmapBridgeDomain", "cdecl"):
    clx_vlan_unmapBridgeDomain = _libs["libsai.so"].get("clx_vlan_unmapBridgeDomain", "cdecl")
    clx_vlan_unmapBridgeDomain.argtypes = [UI32_T, UI32_T, CLX_BRIDGE_DOMAIN_T, CLX_VLAN_TAG_TYPE_T, CLX_VLAN_T, CLX_VLAN_T]
    clx_vlan_unmapBridgeDomain.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vlan.h: 1085
if _libs["libsai.so"].has("clx_vlan_getBridgeDomainMap", "cdecl"):
    clx_vlan_getBridgeDomainMap = _libs["libsai.so"].get("clx_vlan_getBridgeDomainMap", "cdecl")
    clx_vlan_getBridgeDomainMap.argtypes = [UI32_T, UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(CLX_VLAN_TAG_TYPE_T), POINTER(CLX_VLAN_T), POINTER(CLX_VLAN_T)]
    clx_vlan_getBridgeDomainMap.restype = CLX_ERROR_NO_T

CLX_VM_ID_T = UI32_T# ./clx_system/clx_sdk/include/clx_vm.h: 62

enum_anon_49 = c_int# ./clx_system/clx_sdk/include/clx_vm.h: 73

CLX_VM_NORMAL_MODE = 0# ./clx_system/clx_sdk/include/clx_vm.h: 73

CLX_VM_CB_MODE = (CLX_VM_NORMAL_MODE + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 73

CLX_VM_BASE_PE_MODE = (CLX_VM_CB_MODE + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 73

CLX_VM_AGGRE_PE_MODE = (CLX_VM_BASE_PE_MODE + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 73

CLX_VM_IV_MODE = (CLX_VM_AGGRE_PE_MODE + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 73

CLX_VM_MODE_LAST = (CLX_VM_IV_MODE + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 73

CLX_VM_MODE_T = enum_anon_49# ./clx_system/clx_sdk/include/clx_vm.h: 73

enum_anon_50 = c_int# ./clx_system/clx_sdk/include/clx_vm.h: 87

CLX_VM_PORT_TYPE_NORMAL = 0# ./clx_system/clx_sdk/include/clx_vm.h: 87

CLX_VM_PORT_TYPE_1BR_UPSTREAM = (CLX_VM_PORT_TYPE_NORMAL + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 87

CLX_VM_PORT_TYPE_1BR_CASCADE = (CLX_VM_PORT_TYPE_1BR_UPSTREAM + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 87

CLX_VM_PORT_TYPE_1BR_EXTENDED = (CLX_VM_PORT_TYPE_1BR_CASCADE + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 87

CLX_VM_PORT_TYPE_NIV_UPSTREAM = (CLX_VM_PORT_TYPE_1BR_EXTENDED + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 87

CLX_VM_PORT_TYPE_NIV_CASCADE = (CLX_VM_PORT_TYPE_NIV_UPSTREAM + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 87

CLX_VM_PORT_TYPE_NIV_EXTENDED = (CLX_VM_PORT_TYPE_NIV_CASCADE + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 87

CLX_VM_PORT_TYPE_VEPA = (CLX_VM_PORT_TYPE_NIV_EXTENDED + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 87

CLX_VM_PORT_TYPE_LAST = (CLX_VM_PORT_TYPE_VEPA + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 87

CLX_VM_PORT_TYPE_T = enum_anon_50# ./clx_system/clx_sdk/include/clx_vm.h: 87

enum_anon_51 = c_int# ./clx_system/clx_sdk/include/clx_vm.h: 96

CLX_VM_TAG_TYPE_ETAG = 1# ./clx_system/clx_sdk/include/clx_vm.h: 96

CLX_VM_TAG_TYPE_VNTAG = (CLX_VM_TAG_TYPE_ETAG + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 96

CLX_VM_TAG_TYPE_VEPA = (CLX_VM_TAG_TYPE_VNTAG + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 96

CLX_VM_TAG_TYPE_LAST = (CLX_VM_TAG_TYPE_VEPA + 1)# ./clx_system/clx_sdk/include/clx_vm.h: 96

CLX_VM_TAG_TYPE_T = enum_anon_51# ./clx_system/clx_sdk/include/clx_vm.h: 96

# ./clx_system/clx_sdk/include/clx_vm.h: 108
class struct_CLX_VM_PORT_PRTY_S(Structure):
    pass

struct_CLX_VM_PORT_PRTY_S.__slots__ = [
    'port_type',
    'tag_miss_action',
    'rpf_fail_action',
    'pcid',
    'flags',
]
struct_CLX_VM_PORT_PRTY_S._fields_ = [
    ('port_type', CLX_VM_PORT_TYPE_T),
    ('tag_miss_action', CLX_FWD_ACTION_T),
    ('rpf_fail_action', CLX_FWD_ACTION_T),
    ('pcid', CLX_VM_ID_T),
    ('flags', UI32_T),
]

CLX_VM_PORT_PRTY_T = struct_CLX_VM_PORT_PRTY_S# ./clx_system/clx_sdk/include/clx_vm.h: 108

# ./clx_system/clx_sdk/include/clx_vm.h: 119
class struct_CLX_VM_PE_UCAST_ADDR_S(Structure):
    pass

struct_CLX_VM_PE_UCAST_ADDR_S.__slots__ = [
    'vm_id',
    'vm_tag_type',
    'src_port',
    'dst_port',
    'flags',
]
struct_CLX_VM_PE_UCAST_ADDR_S._fields_ = [
    ('vm_id', CLX_VM_ID_T),
    ('vm_tag_type', CLX_VM_TAG_TYPE_T),
    ('src_port', CLX_PORT_T),
    ('dst_port', CLX_PORT_T),
    ('flags', UI32_T),
]

CLX_VM_PE_UCAST_ADDR_T = struct_CLX_VM_PE_UCAST_ADDR_S# ./clx_system/clx_sdk/include/clx_vm.h: 119

# ./clx_system/clx_sdk/include/clx_vm.h: 131
class struct_CLX_VM_PE_MCAST_ADDR_S(Structure):
    pass

struct_CLX_VM_PE_MCAST_ADDR_S.__slots__ = [
    'vm_id',
    'vm_tag_type',
    'src_port',
    'mcast_id',
    'dst_port_bitmap',
    'flags',
]
struct_CLX_VM_PE_MCAST_ADDR_S._fields_ = [
    ('vm_id', CLX_VM_ID_T),
    ('vm_tag_type', CLX_VM_TAG_TYPE_T),
    ('src_port', CLX_PORT_T),
    ('mcast_id', UI32_T),
    ('dst_port_bitmap', CLX_PORT_BITMAP_T),
    ('flags', UI32_T),
]

CLX_VM_PE_MCAST_ADDR_T = struct_CLX_VM_PE_MCAST_ADDR_S# ./clx_system/clx_sdk/include/clx_vm.h: 131

# ./clx_system/clx_sdk/include/clx_vm.h: 152
if _libs["libsai.so"].has("clx_vm_setVmMode", "cdecl"):
    clx_vm_setVmMode = _libs["libsai.so"].get("clx_vm_setVmMode", "cdecl")
    clx_vm_setVmMode.argtypes = [UI32_T, CLX_VM_MODE_T]
    clx_vm_setVmMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 171
if _libs["libsai.so"].has("clx_vm_getVmMode", "cdecl"):
    clx_vm_getVmMode = _libs["libsai.so"].get("clx_vm_getVmMode", "cdecl")
    clx_vm_getVmMode.argtypes = [UI32_T, POINTER(CLX_VM_MODE_T)]
    clx_vm_getVmMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 194
if _libs["libsai.so"].has("clx_vm_createPort", "cdecl"):
    clx_vm_createPort = _libs["libsai.so"].get("clx_vm_createPort", "cdecl")
    clx_vm_createPort.argtypes = [UI32_T, CLX_PORT_T, CLX_VM_ID_T, CLX_VM_TAG_TYPE_T, POINTER(CLX_PORT_T)]
    clx_vm_createPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 217
if _libs["libsai.so"].has("clx_vm_destroyPort", "cdecl"):
    clx_vm_destroyPort = _libs["libsai.so"].get("clx_vm_destroyPort", "cdecl")
    clx_vm_destroyPort.argtypes = [UI32_T, CLX_PORT_T]
    clx_vm_destroyPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 239
if _libs["libsai.so"].has("clx_vm_getPort", "cdecl"):
    clx_vm_getPort = _libs["libsai.so"].get("clx_vm_getPort", "cdecl")
    clx_vm_getPort.argtypes = [UI32_T, CLX_PORT_T, CLX_VM_ID_T, CLX_VM_TAG_TYPE_T, POINTER(CLX_PORT_T)]
    clx_vm_getPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 264
if _libs["libsai.so"].has("clx_vm_getKey", "cdecl"):
    clx_vm_getKey = _libs["libsai.so"].get("clx_vm_getKey", "cdecl")
    clx_vm_getKey.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_PORT_T), POINTER(CLX_VM_ID_T), POINTER(CLX_VM_TAG_TYPE_T)]
    clx_vm_getKey.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 287
if _libs["libsai.so"].has("clx_vm_setUpstreamPort", "cdecl"):
    clx_vm_setUpstreamPort = _libs["libsai.so"].get("clx_vm_setUpstreamPort", "cdecl")
    clx_vm_setUpstreamPort.argtypes = [UI32_T, CLX_PORT_T, CLX_PORT_T]
    clx_vm_setUpstreamPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 307
if _libs["libsai.so"].has("clx_vm_resetUpstreamPort", "cdecl"):
    clx_vm_resetUpstreamPort = _libs["libsai.so"].get("clx_vm_resetUpstreamPort", "cdecl")
    clx_vm_resetUpstreamPort.argtypes = [UI32_T, CLX_PORT_T]
    clx_vm_resetUpstreamPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 326
if _libs["libsai.so"].has("clx_vm_getUpstreamPort", "cdecl"):
    clx_vm_getUpstreamPort = _libs["libsai.so"].get("clx_vm_getUpstreamPort", "cdecl")
    clx_vm_getUpstreamPort.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_PORT_T)]
    clx_vm_getUpstreamPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 347
if _libs["libsai.so"].has("clx_vm_setPortProperty", "cdecl"):
    clx_vm_setPortProperty = _libs["libsai.so"].get("clx_vm_setPortProperty", "cdecl")
    clx_vm_setPortProperty.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_VM_PORT_PRTY_T)]
    clx_vm_setPortProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 367
if _libs["libsai.so"].has("clx_vm_getPortProperty", "cdecl"):
    clx_vm_getPortProperty = _libs["libsai.so"].get("clx_vm_getPortProperty", "cdecl")
    clx_vm_getPortProperty.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_VM_PORT_PRTY_T)]
    clx_vm_getPortProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 389
if _libs["libsai.so"].has("clx_vm_pe_addUcastAddr", "cdecl"):
    clx_vm_pe_addUcastAddr = _libs["libsai.so"].get("clx_vm_pe_addUcastAddr", "cdecl")
    clx_vm_pe_addUcastAddr.argtypes = [UI32_T, POINTER(CLX_VM_PE_UCAST_ADDR_T)]
    clx_vm_pe_addUcastAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 409
if _libs["libsai.so"].has("clx_vm_pe_delUcastAddr", "cdecl"):
    clx_vm_pe_delUcastAddr = _libs["libsai.so"].get("clx_vm_pe_delUcastAddr", "cdecl")
    clx_vm_pe_delUcastAddr.argtypes = [UI32_T, POINTER(CLX_VM_PE_UCAST_ADDR_T)]
    clx_vm_pe_delUcastAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 429
if _libs["libsai.so"].has("clx_vm_pe_getUcastAddr", "cdecl"):
    clx_vm_pe_getUcastAddr = _libs["libsai.so"].get("clx_vm_pe_getUcastAddr", "cdecl")
    clx_vm_pe_getUcastAddr.argtypes = [UI32_T, POINTER(CLX_VM_PE_UCAST_ADDR_T)]
    clx_vm_pe_getUcastAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 450
if _libs["libsai.so"].has("clx_vm_pe_addMcastAddr", "cdecl"):
    clx_vm_pe_addMcastAddr = _libs["libsai.so"].get("clx_vm_pe_addMcastAddr", "cdecl")
    clx_vm_pe_addMcastAddr.argtypes = [UI32_T, POINTER(CLX_VM_PE_MCAST_ADDR_T)]
    clx_vm_pe_addMcastAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 470
if _libs["libsai.so"].has("clx_vm_pe_delMcastAddr", "cdecl"):
    clx_vm_pe_delMcastAddr = _libs["libsai.so"].get("clx_vm_pe_delMcastAddr", "cdecl")
    clx_vm_pe_delMcastAddr.argtypes = [UI32_T, POINTER(CLX_VM_PE_MCAST_ADDR_T)]
    clx_vm_pe_delMcastAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 490
if _libs["libsai.so"].has("clx_vm_pe_getMcastAddr", "cdecl"):
    clx_vm_pe_getMcastAddr = _libs["libsai.so"].get("clx_vm_pe_getMcastAddr", "cdecl")
    clx_vm_pe_getMcastAddr.argtypes = [UI32_T, POINTER(CLX_VM_PE_MCAST_ADDR_T)]
    clx_vm_pe_getMcastAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 511
if _libs["libsai.so"].has("clx_vm_pe_addMcastMemberPort", "cdecl"):
    clx_vm_pe_addMcastMemberPort = _libs["libsai.so"].get("clx_vm_pe_addMcastMemberPort", "cdecl")
    clx_vm_pe_addMcastMemberPort.argtypes = [UI32_T, POINTER(CLX_VM_PE_MCAST_ADDR_T)]
    clx_vm_pe_addMcastMemberPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 532
if _libs["libsai.so"].has("clx_vm_pe_delMcastMemberPort", "cdecl"):
    clx_vm_pe_delMcastMemberPort = _libs["libsai.so"].get("clx_vm_pe_delMcastMemberPort", "cdecl")
    clx_vm_pe_delMcastMemberPort.argtypes = [UI32_T, POINTER(CLX_VM_PE_MCAST_ADDR_T)]
    clx_vm_pe_delMcastMemberPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 556
if _libs["libsai.so"].has("clx_vm_addMcastIntfProperty", "cdecl"):
    clx_vm_addMcastIntfProperty = _libs["libsai.so"].get("clx_vm_addMcastIntfProperty", "cdecl")
    clx_vm_addMcastIntfProperty.argtypes = [UI32_T, CLX_PORT_T, CLX_VM_ID_T, CLX_VM_TAG_TYPE_T, POINTER(CLX_PORT_INTF_PROPERTY_T)]
    clx_vm_addMcastIntfProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 581
if _libs["libsai.so"].has("clx_vm_delMcastIntfProperty", "cdecl"):
    clx_vm_delMcastIntfProperty = _libs["libsai.so"].get("clx_vm_delMcastIntfProperty", "cdecl")
    clx_vm_delMcastIntfProperty.argtypes = [UI32_T, CLX_PORT_T, CLX_VM_ID_T, CLX_VM_TAG_TYPE_T]
    clx_vm_delMcastIntfProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 605
if _libs["libsai.so"].has("clx_vm_getMcastIntfProperty", "cdecl"):
    clx_vm_getMcastIntfProperty = _libs["libsai.so"].get("clx_vm_getMcastIntfProperty", "cdecl")
    clx_vm_getMcastIntfProperty.argtypes = [UI32_T, CLX_PORT_T, CLX_VM_ID_T, CLX_VM_TAG_TYPE_T, POINTER(CLX_PORT_INTF_PROPERTY_T)]
    clx_vm_getMcastIntfProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 635
if _libs["libsai.so"].has("clx_vm_addMcastSegService", "cdecl"):
    clx_vm_addMcastSegService = _libs["libsai.so"].get("clx_vm_addMcastSegService", "cdecl")
    clx_vm_addMcastSegService.argtypes = [UI32_T, CLX_PORT_T, CLX_VM_ID_T, CLX_VM_TAG_TYPE_T, UI32_T, UI32_T, POINTER(CLX_PORT_SEG_SRV_T)]
    clx_vm_addMcastSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 666
if _libs["libsai.so"].has("clx_vm_delMcastSegService", "cdecl"):
    clx_vm_delMcastSegService = _libs["libsai.so"].get("clx_vm_delMcastSegService", "cdecl")
    clx_vm_delMcastSegService.argtypes = [UI32_T, CLX_PORT_T, CLX_VM_ID_T, CLX_VM_TAG_TYPE_T, UI32_T, UI32_T]
    clx_vm_delMcastSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_vm.h: 696
if _libs["libsai.so"].has("clx_vm_getMcastSegService", "cdecl"):
    clx_vm_getMcastSegService = _libs["libsai.so"].get("clx_vm_getMcastSegService", "cdecl")
    clx_vm_getMcastSegService.argtypes = [UI32_T, CLX_PORT_T, CLX_VM_ID_T, CLX_VM_TAG_TYPE_T, UI32_T, UI32_T, POINTER(CLX_PORT_SEG_SRV_T)]
    clx_vm_getMcastSegService.restype = CLX_ERROR_NO_T

enum_anon_52 = c_int# ./clx_system/clx_sdk/include/clx_l3.h: 79

CLX_L3_URPF_CHECK_MODE_DISABLED = 0# ./clx_system/clx_sdk/include/clx_l3.h: 79

CLX_L3_URPF_CHECK_MODE_STRICT = (CLX_L3_URPF_CHECK_MODE_DISABLED + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 79

CLX_L3_URPF_CHECK_MODE_LOOSE = (CLX_L3_URPF_CHECK_MODE_STRICT + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 79

CLX_L3_URPF_CHECK_MODE_LOOSE_IGNORE_DEFAULT = (CLX_L3_URPF_CHECK_MODE_LOOSE + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 79

CLX_L3_URPF_CHECK_MODE_LAST = (CLX_L3_URPF_CHECK_MODE_LOOSE_IGNORE_DEFAULT + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 79

CLX_L3_URPF_CHECK_MODE_T = enum_anon_52# ./clx_system/clx_sdk/include/clx_l3.h: 79

enum_anon_53 = c_int# ./clx_system/clx_sdk/include/clx_l3.h: 89

CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_DROP = 0# ./clx_system/clx_sdk/include/clx_l3.h: 89

CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_SEND2CPU = (CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_DROP + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 89

CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_L2MC_LOOKUP = (CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_SEND2CPU + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 89

CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_NONE = (CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_L2MC_LOOKUP + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 89

CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_LAST = (CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_NONE + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 89

CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_T = enum_anon_53# ./clx_system/clx_sdk/include/clx_l3.h: 89

enum_anon_54 = c_int# ./clx_system/clx_sdk/include/clx_l3.h: 99

CLX_L3_MCAST_LOOKUP_MISS_ACTION_DROP = 0# ./clx_system/clx_sdk/include/clx_l3.h: 99

CLX_L3_MCAST_LOOKUP_MISS_ACTION_SEND2CPU = (CLX_L3_MCAST_LOOKUP_MISS_ACTION_DROP + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 99

CLX_L3_MCAST_LOOKUP_MISS_ACTION_L2MC_LOOKUP = (CLX_L3_MCAST_LOOKUP_MISS_ACTION_SEND2CPU + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 99

CLX_L3_MCAST_LOOKUP_MISS_ACTION_FORWARD = (CLX_L3_MCAST_LOOKUP_MISS_ACTION_L2MC_LOOKUP + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 99

CLX_L3_MCAST_LOOKUP_MISS_ACTION_LAST = (CLX_L3_MCAST_LOOKUP_MISS_ACTION_FORWARD + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 99

CLX_L3_MCAST_LOOKUP_MISS_ACTION_T = enum_anon_54# ./clx_system/clx_sdk/include/clx_l3.h: 99

enum_anon_55 = c_int# ./clx_system/clx_sdk/include/clx_l3.h: 112

CLX_L3_MCAST_EGR_INTF_TYPE_L3 = 0# ./clx_system/clx_sdk/include/clx_l3.h: 112

CLX_L3_MCAST_EGR_INTF_TYPE_VM_1BR = (CLX_L3_MCAST_EGR_INTF_TYPE_L3 + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 112

CLX_L3_MCAST_EGR_INTF_TYPE_VM_NIV = (CLX_L3_MCAST_EGR_INTF_TYPE_VM_1BR + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 112

CLX_L3_MCAST_EGR_INTF_TYPE_VM_VEPA = (CLX_L3_MCAST_EGR_INTF_TYPE_VM_NIV + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 112

CLX_L3_MCAST_EGR_INTF_TYPE_NV = (CLX_L3_MCAST_EGR_INTF_TYPE_VM_VEPA + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 112

CLX_L3_MCAST_EGR_INTF_TYPE_TRILL = (CLX_L3_MCAST_EGR_INTF_TYPE_NV + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 112

CLX_L3_MCAST_EGR_INTF_TYPE_MPLS = (CLX_L3_MCAST_EGR_INTF_TYPE_TRILL + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 112

CLX_L3_MCAST_EGR_INTF_TYPE_LAST = (CLX_L3_MCAST_EGR_INTF_TYPE_MPLS + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 112

CLX_L3_MCAST_EGR_INTF_TYPE_T = enum_anon_55# ./clx_system/clx_sdk/include/clx_l3.h: 112

enum_anon_56 = c_int# ./clx_system/clx_sdk/include/clx_l3.h: 123

CLX_L3_OUTPUT_TYPE_ADJ = 0# ./clx_system/clx_sdk/include/clx_l3.h: 123

CLX_L3_OUTPUT_TYPE_ECMP = (CLX_L3_OUTPUT_TYPE_ADJ + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 123

CLX_L3_OUTPUT_TYPE_NVO3_ADJ = (CLX_L3_OUTPUT_TYPE_ECMP + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 123

CLX_L3_OUTPUT_TYPE_MPLS_LSP = (CLX_L3_OUTPUT_TYPE_NVO3_ADJ + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 123

CLX_L3_OUTPUT_TYPE_MPLS_PW = (CLX_L3_OUTPUT_TYPE_MPLS_LSP + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 123

CLX_L3_OUTPUT_TYPE_LAST = (CLX_L3_OUTPUT_TYPE_MPLS_PW + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 123

CLX_L3_OUTPUT_TYPE_T = enum_anon_56# ./clx_system/clx_sdk/include/clx_l3.h: 123

# ./clx_system/clx_sdk/include/clx_l3.h: 131
class struct_CLX_L3_IP_NETWORK_ADDR_S(Structure):
    pass

struct_CLX_L3_IP_NETWORK_ADDR_S.__slots__ = [
    'ip_addr',
    'ip_mask',
    'ipv4',
]
struct_CLX_L3_IP_NETWORK_ADDR_S._fields_ = [
    ('ip_addr', CLX_IP_T),
    ('ip_mask', CLX_IP_T),
    ('ipv4', BOOL_T),
]

CLX_L3_IP_NETWORK_ADDR_T = struct_CLX_L3_IP_NETWORK_ADDR_S# ./clx_system/clx_sdk/include/clx_l3.h: 131

# ./clx_system/clx_sdk/include/clx_l3.h: 178
class struct_CLX_L3_INTF_INFO_S(Structure):
    pass

struct_CLX_L3_INTF_INFO_S.__slots__ = [
    'intf_id',
    'mac',
    'urpf_mode',
    'vrf_id',
    'flags',
    'igr_mtu_size',
    'egr_mtu_size',
    'ipv4_lookup_miss_action',
    'ipv6_lookup_miss_action',
    'igr_mtu_fail_action',
    'egr_mtu_fail_action',
    'urpf_fail_action',
    'igr_meter_id',
    'egr_meter_id',
    'igr_cnt_id',
    'egr_cnt_id',
    'igr_dist_cnt_id',
    'egr_dist_cnt_id',
    'igr_group_label',
    'egr_group_label',
]
struct_CLX_L3_INTF_INFO_S._fields_ = [
    ('intf_id', UI32_T),
    ('mac', CLX_MAC_T),
    ('urpf_mode', CLX_L3_URPF_CHECK_MODE_T),
    ('vrf_id', UI32_T),
    ('flags', UI32_T),
    ('igr_mtu_size', UI16_T),
    ('egr_mtu_size', UI16_T),
    ('ipv4_lookup_miss_action', CLX_L3_MCAST_LOOKUP_MISS_ACTION_T),
    ('ipv6_lookup_miss_action', CLX_L3_MCAST_LOOKUP_MISS_ACTION_T),
    ('igr_mtu_fail_action', CLX_FWD_ACTION_T),
    ('egr_mtu_fail_action', CLX_FWD_ACTION_T),
    ('urpf_fail_action', CLX_FWD_ACTION_T),
    ('igr_meter_id', UI32_T),
    ('egr_meter_id', UI32_T),
    ('igr_cnt_id', UI32_T),
    ('egr_cnt_id', UI32_T),
    ('igr_dist_cnt_id', UI32_T),
    ('egr_dist_cnt_id', UI32_T),
    ('igr_group_label', UI32_T),
    ('egr_group_label', UI32_T),
]

CLX_L3_INTF_INFO_T = struct_CLX_L3_INTF_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 178

# ./clx_system/clx_sdk/include/clx_l3.h: 201
class struct_CLX_L3_HOST_INFO_S(Structure):
    pass

struct_CLX_L3_HOST_INFO_S.__slots__ = [
    'ip_host_addr',
    'vrf_id',
    'output_type',
    'output_id',
    'tc',
    'flags',
    'group_label',
    'mpls_label',
]
struct_CLX_L3_HOST_INFO_S._fields_ = [
    ('ip_host_addr', CLX_IP_ADDR_T),
    ('vrf_id', UI32_T),
    ('output_type', CLX_L3_OUTPUT_TYPE_T),
    ('output_id', UI32_T),
    ('tc', UI32_T),
    ('flags', UI32_T),
    ('group_label', UI32_T),
    ('mpls_label', UI32_T),
]

CLX_L3_HOST_INFO_T = struct_CLX_L3_HOST_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 201

# ./clx_system/clx_sdk/include/clx_l3.h: 213
class struct_CLX_L3_SUBNET_BCAST_INFO_S(Structure):
    pass

struct_CLX_L3_SUBNET_BCAST_INFO_S.__slots__ = [
    'ip_subnet_addr',
    'vrf_id',
    'mcast_id',
    'group_label',
    'flags',
]
struct_CLX_L3_SUBNET_BCAST_INFO_S._fields_ = [
    ('ip_subnet_addr', CLX_IP_ADDR_T),
    ('vrf_id', UI32_T),
    ('mcast_id', UI32_T),
    ('group_label', UI32_T),
    ('flags', UI32_T),
]

CLX_L3_SUBNET_BCAST_INFO_T = struct_CLX_L3_SUBNET_BCAST_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 213

# ./clx_system/clx_sdk/include/clx_l3.h: 237
class struct_CLX_L3_ROUTE_INFO_S(Structure):
    pass

struct_CLX_L3_ROUTE_INFO_S.__slots__ = [
    'ip_network_addr',
    'vrf_id',
    'output_type',
    'output_id',
    'tc',
    'flags',
    'group_label',
    'mpls_label',
]
struct_CLX_L3_ROUTE_INFO_S._fields_ = [
    ('ip_network_addr', CLX_L3_IP_NETWORK_ADDR_T),
    ('vrf_id', UI32_T),
    ('output_type', CLX_L3_OUTPUT_TYPE_T),
    ('output_id', UI32_T),
    ('tc', UI32_T),
    ('flags', UI32_T),
    ('group_label', UI32_T),
    ('mpls_label', UI32_T),
]

CLX_L3_ROUTE_INFO_T = struct_CLX_L3_ROUTE_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 237

enum_anon_57 = c_int# ./clx_system/clx_sdk/include/clx_l3.h: 253

CLX_L3_ECMP_MODE_TYPE_HW = 0# ./clx_system/clx_sdk/include/clx_l3.h: 253

CLX_L3_ECMP_MODE_TYPE_SW = (CLX_L3_ECMP_MODE_TYPE_HW + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 253

CLX_L3_ECMP_MODE_TYPE_LAST = (CLX_L3_ECMP_MODE_TYPE_SW + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 253

CLX_L3_ECMP_MODE_TYPE_T = enum_anon_57# ./clx_system/clx_sdk/include/clx_l3.h: 253

# ./clx_system/clx_sdk/include/clx_l3.h: 268
class struct_CLX_L3_ECMP_GRP_SW_MODE_INFO_S(Structure):
    pass

struct_CLX_L3_ECMP_GRP_SW_MODE_INFO_S.__slots__ = [
    'sw_hash_val_cnt',
]
struct_CLX_L3_ECMP_GRP_SW_MODE_INFO_S._fields_ = [
    ('sw_hash_val_cnt', UI32_T),
]

CLX_L3_ECMP_GRP_SW_MODE_INFO_T = struct_CLX_L3_ECMP_GRP_SW_MODE_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 268

# ./clx_system/clx_sdk/include/clx_l3.h: 280
class struct_CLX_L3_ECMP_DLB_CFG_S(Structure):
    pass

struct_CLX_L3_ECMP_DLB_CFG_S.__slots__ = [
    'flags',
    'et_id',
]
struct_CLX_L3_ECMP_DLB_CFG_S._fields_ = [
    ('flags', UI32_T),
    ('et_id', UI32_T),
]

CLX_L3_ECMP_DLB_CFG_T = struct_CLX_L3_ECMP_DLB_CFG_S# ./clx_system/clx_sdk/include/clx_l3.h: 280

# ./clx_system/clx_sdk/include/clx_l3.h: 296
class struct_CLX_L3_ECMP_HASH_CFG_S(Structure):
    pass

struct_CLX_L3_ECMP_HASH_CFG_S.__slots__ = [
    'hash_mode',
    'sw_mode_info',
]
struct_CLX_L3_ECMP_HASH_CFG_S._fields_ = [
    ('hash_mode', CLX_L3_ECMP_MODE_TYPE_T),
    ('sw_mode_info', CLX_L3_ECMP_GRP_SW_MODE_INFO_T),
]

CLX_L3_ECMP_HASH_CFG_T = struct_CLX_L3_ECMP_HASH_CFG_S# ./clx_system/clx_sdk/include/clx_l3.h: 296

# ./clx_system/clx_sdk/include/clx_l3.h: 317
class struct_CLX_L3_ECMP_GRP_INFO_S(Structure):
    pass

struct_CLX_L3_ECMP_GRP_INFO_S.__slots__ = [
    'type',
    'path_cnt',
    'weight_cnt',
    'hash_cfg',
    'dlb_cfg',
    'flags',
]
struct_CLX_L3_ECMP_GRP_INFO_S._fields_ = [
    ('type', CLX_L3_OUTPUT_TYPE_T),
    ('path_cnt', UI32_T),
    ('weight_cnt', UI32_T),
    ('hash_cfg', CLX_L3_ECMP_HASH_CFG_T),
    ('dlb_cfg', CLX_L3_ECMP_DLB_CFG_T),
    ('flags', UI32_T),
]

CLX_L3_ECMP_GRP_INFO_T = struct_CLX_L3_ECMP_GRP_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 317

# ./clx_system/clx_sdk/include/clx_l3.h: 333
class struct_CLX_L3_ECMP_PATH_INFO_S(Structure):
    pass

struct_CLX_L3_ECMP_PATH_INFO_S.__slots__ = [
    'type',
    'output_path_id',
    'monitor_id',
    'frr_state_id',
    'mpls_label',
    'weight',
    'flags',
]
struct_CLX_L3_ECMP_PATH_INFO_S._fields_ = [
    ('type', CLX_L3_OUTPUT_TYPE_T),
    ('output_path_id', UI32_T),
    ('monitor_id', UI32_T),
    ('frr_state_id', UI32_T),
    ('mpls_label', UI32_T),
    ('weight', UI32_T),
    ('flags', UI32_T),
]

CLX_L3_ECMP_PATH_INFO_T = struct_CLX_L3_ECMP_PATH_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 333

# ./clx_system/clx_sdk/include/clx_l3.h: 342
class struct_CLX_L3_ROUTER_MAC_INFO_S(Structure):
    pass

struct_CLX_L3_ROUTER_MAC_INFO_S.__slots__ = [
    'mac',
    'mac_mask',
    'intf_id',
    'intf_id_mask',
]
struct_CLX_L3_ROUTER_MAC_INFO_S._fields_ = [
    ('mac', CLX_MAC_T),
    ('mac_mask', CLX_MAC_T),
    ('intf_id', UI32_T),
    ('intf_id_mask', UI32_T),
]

CLX_L3_ROUTER_MAC_INFO_T = struct_CLX_L3_ROUTER_MAC_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 342

# ./clx_system/clx_sdk/include/clx_l3.h: 367
class struct_CLX_L3_VRF_INFO_S(Structure):
    pass

struct_CLX_L3_VRF_INFO_S.__slots__ = [
    'option_header_action',
    'lkp_miss_action',
    'ttl0_action',
    'ttl1_action',
    'meter_id',
    'cnt_id',
    'dist_cnt_id',
    'color_resolve_type',
    'group_label',
    'flags',
]
struct_CLX_L3_VRF_INFO_S._fields_ = [
    ('option_header_action', CLX_FWD_ACTION_T),
    ('lkp_miss_action', CLX_FWD_ACTION_T),
    ('ttl0_action', CLX_FWD_ACTION_T),
    ('ttl1_action', CLX_FWD_ACTION_T),
    ('meter_id', UI32_T),
    ('cnt_id', UI32_T),
    ('dist_cnt_id', UI32_T),
    ('color_resolve_type', CLX_METER_COLOR_RESOLVE_TYPE_T),
    ('group_label', UI32_T),
    ('flags', UI32_T),
]

CLX_L3_VRF_INFO_T = struct_CLX_L3_VRF_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 367

# ./clx_system/clx_sdk/include/clx_l3.h: 428
class struct_CLX_L3_MCAST_GROUP_INFO_S(Structure):
    pass

struct_CLX_L3_MCAST_GROUP_INFO_S.__slots__ = [
    'vrf_id',
    'src_ip',
    'grp_ip',
    'mcast_id',
    'flags',
    'rp_addr',
    'mrpf_check_fail_action',
    'rpf_intf_id',
    'group_label',
]
struct_CLX_L3_MCAST_GROUP_INFO_S._fields_ = [
    ('vrf_id', UI32_T),
    ('src_ip', CLX_IP_ADDR_T),
    ('grp_ip', CLX_IP_ADDR_T),
    ('mcast_id', UI32_T),
    ('flags', UI32_T),
    ('rp_addr', CLX_IP_ADDR_T),
    ('mrpf_check_fail_action', CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_T),
    ('rpf_intf_id', UI32_T),
    ('group_label', UI32_T),
]

CLX_L3_MCAST_GROUP_INFO_T = struct_CLX_L3_MCAST_GROUP_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 428

# ./clx_system/clx_sdk/include/clx_l3.h: 436
class struct_CLX_L3_MCAST_EGR_INTF_NV_S(Structure):
    pass

struct_CLX_L3_MCAST_EGR_INTF_NV_S.__slots__ = [
    'tunnel_key',
    'port',
    'nvo3_adj_id',
]
struct_CLX_L3_MCAST_EGR_INTF_NV_S._fields_ = [
    ('tunnel_key', CLX_TUNNEL_KEY_T),
    ('port', CLX_PORT_T),
    ('nvo3_adj_id', UI32_T),
]

CLX_L3_MCAST_EGR_INTF_NV_T = struct_CLX_L3_MCAST_EGR_INTF_NV_S# ./clx_system/clx_sdk/include/clx_l3.h: 436

# ./clx_system/clx_sdk/include/clx_l3.h: 443
class struct_CLX_L3_MCAST_EGR_INTF_TRILL_S(Structure):
    pass

struct_CLX_L3_MCAST_EGR_INTF_TRILL_S.__slots__ = [
    'egr_nickname',
    'nvo3_adj_id',
]
struct_CLX_L3_MCAST_EGR_INTF_TRILL_S._fields_ = [
    ('egr_nickname', CLX_TRILL_NICKNAME_T),
    ('nvo3_adj_id', UI32_T),
]

CLX_L3_MCAST_EGR_INTF_TRILL_T = struct_CLX_L3_MCAST_EGR_INTF_TRILL_S# ./clx_system/clx_sdk/include/clx_l3.h: 443

# ./clx_system/clx_sdk/include/clx_l3.h: 455
class struct_CLX_L3_MCAST_EGR_INTF_MPLS_S(Structure):
    pass

struct_CLX_L3_MCAST_EGR_INTF_MPLS_S.__slots__ = [
    'mpls_label',
    'port',
    'nvo3_adj_id',
    'flags',
]
struct_CLX_L3_MCAST_EGR_INTF_MPLS_S._fields_ = [
    ('mpls_label', UI32_T),
    ('port', CLX_PORT_T),
    ('nvo3_adj_id', UI32_T),
    ('flags', UI32_T),
]

CLX_L3_MCAST_EGR_INTF_MPLS_T = struct_CLX_L3_MCAST_EGR_INTF_MPLS_S# ./clx_system/clx_sdk/include/clx_l3.h: 455

# ./clx_system/clx_sdk/include/clx_l3.h: 466
class union_anon_58(Union):
    pass

union_anon_58.__slots__ = [
    'vm_id',
    'nv',
    'trill',
    'mpls',
]
union_anon_58._fields_ = [
    ('vm_id', UI32_T),
    ('nv', CLX_L3_MCAST_EGR_INTF_NV_T),
    ('trill', CLX_L3_MCAST_EGR_INTF_TRILL_T),
    ('mpls', CLX_L3_MCAST_EGR_INTF_MPLS_T),
]

# ./clx_system/clx_sdk/include/clx_l3.h: 480
class struct_CLX_L3_MCAST_EGR_INTF_S(Structure):
    pass

struct_CLX_L3_MCAST_EGR_INTF_S.__slots__ = [
    'intf_type',
    'intf_id',
    'vlan_action',
    'svid',
    'cvid',
    'dmac',
    'unnamed_1',
    'flags',
]
struct_CLX_L3_MCAST_EGR_INTF_S._anonymous_ = [
    'unnamed_1',
]
struct_CLX_L3_MCAST_EGR_INTF_S._fields_ = [
    ('intf_type', CLX_L3_MCAST_EGR_INTF_TYPE_T),
    ('intf_id', UI32_T),
    ('vlan_action', CLX_VLAN_ACTION_T),
    ('svid', CLX_VLAN_T),
    ('cvid', CLX_VLAN_T),
    ('dmac', CLX_MAC_T),
    ('unnamed_1', union_anon_58),
    ('flags', UI32_T),
]

CLX_L3_MCAST_EGR_INTF_T = struct_CLX_L3_MCAST_EGR_INTF_S# ./clx_system/clx_sdk/include/clx_l3.h: 480

# ./clx_system/clx_sdk/include/clx_l3.h: 498
class struct_CLX_L3_BFD_INFO_S(Structure):
    pass

struct_CLX_L3_BFD_INFO_S.__slots__ = [
    's_hop_port',
    'm_hop_port',
    'echo_port',
    'flags',
]
struct_CLX_L3_BFD_INFO_S._fields_ = [
    ('s_hop_port', UI32_T),
    ('m_hop_port', UI32_T),
    ('echo_port', UI32_T),
    ('flags', UI32_T),
]

CLX_L3_BFD_INFO_T = struct_CLX_L3_BFD_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 498

enum_CLX_L3_ADJ_TYPE_E = c_int# ./clx_system/clx_sdk/include/clx_l3.h: 506

CLX_L3_ADJ_TYPE_L3 = 0# ./clx_system/clx_sdk/include/clx_l3.h: 506

CLX_L3_ADJ_TYPE_NVO3 = (CLX_L3_ADJ_TYPE_L3 + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 506

CLX_L3_ADJ_TYPE_LAST = (CLX_L3_ADJ_TYPE_NVO3 + 1)# ./clx_system/clx_sdk/include/clx_l3.h: 506

CLX_L3_ADJ_TYPE_T = enum_CLX_L3_ADJ_TYPE_E# ./clx_system/clx_sdk/include/clx_l3.h: 506

# ./clx_system/clx_sdk/include/clx_l3.h: 546
class struct_CLX_L3_ADJ_INFO_S(Structure):
    pass

struct_CLX_L3_ADJ_INFO_S.__slots__ = [
    'adj_type',
    'dst_mac',
    'intf_id',
    'src_mac',
    'svid',
    'cvid',
    'flags',
    'port',
    's_tpid',
    'c_tpid',
    'mtu_size',
    'frr_backup_path',
    'frr_state_id',
    'seg_id',
]
struct_CLX_L3_ADJ_INFO_S._fields_ = [
    ('adj_type', CLX_L3_ADJ_TYPE_T),
    ('dst_mac', CLX_MAC_T),
    ('intf_id', UI32_T),
    ('src_mac', CLX_MAC_T),
    ('svid', CLX_VLAN_T),
    ('cvid', CLX_VLAN_T),
    ('flags', UI32_T),
    ('port', CLX_PORT_T),
    ('s_tpid', UI16_T),
    ('c_tpid', UI16_T),
    ('mtu_size', UI16_T),
    ('frr_backup_path', UI32_T),
    ('frr_state_id', UI32_T),
    ('seg_id', UI32_T),
]

CLX_L3_ADJ_INFO_T = struct_CLX_L3_ADJ_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 546

# ./clx_system/clx_sdk/include/clx_l3.h: 552
class struct_CLX_L3_OPTION_HEADER_INFO_S(Structure):
    pass

struct_CLX_L3_OPTION_HEADER_INFO_S.__slots__ = [
    'ipv4_action',
    'ipv6_action',
]
struct_CLX_L3_OPTION_HEADER_INFO_S._fields_ = [
    ('ipv4_action', CLX_FWD_ACTION_T),
    ('ipv6_action', CLX_FWD_ACTION_T),
]

CLX_L3_OPTION_HEADER_INFO_T = struct_CLX_L3_OPTION_HEADER_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 552

# ./clx_system/clx_sdk/include/clx_l3.h: 568
class struct_CLX_L3_PIM_REG_INFO_S(Structure):
    pass

struct_CLX_L3_PIM_REG_INFO_S.__slots__ = [
    'vrf_id',
    'src_ip',
    'rpf_intf_id',
    'mcast_id',
    'mrpf_check_fail_action',
    'flags',
]
struct_CLX_L3_PIM_REG_INFO_S._fields_ = [
    ('vrf_id', UI32_T),
    ('src_ip', CLX_L3_IP_NETWORK_ADDR_T),
    ('rpf_intf_id', UI32_T),
    ('mcast_id', UI32_T),
    ('mrpf_check_fail_action', CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_T),
    ('flags', UI32_T),
]

CLX_L3_PIM_REG_INFO_T = struct_CLX_L3_PIM_REG_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 568

CLX_L3_ADJ_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, UI32_T, POINTER(CLX_L3_ADJ_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l3.h: 572

CLX_L3_INTF_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(CLX_L3_INTF_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l3.h: 579

CLX_L3_ECMP_GRP_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, UI32_T, POINTER(CLX_L3_ECMP_GRP_INFO_T), POINTER(CLX_L3_ECMP_PATH_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l3.h: 586

CLX_L3_HOST_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_L3_HOST_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l3.h: 594

CLX_L3_ROUTE_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_L3_ROUTE_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l3.h: 600

CLX_L3_MCAST_GROUP_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_L3_MCAST_GROUP_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l3.h: 606

# ./clx_system/clx_sdk/include/clx_l3.h: 632
if _libs["libsai.so"].has("clx_l3_addIntf", "cdecl"):
    clx_l3_addIntf = _libs["libsai.so"].get("clx_l3_addIntf", "cdecl")
    clx_l3_addIntf.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(CLX_L3_INTF_INFO_T)]
    clx_l3_addIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 654
if _libs["libsai.so"].has("clx_l3_delIntf", "cdecl"):
    clx_l3_delIntf = _libs["libsai.so"].get("clx_l3_delIntf", "cdecl")
    clx_l3_delIntf.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_l3_delIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 678
if _libs["libsai.so"].has("clx_l3_getIntf", "cdecl"):
    clx_l3_getIntf = _libs["libsai.so"].get("clx_l3_getIntf", "cdecl")
    clx_l3_getIntf.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(CLX_L3_INTF_INFO_T)]
    clx_l3_getIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 701
if _libs["libsai.so"].has("clx_l3_traverseIntf", "cdecl"):
    clx_l3_traverseIntf = _libs["libsai.so"].get("clx_l3_traverseIntf", "cdecl")
    clx_l3_traverseIntf.argtypes = [UI32_T, CLX_L3_INTF_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l3_traverseIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 733
if _libs["libsai.so"].has("clx_l3_addMyRouterMac", "cdecl"):
    clx_l3_addMyRouterMac = _libs["libsai.so"].get("clx_l3_addMyRouterMac", "cdecl")
    clx_l3_addMyRouterMac.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3_ROUTER_MAC_INFO_T)]
    clx_l3_addMyRouterMac.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 757
if _libs["libsai.so"].has("clx_l3_delMyRouterMac", "cdecl"):
    clx_l3_delMyRouterMac = _libs["libsai.so"].get("clx_l3_delMyRouterMac", "cdecl")
    clx_l3_delMyRouterMac.argtypes = [UI32_T, UI32_T]
    clx_l3_delMyRouterMac.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 778
if _libs["libsai.so"].has("clx_l3_getMyRouterMac", "cdecl"):
    clx_l3_getMyRouterMac = _libs["libsai.so"].get("clx_l3_getMyRouterMac", "cdecl")
    clx_l3_getMyRouterMac.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3_ROUTER_MAC_INFO_T)]
    clx_l3_getMyRouterMac.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 803
if _libs["libsai.so"].has("clx_l3_addAdj", "cdecl"):
    clx_l3_addAdj = _libs["libsai.so"].get("clx_l3_addAdj", "cdecl")
    clx_l3_addAdj.argtypes = [UI32_T, POINTER(CLX_L3_ADJ_INFO_T), POINTER(UI32_T)]
    clx_l3_addAdj.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 823
if _libs["libsai.so"].has("clx_l3_delAdj", "cdecl"):
    clx_l3_delAdj = _libs["libsai.so"].get("clx_l3_delAdj", "cdecl")
    clx_l3_delAdj.argtypes = [UI32_T, CLX_L3_ADJ_TYPE_T, UI32_T]
    clx_l3_delAdj.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 843
if _libs["libsai.so"].has("clx_l3_getAdj", "cdecl"):
    clx_l3_getAdj = _libs["libsai.so"].get("clx_l3_getAdj", "cdecl")
    clx_l3_getAdj.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3_ADJ_INFO_T)]
    clx_l3_getAdj.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 867
if _libs["libsai.so"].has("clx_l3_traverseAdj", "cdecl"):
    clx_l3_traverseAdj = _libs["libsai.so"].get("clx_l3_traverseAdj", "cdecl")
    clx_l3_traverseAdj.argtypes = [UI32_T, CLX_L3_ADJ_TYPE_T, CLX_L3_ADJ_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l3_traverseAdj.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 898
if _libs["libsai.so"].has("clx_l3_addHost", "cdecl"):
    clx_l3_addHost = _libs["libsai.so"].get("clx_l3_addHost", "cdecl")
    clx_l3_addHost.argtypes = [UI32_T, POINTER(CLX_L3_HOST_INFO_T)]
    clx_l3_addHost.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 920
if _libs["libsai.so"].has("clx_l3_delHost", "cdecl"):
    clx_l3_delHost = _libs["libsai.so"].get("clx_l3_delHost", "cdecl")
    clx_l3_delHost.argtypes = [UI32_T, POINTER(CLX_L3_HOST_INFO_T)]
    clx_l3_delHost.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 942
if _libs["libsai.so"].has("clx_l3_getHost", "cdecl"):
    clx_l3_getHost = _libs["libsai.so"].get("clx_l3_getHost", "cdecl")
    clx_l3_getHost.argtypes = [UI32_T, POINTER(CLX_L3_HOST_INFO_T)]
    clx_l3_getHost.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 964
if _libs["libsai.so"].has("clx_l3_traverseHost", "cdecl"):
    clx_l3_traverseHost = _libs["libsai.so"].get("clx_l3_traverseHost", "cdecl")
    clx_l3_traverseHost.argtypes = [UI32_T, CLX_L3_HOST_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l3_traverseHost.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 988
if _libs["libsai.so"].has("clx_l3_addSubnetBcast", "cdecl"):
    clx_l3_addSubnetBcast = _libs["libsai.so"].get("clx_l3_addSubnetBcast", "cdecl")
    clx_l3_addSubnetBcast.argtypes = [UI32_T, POINTER(CLX_L3_SUBNET_BCAST_INFO_T)]
    clx_l3_addSubnetBcast.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1011
if _libs["libsai.so"].has("clx_l3_delSubnetBcast", "cdecl"):
    clx_l3_delSubnetBcast = _libs["libsai.so"].get("clx_l3_delSubnetBcast", "cdecl")
    clx_l3_delSubnetBcast.argtypes = [UI32_T, POINTER(CLX_L3_SUBNET_BCAST_INFO_T)]
    clx_l3_delSubnetBcast.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1032
if _libs["libsai.so"].has("clx_l3_getSubnetBcast", "cdecl"):
    clx_l3_getSubnetBcast = _libs["libsai.so"].get("clx_l3_getSubnetBcast", "cdecl")
    clx_l3_getSubnetBcast.argtypes = [UI32_T, POINTER(CLX_L3_SUBNET_BCAST_INFO_T)]
    clx_l3_getSubnetBcast.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1057
if _libs["libsai.so"].has("clx_l3_addRoute", "cdecl"):
    clx_l3_addRoute = _libs["libsai.so"].get("clx_l3_addRoute", "cdecl")
    clx_l3_addRoute.argtypes = [UI32_T, POINTER(CLX_L3_ROUTE_INFO_T)]
    clx_l3_addRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1078
if _libs["libsai.so"].has("clx_l3_delRoute", "cdecl"):
    clx_l3_delRoute = _libs["libsai.so"].get("clx_l3_delRoute", "cdecl")
    clx_l3_delRoute.argtypes = [UI32_T, POINTER(CLX_L3_ROUTE_INFO_T)]
    clx_l3_delRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1097
if _libs["libsai.so"].has("clx_l3_delRouteAll", "cdecl"):
    clx_l3_delRouteAll = _libs["libsai.so"].get("clx_l3_delRouteAll", "cdecl")
    clx_l3_delRouteAll.argtypes = [UI32_T]
    clx_l3_delRouteAll.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1117
if _libs["libsai.so"].has("clx_l3_getRoute", "cdecl"):
    clx_l3_getRoute = _libs["libsai.so"].get("clx_l3_getRoute", "cdecl")
    clx_l3_getRoute.argtypes = [UI32_T, POINTER(CLX_L3_ROUTE_INFO_T)]
    clx_l3_getRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1139
if _libs["libsai.so"].has("clx_l3_traverseRoute", "cdecl"):
    clx_l3_traverseRoute = _libs["libsai.so"].get("clx_l3_traverseRoute", "cdecl")
    clx_l3_traverseRoute.argtypes = [UI32_T, CLX_L3_ROUTE_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l3_traverseRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1176
if _libs["libsai.so"].has("clx_l3_createEcmpGrp", "cdecl"):
    clx_l3_createEcmpGrp = _libs["libsai.so"].get("clx_l3_createEcmpGrp", "cdecl")
    clx_l3_createEcmpGrp.argtypes = [UI32_T, POINTER(CLX_L3_ECMP_GRP_INFO_T), POINTER(UI32_T)]
    clx_l3_createEcmpGrp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1207
if _libs["libsai.so"].has("clx_l3_setEcmpGrp", "cdecl"):
    clx_l3_setEcmpGrp = _libs["libsai.so"].get("clx_l3_setEcmpGrp", "cdecl")
    clx_l3_setEcmpGrp.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3_ECMP_GRP_INFO_T)]
    clx_l3_setEcmpGrp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1234
if _libs["libsai.so"].has("clx_l3_delEcmpGrp", "cdecl"):
    clx_l3_delEcmpGrp = _libs["libsai.so"].get("clx_l3_delEcmpGrp", "cdecl")
    clx_l3_delEcmpGrp.argtypes = [UI32_T, CLX_L3_OUTPUT_TYPE_T, UI32_T]
    clx_l3_delEcmpGrp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1258
if _libs["libsai.so"].has("clx_l3_getEcmpGrp", "cdecl"):
    clx_l3_getEcmpGrp = _libs["libsai.so"].get("clx_l3_getEcmpGrp", "cdecl")
    clx_l3_getEcmpGrp.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3_ECMP_GRP_INFO_T)]
    clx_l3_getEcmpGrp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1282
if _libs["libsai.so"].has("clx_l3_traverseEcmpGrp", "cdecl"):
    clx_l3_traverseEcmpGrp = _libs["libsai.so"].get("clx_l3_traverseEcmpGrp", "cdecl")
    clx_l3_traverseEcmpGrp.argtypes = [UI32_T, CLX_L3_OUTPUT_TYPE_T, CLX_L3_ECMP_GRP_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l3_traverseEcmpGrp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1308
if _libs["libsai.so"].has("clx_l3_addEcmpGrpPath", "cdecl"):
    clx_l3_addEcmpGrpPath = _libs["libsai.so"].get("clx_l3_addEcmpGrpPath", "cdecl")
    clx_l3_addEcmpGrpPath.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3_ECMP_PATH_INFO_T)]
    clx_l3_addEcmpGrpPath.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1335
if _libs["libsai.so"].has("clx_l3_delEcmpGrpPath", "cdecl"):
    clx_l3_delEcmpGrpPath = _libs["libsai.so"].get("clx_l3_delEcmpGrpPath", "cdecl")
    clx_l3_delEcmpGrpPath.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3_ECMP_PATH_INFO_T)]
    clx_l3_delEcmpGrpPath.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1367
if _libs["libsai.so"].has("clx_l3_getEcmpGrpPathByIdx", "cdecl"):
    clx_l3_getEcmpGrpPathByIdx = _libs["libsai.so"].get("clx_l3_getEcmpGrpPathByIdx", "cdecl")
    clx_l3_getEcmpGrpPathByIdx.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(CLX_L3_ECMP_PATH_INFO_T)]
    clx_l3_getEcmpGrpPathByIdx.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1393
if _libs["libsai.so"].has("clx_l3_setEcmpGrpHashPath", "cdecl"):
    clx_l3_setEcmpGrpHashPath = _libs["libsai.so"].get("clx_l3_setEcmpGrpHashPath", "cdecl")
    clx_l3_setEcmpGrpHashPath.argtypes = [UI32_T, UI32_T, POINTER(UI32_T), UI32_T, POINTER(CLX_L3_ECMP_PATH_INFO_T)]
    clx_l3_setEcmpGrpHashPath.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1422
if _libs["libsai.so"].has("clx_l3_getEcmpGrpHashPath", "cdecl"):
    clx_l3_getEcmpGrpHashPath = _libs["libsai.so"].get("clx_l3_getEcmpGrpHashPath", "cdecl")
    clx_l3_getEcmpGrpHashPath.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(CLX_L3_ECMP_PATH_INFO_T), POINTER(UI32_T), POINTER(UI32_T)]
    clx_l3_getEcmpGrpHashPath.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1448
if _libs["libsai.so"].has("clx_l3_setPktHandlingByVrf", "cdecl"):
    clx_l3_setPktHandlingByVrf = _libs["libsai.so"].get("clx_l3_setPktHandlingByVrf", "cdecl")
    clx_l3_setPktHandlingByVrf.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3_VRF_INFO_T)]
    clx_l3_setPktHandlingByVrf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1470
if _libs["libsai.so"].has("clx_l3_getPktHandlingByVrf", "cdecl"):
    clx_l3_getPktHandlingByVrf = _libs["libsai.so"].get("clx_l3_getPktHandlingByVrf", "cdecl")
    clx_l3_getPktHandlingByVrf.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3_VRF_INFO_T)]
    clx_l3_getPktHandlingByVrf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1490
if _libs["libsai.so"].has("clx_l3_addMcastId", "cdecl"):
    clx_l3_addMcastId = _libs["libsai.so"].get("clx_l3_addMcastId", "cdecl")
    clx_l3_addMcastId.argtypes = [UI32_T, UI32_T, POINTER(UI32_T)]
    clx_l3_addMcastId.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1509
if _libs["libsai.so"].has("clx_l3_delMcastId", "cdecl"):
    clx_l3_delMcastId = _libs["libsai.so"].get("clx_l3_delMcastId", "cdecl")
    clx_l3_delMcastId.argtypes = [UI32_T, UI32_T]
    clx_l3_delMcastId.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1530
if _libs["libsai.so"].has("clx_l3_getMcastId", "cdecl"):
    clx_l3_getMcastId = _libs["libsai.so"].get("clx_l3_getMcastId", "cdecl")
    clx_l3_getMcastId.argtypes = [UI32_T, UI32_T, POINTER(UI32_T), CLX_PORT_BITMAP_T]
    clx_l3_getMcastId.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1554
if _libs["libsai.so"].has("clx_l3_addMcastGroup", "cdecl"):
    clx_l3_addMcastGroup = _libs["libsai.so"].get("clx_l3_addMcastGroup", "cdecl")
    clx_l3_addMcastGroup.argtypes = [UI32_T, POINTER(CLX_L3_MCAST_GROUP_INFO_T)]
    clx_l3_addMcastGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1576
if _libs["libsai.so"].has("clx_l3_delMcastGroup", "cdecl"):
    clx_l3_delMcastGroup = _libs["libsai.so"].get("clx_l3_delMcastGroup", "cdecl")
    clx_l3_delMcastGroup.argtypes = [UI32_T, POINTER(CLX_L3_MCAST_GROUP_INFO_T)]
    clx_l3_delMcastGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1599
if _libs["libsai.so"].has("clx_l3_getMcastGroup", "cdecl"):
    clx_l3_getMcastGroup = _libs["libsai.so"].get("clx_l3_getMcastGroup", "cdecl")
    clx_l3_getMcastGroup.argtypes = [UI32_T, POINTER(CLX_L3_MCAST_GROUP_INFO_T)]
    clx_l3_getMcastGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1622
if _libs["libsai.so"].has("clx_l3_addMcastEgrIntfByPort", "cdecl"):
    clx_l3_addMcastEgrIntfByPort = _libs["libsai.so"].get("clx_l3_addMcastEgrIntfByPort", "cdecl")
    clx_l3_addMcastEgrIntfByPort.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, POINTER(CLX_L3_MCAST_EGR_INTF_T)]
    clx_l3_addMcastEgrIntfByPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1648
if _libs["libsai.so"].has("clx_l3_delMcastEgrIntfByPort", "cdecl"):
    clx_l3_delMcastEgrIntfByPort = _libs["libsai.so"].get("clx_l3_delMcastEgrIntfByPort", "cdecl")
    clx_l3_delMcastEgrIntfByPort.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, POINTER(CLX_L3_MCAST_EGR_INTF_T)]
    clx_l3_delMcastEgrIntfByPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1673
if _libs["libsai.so"].has("clx_l3_setMcastEgrIntfByPort", "cdecl"):
    clx_l3_setMcastEgrIntfByPort = _libs["libsai.so"].get("clx_l3_setMcastEgrIntfByPort", "cdecl")
    clx_l3_setMcastEgrIntfByPort.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, POINTER(CLX_L3_MCAST_EGR_INTF_T)]
    clx_l3_setMcastEgrIntfByPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1701
if _libs["libsai.so"].has("clx_l3_getMcastEgrIntfCntByPort", "cdecl"):
    clx_l3_getMcastEgrIntfCntByPort = _libs["libsai.so"].get("clx_l3_getMcastEgrIntfCntByPort", "cdecl")
    clx_l3_getMcastEgrIntfCntByPort.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(UI32_T)]
    clx_l3_getMcastEgrIntfCntByPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1724
if _libs["libsai.so"].has("clx_l3_getMcastEgrIntfByPort", "cdecl"):
    clx_l3_getMcastEgrIntfByPort = _libs["libsai.so"].get("clx_l3_getMcastEgrIntfByPort", "cdecl")
    clx_l3_getMcastEgrIntfByPort.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, POINTER(CLX_L3_MCAST_EGR_INTF_T), POINTER(UI32_T)]
    clx_l3_getMcastEgrIntfByPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1751
if _libs["libsai.so"].has("clx_l3_addMcastDfIntf", "cdecl"):
    clx_l3_addMcastDfIntf = _libs["libsai.so"].get("clx_l3_addMcastDfIntf", "cdecl")
    clx_l3_addMcastDfIntf.argtypes = [UI32_T, UI32_T, POINTER(CLX_IP_ADDR_T)]
    clx_l3_addMcastDfIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1772
if _libs["libsai.so"].has("clx_l3_delMcastDfIntf", "cdecl"):
    clx_l3_delMcastDfIntf = _libs["libsai.so"].get("clx_l3_delMcastDfIntf", "cdecl")
    clx_l3_delMcastDfIntf.argtypes = [UI32_T, UI32_T, POINTER(CLX_IP_ADDR_T)]
    clx_l3_delMcastDfIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1794
if _libs["libsai.so"].has("clx_l3_getMcastDfIntf", "cdecl"):
    clx_l3_getMcastDfIntf = _libs["libsai.so"].get("clx_l3_getMcastDfIntf", "cdecl")
    clx_l3_getMcastDfIntf.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(UI32_T), POINTER(CLX_IP_ADDR_T)]
    clx_l3_getMcastDfIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1817
if _libs["libsai.so"].has("clx_l3_traverseMcastGroup", "cdecl"):
    clx_l3_traverseMcastGroup = _libs["libsai.so"].get("clx_l3_traverseMcastGroup", "cdecl")
    clx_l3_traverseMcastGroup.argtypes = [UI32_T, CLX_L3_MCAST_GROUP_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l3_traverseMcastGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1838
if _libs["libsai.so"].has("clx_l3_setBfdInfo", "cdecl"):
    clx_l3_setBfdInfo = _libs["libsai.so"].get("clx_l3_setBfdInfo", "cdecl")
    clx_l3_setBfdInfo.argtypes = [UI32_T, POINTER(CLX_L3_BFD_INFO_T)]
    clx_l3_setBfdInfo.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1858
if _libs["libsai.so"].has("clx_l3_getBfdInfo", "cdecl"):
    clx_l3_getBfdInfo = _libs["libsai.so"].get("clx_l3_getBfdInfo", "cdecl")
    clx_l3_getBfdInfo.argtypes = [UI32_T, POINTER(CLX_L3_BFD_INFO_T)]
    clx_l3_getBfdInfo.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1879
if _libs["libsai.so"].has("clx_l3_setBfdCheckFailAction", "cdecl"):
    clx_l3_setBfdCheckFailAction = _libs["libsai.so"].get("clx_l3_setBfdCheckFailAction", "cdecl")
    clx_l3_setBfdCheckFailAction.argtypes = [UI32_T, UI32_T, CLX_FWD_ACTION_T]
    clx_l3_setBfdCheckFailAction.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1900
if _libs["libsai.so"].has("clx_l3_getBfdCheckFailAction", "cdecl"):
    clx_l3_getBfdCheckFailAction = _libs["libsai.so"].get("clx_l3_getBfdCheckFailAction", "cdecl")
    clx_l3_getBfdCheckFailAction.argtypes = [UI32_T, UI32_T, POINTER(CLX_FWD_ACTION_T)]
    clx_l3_getBfdCheckFailAction.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1921
if _libs["libsai.so"].has("clx_l3_setOptionHeaderAction", "cdecl"):
    clx_l3_setOptionHeaderAction = _libs["libsai.so"].get("clx_l3_setOptionHeaderAction", "cdecl")
    clx_l3_setOptionHeaderAction.argtypes = [UI32_T, CLX_L3_OPTION_HEADER_INFO_T]
    clx_l3_setOptionHeaderAction.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1940
if _libs["libsai.so"].has("clx_l3_getOptionHeaderAction", "cdecl"):
    clx_l3_getOptionHeaderAction = _libs["libsai.so"].get("clx_l3_getOptionHeaderAction", "cdecl")
    clx_l3_getOptionHeaderAction.argtypes = [UI32_T, POINTER(CLX_L3_OPTION_HEADER_INFO_T)]
    clx_l3_getOptionHeaderAction.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1961
if _libs["libsai.so"].has("clx_l3_createFrrStateId", "cdecl"):
    clx_l3_createFrrStateId = _libs["libsai.so"].get("clx_l3_createFrrStateId", "cdecl")
    clx_l3_createFrrStateId.argtypes = [UI32_T, CLX_L3_OUTPUT_TYPE_T, POINTER(UI32_T)]
    clx_l3_createFrrStateId.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 1983
if _libs["libsai.so"].has("clx_l3_destroyFrrStateId", "cdecl"):
    clx_l3_destroyFrrStateId = _libs["libsai.so"].get("clx_l3_destroyFrrStateId", "cdecl")
    clx_l3_destroyFrrStateId.argtypes = [UI32_T, CLX_L3_OUTPUT_TYPE_T, UI32_T]
    clx_l3_destroyFrrStateId.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2008
if _libs["libsai.so"].has("clx_l3_setFrrState", "cdecl"):
    clx_l3_setFrrState = _libs["libsai.so"].get("clx_l3_setFrrState", "cdecl")
    clx_l3_setFrrState.argtypes = [UI32_T, CLX_L3_OUTPUT_TYPE_T, UI32_T, BOOL_T]
    clx_l3_setFrrState.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2031
if _libs["libsai.so"].has("clx_l3_getFrrState", "cdecl"):
    clx_l3_getFrrState = _libs["libsai.so"].get("clx_l3_getFrrState", "cdecl")
    clx_l3_getFrrState.argtypes = [UI32_T, CLX_L3_OUTPUT_TYPE_T, UI32_T, POINTER(BOOL_T)]
    clx_l3_getFrrState.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2053
if _libs["libsai.so"].has("clx_l3_addSrcForPimReg", "cdecl"):
    clx_l3_addSrcForPimReg = _libs["libsai.so"].get("clx_l3_addSrcForPimReg", "cdecl")
    clx_l3_addSrcForPimReg.argtypes = [UI32_T, POINTER(CLX_L3_PIM_REG_INFO_T)]
    clx_l3_addSrcForPimReg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2072
if _libs["libsai.so"].has("clx_l3_delSrcForPimReg", "cdecl"):
    clx_l3_delSrcForPimReg = _libs["libsai.so"].get("clx_l3_delSrcForPimReg", "cdecl")
    clx_l3_delSrcForPimReg.argtypes = [UI32_T, POINTER(CLX_L3_PIM_REG_INFO_T)]
    clx_l3_delSrcForPimReg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2091
if _libs["libsai.so"].has("clx_l3_getSrcForPimReg", "cdecl"):
    clx_l3_getSrcForPimReg = _libs["libsai.so"].get("clx_l3_getSrcForPimReg", "cdecl")
    clx_l3_getSrcForPimReg.argtypes = [UI32_T, POINTER(CLX_L3_PIM_REG_INFO_T)]
    clx_l3_getSrcForPimReg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2112
if _libs["libsai.so"].has("clx_l3_addVrrp", "cdecl"):
    clx_l3_addVrrp = _libs["libsai.so"].get("clx_l3_addVrrp", "cdecl")
    clx_l3_addVrrp.argtypes = [UI32_T, UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_l3_addVrrp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2134
if _libs["libsai.so"].has("clx_l3_delVrrp", "cdecl"):
    clx_l3_delVrrp = _libs["libsai.so"].get("clx_l3_delVrrp", "cdecl")
    clx_l3_delVrrp.argtypes = [UI32_T, UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_l3_delVrrp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2156
if _libs["libsai.so"].has("clx_l3_getVrrp", "cdecl"):
    clx_l3_getVrrp = _libs["libsai.so"].get("clx_l3_getVrrp", "cdecl")
    clx_l3_getVrrp.argtypes = [UI32_T, UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_l3_getVrrp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2176
if _libs["libsai.so"].has("clx_l3_addFdlEcmpGroup", "cdecl"):
    clx_l3_addFdlEcmpGroup = _libs["libsai.so"].get("clx_l3_addFdlEcmpGroup", "cdecl")
    clx_l3_addFdlEcmpGroup.argtypes = [UI32_T, UI32_T, POINTER(CLX_FDL_INFO_T)]
    clx_l3_addFdlEcmpGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2195
if _libs["libsai.so"].has("clx_l3_delFdlEcmpGroup", "cdecl"):
    clx_l3_delFdlEcmpGroup = _libs["libsai.so"].get("clx_l3_delFdlEcmpGroup", "cdecl")
    clx_l3_delFdlEcmpGroup.argtypes = [UI32_T, UI32_T]
    clx_l3_delFdlEcmpGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2214
if _libs["libsai.so"].has("clx_l3_getFdlEcmpGroup", "cdecl"):
    clx_l3_getFdlEcmpGroup = _libs["libsai.so"].get("clx_l3_getFdlEcmpGroup", "cdecl")
    clx_l3_getFdlEcmpGroup.argtypes = [UI32_T, UI32_T, POINTER(CLX_FDL_INFO_T)]
    clx_l3_getFdlEcmpGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2242
if _libs["libsai.so"].has("clx_l3_addBulkRoute", "cdecl"):
    clx_l3_addBulkRoute = _libs["libsai.so"].get("clx_l3_addBulkRoute", "cdecl")
    clx_l3_addBulkRoute.argtypes = [UI32_T, CLX_BULK_OP_MODE_T, UI32_T, POINTER(CLX_L3_ROUTE_INFO_T), POINTER(CLX_ERROR_NO_T)]
    clx_l3_addBulkRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2268
if _libs["libsai.so"].has("clx_l3_delBulkRoute", "cdecl"):
    clx_l3_delBulkRoute = _libs["libsai.so"].get("clx_l3_delBulkRoute", "cdecl")
    clx_l3_delBulkRoute.argtypes = [UI32_T, CLX_BULK_OP_MODE_T, UI32_T, POINTER(CLX_L3_ROUTE_INFO_T), POINTER(CLX_ERROR_NO_T)]
    clx_l3_delBulkRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3.h: 2295
if _libs["libsai.so"].has("clx_l3_getBulkRoute", "cdecl"):
    clx_l3_getBulkRoute = _libs["libsai.so"].get("clx_l3_getBulkRoute", "cdecl")
    clx_l3_getBulkRoute.argtypes = [UI32_T, CLX_BULK_OP_MODE_T, UI32_T, POINTER(CLX_L3_ROUTE_INFO_T), POINTER(CLX_ERROR_NO_T)]
    clx_l3_getBulkRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 85
class struct_CLX_MPLS_LSE_S(Structure):
    pass

struct_CLX_MPLS_LSE_S.__slots__ = [
    'label_value',
    'ttl',
    'exp',
    'flags',
]
struct_CLX_MPLS_LSE_S._fields_ = [
    ('label_value', UI32_T),
    ('ttl', UI32_T),
    ('exp', UI32_T),
    ('flags', UI32_T),
]

CLX_MPLS_LSE_T = struct_CLX_MPLS_LSE_S# ./clx_system/clx_sdk/include/clx_mpls.h: 85

# ./clx_system/clx_sdk/include/clx_mpls.h: 98
class struct_CLX_MPLS_ENCAP_KEY_S(Structure):
    pass

struct_CLX_MPLS_ENCAP_KEY_S.__slots__ = [
    'label_num',
    'label_stack',
    'underlay_port',
    'flags',
]
struct_CLX_MPLS_ENCAP_KEY_S._fields_ = [
    ('label_num', UI32_T),
    ('label_stack', CLX_MPLS_LSE_T * int(4)),
    ('underlay_port', CLX_PORT_T),
    ('flags', UI32_T),
]

CLX_MPLS_ENCAP_KEY_T = struct_CLX_MPLS_ENCAP_KEY_S# ./clx_system/clx_sdk/include/clx_mpls.h: 98

# ./clx_system/clx_sdk/include/clx_mpls.h: 105
class struct_CLX_MPLS_MATCH_KEY_S(Structure):
    pass

struct_CLX_MPLS_MATCH_KEY_S.__slots__ = [
    'name_space',
    'label_num',
    'label_stack',
]
struct_CLX_MPLS_MATCH_KEY_S._fields_ = [
    ('name_space', UI32_T),
    ('label_num', UI32_T),
    ('label_stack', UI32_T * int(4)),
]

CLX_MPLS_MATCH_KEY_T = struct_CLX_MPLS_MATCH_KEY_S# ./clx_system/clx_sdk/include/clx_mpls.h: 105

# ./clx_system/clx_sdk/include/clx_mpls.h: 142
class struct_CLX_MPLS_INIT_S(Structure):
    pass

struct_CLX_MPLS_INIT_S.__slots__ = [
    'nvo3_adj_id',
    'l3_intf_id',
    'group_label',
    'pcp',
    'meter_id',
    'cnt_id',
    'dist_cnt_id',
    'sampling_rate',
    'sample_to_mir_session_id',
    'mir_session_bitmap',
    'phb_to_exp_profile_id',
    'phb_to_pcp_dei_profile_id',
    'frr_state_id',
    'frr_backup_lsp',
    'vlan_tag',
    'dtel_profile_id',
    'flags',
]
struct_CLX_MPLS_INIT_S._fields_ = [
    ('nvo3_adj_id', UI32_T),
    ('l3_intf_id', UI32_T),
    ('group_label', UI32_T),
    ('pcp', UI32_T),
    ('meter_id', UI32_T),
    ('cnt_id', UI32_T),
    ('dist_cnt_id', UI32_T),
    ('sampling_rate', UI32_T),
    ('sample_to_mir_session_id', UI32_T),
    ('mir_session_bitmap', UI32_T),
    ('phb_to_exp_profile_id', UI32_T),
    ('phb_to_pcp_dei_profile_id', UI32_T),
    ('frr_state_id', UI32_T),
    ('frr_backup_lsp', CLX_PORT_T),
    ('vlan_tag', CLX_PORT_VLAN_TAG_T),
    ('dtel_profile_id', UI32_T),
    ('flags', UI32_T),
]

CLX_MPLS_INIT_T = struct_CLX_MPLS_INIT_S# ./clx_system/clx_sdk/include/clx_mpls.h: 142

# ./clx_system/clx_sdk/include/clx_mpls.h: 183
class struct_CLX_MPLS_TERM_S(Structure):
    pass

struct_CLX_MPLS_TERM_S.__slots__ = [
    'bdid',
    'vlan_tag',
    'default_pcp',
    'meter_id',
    'cnt_id',
    'dist_cnt_id',
    'exp_to_phb_profile_id',
    'pcp_dei_to_phb_profile_id',
    'dscp_to_phb_profile_id',
    'l2_mtu',
    'group_label',
    'sampling_rate',
    'sample_to_mir_session_id',
    'mir_session_bitmap',
    'dtel_profile_id',
    'flags',
]
struct_CLX_MPLS_TERM_S._fields_ = [
    ('bdid', CLX_BRIDGE_DOMAIN_T),
    ('vlan_tag', CLX_PORT_VLAN_TAG_T),
    ('default_pcp', UI32_T),
    ('meter_id', UI32_T),
    ('cnt_id', UI32_T),
    ('dist_cnt_id', UI32_T),
    ('exp_to_phb_profile_id', UI32_T),
    ('pcp_dei_to_phb_profile_id', UI32_T),
    ('dscp_to_phb_profile_id', UI32_T),
    ('l2_mtu', UI32_T),
    ('group_label', UI32_T),
    ('sampling_rate', UI32_T),
    ('sample_to_mir_session_id', UI32_T),
    ('mir_session_bitmap', UI32_T),
    ('dtel_profile_id', UI32_T),
    ('flags', UI32_T),
]

CLX_MPLS_TERM_T = struct_CLX_MPLS_TERM_S# ./clx_system/clx_sdk/include/clx_mpls.h: 183

enum_anon_59 = c_int# ./clx_system/clx_sdk/include/clx_mpls.h: 195

CLX_MPLS_LABEL_ACTION_NONE = 0# ./clx_system/clx_sdk/include/clx_mpls.h: 195

CLX_MPLS_LABEL_ACTION_PUSH = (CLX_MPLS_LABEL_ACTION_NONE + 1)# ./clx_system/clx_sdk/include/clx_mpls.h: 195

CLX_MPLS_LABEL_ACTION_SWAP = (CLX_MPLS_LABEL_ACTION_PUSH + 1)# ./clx_system/clx_sdk/include/clx_mpls.h: 195

CLX_MPLS_LABEL_ACTION_PHP = (CLX_MPLS_LABEL_ACTION_SWAP + 1)# ./clx_system/clx_sdk/include/clx_mpls.h: 195

CLX_MPLS_LABEL_ACTION_POP = (CLX_MPLS_LABEL_ACTION_PHP + 1)# ./clx_system/clx_sdk/include/clx_mpls.h: 195

CLX_MPLS_LABEL_ACTION_SWAP_PUSH = (CLX_MPLS_LABEL_ACTION_POP + 1)# ./clx_system/clx_sdk/include/clx_mpls.h: 195

CLX_MPLS_LABEL_ACTION_LAST = (CLX_MPLS_LABEL_ACTION_SWAP_PUSH + 1)# ./clx_system/clx_sdk/include/clx_mpls.h: 195

CLX_MPLS_LABEL_ACTION_T = enum_anon_59# ./clx_system/clx_sdk/include/clx_mpls.h: 195

# ./clx_system/clx_sdk/include/clx_mpls.h: 218
class struct_CLX_MPLS_NHLFE_S(Structure):
    pass

struct_CLX_MPLS_NHLFE_S.__slots__ = [
    'label_action',
    'mpls_label',
    'output_type',
    'output_id',
    'frr_state_id',
    'frr_backup_path_type',
    'frr_backup_path',
    'frr_backup_label',
    'tc',
    'flags',
]
struct_CLX_MPLS_NHLFE_S._fields_ = [
    ('label_action', CLX_MPLS_LABEL_ACTION_T),
    ('mpls_label', UI32_T),
    ('output_type', CLX_L3_OUTPUT_TYPE_T),
    ('output_id', UI32_T),
    ('frr_state_id', UI32_T),
    ('frr_backup_path_type', CLX_L3_OUTPUT_TYPE_T),
    ('frr_backup_path', UI32_T),
    ('frr_backup_label', UI32_T),
    ('tc', UI32_T),
    ('flags', UI32_T),
]

CLX_MPLS_NHLFE_T = struct_CLX_MPLS_NHLFE_S# ./clx_system/clx_sdk/include/clx_mpls.h: 218

enum_anon_60 = c_int# ./clx_system/clx_sdk/include/clx_mpls.h: 226

CLX_MPLS_PW_VPLS = 0# ./clx_system/clx_sdk/include/clx_mpls.h: 226

CLX_MPLS_PW_VPWS = (CLX_MPLS_PW_VPLS + 1)# ./clx_system/clx_sdk/include/clx_mpls.h: 226

CLX_MPLS_PW_L3VPN = (CLX_MPLS_PW_VPWS + 1)# ./clx_system/clx_sdk/include/clx_mpls.h: 226

CLX_MPLS_PW_LAST = (CLX_MPLS_PW_L3VPN + 1)# ./clx_system/clx_sdk/include/clx_mpls.h: 226

CLX_MPLS_PW_TYPE_T = enum_anon_60# ./clx_system/clx_sdk/include/clx_mpls.h: 226

# ./clx_system/clx_sdk/include/clx_mpls.h: 246
class struct_CLX_MPLS_PW_KEY_S(Structure):
    pass

struct_CLX_MPLS_PW_KEY_S.__slots__ = [
    'type',
    'outbound_label',
    'inbound_key',
    'svid',
    'cvid',
    'output_type',
    'output_id',
    'flags',
]
struct_CLX_MPLS_PW_KEY_S._fields_ = [
    ('type', CLX_MPLS_PW_TYPE_T),
    ('outbound_label', UI32_T),
    ('inbound_key', CLX_MPLS_MATCH_KEY_T),
    ('svid', CLX_VLAN_T),
    ('cvid', CLX_VLAN_T),
    ('output_type', CLX_L3_OUTPUT_TYPE_T),
    ('output_id', UI32_T),
    ('flags', UI32_T),
]

CLX_MPLS_PW_KEY_T = struct_CLX_MPLS_PW_KEY_S# ./clx_system/clx_sdk/include/clx_mpls.h: 246

# ./clx_system/clx_sdk/include/clx_mpls.h: 294
class struct_CLX_MPLS_PW_S(Structure):
    pass

struct_CLX_MPLS_PW_S.__slots__ = [
    'bdid',
    'outbound_meter_id',
    'inbound_meter_id',
    'outbound_cnt_id',
    'inbound_cnt_id',
    'outbound_dist_cnt_id',
    'inbound_dist_cnt_id',
    'phb_to_exp_profile_id',
    'phb_to_pcp_dei_profile_id',
    'pcp_dei_to_phb_profile_id',
    'exp_to_phb_profile_id',
    'dscp_to_phb_profile_id',
    'frr_backup_path',
    'frr_state_id',
    'bc_mcast_id',
    'uuc_mcast_id',
    'umc_mcast_id',
    'bud_mcast_id',
    'l3_intf_id',
    'flags',
]
struct_CLX_MPLS_PW_S._fields_ = [
    ('bdid', CLX_BRIDGE_DOMAIN_T),
    ('outbound_meter_id', UI32_T),
    ('inbound_meter_id', UI32_T),
    ('outbound_cnt_id', UI32_T),
    ('inbound_cnt_id', UI32_T),
    ('outbound_dist_cnt_id', UI32_T),
    ('inbound_dist_cnt_id', UI32_T),
    ('phb_to_exp_profile_id', UI32_T),
    ('phb_to_pcp_dei_profile_id', UI32_T),
    ('pcp_dei_to_phb_profile_id', UI32_T),
    ('exp_to_phb_profile_id', UI32_T),
    ('dscp_to_phb_profile_id', UI32_T),
    ('frr_backup_path', CLX_PORT_T),
    ('frr_state_id', UI32_T),
    ('bc_mcast_id', UI32_T),
    ('uuc_mcast_id', UI32_T),
    ('umc_mcast_id', UI32_T),
    ('bud_mcast_id', UI32_T),
    ('l3_intf_id', UI32_T),
    ('flags', UI32_T),
]

CLX_MPLS_PW_T = struct_CLX_MPLS_PW_S# ./clx_system/clx_sdk/include/clx_mpls.h: 294

# ./clx_system/clx_sdk/include/clx_mpls.h: 307
class struct_CLX_MPLS_AC_S(Structure):
    pass

struct_CLX_MPLS_AC_S.__slots__ = [
    'port',
    'svid',
    'cvid',
    'flags',
]
struct_CLX_MPLS_AC_S._fields_ = [
    ('port', CLX_PORT_T),
    ('svid', CLX_VLAN_T),
    ('cvid', CLX_VLAN_T),
    ('flags', UI32_T),
]

CLX_MPLS_AC_T = struct_CLX_MPLS_AC_S# ./clx_system/clx_sdk/include/clx_mpls.h: 307

enum_anon_61 = c_int# ./clx_system/clx_sdk/include/clx_mpls.h: 314

CLX_MPLS_LABEL_TYPE_P2P_UHP = 0# ./clx_system/clx_sdk/include/clx_mpls.h: 314

CLX_MPLS_LABEL_TYPE_P2MP_UHP = (CLX_MPLS_LABEL_TYPE_P2P_UHP + 1)# ./clx_system/clx_sdk/include/clx_mpls.h: 314

CLX_MPLS_LABEL_TYPE_LAST = (CLX_MPLS_LABEL_TYPE_P2MP_UHP + 1)# ./clx_system/clx_sdk/include/clx_mpls.h: 314

CLX_MPLS_LABEL_TYPE_T = enum_anon_61# ./clx_system/clx_sdk/include/clx_mpls.h: 314

CLX_MPLS_INIT_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, CLX_PORT_T, POINTER(CLX_MPLS_ENCAP_KEY_T), POINTER(CLX_MPLS_INIT_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_mpls.h: 319

CLX_MPLS_TRANSIT_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_MPLS_MATCH_KEY_T), POINTER(CLX_MPLS_NHLFE_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_mpls.h: 327

CLX_MPLS_TERM_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_MPLS_MATCH_KEY_T), POINTER(CLX_MPLS_TERM_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_mpls.h: 334

CLX_MPLS_PW_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, UI32_T, POINTER(CLX_MPLS_PW_KEY_T), POINTER(CLX_MPLS_PW_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_mpls.h: 341

# ./clx_system/clx_sdk/include/clx_mpls.h: 368
if _libs["libsai.so"].has("clx_mpls_createPort", "cdecl"):
    clx_mpls_createPort = _libs["libsai.so"].get("clx_mpls_createPort", "cdecl")
    clx_mpls_createPort.argtypes = [UI32_T, POINTER(CLX_MPLS_ENCAP_KEY_T), POINTER(CLX_PORT_T)]
    clx_mpls_createPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 390
if _libs["libsai.so"].has("clx_mpls_destroyPort", "cdecl"):
    clx_mpls_destroyPort = _libs["libsai.so"].get("clx_mpls_destroyPort", "cdecl")
    clx_mpls_destroyPort.argtypes = [UI32_T, CLX_PORT_T]
    clx_mpls_destroyPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 411
if _libs["libsai.so"].has("clx_mpls_getPort", "cdecl"):
    clx_mpls_getPort = _libs["libsai.so"].get("clx_mpls_getPort", "cdecl")
    clx_mpls_getPort.argtypes = [UI32_T, POINTER(CLX_MPLS_ENCAP_KEY_T), POINTER(CLX_PORT_T)]
    clx_mpls_getPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 433
if _libs["libsai.so"].has("clx_mpls_getKey", "cdecl"):
    clx_mpls_getKey = _libs["libsai.so"].get("clx_mpls_getKey", "cdecl")
    clx_mpls_getKey.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_MPLS_ENCAP_KEY_T)]
    clx_mpls_getKey.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 456
if _libs["libsai.so"].has("clx_mpls_addInit", "cdecl"):
    clx_mpls_addInit = _libs["libsai.so"].get("clx_mpls_addInit", "cdecl")
    clx_mpls_addInit.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_MPLS_INIT_T)]
    clx_mpls_addInit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 478
if _libs["libsai.so"].has("clx_mpls_delInit", "cdecl"):
    clx_mpls_delInit = _libs["libsai.so"].get("clx_mpls_delInit", "cdecl")
    clx_mpls_delInit.argtypes = [UI32_T, CLX_PORT_T]
    clx_mpls_delInit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 499
if _libs["libsai.so"].has("clx_mpls_getInit", "cdecl"):
    clx_mpls_getInit = _libs["libsai.so"].get("clx_mpls_getInit", "cdecl")
    clx_mpls_getInit.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_MPLS_INIT_T)]
    clx_mpls_getInit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 522
if _libs["libsai.so"].has("clx_mpls_addTerm", "cdecl"):
    clx_mpls_addTerm = _libs["libsai.so"].get("clx_mpls_addTerm", "cdecl")
    clx_mpls_addTerm.argtypes = [UI32_T, POINTER(CLX_MPLS_MATCH_KEY_T), POINTER(CLX_MPLS_TERM_T)]
    clx_mpls_addTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 544
if _libs["libsai.so"].has("clx_mpls_delTerm", "cdecl"):
    clx_mpls_delTerm = _libs["libsai.so"].get("clx_mpls_delTerm", "cdecl")
    clx_mpls_delTerm.argtypes = [UI32_T, POINTER(CLX_MPLS_MATCH_KEY_T)]
    clx_mpls_delTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 565
if _libs["libsai.so"].has("clx_mpls_getTerm", "cdecl"):
    clx_mpls_getTerm = _libs["libsai.so"].get("clx_mpls_getTerm", "cdecl")
    clx_mpls_getTerm.argtypes = [UI32_T, POINTER(CLX_MPLS_MATCH_KEY_T), POINTER(CLX_MPLS_TERM_T)]
    clx_mpls_getTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 588
if _libs["libsai.so"].has("clx_mpls_addTransit", "cdecl"):
    clx_mpls_addTransit = _libs["libsai.so"].get("clx_mpls_addTransit", "cdecl")
    clx_mpls_addTransit.argtypes = [UI32_T, POINTER(CLX_MPLS_MATCH_KEY_T), POINTER(CLX_MPLS_NHLFE_T)]
    clx_mpls_addTransit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 610
if _libs["libsai.so"].has("clx_mpls_delTransit", "cdecl"):
    clx_mpls_delTransit = _libs["libsai.so"].get("clx_mpls_delTransit", "cdecl")
    clx_mpls_delTransit.argtypes = [UI32_T, POINTER(CLX_MPLS_MATCH_KEY_T)]
    clx_mpls_delTransit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 631
if _libs["libsai.so"].has("clx_mpls_getTransit", "cdecl"):
    clx_mpls_getTransit = _libs["libsai.so"].get("clx_mpls_getTransit", "cdecl")
    clx_mpls_getTransit.argtypes = [UI32_T, POINTER(CLX_MPLS_MATCH_KEY_T), POINTER(CLX_MPLS_NHLFE_T)]
    clx_mpls_getTransit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 653
if _libs["libsai.so"].has("clx_mpls_createPwPort", "cdecl"):
    clx_mpls_createPwPort = _libs["libsai.so"].get("clx_mpls_createPwPort", "cdecl")
    clx_mpls_createPwPort.argtypes = [UI32_T, POINTER(CLX_MPLS_PW_KEY_T), POINTER(CLX_PORT_T)]
    clx_mpls_createPwPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 675
if _libs["libsai.so"].has("clx_mpls_destroyPwPort", "cdecl"):
    clx_mpls_destroyPwPort = _libs["libsai.so"].get("clx_mpls_destroyPwPort", "cdecl")
    clx_mpls_destroyPwPort.argtypes = [UI32_T, CLX_PORT_T]
    clx_mpls_destroyPwPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 696
if _libs["libsai.so"].has("clx_mpls_getPwPort", "cdecl"):
    clx_mpls_getPwPort = _libs["libsai.so"].get("clx_mpls_getPwPort", "cdecl")
    clx_mpls_getPwPort.argtypes = [UI32_T, POINTER(CLX_MPLS_PW_KEY_T), POINTER(CLX_PORT_T)]
    clx_mpls_getPwPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 718
if _libs["libsai.so"].has("clx_mpls_getPwKey", "cdecl"):
    clx_mpls_getPwKey = _libs["libsai.so"].get("clx_mpls_getPwKey", "cdecl")
    clx_mpls_getPwKey.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_MPLS_PW_KEY_T)]
    clx_mpls_getPwKey.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 741
if _libs["libsai.so"].has("clx_mpls_addPw", "cdecl"):
    clx_mpls_addPw = _libs["libsai.so"].get("clx_mpls_addPw", "cdecl")
    clx_mpls_addPw.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_MPLS_PW_T)]
    clx_mpls_addPw.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 763
if _libs["libsai.so"].has("clx_mpls_delPw", "cdecl"):
    clx_mpls_delPw = _libs["libsai.so"].get("clx_mpls_delPw", "cdecl")
    clx_mpls_delPw.argtypes = [UI32_T, CLX_PORT_T]
    clx_mpls_delPw.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 784
if _libs["libsai.so"].has("clx_mpls_getPw", "cdecl"):
    clx_mpls_getPw = _libs["libsai.so"].get("clx_mpls_getPw", "cdecl")
    clx_mpls_getPw.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_MPLS_PW_T)]
    clx_mpls_getPw.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 807
if _libs["libsai.so"].has("clx_mpls_addVpws", "cdecl"):
    clx_mpls_addVpws = _libs["libsai.so"].get("clx_mpls_addVpws", "cdecl")
    clx_mpls_addVpws.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_MPLS_AC_T)]
    clx_mpls_addVpws.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 829
if _libs["libsai.so"].has("clx_mpls_delVpws", "cdecl"):
    clx_mpls_delVpws = _libs["libsai.so"].get("clx_mpls_delVpws", "cdecl")
    clx_mpls_delVpws.argtypes = [UI32_T, CLX_PORT_T]
    clx_mpls_delVpws.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 850
if _libs["libsai.so"].has("clx_mpls_getVpws", "cdecl"):
    clx_mpls_getVpws = _libs["libsai.so"].get("clx_mpls_getVpws", "cdecl")
    clx_mpls_getVpws.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_MPLS_AC_T)]
    clx_mpls_getVpws.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 874
if _libs["libsai.so"].has("clx_mpls_setLabelRange", "cdecl"):
    clx_mpls_setLabelRange = _libs["libsai.so"].get("clx_mpls_setLabelRange", "cdecl")
    clx_mpls_setLabelRange.argtypes = [UI32_T, CLX_MPLS_LABEL_TYPE_T, UI32_T, UI32_T]
    clx_mpls_setLabelRange.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 898
if _libs["libsai.so"].has("clx_mpls_getLabelRange", "cdecl"):
    clx_mpls_getLabelRange = _libs["libsai.so"].get("clx_mpls_getLabelRange", "cdecl")
    clx_mpls_getLabelRange.argtypes = [UI32_T, CLX_MPLS_LABEL_TYPE_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_mpls_getLabelRange.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 923
if _libs["libsai.so"].has("clx_mpls_traverseInit", "cdecl"):
    clx_mpls_traverseInit = _libs["libsai.so"].get("clx_mpls_traverseInit", "cdecl")
    clx_mpls_traverseInit.argtypes = [UI32_T, CLX_MPLS_INIT_TRAVERSE_FUNC_T, POINTER(None)]
    clx_mpls_traverseInit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 947
if _libs["libsai.so"].has("clx_mpls_traverseTransit", "cdecl"):
    clx_mpls_traverseTransit = _libs["libsai.so"].get("clx_mpls_traverseTransit", "cdecl")
    clx_mpls_traverseTransit.argtypes = [UI32_T, CLX_MPLS_TRANSIT_TRAVERSE_FUNC_T, POINTER(None)]
    clx_mpls_traverseTransit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 971
if _libs["libsai.so"].has("clx_mpls_traverseTerm", "cdecl"):
    clx_mpls_traverseTerm = _libs["libsai.so"].get("clx_mpls_traverseTerm", "cdecl")
    clx_mpls_traverseTerm.argtypes = [UI32_T, CLX_MPLS_TERM_TRAVERSE_FUNC_T, POINTER(None)]
    clx_mpls_traverseTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mpls.h: 995
if _libs["libsai.so"].has("clx_mpls_traversePw", "cdecl"):
    clx_mpls_traversePw = _libs["libsai.so"].get("clx_mpls_traversePw", "cdecl")
    clx_mpls_traversePw.argtypes = [UI32_T, CLX_MPLS_PW_TRAVERSE_FUNC_T, POINTER(None)]
    clx_mpls_traversePw.restype = CLX_ERROR_NO_T

enum_anon_62 = c_int# ./clx_system/clx_sdk/include/clx_pkt.h: 73

CLX_PKT_SDN_PHY_PORT = 0# ./clx_system/clx_sdk/include/clx_pkt.h: 73

CLX_PKT_SDN_LAG_PORT = 1# ./clx_system/clx_sdk/include/clx_pkt.h: 73

CLX_PKT_SDN_TUNNEL_PORT = 2# ./clx_system/clx_sdk/include/clx_pkt.h: 73

CLX_PKT_SDN_RSV_PORT = 255# ./clx_system/clx_sdk/include/clx_pkt.h: 73

CLX_PKT_SDN_PORT_TYPE_T = enum_anon_62# ./clx_system/clx_sdk/include/clx_pkt.h: 73

# ./clx_system/clx_sdk/include/clx_pkt.h: 83
class struct_CLX_PKT_SDN_PORT_S(Structure):
    pass

struct_CLX_PKT_SDN_PORT_S.__slots__ = [
    'port_type',
    'port_no',
]
struct_CLX_PKT_SDN_PORT_S._fields_ = [
    ('port_type', CLX_PKT_SDN_PORT_TYPE_T),
    ('port_no', UI32_T),
]

CLX_PKT_SDN_PORT_T = struct_CLX_PKT_SDN_PORT_S# ./clx_system/clx_sdk/include/clx_pkt.h: 83

# ./clx_system/clx_sdk/include/clx_pkt.h: 95
class struct_CLX_PKT_SDN_TUNNEL_S(Structure):
    pass

struct_CLX_PKT_SDN_TUNNEL_S.__slots__ = [
    'tunnel_type',
    'tunnel_no',
]
struct_CLX_PKT_SDN_TUNNEL_S._fields_ = [
    ('tunnel_type', CLX_TUNNEL_TYPE_T),
    ('tunnel_no', UI32_T),
]

CLX_PKT_SDN_TUNNEL_T = struct_CLX_PKT_SDN_TUNNEL_S# ./clx_system/clx_sdk/include/clx_pkt.h: 95

enum_anon_63 = c_int# ./clx_system/clx_sdk/include/clx_pkt.h: 107

CLX_PKT_SDN_PKT_IN_REASON_TABLE_MISS = 0# ./clx_system/clx_sdk/include/clx_pkt.h: 107

CLX_PKT_SDN_PKT_IN_REASON_APPLY_ACTION = 1# ./clx_system/clx_sdk/include/clx_pkt.h: 107

CLX_PKT_SDN_PKT_IN_REASON_INVALID_TTL = 2# ./clx_system/clx_sdk/include/clx_pkt.h: 107

CLX_PKT_SDN_PKT_IN_REASON_ACTION_SET = 3# ./clx_system/clx_sdk/include/clx_pkt.h: 107

CLX_PKT_SDN_PKT_IN_REASON_GROUP = 4# ./clx_system/clx_sdk/include/clx_pkt.h: 107

CLX_PKT_SDN_PKT_IN_REASON_PACKET_OUT = 5# ./clx_system/clx_sdk/include/clx_pkt.h: 107

CLX_PKT_SDN_PKT_IN_REASON_LAST = (CLX_PKT_SDN_PKT_IN_REASON_PACKET_OUT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 107

CLX_PKT_SDN_PKT_IN_REASON_T = enum_anon_63# ./clx_system/clx_sdk/include/clx_pkt.h: 107

enum_anon_64 = c_int# ./clx_system/clx_sdk/include/clx_pkt.h: 119

CLX_PKT_KEY_TYPE_IPV6 = 0# ./clx_system/clx_sdk/include/clx_pkt.h: 119

CLX_PKT_KEY_TYPE_IPV4 = (CLX_PKT_KEY_TYPE_IPV6 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 119

CLX_PKT_KEY_TYPE_ARP = (CLX_PKT_KEY_TYPE_IPV4 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 119

CLX_PKT_KEY_TYPE_L2 = (CLX_PKT_KEY_TYPE_ARP + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 119

CLX_PKT_KEY_TYPE_TUNNEL = (CLX_PKT_KEY_TYPE_L2 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 119

CLX_PKT_KEY_TYPE_LAST = (CLX_PKT_KEY_TYPE_TUNNEL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 119

CLX_PKT_KEY_TYPE_T = enum_anon_64# ./clx_system/clx_sdk/include/clx_pkt.h: 119

enum_anon_65 = c_int# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_NONE = 0# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_TRILL = (CLX_PKT_TUNNEL_TYPE_NONE + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_MPLS_GAL = (CLX_PKT_TUNNEL_TYPE_TRILL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_MPLS_PW = (CLX_PKT_TUNNEL_TYPE_MPLS_GAL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_GRE_L2 = (CLX_PKT_TUNNEL_TYPE_MPLS_PW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_GRE = (CLX_PKT_TUNNEL_TYPE_GRE_L2 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_VXLAN_GPE_L2 = (CLX_PKT_TUNNEL_TYPE_GRE + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_VXLAN_GPE = (CLX_PKT_TUNNEL_TYPE_VXLAN_GPE_L2 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_VXLAN_BAS_L2 = (CLX_PKT_TUNNEL_TYPE_VXLAN_GPE + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_VXLAN_BAS = (CLX_PKT_TUNNEL_TYPE_VXLAN_BAS_L2 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_IP = (CLX_PKT_TUNNEL_TYPE_VXLAN_BAS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_GENEVE_L2 = (CLX_PKT_TUNNEL_TYPE_IP + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_GENEVE = (CLX_PKT_TUNNEL_TYPE_GENEVE_L2 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_LAST = (CLX_PKT_TUNNEL_TYPE_GENEVE + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 138

CLX_PKT_TUNNEL_TYPE_T = enum_anon_65# ./clx_system/clx_sdk/include/clx_pkt.h: 138

enum_anon_66 = c_int# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_ECIA_SFLOW = 0# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VLAN_MISS_VLAN_CHK = (CLX_PKT_RX_REASON_ECIA_SFLOW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_PAR_ERR = (CLX_PKT_RX_REASON_VLAN_MISS_VLAN_CHK + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_PAR_WARN = (CLX_PKT_RX_REASON_PAR_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_DOS_CHK = (CLX_PKT_RX_REASON_PAR_WARN + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_BFD_CTRL_PKT = (CLX_PKT_RX_REASON_DOS_CHK + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_INVALID_BFD_PKT = (CLX_PKT_RX_REASON_BFD_CTRL_PKT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_SA_LEARN_FAIL = (CLX_PKT_RX_REASON_INVALID_BFD_PKT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TUNNEL_ECN_CU = (CLX_PKT_RX_REASON_SA_LEARN_FAIL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_FCOE_CLASS_2_F = (CLX_PKT_RX_REASON_TUNNEL_ECN_CU + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_URPF_CHECK_FAIL = (CLX_PKT_RX_REASON_FCOE_CLASS_2_F + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_L3_LKP_MISS = (CLX_PKT_RX_REASON_URPF_CHECK_FAIL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_ICMP_REDIRECT = (CLX_PKT_RX_REASON_L3_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV4_HDR_OPTION = (CLX_PKT_RX_REASON_ICMP_REDIRECT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VCLAG_INVALID = (CLX_PKT_RX_REASON_IPV4_HDR_OPTION + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VM_RPF_FAIL = (CLX_PKT_RX_REASON_VCLAG_INVALID + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VM_L2_FDB_MISS = (CLX_PKT_RX_REASON_VM_RPF_FAIL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IGR_PORT_SFLOW = (CLX_PKT_RX_REASON_VM_L2_FDB_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_EGR_PORT_SFLOW = (CLX_PKT_RX_REASON_IGR_PORT_SFLOW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IGR_FD_SFLOW = (CLX_PKT_RX_REASON_EGR_PORT_SFLOW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_ICIA_SFLOW = (CLX_PKT_RX_REASON_IGR_FD_SFLOW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPSG_CHK = (CLX_PKT_RX_REASON_ICIA_SFLOW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_FCOE_IFR_TO_CPU = (CLX_PKT_RX_REASON_IPSG_CHK + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TTL_EXPIRE = (CLX_PKT_RX_REASON_FCOE_IFR_TO_CPU + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_L3MC_RPF_CHECK = (CLX_PKT_RX_REASON_TTL_EXPIRE + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV6_HOP_BY_HOP_EXT_HDR = (CLX_PKT_RX_REASON_L3MC_RPF_CHECK + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VM_PDU = (CLX_PKT_RX_REASON_IPV6_HOP_BY_HOP_EXT_HDR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_PIM_REGISTER = (CLX_PKT_RX_REASON_VM_PDU + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TUNNEL_TERM_LKP_MISS = (CLX_PKT_RX_REASON_PIM_REGISTER + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_PP = (CLX_PKT_RX_REASON_TUNNEL_TERM_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_EGR_FD_SFLOW = (CLX_PKT_RX_REASON_PP + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VXLAN_ROUTER_ALERT = (CLX_PKT_RX_REASON_EGR_FD_SFLOW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_NVGRE_ROUTER_ALERT = (CLX_PKT_RX_REASON_VXLAN_ROUTER_ALERT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_EX_PMOD_LIMIT = (CLX_PKT_RX_REASON_NVGRE_ROUTER_ALERT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_L3MC_SPT_READY_UNSET = (CLX_PKT_RX_REASON_EX_PMOD_LIMIT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IGR_MTU_FAIL = (CLX_PKT_RX_REASON_L3MC_SPT_READY_UNSET + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_EGR_MTU_FAIL = (CLX_PKT_RX_REASON_IGR_MTU_FAIL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VXLAN_PING = (CLX_PKT_RX_REASON_EGR_MTU_FAIL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_REDIRECT_TO_CPU_L2MC = (CLX_PKT_RX_REASON_VXLAN_PING + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_REDIRECT_TO_CPU_L3MC = (CLX_PKT_RX_REASON_REDIRECT_TO_CPU_L2MC + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_REDIRECT_TO_CPU_L2UC = (CLX_PKT_RX_REASON_REDIRECT_TO_CPU_L3MC + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_REDIRECT_TO_CPU_L3UC = (CLX_PKT_RX_REASON_REDIRECT_TO_CPU_L2UC + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_SDN_IGR_FLOW_SFLOW = (CLX_PKT_RX_REASON_REDIRECT_TO_CPU_L3UC + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_SDN_EGR_FLOW_SFLOW = (CLX_PKT_RX_REASON_SDN_IGR_FLOW_SFLOW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_SDN_HW_LIMITATION = (CLX_PKT_RX_REASON_SDN_EGR_FLOW_SFLOW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_SDN_OTHERS = (CLX_PKT_RX_REASON_SDN_HW_LIMITATION + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_SDN_PKT_IN = (CLX_PKT_RX_REASON_SDN_OTHERS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_SDN_TO_LOCAL = (CLX_PKT_RX_REASON_SDN_PKT_IN + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_CIA_0 = (CLX_PKT_RX_REASON_SDN_TO_LOCAL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_CIA_1 = (CLX_PKT_RX_REASON_CIA_0 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_CIA_2 = (CLX_PKT_RX_REASON_CIA_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_CIA_3 = (CLX_PKT_RX_REASON_CIA_2 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_CIA_4 = (CLX_PKT_RX_REASON_CIA_3 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_CIA_5 = (CLX_PKT_RX_REASON_CIA_4 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_CIA_6 = (CLX_PKT_RX_REASON_CIA_5 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_CIA_7 = (CLX_PKT_RX_REASON_CIA_6 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_0 = (CLX_PKT_RX_REASON_CIA_7 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_1 = (CLX_PKT_RX_REASON_USR_DEFINE_0 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_2 = (CLX_PKT_RX_REASON_USR_DEFINE_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_3 = (CLX_PKT_RX_REASON_USR_DEFINE_2 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_4 = (CLX_PKT_RX_REASON_USR_DEFINE_3 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_5 = (CLX_PKT_RX_REASON_USR_DEFINE_4 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_6 = (CLX_PKT_RX_REASON_USR_DEFINE_5 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_7 = (CLX_PKT_RX_REASON_USR_DEFINE_6 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_8 = (CLX_PKT_RX_REASON_USR_DEFINE_7 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_9 = (CLX_PKT_RX_REASON_USR_DEFINE_8 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_10 = (CLX_PKT_RX_REASON_USR_DEFINE_9 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_11 = (CLX_PKT_RX_REASON_USR_DEFINE_10 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_12 = (CLX_PKT_RX_REASON_USR_DEFINE_11 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_USR_DEFINE_13 = (CLX_PKT_RX_REASON_USR_DEFINE_12 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_L2_LKP_MISS = (CLX_PKT_RX_REASON_USR_DEFINE_13 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_L2_HDR_MISS = (CLX_PKT_RX_REASON_L2_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_L2_SA_MISS = (CLX_PKT_RX_REASON_L2_HDR_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_L2_SA_MOVE = (CLX_PKT_RX_REASON_L2_SA_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV4_VER_ERR = (CLX_PKT_RX_REASON_L2_SA_MOVE + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV4_OPT = (CLX_PKT_RX_REASON_IPV4_VER_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV4_LEN_ERR = (CLX_PKT_RX_REASON_IPV4_OPT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV4_CHKSM_ERR = (CLX_PKT_RX_REASON_IPV4_LEN_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV4_MC_MALFORMED = (CLX_PKT_RX_REASON_IPV4_CHKSM_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV4_MC_LKP_MISS = (CLX_PKT_RX_REASON_IPV4_MC_MALFORMED + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV6_VER_ERR = (CLX_PKT_RX_REASON_IPV4_MC_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV6_LEN_ERR = (CLX_PKT_RX_REASON_IPV6_VER_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV6_MC_MALFORMED = (CLX_PKT_RX_REASON_IPV6_LEN_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPV6_MC_LKP_MISS = (CLX_PKT_RX_REASON_IPV6_MC_MALFORMED + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_FCOE_VER_ERR = (CLX_PKT_RX_REASON_IPV6_MC_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_FCOE_LKP_MISS = (CLX_PKT_RX_REASON_FCOE_VER_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_FCOE_ZONING_FAIL = (CLX_PKT_RX_REASON_FCOE_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_MPLS_CTRL_PKT = (CLX_PKT_RX_REASON_FCOE_ZONING_FAIL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_MPLS_INVALID_PKT = (CLX_PKT_RX_REASON_MPLS_CTRL_PKT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_MPLS_LKP_MISS = (CLX_PKT_RX_REASON_MPLS_INVALID_PKT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_MPLS_UHP_P2P_MISS = (CLX_PKT_RX_REASON_MPLS_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_MPLS_UHP_TTL_0 = (CLX_PKT_RX_REASON_MPLS_UHP_P2P_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_MPLS_UHP_TTL_1 = (CLX_PKT_RX_REASON_MPLS_UHP_TTL_0 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_MPLS_TRANSIT_TTL_0 = (CLX_PKT_RX_REASON_MPLS_UHP_TTL_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_MPLS_TRANSIT_TTL_1 = (CLX_PKT_RX_REASON_MPLS_TRANSIT_TTL_0 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_MPLS_TERM_TTL_0 = (CLX_PKT_RX_REASON_MPLS_TRANSIT_TTL_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_MPLS_TERM_TTL_1 = (CLX_PKT_RX_REASON_MPLS_TERM_TTL_0 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_CTRL_PKT = (CLX_PKT_RX_REASON_MPLS_TERM_TTL_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_INNER_IPV4_UC_LCL = (CLX_PKT_RX_REASON_IP_TUNNEL_CTRL_PKT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_INNER_IPV6_UC_LCL = (CLX_PKT_RX_REASON_IP_TUNNEL_INNER_IPV4_UC_LCL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_INNER_MC_LCL = (CLX_PKT_RX_REASON_IP_TUNNEL_INNER_IPV6_UC_LCL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_INNER_VER_ERR = (CLX_PKT_RX_REASON_IP_TUNNEL_INNER_MC_LCL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_INNER_L3_ROUTE = (CLX_PKT_RX_REASON_IP_TUNNEL_INNER_VER_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV4_FRAG = (CLX_PKT_RX_REASON_IP_TUNNEL_INNER_L3_ROUTE + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV4_OPT = (CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV4_FRAG + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV4_AH = (CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV4_OPT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV4_TTL_0 = (CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV4_AH + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV4_TTL_1 = (CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV4_TTL_0 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV6_FRAG = (CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV4_TTL_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV6_OPT = (CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV6_FRAG + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV6_AH = (CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV6_OPT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV6_TTL_0 = (CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV6_AH + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV6_TTL_1 = (CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV6_TTL_0 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPUC_TUNNEL_INNER_VLAN_MISS = (CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_IPV6_TTL_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IPMC_TUNNEL_INNER_VLAN_MISS = (CLX_PKT_RX_REASON_IPUC_TUNNEL_INNER_VLAN_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_AUTO_TUNNEL_DIP_MISS = (CLX_PKT_RX_REASON_IPMC_TUNNEL_INNER_VLAN_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_AUTO_TUNNEL_SIP_MISS = (CLX_PKT_RX_REASON_AUTO_TUNNEL_DIP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_ETHER_IP_VER_ERR = (CLX_PKT_RX_REASON_AUTO_TUNNEL_SIP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_GRE_VER_ERR = (CLX_PKT_RX_REASON_ETHER_IP_VER_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_GRE_RSVD_NON_ZERO = (CLX_PKT_RX_REASON_GRE_VER_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_GRE_CTRL_FLAG_ERR = (CLX_PKT_RX_REASON_GRE_RSVD_NON_ZERO + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_GRE_ERSPAN_TYP2_VER_ERR = (CLX_PKT_RX_REASON_GRE_CTRL_FLAG_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_GRE_ERSPAN_TYP3_VER_ERR = (CLX_PKT_RX_REASON_GRE_ERSPAN_TYP2_VER_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_GRE_ERSPAN_TYP3_FT_ERR = (CLX_PKT_RX_REASON_GRE_ERSPAN_TYP3_VER_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_GRE_ERSPAN_TERM_LKP_MISS = (CLX_PKT_RX_REASON_GRE_ERSPAN_TYP3_FT_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VXLAN_BAS_RSVD_NON_ZERO = (CLX_PKT_RX_REASON_GRE_ERSPAN_TERM_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VXLAN_BAS_VNI_FLAG_ERR = (CLX_PKT_RX_REASON_VXLAN_BAS_RSVD_NON_ZERO + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VXLAN_BAS_CTRL_FLAG_ERR = (CLX_PKT_RX_REASON_VXLAN_BAS_VNI_FLAG_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VXLAN_BAS_UDP_CHKSM_ERR = (CLX_PKT_RX_REASON_VXLAN_BAS_CTRL_FLAG_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VXLAN_GPE_VNI_FLAG_ERR = (CLX_PKT_RX_REASON_VXLAN_BAS_UDP_CHKSM_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VXLAN_GPE_CTRL_FLAG_ERR = (CLX_PKT_RX_REASON_VXLAN_GPE_VNI_FLAG_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_VXLAN_GPE_UDP_CHKSM_ERR = (CLX_PKT_RX_REASON_VXLAN_GPE_CTRL_FLAG_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TRILL_VER_ERR = (CLX_PKT_RX_REASON_VXLAN_GPE_UDP_CHKSM_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TRILL_MC_FLAG_ERR = (CLX_PKT_RX_REASON_TRILL_VER_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TRILL_OPT = (CLX_PKT_RX_REASON_TRILL_MC_FLAG_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TRILL_LKP_MISS = (CLX_PKT_RX_REASON_TRILL_OPT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TRILL_TRANSIT_TTL_0 = (CLX_PKT_RX_REASON_TRILL_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TRILL_TRANSIT_TTL_1 = (CLX_PKT_RX_REASON_TRILL_TRANSIT_TTL_0 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TRILL_TERM_TTL_0 = (CLX_PKT_RX_REASON_TRILL_TRANSIT_TTL_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TRILL_TERM_TTL_1 = (CLX_PKT_RX_REASON_TRILL_TERM_TTL_0 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TRILL_MRPF_CHECK_FAIL = (CLX_PKT_RX_REASON_TRILL_TERM_TTL_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_NSH_CTRL_PKT = (CLX_PKT_RX_REASON_TRILL_MRPF_CHECK_FAIL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_NSH_INVALID_PKT = (CLX_PKT_RX_REASON_NSH_CTRL_PKT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_NSH_LKP_MISS = (CLX_PKT_RX_REASON_NSH_INVALID_PKT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_ECMP_LKP_MISS = (CLX_PKT_RX_REASON_NSH_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_ACL_LKP_MISS = (CLX_PKT_RX_REASON_ECMP_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_FLOW_LKP_MISS = (CLX_PKT_RX_REASON_ACL_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IGR_FLOW_SFLOW = (CLX_PKT_RX_REASON_FLOW_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_EGR_FLOW_SFLOW = (CLX_PKT_RX_REASON_IGR_FLOW_SFLOW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_HW_ERROR = (CLX_PKT_RX_REASON_EGR_FLOW_SFLOW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_1588_RX_PKT = (CLX_PKT_RX_REASON_HW_ERROR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_STP_BLOCK = (CLX_PKT_RX_REASON_1588_RX_PKT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_STACKING_NEIGHBOR = (CLX_PKT_RX_REASON_STP_BLOCK + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_STACKING_BROADCAST = (CLX_PKT_RX_REASON_STACKING_NEIGHBOR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_STACKING_LOOP = (CLX_PKT_RX_REASON_STACKING_BROADCAST + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_STORM_CONTROL = (CLX_PKT_RX_REASON_STACKING_LOOP + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TUNNEL_INIT_LKP_MISS = (CLX_PKT_RX_REASON_STORM_CONTROL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TUNNEL_INNER_VLAN_MISS = (CLX_PKT_RX_REASON_TUNNEL_INIT_LKP_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TUNNEL_INNER_VLAN_UNEXP = (CLX_PKT_RX_REASON_TUNNEL_INNER_VLAN_MISS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IGR_L3_MTU_FAIL = (CLX_PKT_RX_REASON_TUNNEL_INNER_VLAN_UNEXP + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_EGR_L3_MTU_FAIL = (CLX_PKT_RX_REASON_IGR_L3_MTU_FAIL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IGR_TUNNEL_MTU_FAIL = (CLX_PKT_RX_REASON_EGR_L3_MTU_FAIL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_EGR_TUNNEL_MTU_FAIL = (CLX_PKT_RX_REASON_IGR_TUNNEL_MTU_FAIL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_EGR_IPV4_TTL_1 = (CLX_PKT_RX_REASON_EGR_TUNNEL_MTU_FAIL + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_EGR_IPV6_TTL_1 = (CLX_PKT_RX_REASON_EGR_IPV4_TTL_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_COPY_TO_CPU_L2MC = (CLX_PKT_RX_REASON_EGR_IPV6_TTL_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_COPY_TO_CPU_L3MC = (CLX_PKT_RX_REASON_COPY_TO_CPU_L2MC + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_COPY_TO_CPU_L2UC = (CLX_PKT_RX_REASON_COPY_TO_CPU_L3MC + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_COPY_TO_CPU_L3UC = (CLX_PKT_RX_REASON_COPY_TO_CPU_L2UC + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_FLEX_TUNNEL_UDP_CHKSM_ERR = (CLX_PKT_RX_REASON_COPY_TO_CPU_L3UC + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_FLEX_TUNNEL_0_CHK = (CLX_PKT_RX_REASON_FLEX_TUNNEL_UDP_CHKSM_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_FLEX_TUNNEL_1_CHK = (CLX_PKT_RX_REASON_FLEX_TUNNEL_0_CHK + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_FLEX_TUNNEL_2_CHK = (CLX_PKT_RX_REASON_FLEX_TUNNEL_1_CHK + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_FLEX_TUNNEL_3_CHK = (CLX_PKT_RX_REASON_FLEX_TUNNEL_2_CHK + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_EGR_SFLOW_HIGH_LATENCY = (CLX_PKT_RX_REASON_FLEX_TUNNEL_3_CHK + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_DPP_LOOPBACK = (CLX_PKT_RX_REASON_EGR_SFLOW_HIGH_LATENCY + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_PPPOE_SRV_UNKNOWN = (CLX_PKT_RX_REASON_DPP_LOOPBACK + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_PPPOE_HDR_ERR = (CLX_PKT_RX_REASON_PPPOE_SRV_UNKNOWN + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_PPPOE_ENCAP_ERR = (CLX_PKT_RX_REASON_PPPOE_HDR_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_IPV4_ERR = (CLX_PKT_RX_REASON_PPPOE_ENCAP_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IP_TUNNEL_IPV6_ERR = (CLX_PKT_RX_REASON_IP_TUNNEL_IPV4_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_DECAP_NSH_TTL_1 = (CLX_PKT_RX_REASON_IP_TUNNEL_IPV6_ERR + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_TRANSIT_NSH_TTL_1 = (CLX_PKT_RX_REASON_DECAP_NSH_TTL_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_PORT_CLR_DROP = (CLX_PKT_RX_REASON_TRANSIT_NSH_TTL_1 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_WECMP = (CLX_PKT_RX_REASON_PORT_CLR_DROP + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IOAM_NODE_LEN_INVALID_IPV6 = (CLX_PKT_RX_REASON_WECMP + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IOAM_NODE_LEN_INVALID_GRE = (CLX_PKT_RX_REASON_IOAM_NODE_LEN_INVALID_IPV6 + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_IOAM_NODE_LEN_INVALID_GPE = (CLX_PKT_RX_REASON_IOAM_NODE_LEN_INVALID_GRE + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_OTHERS = (CLX_PKT_RX_REASON_IOAM_NODE_LEN_INVALID_GPE + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_LAST = (CLX_PKT_RX_REASON_OTHERS + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_T = enum_anon_66# ./clx_system/clx_sdk/include/clx_pkt.h: 347

CLX_PKT_RX_REASON_BITMAP_T = UI32_T * int((((CLX_PKT_RX_REASON_LAST - 1) / 32) + 1))# ./clx_system/clx_sdk/include/clx_pkt.h: 352

# ./clx_system/clx_sdk/include/clx_pkt.h: 391
class struct_anon_67(Structure):
    pass

struct_anon_67.__slots__ = [
    'dip',
    'dip_mask',
    'dip_max',
    'next_header',
    'next_header_mask',
    'dst_port',
    'dst_port_mask',
    'src_port',
    'src_port_mask',
    'icmp_type',
    'icmp_type_mask',
    'icmp_code',
    'icmp_code_mask',
    'flags',
    'term_type',
]
struct_anon_67._fields_ = [
    ('dip', CLX_IPV6_T),
    ('dip_mask', CLX_IPV6_T),
    ('dip_max', CLX_IPV6_T),
    ('next_header', UI8_T),
    ('next_header_mask', UI8_T),
    ('dst_port', UI16_T),
    ('dst_port_mask', UI16_T),
    ('src_port', UI16_T),
    ('src_port_mask', UI16_T),
    ('icmp_type', UI8_T),
    ('icmp_type_mask', UI8_T),
    ('icmp_code', UI8_T),
    ('icmp_code_mask', UI8_T),
    ('flags', UI32_T),
    ('term_type', CLX_PKT_TUNNEL_TYPE_T),
]

CLX_PKT_CTRL_TO_CPU_IPV6_KEY_T = struct_anon_67# ./clx_system/clx_sdk/include/clx_pkt.h: 391

# ./clx_system/clx_sdk/include/clx_pkt.h: 429
class struct_anon_68(Structure):
    pass

struct_anon_68.__slots__ = [
    'dip',
    'dip_mask',
    'dip_max',
    'protocol_id',
    'protocol_id_mask',
    'dst_port',
    'dst_port_mask',
    'src_port',
    'src_port_mask',
    'icmp_type',
    'icmp_type_mask',
    'icmp_code',
    'icmp_code_mask',
    'flags',
    'header_length',
    'header_length_mask',
    'term_type',
]
struct_anon_68._fields_ = [
    ('dip', CLX_IPV4_T),
    ('dip_mask', CLX_IPV4_T),
    ('dip_max', CLX_IPV4_T),
    ('protocol_id', UI8_T),
    ('protocol_id_mask', UI8_T),
    ('dst_port', UI16_T),
    ('dst_port_mask', UI16_T),
    ('src_port', UI16_T),
    ('src_port_mask', UI16_T),
    ('icmp_type', UI8_T),
    ('icmp_type_mask', UI8_T),
    ('icmp_code', UI8_T),
    ('icmp_code_mask', UI8_T),
    ('flags', UI32_T),
    ('header_length', UI8_T),
    ('header_length_mask', UI8_T),
    ('term_type', CLX_PKT_TUNNEL_TYPE_T),
]

CLX_PKT_CTRL_TO_CPU_IPV4_KEY_T = struct_anon_68# ./clx_system/clx_sdk/include/clx_pkt.h: 429

# ./clx_system/clx_sdk/include/clx_pkt.h: 446
class struct_anon_69(Structure):
    pass

struct_anon_69.__slots__ = [
    'oper',
    'oper_mask',
    'target_ip',
    'target_ip_mask',
    'flags',
    'term_type',
]
struct_anon_69._fields_ = [
    ('oper', UI16_T),
    ('oper_mask', UI16_T),
    ('target_ip', CLX_IPV4_T),
    ('target_ip_mask', CLX_IPV4_T),
    ('flags', UI32_T),
    ('term_type', CLX_PKT_TUNNEL_TYPE_T),
]

CLX_PKT_CTRL_TO_CPU_ARP_KEY_T = struct_anon_69# ./clx_system/clx_sdk/include/clx_pkt.h: 446

# ./clx_system/clx_sdk/include/clx_pkt.h: 467
class struct_anon_70(Structure):
    pass

struct_anon_70.__slots__ = [
    'da',
    'da_mask',
    'eth_type',
    'eth_type_mask',
    'sub_type',
    'sub_type_mask',
    'flags',
    'term_type',
]
struct_anon_70._fields_ = [
    ('da', CLX_MAC_T),
    ('da_mask', CLX_MAC_T),
    ('eth_type', UI16_T),
    ('eth_type_mask', UI16_T),
    ('sub_type', UI16_T),
    ('sub_type_mask', UI16_T),
    ('flags', UI32_T),
    ('term_type', CLX_PKT_TUNNEL_TYPE_T),
]

CLX_PKT_CTRL_TO_CPU_L2_KEY_T = struct_anon_70# ./clx_system/clx_sdk/include/clx_pkt.h: 467

# ./clx_system/clx_sdk/include/clx_pkt.h: 478
class struct_anon_71(Structure):
    pass

struct_anon_71.__slots__ = [
    'term_type',
    'data',
    'data_mask',
]
struct_anon_71._fields_ = [
    ('term_type', CLX_PKT_TUNNEL_TYPE_T),
    ('data', UI32_T * int(25)),
    ('data_mask', UI32_T * int(25)),
]

CLX_PKT_CTRL_TO_CPU_TUNNEL_KEY_T = struct_anon_71# ./clx_system/clx_sdk/include/clx_pkt.h: 478

# ./clx_system/clx_sdk/include/clx_pkt.h: 488
class union_anon_72(Union):
    pass

union_anon_72.__slots__ = [
    'ipv6',
    'ipv4',
    'arp',
    'l2',
    'tunnel',
]
union_anon_72._fields_ = [
    ('ipv6', CLX_PKT_CTRL_TO_CPU_IPV6_KEY_T),
    ('ipv4', CLX_PKT_CTRL_TO_CPU_IPV4_KEY_T),
    ('arp', CLX_PKT_CTRL_TO_CPU_ARP_KEY_T),
    ('l2', CLX_PKT_CTRL_TO_CPU_L2_KEY_T),
    ('tunnel', CLX_PKT_CTRL_TO_CPU_TUNNEL_KEY_T),
]

CLX_PKT_CTRL_TO_CPU_INKEY_T = union_anon_72# ./clx_system/clx_sdk/include/clx_pkt.h: 488

# ./clx_system/clx_sdk/include/clx_pkt.h: 514
class struct_anon_73(Structure):
    pass

struct_anon_73.__slots__ = [
    'key_type',
    'in_key_value',
    'tag',
    'tag_mask',
    'fwd_action',
    'cpu_reason_code',
    'ctrl_traffic',
    'bpdu',
    'learn',
    'check_vlan_tag',
    'check_vlan_member',
    'valid',
]
struct_anon_73._fields_ = [
    ('key_type', CLX_PKT_KEY_TYPE_T),
    ('in_key_value', CLX_PKT_CTRL_TO_CPU_INKEY_T),
    ('tag', BOOL_T),
    ('tag_mask', BOOL_T),
    ('fwd_action', CLX_FWD_ACTION_T),
    ('cpu_reason_code', CLX_PKT_RX_REASON_T),
    ('ctrl_traffic', UI32_T),
    ('bpdu', UI32_T),
    ('learn', UI32_T),
    ('check_vlan_tag', UI32_T),
    ('check_vlan_member', UI32_T),
    ('valid', BOOL_T),
]

CLX_PKT_CTRL_TO_CPU_ENTRY_T = struct_anon_73# ./clx_system/clx_sdk/include/clx_pkt.h: 514

enum_anon_74 = c_int# ./clx_system/clx_sdk/include/clx_pkt.h: 523

CLX_PKT_TO_CPU_PRI_COPY = 0# ./clx_system/clx_sdk/include/clx_pkt.h: 523

CLX_PKT_TO_CPU_PRI_REDIRECT = (CLX_PKT_TO_CPU_PRI_COPY + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 523

CLX_PKT_TO_CPU_PRI_LAST = (CLX_PKT_TO_CPU_PRI_REDIRECT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 523

CLX_PKT_TO_CPU_PRI_T = enum_anon_74# ./clx_system/clx_sdk/include/clx_pkt.h: 523

enum_anon_75 = c_int# ./clx_system/clx_sdk/include/clx_pkt.h: 532

CLX_PKT_TYPE_GENERIC = 0# ./clx_system/clx_sdk/include/clx_pkt.h: 532

CLX_PKT_TYPE_SDN = (CLX_PKT_TYPE_GENERIC + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 532

CLX_PKT_TYPE_LAST = (CLX_PKT_TYPE_SDN + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 532

CLX_PKT_TYPE_T = enum_anon_75# ./clx_system/clx_sdk/include/clx_pkt.h: 532

# ./clx_system/clx_sdk/include/clx_pkt.h: 539
class struct_anon_76(Structure):
    pass

struct_anon_76.__slots__ = [
    'outer',
    'inner',
]
struct_anon_76._fields_ = [
    ('outer', CLX_VLAN_T),
    ('inner', CLX_VLAN_T),
]

CLX_PKT_VLAN_T = struct_anon_76# ./clx_system/clx_sdk/include/clx_pkt.h: 539

enum_anon_77 = c_int# ./clx_system/clx_sdk/include/clx_pkt.h: 549

CLX_PKT_SEG_TYPE_VLAN_DOUBLE = 0# ./clx_system/clx_sdk/include/clx_pkt.h: 549

CLX_PKT_SEG_TYPE_VLAN_SINGLE = 1# ./clx_system/clx_sdk/include/clx_pkt.h: 549

CLX_PKT_SEG_TYPE_VXLAN = 2# ./clx_system/clx_sdk/include/clx_pkt.h: 549

CLX_PKT_SEG_TYPE_NVGRE = 3# ./clx_system/clx_sdk/include/clx_pkt.h: 549

CLX_PKT_SEG_TYPE_LAST = (CLX_PKT_SEG_TYPE_NVGRE + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 549

CLX_PKT_SEG_TYPE_T = enum_anon_77# ./clx_system/clx_sdk/include/clx_pkt.h: 549

# ./clx_system/clx_sdk/include/clx_pkt.h: 552
class struct_CLX_PKT_BLK_S(Structure):
    pass

struct_CLX_PKT_BLK_S.__slots__ = [
    'ptr_buf',
    'len',
    'ptr_next',
]
struct_CLX_PKT_BLK_S._fields_ = [
    ('ptr_buf', POINTER(UI8_T)),
    ('len', UI32_T),
    ('ptr_next', POINTER(struct_CLX_PKT_BLK_S)),
]

CLX_PKT_BLK_T = struct_CLX_PKT_BLK_S# ./clx_system/clx_sdk/include/clx_pkt.h: 557

# ./clx_system/clx_sdk/include/clx_pkt.h: 624
class struct_anon_78(Structure):
    pass

struct_anon_78.__slots__ = [
    'pkt_type',
    'color',
    'tc',
    'igr_phy_port',
    'egr_phy_port',
    'igr_port',
    'egr_port',
    'igr_tag_type',
    'bdid',
    'igr_intf_id',
    'egr_intf_id',
    'egr_seg_type',
    'egr_seg_id',
    'vmtag_type',
    'vm_id',
    'reason_bitmap',
    'queue',
    'group_label',
    'ts_sec',
    'ts_nsec',
    'path',
    'in_port',
    'in_phy_port',
    'table_id',
    'tunnel_header_length',
    'flow_id',
    'tunnel_id',
    'metadata',
    'reason_type',
    'igr_sflow_sample_point',
    'egr_sflow_sample_point',
    'ptr_data',
    'total_len',
    'flags',
]
struct_anon_78._fields_ = [
    ('pkt_type', CLX_PKT_TYPE_T),
    ('color', CLX_COLOR_T),
    ('tc', UI32_T),
    ('igr_phy_port', CLX_PORT_T),
    ('egr_phy_port', CLX_PORT_T),
    ('igr_port', CLX_PORT_T),
    ('egr_port', CLX_PORT_T),
    ('igr_tag_type', CLX_VLAN_TAG_T),
    ('bdid', CLX_BRIDGE_DOMAIN_T),
    ('igr_intf_id', UI32_T),
    ('egr_intf_id', UI32_T),
    ('egr_seg_type', CLX_PKT_SEG_TYPE_T),
    ('egr_seg_id', UI32_T),
    ('vmtag_type', CLX_VM_TAG_TYPE_T),
    ('vm_id', CLX_VM_ID_T),
    ('reason_bitmap', CLX_PKT_RX_REASON_BITMAP_T),
    ('queue', UI32_T),
    ('group_label', UI32_T),
    ('ts_sec', UI32_T),
    ('ts_nsec', UI32_T),
    ('path', UI32_T),
    ('in_port', CLX_PKT_SDN_PORT_T),
    ('in_phy_port', CLX_PKT_SDN_PORT_T),
    ('table_id', UI8_T),
    ('tunnel_header_length', UI16_T),
    ('flow_id', UI64_T),
    ('tunnel_id', CLX_PKT_SDN_TUNNEL_T),
    ('metadata', UI64_T),
    ('reason_type', CLX_PKT_SDN_PKT_IN_REASON_T),
    ('igr_sflow_sample_point', UI16_T),
    ('egr_sflow_sample_point', UI16_T),
    ('ptr_data', POINTER(CLX_PKT_BLK_T)),
    ('total_len', UI32_T),
    ('flags', UI32_T),
]

CLX_PKT_RX_PKT_T = struct_anon_78# ./clx_system/clx_sdk/include/clx_pkt.h: 624

CLX_PKT_RX_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_PKT_RX_PKT_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_pkt.h: 629

CLX_PKT_RX_ALLOC_FUNC_T = CFUNCTYPE(UNCHECKED(POINTER(c_ubyte)), )# ./clx_system/clx_sdk/include/clx_pkt.h: 635

CLX_PKT_RX_FREE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_pkt.h: 640

# ./clx_system/clx_sdk/include/clx_pkt.h: 654
class struct_anon_79(Structure):
    pass

struct_anon_79.__slots__ = [
    'buf_len',
    'rx_alloc',
    'rx_free',
    'callback',
    'ptr_cookie',
    'flags',
]
struct_anon_79._fields_ = [
    ('buf_len', UI32_T),
    ('rx_alloc', CLX_PKT_RX_ALLOC_FUNC_T),
    ('rx_free', CLX_PKT_RX_FREE_FUNC_T),
    ('callback', CLX_PKT_RX_FUNC_T),
    ('ptr_cookie', POINTER(None)),
    ('flags', UI32_T),
]

CLX_PKT_RX_CFG_T = struct_anon_79# ./clx_system/clx_sdk/include/clx_pkt.h: 654

CLX_PKT_TX_FUNC_T = CFUNCTYPE(UNCHECKED(None), UI32_T, POINTER(None), POINTER(None))# ./clx_system/clx_sdk/include/clx_pkt.h: 658

enum_anon_80 = c_int# ./clx_system/clx_sdk/include/clx_pkt.h: 668

CLX_PKT_TX_MODE_ETH = 1# ./clx_system/clx_sdk/include/clx_pkt.h: 668

CLX_PKT_TX_MODE_RAW = 3# ./clx_system/clx_sdk/include/clx_pkt.h: 668

CLX_PKT_TX_MODE_LAST = (CLX_PKT_TX_MODE_RAW + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 668

CLX_PKT_TX_MODE_T = enum_anon_80# ./clx_system/clx_sdk/include/clx_pkt.h: 668

enum_anon_81 = c_int# ./clx_system/clx_sdk/include/clx_pkt.h: 676

CLX_PKT_TX_RAW_MODE_PORT = 0# ./clx_system/clx_sdk/include/clx_pkt.h: 676

CLX_PKT_TX_RAW_MODE_CPU = (CLX_PKT_TX_RAW_MODE_PORT + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 676

CLX_PKT_TX_RAW_MODE_MCAST = (CLX_PKT_TX_RAW_MODE_CPU + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 676

CLX_PKT_TX_RAW_MODE_LAST = (CLX_PKT_TX_RAW_MODE_MCAST + 1)# ./clx_system/clx_sdk/include/clx_pkt.h: 676

CLX_PKT_TX_RAW_MODE_T = enum_anon_81# ./clx_system/clx_sdk/include/clx_pkt.h: 676

# ./clx_system/clx_sdk/include/clx_pkt.h: 696
class struct_anon_82(Structure):
    pass

struct_anon_82.__slots__ = [
    'type',
    'egr_phy_port',
    'cpu_id',
    'rmt_cpu_queue',
    'mcast_id',
    'color',
    'tc',
    'pcp',
]
struct_anon_82._fields_ = [
    ('type', CLX_PKT_TX_RAW_MODE_T),
    ('egr_phy_port', CLX_PORT_T),
    ('cpu_id', UI32_T),
    ('rmt_cpu_queue', UI32_T),
    ('mcast_id', UI32_T),
    ('color', CLX_COLOR_T),
    ('tc', UI32_T),
    ('pcp', UI8_T),
]

CLX_PKT_TX_RAW_T = struct_anon_82# ./clx_system/clx_sdk/include/clx_pkt.h: 696

# ./clx_system/clx_sdk/include/clx_pkt.h: 702
class struct_anon_83(Structure):
    pass

struct_anon_83.__slots__ = [
    'igr_phy_port',
]
struct_anon_83._fields_ = [
    ('igr_phy_port', CLX_PORT_T),
]

CLX_PKT_TX_ETH_T = struct_anon_83# ./clx_system/clx_sdk/include/clx_pkt.h: 702

# ./clx_system/clx_sdk/include/clx_pkt.h: 710
class union_anon_84(Union):
    pass

union_anon_84.__slots__ = [
    'raw',
    'eth',
]
union_anon_84._fields_ = [
    ('raw', CLX_PKT_TX_RAW_T),
    ('eth', CLX_PKT_TX_ETH_T),
]

# ./clx_system/clx_sdk/include/clx_pkt.h: 731
class struct_anon_85(Structure):
    pass

struct_anon_85.__slots__ = [
    'pkt_type',
    'tx_mode',
    'unnamed_1',
    'ptr_data',
    'callback',
    'ptr_cookie',
    'seq_num',
    'flags',
]
struct_anon_85._anonymous_ = [
    'unnamed_1',
]
struct_anon_85._fields_ = [
    ('pkt_type', CLX_PKT_TYPE_T),
    ('tx_mode', CLX_PKT_TX_MODE_T),
    ('unnamed_1', union_anon_84),
    ('ptr_data', POINTER(CLX_PKT_BLK_T)),
    ('callback', CLX_PKT_TX_FUNC_T),
    ('ptr_cookie', POINTER(None)),
    ('seq_num', UI16_T),
    ('flags', UI32_T),
]

CLX_PKT_TX_PKT_T = struct_anon_85# ./clx_system/clx_sdk/include/clx_pkt.h: 731

# ./clx_system/clx_sdk/include/clx_pkt.h: 740
class struct_anon_86(Structure):
    pass

struct_anon_86.__slots__ = [
    'packet',
    'under_size_err',
    'over_size_err',
]
struct_anon_86._fields_ = [
    ('packet', UI32_T),
    ('under_size_err', UI32_T),
    ('over_size_err', UI32_T),
]

CLX_PKT_TX_CNT_T = struct_anon_86# ./clx_system/clx_sdk/include/clx_pkt.h: 740

# ./clx_system/clx_sdk/include/clx_pkt.h: 746
class struct_anon_87(Structure):
    pass

struct_anon_87.__slots__ = [
    'packet',
]
struct_anon_87._fields_ = [
    ('packet', UI32_T),
]

CLX_PKT_RX_CNT_T = struct_anon_87# ./clx_system/clx_sdk/include/clx_pkt.h: 746

# ./clx_system/clx_sdk/include/clx_pkt.h: 766
if _libs["libsai.so"].has("clx_pkt_setRxConfig", "cdecl"):
    clx_pkt_setRxConfig = _libs["libsai.so"].get("clx_pkt_setRxConfig", "cdecl")
    clx_pkt_setRxConfig.argtypes = [UI32_T, POINTER(CLX_PKT_RX_CFG_T)]
    clx_pkt_setRxConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 784
if _libs["libsai.so"].has("clx_pkt_getRxConfig", "cdecl"):
    clx_pkt_getRxConfig = _libs["libsai.so"].get("clx_pkt_getRxConfig", "cdecl")
    clx_pkt_getRxConfig.argtypes = [UI32_T, POINTER(CLX_PKT_RX_CFG_T)]
    clx_pkt_getRxConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 805
if _libs["libsai.so"].has("clx_pkt_sendPacket", "cdecl"):
    clx_pkt_sendPacket = _libs["libsai.so"].get("clx_pkt_sendPacket", "cdecl")
    clx_pkt_sendPacket.argtypes = [UI32_T, UI32_T, POINTER(CLX_PKT_TX_PKT_T)]
    clx_pkt_sendPacket.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 827
if _libs["libsai.so"].has("clx_pkt_setQueueToRxChannel", "cdecl"):
    clx_pkt_setQueueToRxChannel = _libs["libsai.so"].get("clx_pkt_setQueueToRxChannel", "cdecl")
    clx_pkt_setQueueToRxChannel.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_pkt_setQueueToRxChannel.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 848
if _libs["libsai.so"].has("clx_pkt_getQueueToRxChannel", "cdecl"):
    clx_pkt_getQueueToRxChannel = _libs["libsai.so"].get("clx_pkt_getQueueToRxChannel", "cdecl")
    clx_pkt_getQueueToRxChannel.argtypes = [UI32_T, UI32_T, POINTER(UI32_T)]
    clx_pkt_getQueueToRxChannel.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 869
if _libs["libsai.so"].has("clx_pkt_setRxQueueTruncateSize", "cdecl"):
    clx_pkt_setRxQueueTruncateSize = _libs["libsai.so"].get("clx_pkt_setRxQueueTruncateSize", "cdecl")
    clx_pkt_setRxQueueTruncateSize.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_pkt_setRxQueueTruncateSize.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 890
if _libs["libsai.so"].has("clx_pkt_getRxQueueTruncateSize", "cdecl"):
    clx_pkt_getRxQueueTruncateSize = _libs["libsai.so"].get("clx_pkt_getRxQueueTruncateSize", "cdecl")
    clx_pkt_getRxQueueTruncateSize.argtypes = [UI32_T, UI32_T, POINTER(UI32_T)]
    clx_pkt_getRxQueueTruncateSize.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 912
if _libs["libsai.so"].has("clx_pkt_setTxChannelCosBitmap", "cdecl"):
    clx_pkt_setTxChannelCosBitmap = _libs["libsai.so"].get("clx_pkt_setTxChannelCosBitmap", "cdecl")
    clx_pkt_setTxChannelCosBitmap.argtypes = [UI32_T, UI32_T, UI8_T]
    clx_pkt_setTxChannelCosBitmap.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 932
if _libs["libsai.so"].has("clx_pkt_getTxChannelCosBitmap", "cdecl"):
    clx_pkt_getTxChannelCosBitmap = _libs["libsai.so"].get("clx_pkt_getTxChannelCosBitmap", "cdecl")
    clx_pkt_getTxChannelCosBitmap.argtypes = [UI32_T, UI32_T, POINTER(UI8_T)]
    clx_pkt_getTxChannelCosBitmap.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 954
if _libs["libsai.so"].has("clx_pkt_setCtrlToCpuEntry", "cdecl"):
    clx_pkt_setCtrlToCpuEntry = _libs["libsai.so"].get("clx_pkt_setCtrlToCpuEntry", "cdecl")
    clx_pkt_setCtrlToCpuEntry.argtypes = [UI32_T, UI32_T, POINTER(CLX_PKT_CTRL_TO_CPU_ENTRY_T)]
    clx_pkt_setCtrlToCpuEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 975
if _libs["libsai.so"].has("clx_pkt_getCtrlToCpuEntry", "cdecl"):
    clx_pkt_getCtrlToCpuEntry = _libs["libsai.so"].get("clx_pkt_getCtrlToCpuEntry", "cdecl")
    clx_pkt_getCtrlToCpuEntry.argtypes = [UI32_T, UI32_T, POINTER(CLX_PKT_CTRL_TO_CPU_ENTRY_T)]
    clx_pkt_getCtrlToCpuEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 995
if _libs["libsai.so"].has("clx_pkt_delCtrlToCpuEntryAll", "cdecl"):
    clx_pkt_delCtrlToCpuEntryAll = _libs["libsai.so"].get("clx_pkt_delCtrlToCpuEntryAll", "cdecl")
    clx_pkt_delCtrlToCpuEntryAll.argtypes = [UI32_T]
    clx_pkt_delCtrlToCpuEntryAll.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 1014
if _libs["libsai.so"].has("clx_pkt_setRxDefaultQueue", "cdecl"):
    clx_pkt_setRxDefaultQueue = _libs["libsai.so"].get("clx_pkt_setRxDefaultQueue", "cdecl")
    clx_pkt_setRxDefaultQueue.argtypes = [UI32_T, UI32_T]
    clx_pkt_setRxDefaultQueue.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 1033
if _libs["libsai.so"].has("clx_pkt_getRxDefaultQueue", "cdecl"):
    clx_pkt_getRxDefaultQueue = _libs["libsai.so"].get("clx_pkt_getRxDefaultQueue", "cdecl")
    clx_pkt_getRxDefaultQueue.argtypes = [UI32_T, POINTER(UI32_T)]
    clx_pkt_getRxDefaultQueue.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 1054
if _libs["libsai.so"].has("clx_pkt_setRxQueueMapping", "cdecl"):
    clx_pkt_setRxQueueMapping = _libs["libsai.so"].get("clx_pkt_setRxQueueMapping", "cdecl")
    clx_pkt_setRxQueueMapping.argtypes = [UI32_T, UI32_T, CLX_PKT_RX_REASON_BITMAP_T]
    clx_pkt_setRxQueueMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 1075
if _libs["libsai.so"].has("clx_pkt_getRxQueueMapping", "cdecl"):
    clx_pkt_getRxQueueMapping = _libs["libsai.so"].get("clx_pkt_getRxQueueMapping", "cdecl")
    clx_pkt_getRxQueueMapping.argtypes = [UI32_T, UI32_T, POINTER(CLX_PKT_RX_REASON_BITMAP_T)]
    clx_pkt_getRxQueueMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 1096
if _libs["libsai.so"].has("clx_pkt_setRxToCpuPri", "cdecl"):
    clx_pkt_setRxToCpuPri = _libs["libsai.so"].get("clx_pkt_setRxToCpuPri", "cdecl")
    clx_pkt_setRxToCpuPri.argtypes = [UI32_T, CLX_PKT_TO_CPU_PRI_T]
    clx_pkt_setRxToCpuPri.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 1115
if _libs["libsai.so"].has("clx_pkt_getRxToCpuPri", "cdecl"):
    clx_pkt_getRxToCpuPri = _libs["libsai.so"].get("clx_pkt_getRxToCpuPri", "cdecl")
    clx_pkt_getRxToCpuPri.argtypes = [UI32_T, POINTER(CLX_PKT_TO_CPU_PRI_T)]
    clx_pkt_getRxToCpuPri.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 1135
if _libs["libsai.so"].has("clx_pkt_setRxRedirectToCpu", "cdecl"):
    clx_pkt_setRxRedirectToCpu = _libs["libsai.so"].get("clx_pkt_setRxRedirectToCpu", "cdecl")
    clx_pkt_setRxRedirectToCpu.argtypes = [UI32_T, CLX_PKT_RX_REASON_BITMAP_T, BOOL_T]
    clx_pkt_setRxRedirectToCpu.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 1155
if _libs["libsai.so"].has("clx_pkt_getRxRedirectToCpu", "cdecl"):
    clx_pkt_getRxRedirectToCpu = _libs["libsai.so"].get("clx_pkt_getRxRedirectToCpu", "cdecl")
    clx_pkt_getRxRedirectToCpu.argtypes = [UI32_T, POINTER(CLX_PKT_RX_REASON_BITMAP_T)]
    clx_pkt_getRxRedirectToCpu.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 1177
if _libs["libsai.so"].has("clx_pkt_setRxMapping", "cdecl"):
    clx_pkt_setRxMapping = _libs["libsai.so"].get("clx_pkt_setRxMapping", "cdecl")
    clx_pkt_setRxMapping.argtypes = [UI32_T, UI32_T, UI32_T, CLX_PKT_RX_REASON_BITMAP_T]
    clx_pkt_setRxMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pkt.h: 1201
if _libs["libsai.so"].has("clx_pkt_getRxMapping", "cdecl"):
    clx_pkt_getRxMapping = _libs["libsai.so"].get("clx_pkt_getRxMapping", "cdecl")
    clx_pkt_getRxMapping.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(CLX_PKT_RX_REASON_BITMAP_T)]
    clx_pkt_getRxMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 97
class struct_CLX_L2_ADDR_S(Structure):
    pass

struct_CLX_L2_ADDR_S.__slots__ = [
    'bdid',
    'mac',
    'port',
    'action',
    'svid',
    'cvid',
    'tc',
    'group_label',
    'flags',
]
struct_CLX_L2_ADDR_S._fields_ = [
    ('bdid', CLX_BRIDGE_DOMAIN_T),
    ('mac', CLX_MAC_T),
    ('port', CLX_PORT_T),
    ('action', CLX_VLAN_ACTION_T),
    ('svid', CLX_VLAN_T),
    ('cvid', CLX_VLAN_T),
    ('tc', UI8_T),
    ('group_label', UI32_T),
    ('flags', UI32_T),
]

CLX_L2_ADDR_T = struct_CLX_L2_ADDR_S# ./clx_system/clx_sdk/include/clx_l2.h: 97

enum_anon_88 = c_int# ./clx_system/clx_sdk/include/clx_l2.h: 106

CLX_L2_ADDR_MATCH_FIELD_STATIC = (1 << 0)# ./clx_system/clx_sdk/include/clx_l2.h: 106

CLX_L2_ADDR_MATCH_FIELD_BDID = (1 << 1)# ./clx_system/clx_sdk/include/clx_l2.h: 106

CLX_L2_ADDR_MATCH_FIELD_PORT = (1 << 2)# ./clx_system/clx_sdk/include/clx_l2.h: 106

CLX_L2_ADDR_MATCH_FIELD_PENDING = (1 << 3)# ./clx_system/clx_sdk/include/clx_l2.h: 106

CLX_L2_ADDR_MATCH_FIELD_LAST = (CLX_L2_ADDR_MATCH_FIELD_PENDING + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 106

CLX_L2_ADDR_MATCH_FIELD_T = enum_anon_88# ./clx_system/clx_sdk/include/clx_l2.h: 106

enum_anon_89 = c_int# ./clx_system/clx_sdk/include/clx_l2.h: 125

CLX_L2_ADDR_REPLACE_FIELD_DEL = (1 << 0)# ./clx_system/clx_sdk/include/clx_l2.h: 125

CLX_L2_ADDR_REPLACE_FIELD_STATIC = (1 << 1)# ./clx_system/clx_sdk/include/clx_l2.h: 125

CLX_L2_ADDR_REPLACE_FIELD_PENDING = (1 << 2)# ./clx_system/clx_sdk/include/clx_l2.h: 125

CLX_L2_ADDR_REPLACE_FIELD_DROP = (1 << 3)# ./clx_system/clx_sdk/include/clx_l2.h: 125

CLX_L2_ADDR_REPLACE_FIELD_SECURE = (1 << 4)# ./clx_system/clx_sdk/include/clx_l2.h: 125

CLX_L2_ADDR_REPLACE_FIELD_TC = (1 << 5)# ./clx_system/clx_sdk/include/clx_l2.h: 125

CLX_L2_ADDR_REPLACE_FIELD_PORT = (1 << 6)# ./clx_system/clx_sdk/include/clx_l2.h: 125

CLX_L2_ADDR_REPLACE_FIELD_VLAN = (1 << 7)# ./clx_system/clx_sdk/include/clx_l2.h: 125

CLX_L2_ADDR_REPLACE_FIELD_LAST = (CLX_L2_ADDR_REPLACE_FIELD_VLAN + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 125

CLX_L2_ADDR_REPLACE_FIELD_T = enum_anon_89# ./clx_system/clx_sdk/include/clx_l2.h: 125

enum_anon_90 = c_int# ./clx_system/clx_sdk/include/clx_l2.h: 133

CLX_L2_ADDR_NOTIFY_ADD = 0# ./clx_system/clx_sdk/include/clx_l2.h: 133

CLX_L2_ADDR_NOTIFY_MODIFY = (CLX_L2_ADDR_NOTIFY_ADD + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 133

CLX_L2_ADDR_NOTIFY_DELETE = (CLX_L2_ADDR_NOTIFY_MODIFY + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 133

CLX_L2_ADDR_NOTIFY_LAST = (CLX_L2_ADDR_NOTIFY_DELETE + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 133

CLX_L2_ADDR_NOTIFY_REASON_T = enum_anon_90# ./clx_system/clx_sdk/include/clx_l2.h: 133

CLX_L2_ADDR_NOTIFY_FUNC_T = CFUNCTYPE(UNCHECKED(None), UI32_T, CLX_L2_ADDR_NOTIFY_REASON_T, POINTER(CLX_L2_ADDR_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l2.h: 136

CLX_L2_ADDR_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_L2_ADDR_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l2.h: 143

enum_anon_91 = c_int# ./clx_system/clx_sdk/include/clx_l2.h: 163

CLX_L2_MCAST_EGR_INTF_TYPE_PORT = 0# ./clx_system/clx_sdk/include/clx_l2.h: 163

CLX_L2_MCAST_EGR_INTF_TYPE_L2 = (CLX_L2_MCAST_EGR_INTF_TYPE_PORT + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 163

CLX_L2_MCAST_EGR_INTF_TYPE_VM_1BR = (CLX_L2_MCAST_EGR_INTF_TYPE_L2 + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 163

CLX_L2_MCAST_EGR_INTF_TYPE_VM_NIV = (CLX_L2_MCAST_EGR_INTF_TYPE_VM_1BR + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 163

CLX_L2_MCAST_EGR_INTF_TYPE_VM_VEPA = (CLX_L2_MCAST_EGR_INTF_TYPE_VM_NIV + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 163

CLX_L2_MCAST_EGR_INTF_TYPE_NV = (CLX_L2_MCAST_EGR_INTF_TYPE_VM_VEPA + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 163

CLX_L2_MCAST_EGR_INTF_TYPE_TRILL = (CLX_L2_MCAST_EGR_INTF_TYPE_NV + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 163

CLX_L2_MCAST_EGR_INTF_TYPE_MPLS = (CLX_L2_MCAST_EGR_INTF_TYPE_TRILL + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 163

CLX_L2_MCAST_EGR_INTF_TYPE_LAST = (CLX_L2_MCAST_EGR_INTF_TYPE_MPLS + 1)# ./clx_system/clx_sdk/include/clx_l2.h: 163

CLX_L2_MCAST_EGR_INTF_TYPE_T = enum_anon_91# ./clx_system/clx_sdk/include/clx_l2.h: 163

# ./clx_system/clx_sdk/include/clx_l2.h: 170
class struct_CLX_L2_MCAST_EGR_INTF_NV_S(Structure):
    pass

struct_CLX_L2_MCAST_EGR_INTF_NV_S.__slots__ = [
    'tnl_port',
    'tnl_key',
    'nvo3_adj_id',
]
struct_CLX_L2_MCAST_EGR_INTF_NV_S._fields_ = [
    ('tnl_port', CLX_PORT_T),
    ('tnl_key', CLX_TUNNEL_KEY_T),
    ('nvo3_adj_id', UI32_T),
]

CLX_L2_MCAST_EGR_INTF_NV_T = struct_CLX_L2_MCAST_EGR_INTF_NV_S# ./clx_system/clx_sdk/include/clx_l2.h: 170

# ./clx_system/clx_sdk/include/clx_l2.h: 176
class struct_CLX_L2_MCAST_EGR_INTF_TRILL_S(Structure):
    pass

struct_CLX_L2_MCAST_EGR_INTF_TRILL_S.__slots__ = [
    'egr_nickname',
    'nvo3_adj_id',
]
struct_CLX_L2_MCAST_EGR_INTF_TRILL_S._fields_ = [
    ('egr_nickname', CLX_TRILL_NICKNAME_T),
    ('nvo3_adj_id', UI32_T),
]

CLX_L2_MCAST_EGR_INTF_TRILL_T = struct_CLX_L2_MCAST_EGR_INTF_TRILL_S# ./clx_system/clx_sdk/include/clx_l2.h: 176

# ./clx_system/clx_sdk/include/clx_l2.h: 181
class struct_CLX_L2_MCAST_EGR_INTF_MPLS_S(Structure):
    pass

struct_CLX_L2_MCAST_EGR_INTF_MPLS_S.__slots__ = [
    'pw_port',
]
struct_CLX_L2_MCAST_EGR_INTF_MPLS_S._fields_ = [
    ('pw_port', CLX_PORT_T),
]

CLX_L2_MCAST_EGR_INTF_MPLS_T = struct_CLX_L2_MCAST_EGR_INTF_MPLS_S# ./clx_system/clx_sdk/include/clx_l2.h: 181

# ./clx_system/clx_sdk/include/clx_l2.h: 193
class union_anon_92(Union):
    pass

union_anon_92.__slots__ = [
    'vm_id',
    'nv',
    'trill',
    'mpls',
]
union_anon_92._fields_ = [
    ('vm_id', UI32_T),
    ('nv', CLX_L2_MCAST_EGR_INTF_NV_T),
    ('trill', CLX_L2_MCAST_EGR_INTF_TRILL_T),
    ('mpls', CLX_L2_MCAST_EGR_INTF_MPLS_T),
]

# ./clx_system/clx_sdk/include/clx_l2.h: 203
class struct_CLX_L2_MCAST_EGR_INTF_S(Structure):
    pass

struct_CLX_L2_MCAST_EGR_INTF_S.__slots__ = [
    'type',
    'port',
    'bdid',
    'action',
    'svid',
    'cvid',
    'unnamed_1',
    'flags',
]
struct_CLX_L2_MCAST_EGR_INTF_S._anonymous_ = [
    'unnamed_1',
]
struct_CLX_L2_MCAST_EGR_INTF_S._fields_ = [
    ('type', CLX_L2_MCAST_EGR_INTF_TYPE_T),
    ('port', UI32_T),
    ('bdid', CLX_BRIDGE_DOMAIN_T),
    ('action', CLX_VLAN_ACTION_T),
    ('svid', CLX_VLAN_T),
    ('cvid', CLX_VLAN_T),
    ('unnamed_1', union_anon_92),
    ('flags', UI32_T),
]

CLX_L2_MCAST_EGR_INTF_T = struct_CLX_L2_MCAST_EGR_INTF_S# ./clx_system/clx_sdk/include/clx_l2.h: 203

# ./clx_system/clx_sdk/include/clx_l2.h: 221
class struct_CLX_L2_MCAST_ADDR_S(Structure):
    pass

struct_CLX_L2_MCAST_ADDR_S.__slots__ = [
    'bdid',
    'mac',
    'mcast_id',
    'tc',
    'group_label',
    'svid',
    'flags',
]
struct_CLX_L2_MCAST_ADDR_S._fields_ = [
    ('bdid', CLX_BRIDGE_DOMAIN_T),
    ('mac', CLX_MAC_T),
    ('mcast_id', UI32_T),
    ('tc', UI8_T),
    ('group_label', UI32_T),
    ('svid', UI32_T),
    ('flags', UI32_T),
]

CLX_L2_MCAST_ADDR_T = struct_CLX_L2_MCAST_ADDR_S# ./clx_system/clx_sdk/include/clx_l2.h: 221

CLX_L2_MCAST_ADDR_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_L2_MCAST_ADDR_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l2.h: 224

# ./clx_system/clx_sdk/include/clx_l2.h: 244
class struct_CLX_L2_IP_MCAST_GROUP_S(Structure):
    pass

struct_CLX_L2_IP_MCAST_GROUP_S.__slots__ = [
    'bdid',
    'grp_ip',
    'src_ip',
    'mcast_id',
    'group_label',
    'svid',
    'flags',
]
struct_CLX_L2_IP_MCAST_GROUP_S._fields_ = [
    ('bdid', CLX_BRIDGE_DOMAIN_T),
    ('grp_ip', CLX_IP_ADDR_T),
    ('src_ip', CLX_IP_ADDR_T),
    ('mcast_id', UI32_T),
    ('group_label', UI32_T),
    ('svid', UI32_T),
    ('flags', UI32_T),
]

CLX_L2_IP_MCAST_GROUP_T = struct_CLX_L2_IP_MCAST_GROUP_S# ./clx_system/clx_sdk/include/clx_l2.h: 244

# ./clx_system/clx_sdk/include/clx_l2.h: 266
if _libs["libsai.so"].has("clx_l2_addAddr", "cdecl"):
    clx_l2_addAddr = _libs["libsai.so"].get("clx_l2_addAddr", "cdecl")
    clx_l2_addAddr.argtypes = [UI32_T, POINTER(CLX_L2_ADDR_T)]
    clx_l2_addAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 286
if _libs["libsai.so"].has("clx_l2_delAddr", "cdecl"):
    clx_l2_delAddr = _libs["libsai.so"].get("clx_l2_delAddr", "cdecl")
    clx_l2_delAddr.argtypes = [UI32_T, POINTER(CLX_L2_ADDR_T)]
    clx_l2_delAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 306
if _libs["libsai.so"].has("clx_l2_getAddr", "cdecl"):
    clx_l2_getAddr = _libs["libsai.so"].get("clx_l2_getAddr", "cdecl")
    clx_l2_getAddr.argtypes = [UI32_T, POINTER(CLX_L2_ADDR_T)]
    clx_l2_getAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 336
if _libs["libsai.so"].has("clx_l2_replaceAddr", "cdecl"):
    clx_l2_replaceAddr = _libs["libsai.so"].get("clx_l2_replaceAddr", "cdecl")
    clx_l2_replaceAddr.argtypes = [UI32_T, UI32_T, POINTER(CLX_L2_ADDR_T), UI32_T, POINTER(CLX_L2_ADDR_T)]
    clx_l2_replaceAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 359
if _libs["libsai.so"].has("clx_l2_traverseAddr", "cdecl"):
    clx_l2_traverseAddr = _libs["libsai.so"].get("clx_l2_traverseAddr", "cdecl")
    clx_l2_traverseAddr.argtypes = [UI32_T, CLX_L2_ADDR_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l2_traverseAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 381
if _libs["libsai.so"].has("clx_l2_registerAddrNotifyCallback", "cdecl"):
    clx_l2_registerAddrNotifyCallback = _libs["libsai.so"].get("clx_l2_registerAddrNotifyCallback", "cdecl")
    clx_l2_registerAddrNotifyCallback.argtypes = [UI32_T, CLX_L2_ADDR_NOTIFY_FUNC_T, POINTER(None)]
    clx_l2_registerAddrNotifyCallback.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 403
if _libs["libsai.so"].has("clx_l2_deregisterAddrNotifyCallback", "cdecl"):
    clx_l2_deregisterAddrNotifyCallback = _libs["libsai.so"].get("clx_l2_deregisterAddrNotifyCallback", "cdecl")
    clx_l2_deregisterAddrNotifyCallback.argtypes = [UI32_T, CLX_L2_ADDR_NOTIFY_FUNC_T, POINTER(None)]
    clx_l2_deregisterAddrNotifyCallback.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 429
if _libs["libsai.so"].has("clx_l2_addMcastId", "cdecl"):
    clx_l2_addMcastId = _libs["libsai.so"].get("clx_l2_addMcastId", "cdecl")
    clx_l2_addMcastId.argtypes = [UI32_T, UI32_T, POINTER(UI32_T)]
    clx_l2_addMcastId.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 449
if _libs["libsai.so"].has("clx_l2_delMcastId", "cdecl"):
    clx_l2_delMcastId = _libs["libsai.so"].get("clx_l2_delMcastId", "cdecl")
    clx_l2_delMcastId.argtypes = [UI32_T, UI32_T]
    clx_l2_delMcastId.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 469
if _libs["libsai.so"].has("clx_l2_getMcastId", "cdecl"):
    clx_l2_getMcastId = _libs["libsai.so"].get("clx_l2_getMcastId", "cdecl")
    clx_l2_getMcastId.argtypes = [UI32_T, UI32_T, POINTER(UI32_T), CLX_PORT_BITMAP_T]
    clx_l2_getMcastId.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 492
if _libs["libsai.so"].has("clx_l2_addMcastEgrIntf", "cdecl"):
    clx_l2_addMcastEgrIntf = _libs["libsai.so"].get("clx_l2_addMcastEgrIntf", "cdecl")
    clx_l2_addMcastEgrIntf.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(CLX_L2_MCAST_EGR_INTF_T)]
    clx_l2_addMcastEgrIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 518
if _libs["libsai.so"].has("clx_l2_delMcastEgrIntf", "cdecl"):
    clx_l2_delMcastEgrIntf = _libs["libsai.so"].get("clx_l2_delMcastEgrIntf", "cdecl")
    clx_l2_delMcastEgrIntf.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(CLX_L2_MCAST_EGR_INTF_T)]
    clx_l2_delMcastEgrIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 539
if _libs["libsai.so"].has("clx_l2_getMcastEgrIntfCnt", "cdecl"):
    clx_l2_getMcastEgrIntfCnt = _libs["libsai.so"].get("clx_l2_getMcastEgrIntfCnt", "cdecl")
    clx_l2_getMcastEgrIntfCnt.argtypes = [UI32_T, UI32_T, POINTER(UI32_T)]
    clx_l2_getMcastEgrIntfCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 561
if _libs["libsai.so"].has("clx_l2_getMcastEgrIntf", "cdecl"):
    clx_l2_getMcastEgrIntf = _libs["libsai.so"].get("clx_l2_getMcastEgrIntf", "cdecl")
    clx_l2_getMcastEgrIntf.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(CLX_L2_MCAST_EGR_INTF_T), POINTER(UI32_T)]
    clx_l2_getMcastEgrIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 585
if _libs["libsai.so"].has("clx_l2_addMcastAddr", "cdecl"):
    clx_l2_addMcastAddr = _libs["libsai.so"].get("clx_l2_addMcastAddr", "cdecl")
    clx_l2_addMcastAddr.argtypes = [UI32_T, POINTER(CLX_L2_MCAST_ADDR_T)]
    clx_l2_addMcastAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 605
if _libs["libsai.so"].has("clx_l2_delMcastAddr", "cdecl"):
    clx_l2_delMcastAddr = _libs["libsai.so"].get("clx_l2_delMcastAddr", "cdecl")
    clx_l2_delMcastAddr.argtypes = [UI32_T, POINTER(CLX_L2_MCAST_ADDR_T)]
    clx_l2_delMcastAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 625
if _libs["libsai.so"].has("clx_l2_getMcastAddr", "cdecl"):
    clx_l2_getMcastAddr = _libs["libsai.so"].get("clx_l2_getMcastAddr", "cdecl")
    clx_l2_getMcastAddr.argtypes = [UI32_T, POINTER(CLX_L2_MCAST_ADDR_T)]
    clx_l2_getMcastAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 645
if _libs["libsai.so"].has("clx_l2_traverseMcastAddr", "cdecl"):
    clx_l2_traverseMcastAddr = _libs["libsai.so"].get("clx_l2_traverseMcastAddr", "cdecl")
    clx_l2_traverseMcastAddr.argtypes = [UI32_T, CLX_L2_MCAST_ADDR_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l2_traverseMcastAddr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 667
if _libs["libsai.so"].has("clx_l2_addIpMcastGroup", "cdecl"):
    clx_l2_addIpMcastGroup = _libs["libsai.so"].get("clx_l2_addIpMcastGroup", "cdecl")
    clx_l2_addIpMcastGroup.argtypes = [UI32_T, POINTER(CLX_L2_IP_MCAST_GROUP_T)]
    clx_l2_addIpMcastGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 687
if _libs["libsai.so"].has("clx_l2_delIpMcastGroup", "cdecl"):
    clx_l2_delIpMcastGroup = _libs["libsai.so"].get("clx_l2_delIpMcastGroup", "cdecl")
    clx_l2_delIpMcastGroup.argtypes = [UI32_T, POINTER(CLX_L2_IP_MCAST_GROUP_T)]
    clx_l2_delIpMcastGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l2.h: 707
if _libs["libsai.so"].has("clx_l2_getIpMcastGroup", "cdecl"):
    clx_l2_getIpMcastGroup = _libs["libsai.so"].get("clx_l2_getIpMcastGroup", "cdecl")
    clx_l2_getIpMcastGroup.argtypes = [UI32_T, POINTER(CLX_L2_IP_MCAST_GROUP_T)]
    clx_l2_getIpMcastGroup.restype = CLX_ERROR_NO_T

CLX_FCOE_FCID_T = UI32_T# ./clx_system/clx_sdk/include/clx_fcoe.h: 58

# ./clx_system/clx_sdk/include/clx_fcoe.h: 64
class struct_CLX_FCOE_FCID_ADDR_S(Structure):
    pass

struct_CLX_FCOE_FCID_ADDR_S.__slots__ = [
    'fcid',
    'mask',
]
struct_CLX_FCOE_FCID_ADDR_S._fields_ = [
    ('fcid', CLX_FCOE_FCID_T),
    ('mask', CLX_FCOE_FCID_T),
]

CLX_FCOE_FCID_ADDR_T = struct_CLX_FCOE_FCID_ADDR_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 64

# ./clx_system/clx_sdk/include/clx_fcoe.h: 92
class struct_CLX_FCOE_INTF_INFO_S(Structure):
    pass

struct_CLX_FCOE_INTF_INFO_S.__slots__ = [
    'intf_idx',
    'vrf_id',
    'mac',
    'flags',
    'igr_meter_id',
    'egr_meter_id',
    'igr_cnt_id',
    'egr_cnt_id',
    'igr_dist_cnt_id',
    'egr_dist_cnt_id',
    'igr_group_label',
    'egr_group_label',
]
struct_CLX_FCOE_INTF_INFO_S._fields_ = [
    ('intf_idx', UI32_T),
    ('vrf_id', UI32_T),
    ('mac', CLX_MAC_T),
    ('flags', UI32_T),
    ('igr_meter_id', UI32_T),
    ('egr_meter_id', UI32_T),
    ('igr_cnt_id', UI32_T),
    ('egr_cnt_id', UI32_T),
    ('igr_dist_cnt_id', UI32_T),
    ('egr_dist_cnt_id', UI32_T),
    ('igr_group_label', UI32_T),
    ('egr_group_label', UI32_T),
]

CLX_FCOE_INTF_INFO_T = struct_CLX_FCOE_INTF_INFO_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 92

# ./clx_system/clx_sdk/include/clx_fcoe.h: 110
class struct_CLX_FCOE_HOST_INFO_S(Structure):
    pass

struct_CLX_FCOE_HOST_INFO_S.__slots__ = [
    'vrf_id',
    'fcid',
    'output_type',
    'output_id',
    'tc',
    'flags',
    'group_label',
]
struct_CLX_FCOE_HOST_INFO_S._fields_ = [
    ('vrf_id', UI32_T),
    ('fcid', CLX_FCOE_FCID_T),
    ('output_type', CLX_L3_OUTPUT_TYPE_T),
    ('output_id', UI32_T),
    ('tc', UI32_T),
    ('flags', UI32_T),
    ('group_label', UI32_T),
]

CLX_FCOE_HOST_INFO_T = struct_CLX_FCOE_HOST_INFO_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 110

# ./clx_system/clx_sdk/include/clx_fcoe.h: 128
class struct_CLX_FCOE_ROUTE_INFO_S(Structure):
    pass

struct_CLX_FCOE_ROUTE_INFO_S.__slots__ = [
    'vrf_id',
    'fcid_addr',
    'output_type',
    'output_id',
    'tc',
    'flags',
    'group_label',
]
struct_CLX_FCOE_ROUTE_INFO_S._fields_ = [
    ('vrf_id', UI32_T),
    ('fcid_addr', CLX_FCOE_FCID_ADDR_T),
    ('output_type', CLX_L3_OUTPUT_TYPE_T),
    ('output_id', UI32_T),
    ('tc', UI32_T),
    ('flags', UI32_T),
    ('group_label', UI32_T),
]

CLX_FCOE_ROUTE_INFO_T = struct_CLX_FCOE_ROUTE_INFO_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 128

# ./clx_system/clx_sdk/include/clx_fcoe.h: 135
class struct_CLX_FCOE_ZONE_S(Structure):
    pass

struct_CLX_FCOE_ZONE_S.__slots__ = [
    'bdid',
    'src_fcid',
    'dst_fcid',
]
struct_CLX_FCOE_ZONE_S._fields_ = [
    ('bdid', CLX_BRIDGE_DOMAIN_T),
    ('src_fcid', CLX_FCOE_FCID_T),
    ('dst_fcid', CLX_FCOE_FCID_T),
]

CLX_FCOE_ZONE_T = struct_CLX_FCOE_ZONE_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 135

enum_anon_93 = c_int# ./clx_system/clx_sdk/include/clx_fcoe.h: 142

CLX_FCOE_CLV_PORT_MODE_IS_F = 0# ./clx_system/clx_sdk/include/clx_fcoe.h: 142

CLX_FCOE_CLV_PORT_MODE_IS_CL = (CLX_FCOE_CLV_PORT_MODE_IS_F + 1)# ./clx_system/clx_sdk/include/clx_fcoe.h: 142

CLX_FCOE_CLV_PORT_MODE_LAST = (CLX_FCOE_CLV_PORT_MODE_IS_CL + 1)# ./clx_system/clx_sdk/include/clx_fcoe.h: 142

CLX_FCOE_CLV_PORT_MODE_T = enum_anon_93# ./clx_system/clx_sdk/include/clx_fcoe.h: 142

# ./clx_system/clx_sdk/include/clx_fcoe.h: 148
class struct_CLX_FCOE_CLV_PORT_INFO_S(Structure):
    pass

struct_CLX_FCOE_CLV_PORT_INFO_S.__slots__ = [
    'port_mode',
    'port_np_id',
]
struct_CLX_FCOE_CLV_PORT_INFO_S._fields_ = [
    ('port_mode', CLX_FCOE_CLV_PORT_MODE_T),
    ('port_np_id', CLX_PORT_T),
]

CLX_FCOE_CLV_PORT_INFO_T = struct_CLX_FCOE_CLV_PORT_INFO_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 148

# ./clx_system/clx_sdk/include/clx_fcoe.h: 160
class struct_CLX_FCOE_FC_FRAME_ACTION_S(Structure):
    pass

struct_CLX_FCOE_FC_FRAME_ACTION_S.__slots__ = [
    'flags',
]
struct_CLX_FCOE_FC_FRAME_ACTION_S._fields_ = [
    ('flags', UI32_T),
]

CLX_FCOE_FC_FRAME_ACTION_T = struct_CLX_FCOE_FC_FRAME_ACTION_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 160

# ./clx_system/clx_sdk/include/clx_fcoe.h: 185
if _libs["libsai.so"].has("clx_fcoe_addIntf", "cdecl"):
    clx_fcoe_addIntf = _libs["libsai.so"].get("clx_fcoe_addIntf", "cdecl")
    clx_fcoe_addIntf.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(CLX_FCOE_INTF_INFO_T)]
    clx_fcoe_addIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 206
if _libs["libsai.so"].has("clx_fcoe_delIntf", "cdecl"):
    clx_fcoe_delIntf = _libs["libsai.so"].get("clx_fcoe_delIntf", "cdecl")
    clx_fcoe_delIntf.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_fcoe_delIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 226
if _libs["libsai.so"].has("clx_fcoe_getIntf", "cdecl"):
    clx_fcoe_getIntf = _libs["libsai.so"].get("clx_fcoe_getIntf", "cdecl")
    clx_fcoe_getIntf.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(CLX_FCOE_INTF_INFO_T)]
    clx_fcoe_getIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 252
if _libs["libsai.so"].has("clx_fcoe_addHost", "cdecl"):
    clx_fcoe_addHost = _libs["libsai.so"].get("clx_fcoe_addHost", "cdecl")
    clx_fcoe_addHost.argtypes = [UI32_T, POINTER(CLX_FCOE_HOST_INFO_T)]
    clx_fcoe_addHost.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 272
if _libs["libsai.so"].has("clx_fcoe_delHost", "cdecl"):
    clx_fcoe_delHost = _libs["libsai.so"].get("clx_fcoe_delHost", "cdecl")
    clx_fcoe_delHost.argtypes = [UI32_T, POINTER(CLX_FCOE_HOST_INFO_T)]
    clx_fcoe_delHost.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 292
if _libs["libsai.so"].has("clx_fcoe_getHost", "cdecl"):
    clx_fcoe_getHost = _libs["libsai.so"].get("clx_fcoe_getHost", "cdecl")
    clx_fcoe_getHost.argtypes = [UI32_T, POINTER(CLX_FCOE_HOST_INFO_T)]
    clx_fcoe_getHost.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 318
if _libs["libsai.so"].has("clx_fcoe_addRoute", "cdecl"):
    clx_fcoe_addRoute = _libs["libsai.so"].get("clx_fcoe_addRoute", "cdecl")
    clx_fcoe_addRoute.argtypes = [UI32_T, POINTER(CLX_FCOE_ROUTE_INFO_T)]
    clx_fcoe_addRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 338
if _libs["libsai.so"].has("clx_fcoe_delRoute", "cdecl"):
    clx_fcoe_delRoute = _libs["libsai.so"].get("clx_fcoe_delRoute", "cdecl")
    clx_fcoe_delRoute.argtypes = [UI32_T, POINTER(CLX_FCOE_ROUTE_INFO_T)]
    clx_fcoe_delRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 358
if _libs["libsai.so"].has("clx_fcoe_getRoute", "cdecl"):
    clx_fcoe_getRoute = _libs["libsai.so"].get("clx_fcoe_getRoute", "cdecl")
    clx_fcoe_getRoute.argtypes = [UI32_T, POINTER(CLX_FCOE_ROUTE_INFO_T)]
    clx_fcoe_getRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 381
if _libs["libsai.so"].has("clx_fcoe_setVntovnEnable", "cdecl"):
    clx_fcoe_setVntovnEnable = _libs["libsai.so"].get("clx_fcoe_setVntovnEnable", "cdecl")
    clx_fcoe_setVntovnEnable.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, BOOL_T]
    clx_fcoe_setVntovnEnable.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 402
if _libs["libsai.so"].has("clx_fcoe_getVntovnEnable", "cdecl"):
    clx_fcoe_getVntovnEnable = _libs["libsai.so"].get("clx_fcoe_getVntovnEnable", "cdecl")
    clx_fcoe_getVntovnEnable.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(BOOL_T)]
    clx_fcoe_getVntovnEnable.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 425
if _libs["libsai.so"].has("clx_fcoe_setZoneCheck", "cdecl"):
    clx_fcoe_setZoneCheck = _libs["libsai.so"].get("clx_fcoe_setZoneCheck", "cdecl")
    clx_fcoe_setZoneCheck.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, BOOL_T]
    clx_fcoe_setZoneCheck.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 446
if _libs["libsai.so"].has("clx_fcoe_getZoneCheck", "cdecl"):
    clx_fcoe_getZoneCheck = _libs["libsai.so"].get("clx_fcoe_getZoneCheck", "cdecl")
    clx_fcoe_getZoneCheck.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(BOOL_T)]
    clx_fcoe_getZoneCheck.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 471
if _libs["libsai.so"].has("clx_fcoe_addZone", "cdecl"):
    clx_fcoe_addZone = _libs["libsai.so"].get("clx_fcoe_addZone", "cdecl")
    clx_fcoe_addZone.argtypes = [UI32_T, POINTER(CLX_FCOE_ZONE_T)]
    clx_fcoe_addZone.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 490
if _libs["libsai.so"].has("clx_fcoe_delZone", "cdecl"):
    clx_fcoe_delZone = _libs["libsai.so"].get("clx_fcoe_delZone", "cdecl")
    clx_fcoe_delZone.argtypes = [UI32_T, POINTER(CLX_FCOE_ZONE_T)]
    clx_fcoe_delZone.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 509
if _libs["libsai.so"].has("clx_fcoe_getZone", "cdecl"):
    clx_fcoe_getZone = _libs["libsai.so"].get("clx_fcoe_getZone", "cdecl")
    clx_fcoe_getZone.argtypes = [UI32_T, POINTER(CLX_FCOE_ZONE_T), POINTER(BOOL_T)]
    clx_fcoe_getZone.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 531
if _libs["libsai.so"].has("clx_fcoe_setPortNpvConfig", "cdecl"):
    clx_fcoe_setPortNpvConfig = _libs["libsai.so"].get("clx_fcoe_setPortNpvConfig", "cdecl")
    clx_fcoe_setPortNpvConfig.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_FCOE_CLV_PORT_INFO_T)]
    clx_fcoe_setPortNpvConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 552
if _libs["libsai.so"].has("clx_fcoe_getPortNpvConfig", "cdecl"):
    clx_fcoe_getPortNpvConfig = _libs["libsai.so"].get("clx_fcoe_getPortNpvConfig", "cdecl")
    clx_fcoe_getPortNpvConfig.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_FCOE_CLV_PORT_INFO_T)]
    clx_fcoe_getPortNpvConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 580
if _libs["libsai.so"].has("clx_fcoe_setFrameTypeAction", "cdecl"):
    clx_fcoe_setFrameTypeAction = _libs["libsai.so"].get("clx_fcoe_setFrameTypeAction", "cdecl")
    clx_fcoe_setFrameTypeAction.argtypes = [UI32_T, POINTER(CLX_FCOE_FC_FRAME_ACTION_T)]
    clx_fcoe_setFrameTypeAction.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 599
if _libs["libsai.so"].has("clx_fcoe_getFrameTypeAction", "cdecl"):
    clx_fcoe_getFrameTypeAction = _libs["libsai.so"].get("clx_fcoe_getFrameTypeAction", "cdecl")
    clx_fcoe_getFrameTypeAction.argtypes = [UI32_T, POINTER(CLX_FCOE_FC_FRAME_ACTION_T)]
    clx_fcoe_getFrameTypeAction.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 618
if _libs["libsai.so"].has("clx_fcoe_createPort", "cdecl"):
    clx_fcoe_createPort = _libs["libsai.so"].get("clx_fcoe_createPort", "cdecl")
    clx_fcoe_createPort.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_PORT_T)]
    clx_fcoe_createPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_fcoe.h: 638
if _libs["libsai.so"].has("clx_fcoe_destroyPort", "cdecl"):
    clx_fcoe_destroyPort = _libs["libsai.so"].get("clx_fcoe_destroyPort", "cdecl")
    clx_fcoe_destroyPort.argtypes = [UI32_T, CLX_PORT_T]
    clx_fcoe_destroyPort.restype = CLX_ERROR_NO_T

enum_anon_94 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 76

CLX_ACL_GROUP_INGRESS = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 76

CLX_ACL_GROUP_EGRESS = (CLX_ACL_GROUP_INGRESS + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 76

CLX_ACL_GROUP_LAST = (CLX_ACL_GROUP_EGRESS + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 76

CLX_ACL_GROUP_T = enum_anon_94# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 76

enum_anon_95 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 86

CLX_ACL_FRAME_MAC = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 86

CLX_ACL_FRAME_ARP = (CLX_ACL_FRAME_MAC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 86

CLX_ACL_FRAME_IPV4 = (CLX_ACL_FRAME_ARP + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 86

CLX_ACL_FRAME_IPV6 = (CLX_ACL_FRAME_IPV4 + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 86

CLX_ACL_FRAME_FCOE = (CLX_ACL_FRAME_IPV6 + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 86

CLX_ACL_FRAME_LAST = (CLX_ACL_FRAME_FCOE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 86

CLX_ACL_FRAME_T = enum_anon_95# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 86

enum_anon_96 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 95

CLX_ACL_L2_FRAME_ETHERNET = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 95

CLX_ACL_L2_FRAME_RFC1042 = (CLX_ACL_L2_FRAME_ETHERNET + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 95

CLX_ACL_L2_FRAME_SNAP_OTHER = (CLX_ACL_L2_FRAME_RFC1042 + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 95

CLX_ACL_L2_FRAME_LLC_OTHER = (CLX_ACL_L2_FRAME_SNAP_OTHER + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 95

CLX_ACL_L2_FRAME_LAST = (CLX_ACL_L2_FRAME_LLC_OTHER + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 95

CLX_ACL_L2_FRAME_T = enum_anon_96# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 95

enum_anon_97 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 104

CLX_ACL_VM_TAG_NONE = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 104

CLX_ACL_VM_TAG_ETAG = (CLX_ACL_VM_TAG_NONE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 104

CLX_ACL_VM_TAG_VNTAG = (CLX_ACL_VM_TAG_ETAG + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 104

CLX_ACL_VM_TAG_VEPA = (CLX_ACL_VM_TAG_VNTAG + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 104

CLX_ACL_VM_TAG_LAST = (CLX_ACL_VM_TAG_VEPA + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 104

CLX_ACL_VM_TAG_T = enum_anon_97# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 104

enum_anon_98 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 115

CLX_ACL_TNL_IPV4 = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 115

CLX_ACL_TNL_IPV4_GRE = (CLX_ACL_TNL_IPV4 + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 115

CLX_ACL_TNL_IPV4_VXLAN = (CLX_ACL_TNL_IPV4_GRE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 115

CLX_ACL_TNL_IPV6 = (CLX_ACL_TNL_IPV4_VXLAN + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 115

CLX_ACL_TNL_IPV6_GRE = (CLX_ACL_TNL_IPV6 + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 115

CLX_ACL_TNL_IPV6_VXLAN = (CLX_ACL_TNL_IPV6_GRE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 115

CLX_ACL_TNL_LAST = (CLX_ACL_TNL_IPV6_VXLAN + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 115

CLX_ACL_TNL_T = enum_anon_98# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 115

enum_anon_99 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 128

CLX_ACL_FWD_L2UC = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 128

CLX_ACL_FWD_L2BC = (CLX_ACL_FWD_L2UC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 128

CLX_ACL_FWD_L2UUC = (CLX_ACL_FWD_L2BC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 128

CLX_ACL_FWD_L2MC = (CLX_ACL_FWD_L2UUC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 128

CLX_ACL_FWD_L2UMC = (CLX_ACL_FWD_L2MC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 128

CLX_ACL_FWD_L3UC = (CLX_ACL_FWD_L2UMC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 128

CLX_ACL_FWD_L3MC = (CLX_ACL_FWD_L3UC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 128

CLX_ACL_FWD_L3UMC = (CLX_ACL_FWD_L3MC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 128

CLX_ACL_FWD_LAST = (CLX_ACL_FWD_L3UMC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 128

CLX_ACL_FWD_T = enum_anon_99# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 128

enum_anon_100 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 137

CLX_ACL_L2_LOOKUP_SKIP = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 137

CLX_ACL_L2_LOOKUP_HIT = (CLX_ACL_L2_LOOKUP_SKIP + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 137

CLX_ACL_L2_LOOKUP_MISS = (CLX_ACL_L2_LOOKUP_HIT + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 137

CLX_ACL_L2_LOOKUP_MOVE = (CLX_ACL_L2_LOOKUP_MISS + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 137

CLX_ACL_L2_LOOKUP_LAST = (CLX_ACL_L2_LOOKUP_MOVE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 137

CLX_ACL_L2_LOOKUP_T = enum_anon_100# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 137

enum_anon_101 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 148

CLX_ACL_FCOE_HDR_NOT_EXISTED = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 148

CLX_ACL_FCOE_HDR_STD = (CLX_ACL_FCOE_HDR_NOT_EXISTED + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 148

CLX_ACL_FCOE_HDR_VFT = (CLX_ACL_FCOE_HDR_STD + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 148

CLX_ACL_FCOE_HDR_IFR = (CLX_ACL_FCOE_HDR_VFT + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 148

CLX_ACL_FCOE_HDR_ENCAP = (CLX_ACL_FCOE_HDR_IFR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 148

CLX_ACL_FCOE_HDR_UNKNOWN = (CLX_ACL_FCOE_HDR_ENCAP + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 148

CLX_ACL_FCOE_HDR_LAST = (CLX_ACL_FCOE_HDR_UNKNOWN + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 148

CLX_ACL_FCOE_HDR_T = enum_anon_101# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 148

enum_anon_102 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 157

CLX_ACL_FRG_NONE = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 157

CLX_ACL_FRG_FIRST = (CLX_ACL_FRG_NONE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 157

CLX_ACL_FRG_MIDDLE = (CLX_ACL_FRG_FIRST + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 157

CLX_ACL_FRG_END = (CLX_ACL_FRG_MIDDLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 157

CLX_ACL_FRG_LAST = (CLX_ACL_FRG_END + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 157

CLX_ACL_FRG_T = enum_anon_102# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 157

enum_anon_103 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 165

CLX_ACL_TTL_ZERO = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 165

CLX_ACL_TTL_ONE = (CLX_ACL_TTL_ZERO + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 165

CLX_ACL_TTL_GT_ONE = (CLX_ACL_TTL_ONE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 165

CLX_ACL_TTL_LAST = (CLX_ACL_TTL_GT_ONE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 165

CLX_ACL_TTL_T = enum_anon_103# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 165

enum_anon_104 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 174

CLX_ACL_ARP_FRAME_ARP_REQUEST = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 174

CLX_ACL_ARP_FRAME_ARP_RESPONSE = (CLX_ACL_ARP_FRAME_ARP_REQUEST + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 174

CLX_ACL_ARP_FRAME_RARP_REQUEST = (CLX_ACL_ARP_FRAME_ARP_RESPONSE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 174

CLX_ACL_ARP_FRAME_RARP_RESPONSE = (CLX_ACL_ARP_FRAME_RARP_REQUEST + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 174

CLX_ACL_ARP_FRAME_LAST = (CLX_ACL_ARP_FRAME_RARP_RESPONSE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 174

CLX_ACL_ARP_FRAME_T = enum_anon_104# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 174

enum_anon_105 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_TNL_STAG_PCP_DEI = (1 << 0)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_TNL_CTAG_PCP_DEI = (1 << 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_TNL_DSCP_ECN = (1 << 2)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_STAG_PCP_DEI = (1 << 3)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_CTAG_PCP_DEI = (1 << 4)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_DSCP_ECN = (1 << 5)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_TC_COLOR = (1 << 6)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_IPV6_PROTOCOL_LIST = (1 << 7)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_IPV6_PROTOCOL_ENCODE = (1 << 8)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_LOU_GROUP_0 = (1 << 9)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_LOU_GROUP_1 = (1 << 10)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_LOU_GROUP_2 = (1 << 11)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_LOU_GROUP_3 = (1 << 12)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_UDF_KEY_SINGLE = (1 << 13)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_UDF_KEY_DOUBLE = (1 << 14)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_L2_BIDIR = (1 << 15)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_L3_BIDIR = (1 << 16)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_L4_BIDIR = (1 << 17)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_BASE_KEY_L2 = (1 << 18)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_BASE_KEY_L3 = (1 << 19)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

CLX_ACL_GROUP_FORMAT_T = enum_anon_105# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 199

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 216
class struct_CLX_ACL_GROUP_PROFILE_S(Structure):
    pass

struct_CLX_ACL_GROUP_PROFILE_S.__slots__ = [
    'mac_pkt_format_bitmap',
    'arp_pkt_format_bitmap',
    'ipv4_pkt_format_bitmap',
    'ipv6_pkt_format_bitmap',
    'fcoe_pkt_format_bitmap',
    'flags',
]
struct_CLX_ACL_GROUP_PROFILE_S._fields_ = [
    ('mac_pkt_format_bitmap', UI32_T),
    ('arp_pkt_format_bitmap', UI32_T),
    ('ipv4_pkt_format_bitmap', UI32_T),
    ('ipv6_pkt_format_bitmap', UI32_T),
    ('fcoe_pkt_format_bitmap', UI32_T),
    ('flags', UI32_T),
]

CLX_ACL_GROUP_PROFILE_T = struct_CLX_ACL_GROUP_PROFILE_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 216

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 248
class struct_CLX_ACL_PKT_FORMAT_S(Structure):
    pass

struct_CLX_ACL_PKT_FORMAT_S.__slots__ = [
    'port_lag_id',
    'port_lag_id_mask',
    'ethertype',
    'ethertype_mask',
    'protocol',
    'protocol_mask',
    'tnl_protocol',
    'tnl_protocol_mask',
    'acl_frame_type',
    'l2_frame_type',
    'vm_tag_type',
    'tnl_type',
    'flags',
    'flags_mask',
]
struct_CLX_ACL_PKT_FORMAT_S._fields_ = [
    ('port_lag_id', UI16_T),
    ('port_lag_id_mask', UI16_T),
    ('ethertype', UI16_T),
    ('ethertype_mask', UI16_T),
    ('protocol', UI8_T),
    ('protocol_mask', UI8_T),
    ('tnl_protocol', UI8_T),
    ('tnl_protocol_mask', UI8_T),
    ('acl_frame_type', CLX_ACL_FRAME_T),
    ('l2_frame_type', CLX_ACL_L2_FRAME_T),
    ('vm_tag_type', CLX_ACL_VM_TAG_T),
    ('tnl_type', CLX_ACL_TNL_T),
    ('flags', UI32_T),
    ('flags_mask', UI32_T),
]

CLX_ACL_PKT_FORMAT_T = struct_CLX_ACL_PKT_FORMAT_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 248

enum_anon_106 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_NONE = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_START_PKT_HDR = (CLX_ACL_PKG_BASE_NONE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_START_TNL_HDR = (CLX_ACL_PKG_BASE_START_PKT_HDR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_START_L2_HDR = (CLX_ACL_PKG_BASE_START_TNL_HDR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_START_L3_HDR = (CLX_ACL_PKG_BASE_START_L2_HDR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_START_L4_HDR = (CLX_ACL_PKG_BASE_START_L3_HDR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_END_TNL_HDR = (CLX_ACL_PKG_BASE_START_L4_HDR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_END_L2_HDR = (CLX_ACL_PKG_BASE_END_TNL_HDR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_END_L3_HDR = (CLX_ACL_PKG_BASE_END_L2_HDR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_END_L4_HDR = (CLX_ACL_PKG_BASE_END_L3_HDR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_LAST = (CLX_ACL_PKG_BASE_END_L4_HDR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

CLX_ACL_PKG_BASE_T = enum_anon_106# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 263

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 274
class struct_CLX_ACL_PKG_CFG_S(Structure):
    pass

struct_CLX_ACL_PKG_CFG_S.__slots__ = [
    'type',
    'offset',
    'mask',
    'flags',
]
struct_CLX_ACL_PKG_CFG_S._fields_ = [
    ('type', CLX_ACL_PKG_BASE_T),
    ('offset', UI32_T),
    ('mask', UI32_T),
    ('flags', UI32_T),
]

CLX_ACL_PKG_CFG_T = struct_CLX_ACL_PKG_CFG_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 274

enum_anon_107 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_L2_SA_GROUP_LABEL = (1 << 0)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_L2_DA_GROUP_LABEL = (1 << 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_L3_SA_GROUP_LABEL = (1 << 2)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_L3_DA_GROUP_LABEL = (1 << 3)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_INTF_GROUP_LABEL = (1 << 4)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_SERVICE_GROUP_LABEL = (1 << 5)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_LOU = (1 << 6)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_PORT_BITMAP = (1 << 7)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_BDID = (1 << 8)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_L3_INTF_ID = (1 << 9)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_STAG_VID = (1 << 10)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_CTAG_VID = (1 << 11)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_STAG_PCP_DEI = (1 << 12)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_CTAG_PCP_DEI = (1 << 13)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_VLAN_TAG_MODE_1Q = (1 << 14)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_L3_ROUTE = (1 << 15)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

CLX_ACL_UDF_INTERNAL_KEY_T = enum_anon_107# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 295

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 317
class struct_CLX_ACL_UDF_KEY_PROFILE_S(Structure):
    pass

struct_CLX_ACL_UDF_KEY_PROFILE_S.__slots__ = [
    'pkg_cfg',
    'pkg_cnt',
    'internal_key_bitmap',
    'flow_pkg_cfg',
    'flow_pkg_cnt',
    'flow_internal_key_bitmap',
    'flow_profile_id',
    'flow_1_pkg_cfg',
    'flow_1_pkg_cnt',
    'flow_1_internal_key_bitmap',
    'flow_1_profile_id',
    'flags',
]
struct_CLX_ACL_UDF_KEY_PROFILE_S._fields_ = [
    ('pkg_cfg', CLX_ACL_PKG_CFG_T * int(46)),
    ('pkg_cnt', UI32_T),
    ('internal_key_bitmap', UI32_T),
    ('flow_pkg_cfg', CLX_ACL_PKG_CFG_T * int(31)),
    ('flow_pkg_cnt', UI32_T),
    ('flow_internal_key_bitmap', UI32_T),
    ('flow_profile_id', UI32_T),
    ('flow_1_pkg_cfg', CLX_ACL_PKG_CFG_T * int(16)),
    ('flow_1_pkg_cnt', UI32_T),
    ('flow_1_internal_key_bitmap', UI32_T),
    ('flow_1_profile_id', UI32_T),
    ('flags', UI32_T),
]

CLX_ACL_UDF_KEY_PROFILE_T = struct_CLX_ACL_UDF_KEY_PROFILE_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 317

enum_anon_108 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

CLX_ACL_LOU_NONE = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

CLX_ACL_LOU_SVID = (CLX_ACL_LOU_NONE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

CLX_ACL_LOU_CVID = (CLX_ACL_LOU_SVID + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

CLX_ACL_LOU_IP_PAYLOAD_LEN = (CLX_ACL_LOU_CVID + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

CLX_ACL_LOU_IP_TTL = (CLX_ACL_LOU_IP_PAYLOAD_LEN + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

CLX_ACL_LOU_SRC_PORT = (CLX_ACL_LOU_IP_TTL + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

CLX_ACL_LOU_DST_PORT = (CLX_ACL_LOU_SRC_PORT + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

CLX_ACL_LOU_PKG = (CLX_ACL_LOU_DST_PORT + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

CLX_ACL_LOU_IP_TOTAL_LEN = (CLX_ACL_LOU_PKG + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

CLX_ACL_LOU_LAST = (CLX_ACL_LOU_IP_TOTAL_LEN + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

CLX_ACL_LOU_T = enum_anon_108# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 331

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 348
class struct_CLX_ACL_LOU_CFG_S(Structure):
    pass

struct_CLX_ACL_LOU_CFG_S.__slots__ = [
    'type',
    'pkg_base_type',
    'pkg_offset',
    'val_mask',
    'val_max',
    'val_min',
    'flags',
]
struct_CLX_ACL_LOU_CFG_S._fields_ = [
    ('type', CLX_ACL_LOU_T),
    ('pkg_base_type', CLX_ACL_PKG_BASE_T),
    ('pkg_offset', UI32_T),
    ('val_mask', UI16_T),
    ('val_max', UI16_T),
    ('val_min', UI16_T),
    ('flags', UI32_T),
]

CLX_ACL_LOU_CFG_T = struct_CLX_ACL_LOU_CFG_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 348

enum_anon_109 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 359

CLX_ACL_CLASSIFY_KEY_MAC = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 359

CLX_ACL_CLASSIFY_KEY_ARP = (CLX_ACL_CLASSIFY_KEY_MAC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 359

CLX_ACL_CLASSIFY_KEY_IPV4 = (CLX_ACL_CLASSIFY_KEY_ARP + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 359

CLX_ACL_CLASSIFY_KEY_IPV6 = (CLX_ACL_CLASSIFY_KEY_IPV4 + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 359

CLX_ACL_CLASSIFY_KEY_FCOE = (CLX_ACL_CLASSIFY_KEY_IPV6 + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 359

CLX_ACL_CLASSIFY_KEY_UDF = (CLX_ACL_CLASSIFY_KEY_FCOE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 359

CLX_ACL_CLASSIFY_KEY_LAST = (CLX_ACL_CLASSIFY_KEY_UDF + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 359

CLX_ACL_CLASSIFY_KEY_T = enum_anon_109# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 359

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 369
class struct_CLX_ACL_MAC_KEY_S(Structure):
    pass

struct_CLX_ACL_MAC_KEY_S.__slots__ = [
    'dmac',
    'dmac_mask',
    'smac',
    'smac_mask',
    'ether_type',
    'ether_type_mask',
]
struct_CLX_ACL_MAC_KEY_S._fields_ = [
    ('dmac', CLX_MAC_T),
    ('dmac_mask', CLX_MAC_T),
    ('smac', CLX_MAC_T),
    ('smac_mask', CLX_MAC_T),
    ('ether_type', UI16_T),
    ('ether_type_mask', UI16_T),
]

CLX_ACL_MAC_KEY_T = struct_CLX_ACL_MAC_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 369

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 385
class struct_CLX_ACL_ARP_KEY_S(Structure):
    pass

struct_CLX_ACL_ARP_KEY_S.__slots__ = [
    'sender_mac',
    'sender_mac_mask',
    'sender_ip',
    'sender_ip_mask',
    'target_mac',
    'target_mac_mask',
    'target_ip',
    'target_ip_mask',
    'arp_frame_type',
    'flags',
]
struct_CLX_ACL_ARP_KEY_S._fields_ = [
    ('sender_mac', CLX_MAC_T),
    ('sender_mac_mask', CLX_MAC_T),
    ('sender_ip', CLX_IPV4_T),
    ('sender_ip_mask', CLX_IPV4_T),
    ('target_mac', CLX_MAC_T),
    ('target_mac_mask', CLX_MAC_T),
    ('target_ip', CLX_IPV4_T),
    ('target_ip_mask', CLX_IPV4_T),
    ('arp_frame_type', CLX_ACL_ARP_FRAME_T),
    ('flags', UI32_T),
]

CLX_ACL_ARP_KEY_T = struct_CLX_ACL_ARP_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 385

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 416
class struct_CLX_ACL_IPV4_KEY_S(Structure):
    pass

struct_CLX_ACL_IPV4_KEY_S.__slots__ = [
    'dip',
    'dip_mask',
    'sip',
    'sip_mask',
    'protocol',
    'protocol_mask',
    'dst_port',
    'dst_port_mask',
    'src_port',
    'src_port_mask',
    'tcp_flag',
    'tcp_flag_mask',
    'icmp_type',
    'icmp_type_mask',
    'icmp_code',
    'icmp_code_mask',
    'igmp_type',
    'igmp_type_mask',
    'frg_type',
    'ttl_type',
    'flags',
    'flags_mask',
]
struct_CLX_ACL_IPV4_KEY_S._fields_ = [
    ('dip', CLX_IPV4_T),
    ('dip_mask', CLX_IPV4_T),
    ('sip', CLX_IPV4_T),
    ('sip_mask', CLX_IPV4_T),
    ('protocol', UI8_T),
    ('protocol_mask', UI8_T),
    ('dst_port', UI16_T),
    ('dst_port_mask', UI16_T),
    ('src_port', UI16_T),
    ('src_port_mask', UI16_T),
    ('tcp_flag', UI16_T),
    ('tcp_flag_mask', UI16_T),
    ('icmp_type', UI8_T),
    ('icmp_type_mask', UI8_T),
    ('icmp_code', UI8_T),
    ('icmp_code_mask', UI8_T),
    ('igmp_type', UI8_T),
    ('igmp_type_mask', UI8_T),
    ('frg_type', CLX_ACL_FRG_T),
    ('ttl_type', CLX_ACL_TTL_T),
    ('flags', UI32_T),
    ('flags_mask', UI32_T),
]

CLX_ACL_IPV4_KEY_T = struct_CLX_ACL_IPV4_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 416

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 456
class struct_CLX_ACL_IPV6_KEY_S(Structure):
    pass

struct_CLX_ACL_IPV6_KEY_S.__slots__ = [
    'dip',
    'dip_mask',
    'sip',
    'sip_mask',
    'protocol',
    'protocol_mask',
    'flow_label',
    'flow_label_mask',
    'first_ext_hdr_protocol',
    'first_ext_hdr_protocol_mask',
    'second_ext_hdr_protocol',
    'second_ext_hdr_protocol_mask',
    'dst_port',
    'dst_port_mask',
    'src_port',
    'src_port_mask',
    'tcp_flag',
    'tcp_flag_mask',
    'icmp_type',
    'icmp_type_mask',
    'icmp_code',
    'icmp_code_mask',
    'igmp_type',
    'igmp_type_mask',
    'frg_type',
    'ttl_type',
    'flags',
    'flags_mask',
]
struct_CLX_ACL_IPV6_KEY_S._fields_ = [
    ('dip', CLX_IPV6_T),
    ('dip_mask', CLX_IPV6_T),
    ('sip', CLX_IPV6_T),
    ('sip_mask', CLX_IPV6_T),
    ('protocol', UI8_T),
    ('protocol_mask', UI8_T),
    ('flow_label', UI32_T),
    ('flow_label_mask', UI32_T),
    ('first_ext_hdr_protocol', UI8_T),
    ('first_ext_hdr_protocol_mask', UI8_T),
    ('second_ext_hdr_protocol', UI8_T),
    ('second_ext_hdr_protocol_mask', UI8_T),
    ('dst_port', UI16_T),
    ('dst_port_mask', UI16_T),
    ('src_port', UI16_T),
    ('src_port_mask', UI16_T),
    ('tcp_flag', UI16_T),
    ('tcp_flag_mask', UI16_T),
    ('icmp_type', UI8_T),
    ('icmp_type_mask', UI8_T),
    ('icmp_code', UI8_T),
    ('icmp_code_mask', UI8_T),
    ('igmp_type', UI8_T),
    ('igmp_type_mask', UI8_T),
    ('frg_type', CLX_ACL_FRG_T),
    ('ttl_type', CLX_ACL_TTL_T),
    ('flags', UI32_T),
    ('flags_mask', UI32_T),
]

CLX_ACL_IPV6_KEY_T = struct_CLX_ACL_IPV6_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 456

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 488
class struct_CLX_ACL_FCOE_KEY_S(Structure):
    pass

struct_CLX_ACL_FCOE_KEY_S.__slots__ = [
    'sof',
    'sof_mask',
    'r_ctl',
    'r_ctl_mask',
    'type',
    'type_mask',
    'dst_fcid',
    'dst_fcid_mask',
    'src_fcid',
    'src_fcid_mask',
    'cs_ctl',
    'cs_ctl_mask',
    'f_ctl',
    'f_ctl_mask',
    'df_ctl',
    'df_ctl_mask',
    'ox_id',
    'ox_id_mask',
    'rx_id',
    'rx_id_mask',
    'vft_type',
    'vft_type_mask',
    'first_hdr_type',
    'second_hdr_type',
    'flags',
]
struct_CLX_ACL_FCOE_KEY_S._fields_ = [
    ('sof', UI8_T),
    ('sof_mask', UI8_T),
    ('r_ctl', UI8_T),
    ('r_ctl_mask', UI8_T),
    ('type', UI8_T),
    ('type_mask', UI8_T),
    ('dst_fcid', CLX_FCOE_FCID_T),
    ('dst_fcid_mask', CLX_FCOE_FCID_T),
    ('src_fcid', CLX_FCOE_FCID_T),
    ('src_fcid_mask', CLX_FCOE_FCID_T),
    ('cs_ctl', UI8_T),
    ('cs_ctl_mask', UI8_T),
    ('f_ctl', UI32_T),
    ('f_ctl_mask', UI32_T),
    ('df_ctl', UI8_T),
    ('df_ctl_mask', UI8_T),
    ('ox_id', UI16_T),
    ('ox_id_mask', UI16_T),
    ('rx_id', UI16_T),
    ('rx_id_mask', UI16_T),
    ('vft_type', UI8_T),
    ('vft_type_mask', UI8_T),
    ('first_hdr_type', CLX_ACL_FCOE_HDR_T),
    ('second_hdr_type', CLX_ACL_FCOE_HDR_T),
    ('flags', UI32_T),
]

CLX_ACL_FCOE_KEY_T = struct_CLX_ACL_FCOE_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 488

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 514
class struct_CLX_ACL_QOS_KEY_S(Structure):
    pass

struct_CLX_ACL_QOS_KEY_S.__slots__ = [
    'pcp',
    'pcp_mask',
    'dei',
    'dei_mask',
    'dscp',
    'dscp_mask',
    'ecn',
    'ecn_mask',
    'tc',
    'tc_mask',
    'color',
    'flags',
]
struct_CLX_ACL_QOS_KEY_S._fields_ = [
    ('pcp', UI8_T),
    ('pcp_mask', UI8_T),
    ('dei', UI8_T),
    ('dei_mask', UI8_T),
    ('dscp', UI8_T),
    ('dscp_mask', UI8_T),
    ('ecn', UI8_T),
    ('ecn_mask', UI8_T),
    ('tc', UI8_T),
    ('tc_mask', UI8_T),
    ('color', CLX_COLOR_T),
    ('flags', UI32_T),
]

CLX_ACL_QOS_KEY_T = struct_CLX_ACL_QOS_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 514

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 580
class struct_CLX_ACL_PP_INFO_KEY_S(Structure):
    pass

struct_CLX_ACL_PP_INFO_KEY_S.__slots__ = [
    'intf_group_label',
    'intf_group_label_mask',
    'vlan_group_label',
    'vlan_group_label_mask',
    'service_group_label',
    'service_group_label_mask',
    'l3_intf_group_label',
    'l3_intf_group_label_mask',
    'ingress_acl_group_label',
    'ingress_acl_group_label_mask',
    'l2_da_group_label',
    'l2_da_group_label_mask',
    'l2_sa_group_label',
    'l2_sa_group_label_mask',
    'l3_da_group_label',
    'l3_da_group_label_mask',
    'l3_sa_group_label',
    'l3_sa_group_label_mask',
    'bdid',
    'bdid_mask',
    'l3_intf_id',
    'l3_intf_id_mask',
    'l2_frame_type',
    'fwd_type',
    'l2_da_lookup_type',
    'l2_sa_lookup_type',
    'svid',
    'svid_mask',
    'cvid',
    'cvid_mask',
    'flags',
    'flags_mask',
]
struct_CLX_ACL_PP_INFO_KEY_S._fields_ = [
    ('intf_group_label', UI32_T),
    ('intf_group_label_mask', UI32_T),
    ('vlan_group_label', UI32_T),
    ('vlan_group_label_mask', UI32_T),
    ('service_group_label', UI32_T),
    ('service_group_label_mask', UI32_T),
    ('l3_intf_group_label', UI32_T),
    ('l3_intf_group_label_mask', UI32_T),
    ('ingress_acl_group_label', UI32_T),
    ('ingress_acl_group_label_mask', UI32_T),
    ('l2_da_group_label', UI32_T),
    ('l2_da_group_label_mask', UI32_T),
    ('l2_sa_group_label', UI32_T),
    ('l2_sa_group_label_mask', UI32_T),
    ('l3_da_group_label', UI32_T),
    ('l3_da_group_label_mask', UI32_T),
    ('l3_sa_group_label', UI32_T),
    ('l3_sa_group_label_mask', UI32_T),
    ('bdid', UI32_T),
    ('bdid_mask', UI32_T),
    ('l3_intf_id', UI32_T),
    ('l3_intf_id_mask', UI32_T),
    ('l2_frame_type', CLX_ACL_L2_FRAME_T),
    ('fwd_type', CLX_ACL_FWD_T),
    ('l2_da_lookup_type', CLX_ACL_L2_LOOKUP_T),
    ('l2_sa_lookup_type', CLX_ACL_L2_LOOKUP_T),
    ('svid', UI32_T),
    ('svid_mask', UI32_T),
    ('cvid', UI32_T),
    ('cvid_mask', UI32_T),
    ('flags', UI32_T),
    ('flags_mask', UI32_T),
]

CLX_ACL_PP_INFO_KEY_T = struct_CLX_ACL_PP_INFO_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 580

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 622
class struct_CLX_ACL_PKG_KEY_S(Structure):
    pass

struct_CLX_ACL_PKG_KEY_S.__slots__ = [
    'l2_sa_group_label',
    'l2_sa_group_label_mask',
    'l2_da_group_label',
    'l2_da_group_label_mask',
    'l3_sa_group_label',
    'l3_sa_group_label_mask',
    'l3_da_group_label',
    'l3_da_group_label_mask',
    'intf_group_label',
    'intf_group_label_mask',
    'service_group_label',
    'service_group_label_mask',
    'bdid',
    'bdid_mask',
    'l3_intf_id',
    'l3_intf_id_mask',
    'svid',
    'svid_mask',
    'spcp',
    'spcp_mask',
    'sdei',
    'sdei_mask',
    'cvid',
    'cvid_mask',
    'cpcp',
    'cpcp_mask',
    'cdei',
    'cdei_mask',
    'pkg_cnt',
    'data',
    'mask',
    'flags',
    'flags_mask',
]
struct_CLX_ACL_PKG_KEY_S._fields_ = [
    ('l2_sa_group_label', UI32_T),
    ('l2_sa_group_label_mask', UI32_T),
    ('l2_da_group_label', UI32_T),
    ('l2_da_group_label_mask', UI32_T),
    ('l3_sa_group_label', UI32_T),
    ('l3_sa_group_label_mask', UI32_T),
    ('l3_da_group_label', UI32_T),
    ('l3_da_group_label_mask', UI32_T),
    ('intf_group_label', UI32_T),
    ('intf_group_label_mask', UI32_T),
    ('service_group_label', UI32_T),
    ('service_group_label_mask', UI32_T),
    ('bdid', UI32_T),
    ('bdid_mask', UI32_T),
    ('l3_intf_id', UI32_T),
    ('l3_intf_id_mask', UI32_T),
    ('svid', UI16_T),
    ('svid_mask', UI16_T),
    ('spcp', UI8_T),
    ('spcp_mask', UI8_T),
    ('sdei', UI8_T),
    ('sdei_mask', UI8_T),
    ('cvid', UI16_T),
    ('cvid_mask', UI16_T),
    ('cpcp', UI8_T),
    ('cpcp_mask', UI8_T),
    ('cdei', UI8_T),
    ('cdei_mask', UI8_T),
    ('pkg_cnt', UI32_T),
    ('data', UI32_T * int(46)),
    ('mask', UI32_T * int(46)),
    ('flags', UI32_T),
    ('flags_mask', UI32_T),
]

CLX_ACL_PKG_KEY_T = struct_CLX_ACL_PKG_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 622

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 628
class struct_CLX_ACL_LOU_KEY_S(Structure):
    pass

struct_CLX_ACL_LOU_KEY_S.__slots__ = [
    'lou_cnt',
    'lou_id',
]
struct_CLX_ACL_LOU_KEY_S._fields_ = [
    ('lou_cnt', UI32_T),
    ('lou_id', UI32_T * int(16)),
]

CLX_ACL_LOU_KEY_T = struct_CLX_ACL_LOU_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 628

enum_anon_110 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 636

CLX_ACL_UDF_KEY_AUTO = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 636

CLX_ACL_UDF_KEY_UDF_0 = (CLX_ACL_UDF_KEY_AUTO + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 636

CLX_ACL_UDF_KEY_UDF_1 = (CLX_ACL_UDF_KEY_UDF_0 + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 636

CLX_ACL_UDF_KEY_LAST = (CLX_ACL_UDF_KEY_UDF_1 + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 636

CLX_ACL_UDF_KEY_T = enum_anon_110# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 636

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 671
class struct_CLX_ACL_CLASSIFY_S(Structure):
    pass

struct_CLX_ACL_CLASSIFY_S.__slots__ = [
    'classify_key_type',
    'port_bitmap',
    'mac_key',
    'arp_key',
    'ipv4_key',
    'ipv6_key',
    'fcoe_key',
    'qos_key',
    'pp_info_key',
    'pkg_key',
    'lou_key',
    'udf_key_profile_id',
    'udf_key_profile_id_mask',
    'udf_key_type',
    'flags',
]
struct_CLX_ACL_CLASSIFY_S._fields_ = [
    ('classify_key_type', CLX_ACL_CLASSIFY_KEY_T),
    ('port_bitmap', CLX_PORT_BITMAP_T),
    ('mac_key', CLX_ACL_MAC_KEY_T),
    ('arp_key', CLX_ACL_ARP_KEY_T),
    ('ipv4_key', CLX_ACL_IPV4_KEY_T),
    ('ipv6_key', CLX_ACL_IPV6_KEY_T),
    ('fcoe_key', CLX_ACL_FCOE_KEY_T),
    ('qos_key', CLX_ACL_QOS_KEY_T),
    ('pp_info_key', CLX_ACL_PP_INFO_KEY_T),
    ('pkg_key', CLX_ACL_PKG_KEY_T),
    ('lou_key', CLX_ACL_LOU_KEY_T),
    ('udf_key_profile_id', UI32_T),
    ('udf_key_profile_id_mask', UI32_T),
    ('udf_key_type', CLX_ACL_UDF_KEY_T),
    ('flags', UI32_T),
]

CLX_ACL_CLASSIFY_T = struct_CLX_ACL_CLASSIFY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 671

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 691
class struct_CLX_ACL_QOS_ACTION_S(Structure):
    pass

struct_CLX_ACL_QOS_ACTION_S.__slots__ = [
    'pcp',
    'dei',
    'dscp',
    'ecn',
    'tc',
    'color',
    'flags',
]
struct_CLX_ACL_QOS_ACTION_S._fields_ = [
    ('pcp', UI8_T),
    ('dei', UI8_T),
    ('dscp', UI8_T),
    ('ecn', UI8_T),
    ('tc', UI8_T),
    ('color', CLX_COLOR_T),
    ('flags', UI32_T),
]

CLX_ACL_QOS_ACTION_T = struct_CLX_ACL_QOS_ACTION_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 691

enum_anon_111 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 702

CLX_ACL_REDIRECT_L2_UC = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 702

CLX_ACL_REDIRECT_L3_UC = (CLX_ACL_REDIRECT_L2_UC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 702

CLX_ACL_REDIRECT_L3_ECMP = (CLX_ACL_REDIRECT_L3_UC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 702

CLX_ACL_REDIRECT_L2_MC = (CLX_ACL_REDIRECT_L3_ECMP + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 702

CLX_ACL_REDIRECT_L3_MC = (CLX_ACL_REDIRECT_L2_MC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 702

CLX_ACL_REDIRECT_CPU = (CLX_ACL_REDIRECT_L3_MC + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 702

CLX_ACL_REDIRECT_LAST = (CLX_ACL_REDIRECT_CPU + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 702

CLX_ACL_REDIRECT_T = enum_anon_111# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 702

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 716
class struct_CLX_ACL_REDIRECT_ACTION_S(Structure):
    pass

struct_CLX_ACL_REDIRECT_ACTION_S.__slots__ = [
    'redirect_type',
    'port',
    'bdid',
    'adj_id',
    'ecmp_group_id',
    'mcast_id',
    'cpu_reason_bitmap',
    'flags',
]
struct_CLX_ACL_REDIRECT_ACTION_S._fields_ = [
    ('redirect_type', CLX_ACL_REDIRECT_T),
    ('port', CLX_PORT_T),
    ('bdid', CLX_BRIDGE_DOMAIN_T),
    ('adj_id', UI32_T),
    ('ecmp_group_id', UI32_T),
    ('mcast_id', UI32_T),
    ('cpu_reason_bitmap', CLX_PKT_RX_REASON_BITMAP_T),
    ('flags', UI32_T),
]

CLX_ACL_REDIRECT_ACTION_T = struct_CLX_ACL_REDIRECT_ACTION_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 716

enum_anon_112 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 726

CLX_ACL_REWRITE_DEL = 1# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 726

CLX_ACL_REWRITE_ADD = (CLX_ACL_REWRITE_DEL + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 726

CLX_ACL_REWRITE_SET = (CLX_ACL_REWRITE_ADD + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 726

CLX_ACL_REWRITE_SET_WITH_MASK = (CLX_ACL_REWRITE_SET + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 726

CLX_ACL_REWRITE_SET_INCR = (CLX_ACL_REWRITE_SET_WITH_MASK + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 726

CLX_ACL_REWRITE_LAST = (CLX_ACL_REWRITE_SET_INCR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 726

CLX_ACL_REWRITE_ACTION_T = enum_anon_112# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 726

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 736
class struct_CLX_ACL_REWRITE_CFG_S(Structure):
    pass

struct_CLX_ACL_REWRITE_CFG_S.__slots__ = [
    'type',
    'pkg_base_type',
    'byte_offset',
    'byte_cnt',
    'data',
    'mask',
]
struct_CLX_ACL_REWRITE_CFG_S._fields_ = [
    ('type', CLX_ACL_REWRITE_ACTION_T),
    ('pkg_base_type', CLX_ACL_PKG_BASE_T),
    ('byte_offset', UI32_T),
    ('byte_cnt', UI32_T),
    ('data', UI8_T * int(16)),
    ('mask', UI8_T * int(8)),
]

CLX_ACL_REWRITE_CFG_T = struct_CLX_ACL_REWRITE_CFG_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 736

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 742
class struct_CLX_ACL_PKT_REWRITE_S(Structure):
    pass

struct_CLX_ACL_PKT_REWRITE_S.__slots__ = [
    'rewrite_cfg',
    'rewrite_cnt',
]
struct_CLX_ACL_PKT_REWRITE_S._fields_ = [
    ('rewrite_cfg', CLX_ACL_REWRITE_CFG_T * int(9)),
    ('rewrite_cnt', UI32_T),
]

CLX_ACL_PKT_REWRITE_T = struct_CLX_ACL_PKT_REWRITE_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 742

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 796
class struct_CLX_ACL_ACTION_S(Structure):
    pass

struct_CLX_ACL_ACTION_S.__slots__ = [
    'priority',
    'mir_session_bitmap',
    'sampling_rate',
    'sample_to_mir_session_id',
    'meter_id',
    'counter_id',
    'dist_counter_id',
    'ingress_acl_group_label',
    'da_group_label',
    'qos_action_color_blind',
    'qos_action_color_green',
    'qos_action_color_yellow',
    'qos_action_color_red',
    'cpu_reason_bitmap',
    'redirect_action',
    'pkt_rewrite',
    'dtel_profile_id',
    'flags',
]
struct_CLX_ACL_ACTION_S._fields_ = [
    ('priority', UI32_T),
    ('mir_session_bitmap', UI32_T),
    ('sampling_rate', UI32_T),
    ('sample_to_mir_session_id', UI32_T),
    ('meter_id', UI32_T),
    ('counter_id', UI32_T),
    ('dist_counter_id', UI32_T),
    ('ingress_acl_group_label', UI32_T),
    ('da_group_label', UI32_T),
    ('qos_action_color_blind', CLX_ACL_QOS_ACTION_T),
    ('qos_action_color_green', CLX_ACL_QOS_ACTION_T),
    ('qos_action_color_yellow', CLX_ACL_QOS_ACTION_T),
    ('qos_action_color_red', CLX_ACL_QOS_ACTION_T),
    ('cpu_reason_bitmap', CLX_PKT_RX_REASON_BITMAP_T),
    ('redirect_action', CLX_ACL_REDIRECT_ACTION_T),
    ('pkt_rewrite', CLX_ACL_PKT_REWRITE_T),
    ('dtel_profile_id', UI32_T),
    ('flags', UI32_T),
]

CLX_ACL_ACTION_T = struct_CLX_ACL_ACTION_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 796

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 804
class struct_CLX_ACL_GROUP_INFO_S(Structure):
    pass

struct_CLX_ACL_GROUP_INFO_S.__slots__ = [
    'type',
    'group_id',
    'priority',
    'group_profile',
]
struct_CLX_ACL_GROUP_INFO_S._fields_ = [
    ('type', CLX_ACL_GROUP_T),
    ('group_id', UI32_T),
    ('priority', UI32_T),
    ('group_profile', CLX_ACL_GROUP_PROFILE_T),
]

CLX_ACL_GROUP_INFO_T = struct_CLX_ACL_GROUP_INFO_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 804

CLX_ACL_GROUP_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_ACL_GROUP_INFO_T), POINTER(None))# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 807

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 821
class struct_CLX_ACL_ENTRY_INFO_S(Structure):
    pass

struct_CLX_ACL_ENTRY_INFO_S.__slots__ = [
    'type',
    'group_id',
    'entry_id',
    'priority',
    'entry_valid',
    'classify',
    'action',
]
struct_CLX_ACL_ENTRY_INFO_S._fields_ = [
    ('type', CLX_ACL_GROUP_T),
    ('group_id', UI32_T),
    ('entry_id', UI32_T),
    ('priority', UI32_T),
    ('entry_valid', BOOL_T),
    ('classify', CLX_ACL_CLASSIFY_T),
    ('action', CLX_ACL_ACTION_T),
]

CLX_ACL_ENTRY_INFO_T = struct_CLX_ACL_ENTRY_INFO_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 821

CLX_ACL_ENTRY_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_ACL_ENTRY_INFO_T), POINTER(None))# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 824

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 835
class struct_CLX_ACL_UDF_INFO_S(Structure):
    pass

struct_CLX_ACL_UDF_INFO_S.__slots__ = [
    'type',
    'udf_key_profile_id',
    'pkt_format',
    'profile',
]
struct_CLX_ACL_UDF_INFO_S._fields_ = [
    ('type', CLX_ACL_GROUP_T),
    ('udf_key_profile_id', UI32_T),
    ('pkt_format', CLX_ACL_PKT_FORMAT_T),
    ('profile', CLX_ACL_UDF_KEY_PROFILE_T),
]

CLX_ACL_UDF_INFO_T = struct_CLX_ACL_UDF_INFO_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 835

CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_ACL_UDF_INFO_T), POINTER(None))# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 838

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 849
class struct_CLX_ACL_LOU_INFO_S(Structure):
    pass

struct_CLX_ACL_LOU_INFO_S.__slots__ = [
    'type',
    'id',
    'lou_id',
    'lou_cfg',
]
struct_CLX_ACL_LOU_INFO_S._fields_ = [
    ('type', CLX_ACL_GROUP_T),
    ('id', UI32_T),
    ('lou_id', UI32_T),
    ('lou_cfg', CLX_ACL_LOU_CFG_T),
]

CLX_ACL_LOU_INFO_T = struct_CLX_ACL_LOU_INFO_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 849

CLX_ACL_LOU_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_ACL_LOU_INFO_T), POINTER(None))# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 852

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 878
if _libs["libsai.so"].has("clx_acl_addGroup", "cdecl"):
    clx_acl_addGroup = _libs["libsai.so"].get("clx_acl_addGroup", "cdecl")
    clx_acl_addGroup.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, POINTER(CLX_ACL_GROUP_PROFILE_T), POINTER(UI32_T)]
    clx_acl_addGroup.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 902
if _libs["libsai.so"].has("clx_acl_delGroup", "cdecl"):
    clx_acl_delGroup = _libs["libsai.so"].get("clx_acl_delGroup", "cdecl")
    clx_acl_delGroup.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T]
    clx_acl_delGroup.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 925
if _libs["libsai.so"].has("clx_acl_getGroup", "cdecl"):
    clx_acl_getGroup = _libs["libsai.so"].get("clx_acl_getGroup", "cdecl")
    clx_acl_getGroup.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, POINTER(UI32_T), POINTER(CLX_ACL_GROUP_PROFILE_T)]
    clx_acl_getGroup.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 965
if _libs["libsai.so"].has("clx_acl_addUdfKeyProfile", "cdecl"):
    clx_acl_addUdfKeyProfile = _libs["libsai.so"].get("clx_acl_addUdfKeyProfile", "cdecl")
    clx_acl_addUdfKeyProfile.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, POINTER(CLX_ACL_PKT_FORMAT_T), POINTER(CLX_ACL_UDF_KEY_PROFILE_T)]
    clx_acl_addUdfKeyProfile.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 989
if _libs["libsai.so"].has("clx_acl_delUdfKeyProfile", "cdecl"):
    clx_acl_delUdfKeyProfile = _libs["libsai.so"].get("clx_acl_delUdfKeyProfile", "cdecl")
    clx_acl_delUdfKeyProfile.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T]
    clx_acl_delUdfKeyProfile.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1012
if _libs["libsai.so"].has("clx_acl_getUdfKeyProfile", "cdecl"):
    clx_acl_getUdfKeyProfile = _libs["libsai.so"].get("clx_acl_getUdfKeyProfile", "cdecl")
    clx_acl_getUdfKeyProfile.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, POINTER(CLX_ACL_PKT_FORMAT_T), POINTER(CLX_ACL_UDF_KEY_PROFILE_T)]
    clx_acl_getUdfKeyProfile.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1039
if _libs["libsai.so"].has("clx_acl_addLou", "cdecl"):
    clx_acl_addLou = _libs["libsai.so"].get("clx_acl_addLou", "cdecl")
    clx_acl_addLou.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, UI32_T, POINTER(CLX_ACL_LOU_CFG_T)]
    clx_acl_addLou.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1065
if _libs["libsai.so"].has("clx_acl_delLou", "cdecl"):
    clx_acl_delLou = _libs["libsai.so"].get("clx_acl_delLou", "cdecl")
    clx_acl_delLou.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, UI32_T]
    clx_acl_delLou.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1090
if _libs["libsai.so"].has("clx_acl_getLou", "cdecl"):
    clx_acl_getLou = _libs["libsai.so"].get("clx_acl_getLou", "cdecl")
    clx_acl_getLou.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, UI32_T, POINTER(CLX_ACL_LOU_CFG_T)]
    clx_acl_getLou.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1115
if _libs["libsai.so"].has("clx_acl_allocEntryId", "cdecl"):
    clx_acl_allocEntryId = _libs["libsai.so"].get("clx_acl_allocEntryId", "cdecl")
    clx_acl_allocEntryId.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, UI32_T, POINTER(UI32_T)]
    clx_acl_allocEntryId.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1138
if _libs["libsai.so"].has("clx_acl_freeEntryId", "cdecl"):
    clx_acl_freeEntryId = _libs["libsai.so"].get("clx_acl_freeEntryId", "cdecl")
    clx_acl_freeEntryId.argtypes = [UI32_T, UI32_T]
    clx_acl_freeEntryId.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1160
if _libs["libsai.so"].has("clx_acl_getEntryIdInfo", "cdecl"):
    clx_acl_getEntryIdInfo = _libs["libsai.so"].get("clx_acl_getEntryIdInfo", "cdecl")
    clx_acl_getEntryIdInfo.argtypes = [UI32_T, UI32_T, POINTER(CLX_ACL_GROUP_T), POINTER(UI32_T), POINTER(UI32_T)]
    clx_acl_getEntryIdInfo.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1186
if _libs["libsai.so"].has("clx_acl_addEntry", "cdecl"):
    clx_acl_addEntry = _libs["libsai.so"].get("clx_acl_addEntry", "cdecl")
    clx_acl_addEntry.argtypes = [UI32_T, UI32_T, BOOL_T, POINTER(CLX_ACL_CLASSIFY_T), POINTER(CLX_ACL_ACTION_T)]
    clx_acl_addEntry.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1210
if _libs["libsai.so"].has("clx_acl_delEntry", "cdecl"):
    clx_acl_delEntry = _libs["libsai.so"].get("clx_acl_delEntry", "cdecl")
    clx_acl_delEntry.argtypes = [UI32_T, UI32_T]
    clx_acl_delEntry.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1232
if _libs["libsai.so"].has("clx_acl_getEntry", "cdecl"):
    clx_acl_getEntry = _libs["libsai.so"].get("clx_acl_getEntry", "cdecl")
    clx_acl_getEntry.argtypes = [UI32_T, UI32_T, POINTER(BOOL_T), POINTER(CLX_ACL_CLASSIFY_T), POINTER(CLX_ACL_ACTION_T)]
    clx_acl_getEntry.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1257
if _libs["libsai.so"].has("clx_acl_addFlowEntry", "cdecl"):
    clx_acl_addFlowEntry = _libs["libsai.so"].get("clx_acl_addFlowEntry", "cdecl")
    clx_acl_addFlowEntry.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, POINTER(CLX_ACL_CLASSIFY_T), POINTER(CLX_ACL_ACTION_T), POINTER(UI32_T)]
    clx_acl_addFlowEntry.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1282
if _libs["libsai.so"].has("clx_acl_delFlowEntry", "cdecl"):
    clx_acl_delFlowEntry = _libs["libsai.so"].get("clx_acl_delFlowEntry", "cdecl")
    clx_acl_delFlowEntry.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, UI32_T]
    clx_acl_delFlowEntry.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1306
if _libs["libsai.so"].has("clx_acl_getFlowEntry", "cdecl"):
    clx_acl_getFlowEntry = _libs["libsai.so"].get("clx_acl_getFlowEntry", "cdecl")
    clx_acl_getFlowEntry.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, UI32_T, POINTER(CLX_ACL_CLASSIFY_T), POINTER(CLX_ACL_ACTION_T)]
    clx_acl_getFlowEntry.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1332
if _libs["libsai.so"].has("clx_acl_traverseGroup", "cdecl"):
    clx_acl_traverseGroup = _libs["libsai.so"].get("clx_acl_traverseGroup", "cdecl")
    clx_acl_traverseGroup.argtypes = [UI32_T, CLX_ACL_GROUP_T, CLX_ACL_GROUP_TRAVERSE_FUNC_T, POINTER(None)]
    clx_acl_traverseGroup.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1357
if _libs["libsai.so"].has("clx_acl_traverseEntry", "cdecl"):
    clx_acl_traverseEntry = _libs["libsai.so"].get("clx_acl_traverseEntry", "cdecl")
    clx_acl_traverseEntry.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, CLX_ACL_ENTRY_TRAVERSE_FUNC_T, POINTER(None)]
    clx_acl_traverseEntry.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1382
if _libs["libsai.so"].has("clx_acl_traverseUdfKeyProfile", "cdecl"):
    clx_acl_traverseUdfKeyProfile = _libs["libsai.so"].get("clx_acl_traverseUdfKeyProfile", "cdecl")
    clx_acl_traverseUdfKeyProfile.argtypes = [UI32_T, CLX_ACL_GROUP_T, CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T, POINTER(None)]
    clx_acl_traverseUdfKeyProfile.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 1408
if _libs["libsai.so"].has("clx_acl_traverseLou", "cdecl"):
    clx_acl_traverseLou = _libs["libsai.so"].get("clx_acl_traverseLou", "cdecl")
    clx_acl_traverseLou.argtypes = [UI32_T, CLX_ACL_GROUP_T, UI32_T, CLX_ACL_LOU_TRAVERSE_FUNC_T, POINTER(None)]
    clx_acl_traverseLou.restype = CLX_ERROR_NO_T

enum_anon_113 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_CHIP_MODE = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_MAX_SPEED = (CLX_CFG_TYPE_CHIP_MODE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_LANE_NUM = (CLX_CFG_TYPE_PORT_MAX_SPEED + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_TX_LANE = (CLX_CFG_TYPE_PORT_LANE_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_RX_LANE = (CLX_CFG_TYPE_PORT_TX_LANE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_TX_POLARITY_REV = (CLX_CFG_TYPE_PORT_RX_LANE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_RX_POLARITY_REV = (CLX_CFG_TYPE_PORT_TX_POLARITY_REV + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_EXT_LANE = (CLX_CFG_TYPE_PORT_RX_POLARITY_REV + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_VALID = (CLX_CFG_TYPE_PORT_EXT_LANE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_L2_THREAD_PRI = (CLX_CFG_TYPE_PORT_VALID + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_L2_THREAD_STACK = (CLX_CFG_TYPE_L2_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_L2_ADDR_MODE = (CLX_CFG_TYPE_L2_THREAD_STACK + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_TX_GPD_NUM = (CLX_CFG_TYPE_L2_ADDR_MODE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_RX_GPD_NUM = (CLX_CFG_TYPE_PKT_TX_GPD_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_RX_SCHED_MODE = (CLX_CFG_TYPE_PKT_RX_GPD_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_TX_QUEUE_LEN = (CLX_CFG_TYPE_PKT_RX_SCHED_MODE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_RX_QUEUE_LEN = (CLX_CFG_TYPE_PKT_TX_QUEUE_LEN + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_RX_QUEUE_WEIGHT = (CLX_CFG_TYPE_PKT_RX_QUEUE_LEN + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_RX_ISR_THREAD_PRI = (CLX_CFG_TYPE_PKT_RX_QUEUE_WEIGHT + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_RX_ISR_THREAD_STACK = (CLX_CFG_TYPE_PKT_RX_ISR_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_RX_FREE_THREAD_PRI = (CLX_CFG_TYPE_PKT_RX_ISR_THREAD_STACK + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_RX_FREE_THREAD_STACK = (CLX_CFG_TYPE_PKT_RX_FREE_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_TX_ISR_THREAD_PRI = (CLX_CFG_TYPE_PKT_RX_FREE_THREAD_STACK + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_TX_ISR_THREAD_STACK = (CLX_CFG_TYPE_PKT_TX_ISR_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_TX_FREE_THREAD_PRI = (CLX_CFG_TYPE_PKT_TX_ISR_THREAD_STACK + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_TX_FREE_THREAD_STACK = (CLX_CFG_TYPE_PKT_TX_FREE_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_ERROR_ISR_THREAD_PRI = (CLX_CFG_TYPE_PKT_TX_FREE_THREAD_STACK + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_ERROR_ISR_THREAD_STACK = (CLX_CFG_TYPE_PKT_ERROR_ISR_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_CNT_THREAD_PRI = (CLX_CFG_TYPE_PKT_ERROR_ISR_THREAD_STACK + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_CNT_THREAD_STACK = (CLX_CFG_TYPE_CNT_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_IFMON_THREAD_PRI = (CLX_CFG_TYPE_CNT_THREAD_STACK + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_IFMON_THREAD_STACK = (CLX_CFG_TYPE_IFMON_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_SHARE_MEM_SDN_ENTRY_NUM = (CLX_CFG_TYPE_IFMON_THREAD_STACK + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_SHARE_MEM_L3_ENTRY_NUM = (CLX_CFG_TYPE_SHARE_MEM_SDN_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_SHARE_MEM_L2_ENTRY_NUM = (CLX_CFG_TYPE_SHARE_MEM_L3_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DLB_MONITOR_MODE = (CLX_CFG_TYPE_SHARE_MEM_L2_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DLB_LAG_MONITOR_THREAD_PRI = (CLX_CFG_TYPE_DLB_MONITOR_MODE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DLB_LAG_MONITOR_THREAD_SLEEP_TIME = (CLX_CFG_TYPE_DLB_LAG_MONITOR_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DLB_L3_MONITOR_THREAD_PRI = (CLX_CFG_TYPE_DLB_LAG_MONITOR_THREAD_SLEEP_TIME + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DLB_L3_MONITOR_THREAD_SLEEP_TIME = (CLX_CFG_TYPE_DLB_L3_MONITOR_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DLB_L3_INTR_THREAD_PRI = (CLX_CFG_TYPE_DLB_L3_MONITOR_THREAD_SLEEP_TIME + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DLB_NVO3_MONITOR_THREAD_PRI = (CLX_CFG_TYPE_DLB_L3_INTR_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DLB_NVO3_MONITOR_THREAD_SLEEP_TIME = (CLX_CFG_TYPE_DLB_NVO3_MONITOR_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DLB_NVO3_INTR_THREAD_PRI = (CLX_CFG_TYPE_DLB_NVO3_MONITOR_THREAD_SLEEP_TIME + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_L3_ECMP_MIN_BLOCK_SIZE = (CLX_CFG_TYPE_DLB_NVO3_INTR_THREAD_PRI + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_L3_ECMP_BLOCK_SIZE = (CLX_CFG_TYPE_L3_ECMP_MIN_BLOCK_SIZE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_TCAM_L3_WITH_IPV6_PREFIX_128_REGION_ENTRY_NUM = (CLX_CFG_TYPE_L3_ECMP_BLOCK_SIZE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_TCAM_L3_WITH_IPV6_PREFIX_64_REGION_ENTRY_NUM = (CLX_CFG_TYPE_TCAM_L3_WITH_IPV6_PREFIX_128_REGION_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_HASH_L2_FDB_REGION_ENTRY_NUM = (CLX_CFG_TYPE_TCAM_L3_WITH_IPV6_PREFIX_64_REGION_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_HASH_L2_GROUP_REGION_ENTRY_NUM = (CLX_CFG_TYPE_HASH_L2_FDB_REGION_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_HASH_SECURITY_REGION_ENTRY_NUM = (CLX_CFG_TYPE_HASH_L2_GROUP_REGION_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_HASH_L3_WITH_IPV6_PREFIX_128_REGION_ENTRY_NUM = (CLX_CFG_TYPE_HASH_SECURITY_REGION_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_HASH_L3_WITH_IPV6_PREFIX_64_REGION_ENTRY_NUM = (CLX_CFG_TYPE_HASH_L3_WITH_IPV6_PREFIX_128_REGION_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_HASH_L3_WITHOUT_PREFIX_REGION_ENTRY_NUM = (CLX_CFG_TYPE_HASH_L3_WITH_IPV6_PREFIX_64_REGION_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_HASH_L3_RPF_REGION_ENTRY_NUM = (CLX_CFG_TYPE_HASH_L3_WITHOUT_PREFIX_REGION_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_HASH_FLOW_REGION_ENTRY_NUM = (CLX_CFG_TYPE_HASH_L3_RPF_REGION_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_FC_MODE = (CLX_CFG_TYPE_HASH_FLOW_REGION_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_PFC_STATE = (CLX_CFG_TYPE_PORT_FC_MODE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_PFC_QUEUE_STATE = (CLX_CFG_TYPE_PORT_PFC_STATE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_PFC_MAPPING = (CLX_CFG_TYPE_PORT_PFC_QUEUE_STATE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_TRILL_ENABLE = (CLX_CFG_TYPE_PORT_PFC_MAPPING + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_USE_UNIT_PORT = (CLX_CFG_TYPE_TRILL_ENABLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_MAC_VLAN_ENABLE = (CLX_CFG_TYPE_USE_UNIT_PORT + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_CPI_PORT_MODE = (CLX_CFG_TYPE_MAC_VLAN_ENABLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PHY_ADDR = (CLX_CFG_TYPE_CPI_PORT_MODE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_LED_CFG = (CLX_CFG_TYPE_PHY_ADDR + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_USER_BUF_CTRL = (CLX_CFG_TYPE_LED_CFG + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_ARIES_SDP_MODE = (CLX_CFG_TYPE_USER_BUF_CTRL + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_FAIR_BUF_CTRL = (CLX_CFG_TYPE_ARIES_SDP_MODE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_HRM_BUF_SIZE = (CLX_CFG_TYPE_FAIR_BUF_CTRL + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_STEERING_TRUNCATE_ENABLE = (CLX_CFG_TYPE_HRM_BUF_SIZE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_FABRIC_MODE_ENABLE = (CLX_CFG_TYPE_STEERING_TRUNCATE_ENABLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_ACL_TCP_FLAGS_ENCODE_ENABLE = (CLX_CFG_TYPE_FABRIC_MODE_ENABLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_TCAM_ECC_SCAN_ENABLE = (CLX_CFG_TYPE_ACL_TCP_FLAGS_ENCODE_ENABLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PORT_BUF_MAX = (CLX_CFG_TYPE_TCAM_ECC_SCAN_ENABLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_INGRESS_DYNAMIC_BUF = (CLX_CFG_TYPE_PORT_BUF_MAX + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_EGRESS_DYNAMIC_BUF = (CLX_CFG_TYPE_INGRESS_DYNAMIC_BUF + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DCQCN_ENABLE = (CLX_CFG_TYPE_EGRESS_DYNAMIC_BUF + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DCTCP_MODE = (CLX_CFG_TYPE_DCQCN_ENABLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_QUEUE_GROUP_MAP = (CLX_CFG_TYPE_DCTCP_MODE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_FLOWCTRL_RESERVE_MODE = (CLX_CFG_TYPE_QUEUE_GROUP_MAP + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_FLOWCTRL_RESERVE_QUEUE = (CLX_CFG_TYPE_FLOWCTRL_RESERVE_MODE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_EGR_SYSTEM_GROUP_MAP = (CLX_CFG_TYPE_FLOWCTRL_RESERVE_QUEUE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_MPLS_SR_NUM = (CLX_CFG_TYPE_EGR_SYSTEM_GROUP_MAP + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_L2_BYPASS_LAG_PRUNE_GROUP_NUM = (CLX_CFG_TYPE_MPLS_SR_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_L3_BYPASS_LAG_PRUNE_GROUP_NUM = (CLX_CFG_TYPE_L2_BYPASS_LAG_PRUNE_GROUP_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_DTEL_PROFILE_NUM = (CLX_CFG_TYPE_L3_BYPASS_LAG_PRUNE_GROUP_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_TCAM_L3_SIP_ENABLE = (CLX_CFG_TYPE_DTEL_PROFILE_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_L3_ECMP_FDL_ENABLE = (CLX_CFG_TYPE_TCAM_L3_SIP_ENABLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_HASH_L3_IPV4_PREFIX_LENGTH_ENTRY_NUM = (CLX_CFG_TYPE_L3_ECMP_FDL_ENABLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_HASH_L3_IPV6_PREFIX_LENGTH_ENTRY_NUM = (CLX_CFG_TYPE_HASH_L3_IPV4_PREFIX_LENGTH_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_ACL_DROP_REDIRECT_CPU_PKT = (CLX_CFG_TYPE_HASH_L3_IPV6_PREFIX_LENGTH_ENTRY_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_STACKING_CHIP_PORT_NUM = (CLX_CFG_TYPE_ACL_DROP_REDIRECT_CPU_PKT + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_BUF_SNAPSHOT_INTERVAL = (CLX_CFG_TYPE_STACKING_CHIP_PORT_NUM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_LAG_MEMBER_AUTO_UPDATE = (CLX_CFG_TYPE_BUF_SNAPSHOT_INTERVAL + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_PKT_DMA_ENHANCE_ENABLE = (CLX_CFG_TYPE_LAG_MEMBER_AUTO_UPDATE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_L2_POLLING_INTERVAL = (CLX_CFG_TYPE_PKT_DMA_ENHANCE_ENABLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_LAG_MC_RESILIENT_ENABLE = (CLX_CFG_TYPE_L2_POLLING_INTERVAL + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_LAST = (CLX_CFG_TYPE_LAG_MC_RESILIENT_ENABLE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

CLX_CFG_TYPE_T = enum_anon_113# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 346

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 356
class struct_CLX_CFG_VALUE_S(Structure):
    pass

struct_CLX_CFG_VALUE_S.__slots__ = [
    'param0',
    'param1',
    'value',
]
struct_CLX_CFG_VALUE_S._fields_ = [
    ('param0', UI32_T),
    ('param1', UI32_T),
    ('value', I32_T),
]

CLX_CFG_VALUE_T = struct_CLX_CFG_VALUE_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 356

CLX_CFG_GET_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, CLX_CFG_TYPE_T, POINTER(CLX_CFG_VALUE_T))# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 359

CLX_CFG_GET_LED_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(POINTER(UI32_T)), POINTER(UI32_T))# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 365

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 397
if _libs["libsai.so"].has("clx_cfg_register", "cdecl"):
    clx_cfg_register = _libs["libsai.so"].get("clx_cfg_register", "cdecl")
    clx_cfg_register.argtypes = [UI32_T, CLX_CFG_GET_FUNC_T]
    clx_cfg_register.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 424
if _libs["libsai.so"].has("clx_cfg_led_register", "cdecl"):
    clx_cfg_led_register = _libs["libsai.so"].get("clx_cfg_led_register", "cdecl")
    clx_cfg_led_register.argtypes = [UI32_T, CLX_CFG_GET_LED_FUNC_T]
    clx_cfg_led_register.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 75
class struct_CLX_DTEL_DPP_HDR_S(Structure):
    pass

struct_CLX_DTEL_DPP_HDR_S.__slots__ = [
    'probe_mark_1',
    'probe_mark_2',
    'probe_mask',
    'hop_lim',
    'max_len',
    'cur_len',
    'send_id',
    'seq_num',
]
struct_CLX_DTEL_DPP_HDR_S._fields_ = [
    ('probe_mark_1', UI32_T),
    ('probe_mark_2', UI32_T),
    ('probe_mask', UI32_T),
    ('hop_lim', UI32_T),
    ('max_len', UI32_T),
    ('cur_len', UI32_T),
    ('send_id', UI32_T),
    ('seq_num', UI32_T),
]

CLX_DTEL_DPP_HDR_T = struct_CLX_DTEL_DPP_HDR_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 75

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 87
class struct_CLX_DTEL_DPP_S(Structure):
    pass

struct_CLX_DTEL_DPP_S.__slots__ = [
    'ipv4_addr',
    'ipv6_addr',
    'check_threshold',
    'udp_dp',
    'v6_nhdr',
    'opq_id',
    'dev_id',
    'dpp_hdr',
]
struct_CLX_DTEL_DPP_S._fields_ = [
    ('ipv4_addr', CLX_IPV4_T),
    ('ipv6_addr', CLX_IPV6_T),
    ('check_threshold', BOOL_T),
    ('udp_dp', UI32_T),
    ('v6_nhdr', UI32_T),
    ('opq_id', UI32_T),
    ('dev_id', UI32_T),
    ('dpp_hdr', CLX_DTEL_DPP_HDR_T),
]

CLX_DTEL_DPP_T = struct_CLX_DTEL_DPP_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 87

enum_anon_114 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_HOP_LIM_NODE_ID = (1 << 15)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_IF_ID = (1 << 14)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_TS_SEC = (1 << 13)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_TS_NSEC = (1 << 12)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_TRANS_DELAY = (1 << 11)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_APP_DATA = (1 << 10)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_QUEUE_DEPTH = (1 << 9)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_OPACK_INFO = (1 << 8)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_HOP_LIM_NODE_ID_WIDE = (1 << 7)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_IF_ID_WIDE = (1 << 6)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_APP_DATA_WIDE = (1 << 5)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_CHKSM = (1 << 4)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

CLX_DTEL_IOAM_TRACE_TYPE_T = enum_anon_114# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 105

enum_anon_115 = c_int# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 119

CLX_DTEL_TYPE_NONE = 0# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 119

CLX_DTEL_TYPE_IOAM = (CLX_DTEL_TYPE_NONE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 119

CLX_DTEL_TYPE_IOAM_TRANSIT = (CLX_DTEL_TYPE_IOAM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 119

CLX_DTEL_TYPE_DPP = (CLX_DTEL_TYPE_IOAM_TRANSIT + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 119

CLX_DTEL_TYPE_IFA_LIVE_MODE = (CLX_DTEL_TYPE_DPP + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 119

CLX_DTEL_TYPE_IFA_SAMPLE_MODE = (CLX_DTEL_TYPE_IFA_LIVE_MODE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 119

CLX_DTEL_TYPE_IFA_TRANSIT = (CLX_DTEL_TYPE_IFA_SAMPLE_MODE + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 119

CLX_DTEL_TYPE_IFA_TERM = (CLX_DTEL_TYPE_IFA_TRANSIT + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 119

CLX_DTEL_TYPE_LAST = (CLX_DTEL_TYPE_IFA_TERM + 1)# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 119

CLX_DTEL_TYPE_T = enum_anon_115# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 119

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 136
class struct_CLX_DTEL_CFG_S(Structure):
    pass

struct_CLX_DTEL_CFG_S.__slots__ = [
    'ifa_hdr',
    'type',
    'ioam_opt_header',
    'ioam_node_len',
    'ioam_node_id',
    'ioam_max_len',
    'opq_id',
    'dev_id',
    'udp_dp',
    'ifa_tid',
    'ifa_user_defined_0',
    'ifa_user_defined_1',
    'sampling_rate',
]
struct_CLX_DTEL_CFG_S._fields_ = [
    ('ifa_hdr', CLX_DTEL_DPP_HDR_T),
    ('type', CLX_DTEL_TYPE_T),
    ('ioam_opt_header', UI32_T),
    ('ioam_node_len', UI32_T),
    ('ioam_node_id', UI32_T),
    ('ioam_max_len', UI32_T),
    ('opq_id', UI32_T),
    ('dev_id', UI32_T),
    ('udp_dp', UI32_T),
    ('ifa_tid', UI32_T),
    ('ifa_user_defined_0', UI32_T),
    ('ifa_user_defined_1', UI32_T),
    ('sampling_rate', UI32_T),
]

CLX_DTEL_CFG_T = struct_CLX_DTEL_CFG_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 136

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 159
if _libs["libsai.so"].has("clx_dtel_setProfile", "cdecl"):
    clx_dtel_setProfile = _libs["libsai.so"].get("clx_dtel_setProfile", "cdecl")
    clx_dtel_setProfile.argtypes = [UI32_T, UI32_T, POINTER(CLX_DTEL_CFG_T)]
    clx_dtel_setProfile.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 183
if _libs["libsai.so"].has("clx_dtel_getProfile", "cdecl"):
    clx_dtel_getProfile = _libs["libsai.so"].get("clx_dtel_getProfile", "cdecl")
    clx_dtel_getProfile.argtypes = [UI32_T, UI32_T, POINTER(CLX_DTEL_CFG_T)]
    clx_dtel_getProfile.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 208
if _libs["libsai.so"].has("clx_dtel_setDppLoopback", "cdecl"):
    clx_dtel_setDppLoopback = _libs["libsai.so"].get("clx_dtel_setDppLoopback", "cdecl")
    clx_dtel_setDppLoopback.argtypes = [UI32_T, POINTER(CLX_DTEL_DPP_T)]
    clx_dtel_setDppLoopback.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 230
if _libs["libsai.so"].has("clx_dtel_getDppLoopback", "cdecl"):
    clx_dtel_getDppLoopback = _libs["libsai.so"].get("clx_dtel_getDppLoopback", "cdecl")
    clx_dtel_getDppLoopback.argtypes = [UI32_T, POINTER(CLX_DTEL_DPP_T)]
    clx_dtel_getDppLoopback.restype = CLX_ERROR_NO_T

enum_CLX_MODULE_E = c_int# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_IFMAP = 0# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_VLAN = (CLX_MODULE_IFMAP + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_PORT = (CLX_MODULE_VLAN + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_IFMON = (CLX_MODULE_PORT + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_L2 = (CLX_MODULE_IFMON + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_STP = (CLX_MODULE_L2 + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_LAG = (CLX_MODULE_STP + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_MIR = (CLX_MODULE_LAG + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_L3 = (CLX_MODULE_MIR + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_L3T = (CLX_MODULE_L3 + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_SWC = (CLX_MODULE_L3T + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_QOS = (CLX_MODULE_SWC + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_METER = (CLX_MODULE_QOS + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_PKT = (CLX_MODULE_METER + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_ACL = (CLX_MODULE_PKT + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_STAT = (CLX_MODULE_ACL + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_SEC = (CLX_MODULE_STAT + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_SFLOW = (CLX_MODULE_SEC + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_TM = (CLX_MODULE_SFLOW + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_VM = (CLX_MODULE_TM + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_FCOE = (CLX_MODULE_VM + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_TRILL = (CLX_MODULE_FCOE + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_SDN = (CLX_MODULE_TRILL + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_DIAG = (CLX_MODULE_SDN + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_CLI = (CLX_MODULE_DIAG + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_LOG = (CLX_MODULE_CLI + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_OSAL = (CLX_MODULE_LOG + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_DCC = (CLX_MODULE_OSAL + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_AML = (CLX_MODULE_DCC + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_HAL = (CLX_MODULE_AML + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_PHY = (CLX_MODULE_HAL + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_INIT = (CLX_MODULE_PHY + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_CMLIB = (CLX_MODULE_INIT + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_NV = (CLX_MODULE_CMLIB + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_MPLS = (CLX_MODULE_NV + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_SFC = (CLX_MODULE_MPLS + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_CHIP = (CLX_MODULE_SFC + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_DCC_CH = (CLX_MODULE_CHIP + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_MISC = (CLX_MODULE_DCC_CH + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_STK = (CLX_MODULE_MISC + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_PPPOE = (CLX_MODULE_STK + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_DTEL = (CLX_MODULE_PPPOE + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_LAST = (CLX_MODULE_DTEL + 1)# ./clx_system/clx_sdk/include/clx_module.h: 102

CLX_MODULE_T = enum_CLX_MODULE_E# ./clx_system/clx_sdk/include/clx_module.h: 102

# ./clx_system/clx_sdk/include/clx_module.h: 128
if _libs["libsai.so"].has("clx_module_getModuleName", "cdecl"):
    clx_module_getModuleName = _libs["libsai.so"].get("clx_module_getModuleName", "cdecl")
    clx_module_getModuleName.argtypes = [UI32_T]
    clx_module_getModuleName.restype = POINTER(C8_T)

enum_anon_116 = c_int# ./clx_system/clx_sdk/include/clx_ifmon.h: 67

CLX_IFMON_MODE_INTR = 0# ./clx_system/clx_sdk/include/clx_ifmon.h: 67

CLX_IFMON_MODE_POLL = (CLX_IFMON_MODE_INTR + 1)# ./clx_system/clx_sdk/include/clx_ifmon.h: 67

CLX_IFMON_MODE_LAST = (CLX_IFMON_MODE_POLL + 1)# ./clx_system/clx_sdk/include/clx_ifmon.h: 67

CLX_IFMON_MODE_T = enum_anon_116# ./clx_system/clx_sdk/include/clx_ifmon.h: 67

CLX_IFMON_NOTIFY_FUNC_T = CFUNCTYPE(UNCHECKED(None), UI32_T, UI32_T, UI32_T, POINTER(None))# ./clx_system/clx_sdk/include/clx_ifmon.h: 69

# ./clx_system/clx_sdk/include/clx_ifmon.h: 97
if _libs["libsai.so"].has("clx_ifmon_getMode", "cdecl"):
    clx_ifmon_getMode = _libs["libsai.so"].get("clx_ifmon_getMode", "cdecl")
    clx_ifmon_getMode.argtypes = [UI32_T, POINTER(CLX_IFMON_MODE_T), POINTER(CLX_PORT_BITMAP_T), POINTER(UI32_T)]
    clx_ifmon_getMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_ifmon.h: 123
if _libs["libsai.so"].has("clx_ifmon_setMode", "cdecl"):
    clx_ifmon_setMode = _libs["libsai.so"].get("clx_ifmon_setMode", "cdecl")
    clx_ifmon_setMode.argtypes = [UI32_T, CLX_IFMON_MODE_T, CLX_PORT_BITMAP_T, UI32_T]
    clx_ifmon_setMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_ifmon.h: 145
if _libs["libsai.so"].has("clx_ifmon_register", "cdecl"):
    clx_ifmon_register = _libs["libsai.so"].get("clx_ifmon_register", "cdecl")
    clx_ifmon_register.argtypes = [UI32_T, CLX_IFMON_NOTIFY_FUNC_T, POINTER(None)]
    clx_ifmon_register.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_ifmon.h: 166
if _libs["libsai.so"].has("clx_ifmon_deregister", "cdecl"):
    clx_ifmon_deregister = _libs["libsai.so"].get("clx_ifmon_deregister", "cdecl")
    clx_ifmon_deregister.argtypes = [UI32_T, CLX_IFMON_NOTIFY_FUNC_T, POINTER(None)]
    clx_ifmon_deregister.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_netif.h: 63
class struct_anon_117(Structure):
    pass

struct_anon_117.__slots__ = [
    'tx_pkt',
    'tx_queue_full',
    'tx_error',
    'rx_pkt',
]
struct_anon_117._fields_ = [
    ('tx_pkt', UI32_T),
    ('tx_queue_full', UI32_T),
    ('tx_error', UI32_T),
    ('rx_pkt', UI32_T),
]

CLX_NETIF_INTF_CNT_T = struct_anon_117# ./clx_system/clx_sdk/include/clx_netif.h: 63

# ./clx_system/clx_sdk/include/clx_netif.h: 78
class struct_anon_118(Structure):
    pass

struct_anon_118.__slots__ = [
    'id',
    'name',
    'port',
    'mac',
    'flags',
]
struct_anon_118._fields_ = [
    ('id', UI32_T),
    ('name', C8_T * int(16)),
    ('port', CLX_PORT_T),
    ('mac', CLX_MAC_T),
    ('flags', UI32_T),
]

CLX_NETIF_INTF_T = struct_anon_118# ./clx_system/clx_sdk/include/clx_netif.h: 78

# ./clx_system/clx_sdk/include/clx_netif.h: 86
class struct_anon_119(Structure):
    pass

struct_anon_119.__slots__ = [
    'name',
    'mc_group_name',
]
struct_anon_119._fields_ = [
    ('name', C8_T * int(16)),
    ('mc_group_name', C8_T * int(16)),
]

CLX_NETIF_RX_DST_NETLINK_T = struct_anon_119# ./clx_system/clx_sdk/include/clx_netif.h: 86

enum_anon_120 = c_int# ./clx_system/clx_sdk/include/clx_netif.h: 96

CLX_NETIF_RX_DST_SDK = 0# ./clx_system/clx_sdk/include/clx_netif.h: 96

CLX_NETIF_RX_DST_NETLINK = (CLX_NETIF_RX_DST_SDK + 1)# ./clx_system/clx_sdk/include/clx_netif.h: 96

CLX_NETIF_RX_DST_LAST = (CLX_NETIF_RX_DST_NETLINK + 1)# ./clx_system/clx_sdk/include/clx_netif.h: 96

CLX_NETIF_RX_DST_TYPE_T = enum_anon_120# ./clx_system/clx_sdk/include/clx_netif.h: 96

# ./clx_system/clx_sdk/include/clx_netif.h: 126
class struct_anon_121(Structure):
    pass

struct_anon_121.__slots__ = [
    'id',
    'name',
    'priority',
    'port',
    'reason_bitmap',
    'pattern',
    'mask',
    'offset',
    'flags',
    'dst_type',
    'netlink',
]
struct_anon_121._fields_ = [
    ('id', UI32_T),
    ('name', C8_T * int(16)),
    ('priority', UI32_T),
    ('port', CLX_PORT_T),
    ('reason_bitmap', CLX_PKT_RX_REASON_BITMAP_T),
    ('pattern', (UI8_T * int(8)) * int(4)),
    ('mask', (UI8_T * int(8)) * int(4)),
    ('offset', UI32_T * int(4)),
    ('flags', UI32_T),
    ('dst_type', CLX_NETIF_RX_DST_TYPE_T),
    ('netlink', CLX_NETIF_RX_DST_NETLINK_T),
]

CLX_NETIF_PROFILE_T = struct_anon_121# ./clx_system/clx_sdk/include/clx_netif.h: 126

# ./clx_system/clx_sdk/include/clx_netif.h: 147
if _libs["libsai.so"].has("clx_netif_createIntf", "cdecl"):
    clx_netif_createIntf = _libs["libsai.so"].get("clx_netif_createIntf", "cdecl")
    clx_netif_createIntf.argtypes = [UI32_T, POINTER(CLX_NETIF_INTF_T), POINTER(UI32_T)]
    clx_netif_createIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_netif.h: 170
if _libs["libsai.so"].has("clx_netif_destroyIntf", "cdecl"):
    clx_netif_destroyIntf = _libs["libsai.so"].get("clx_netif_destroyIntf", "cdecl")
    clx_netif_destroyIntf.argtypes = [UI32_T, UI32_T]
    clx_netif_destroyIntf.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_netif.h: 192
if _libs["libsai.so"].has("clx_netif_createProfile", "cdecl"):
    clx_netif_createProfile = _libs["libsai.so"].get("clx_netif_createProfile", "cdecl")
    clx_netif_createProfile.argtypes = [UI32_T, POINTER(CLX_NETIF_PROFILE_T), POINTER(UI32_T)]
    clx_netif_createProfile.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_netif.h: 214
if _libs["libsai.so"].has("clx_netif_destroyProfile", "cdecl"):
    clx_netif_destroyProfile = _libs["libsai.so"].get("clx_netif_destroyProfile", "cdecl")
    clx_netif_destroyProfile.argtypes = [UI32_T, UI32_T]
    clx_netif_destroyProfile.restype = CLX_ERROR_NO_T

enum_anon_122 = c_int# ./clx_system/clx_sdk/include/clx_netif.h: 229

CLX_NETIF_INTF_PROPERTY_IGR_SAMPLING_RATE = 0# ./clx_system/clx_sdk/include/clx_netif.h: 229

CLX_NETIF_INTF_PROPERTY_EGR_SAMPLING_RATE = (CLX_NETIF_INTF_PROPERTY_IGR_SAMPLING_RATE + 1)# ./clx_system/clx_sdk/include/clx_netif.h: 229

CLX_NETIF_INTF_PROPERTY_LAST = (CLX_NETIF_INTF_PROPERTY_EGR_SAMPLING_RATE + 1)# ./clx_system/clx_sdk/include/clx_netif.h: 229

CLX_NETIF_INTF_PROPERTY_T = enum_anon_122# ./clx_system/clx_sdk/include/clx_netif.h: 229

# ./clx_system/clx_sdk/include/clx_netif.h: 235
class struct_anon_123(Structure):
    pass

struct_anon_123.__slots__ = [
    'name',
]
struct_anon_123._fields_ = [
    ('name', C8_T * int(16)),
]

CLX_NETIF_NETLINK_MC_GROUP_T = struct_anon_123# ./clx_system/clx_sdk/include/clx_netif.h: 235

# ./clx_system/clx_sdk/include/clx_netif.h: 244
class struct_anon_124(Structure):
    pass

struct_anon_124.__slots__ = [
    'id',
    'name',
    'mc_group',
    'mc_group_num',
]
struct_anon_124._fields_ = [
    ('id', UI32_T),
    ('name', C8_T * int(16)),
    ('mc_group', CLX_NETIF_NETLINK_MC_GROUP_T * int(32)),
    ('mc_group_num', UI32_T),
]

CLX_NETIF_NETLINK_T = struct_anon_124# ./clx_system/clx_sdk/include/clx_netif.h: 244

# ./clx_system/clx_sdk/include/clx_netif.h: 247
if _libs["libsai.so"].has("clx_netif_setIntfProperty", "cdecl"):
    clx_netif_setIntfProperty = _libs["libsai.so"].get("clx_netif_setIntfProperty", "cdecl")
    clx_netif_setIntfProperty.argtypes = [UI32_T, UI32_T, CLX_NETIF_INTF_PROPERTY_T, UI32_T, UI32_T]
    clx_netif_setIntfProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_netif.h: 255
if _libs["libsai.so"].has("clx_netif_getIntfProperty", "cdecl"):
    clx_netif_getIntfProperty = _libs["libsai.so"].get("clx_netif_getIntfProperty", "cdecl")
    clx_netif_getIntfProperty.argtypes = [UI32_T, UI32_T, CLX_NETIF_INTF_PROPERTY_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_netif_getIntfProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_netif.h: 263
if _libs["libsai.so"].has("clx_netif_createNetlink", "cdecl"):
    clx_netif_createNetlink = _libs["libsai.so"].get("clx_netif_createNetlink", "cdecl")
    clx_netif_createNetlink.argtypes = [UI32_T, POINTER(CLX_NETIF_NETLINK_T), POINTER(UI32_T)]
    clx_netif_createNetlink.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_netif.h: 269
if _libs["libsai.so"].has("clx_netif_destroyNetlink", "cdecl"):
    clx_netif_destroyNetlink = _libs["libsai.so"].get("clx_netif_destroyNetlink", "cdecl")
    clx_netif_destroyNetlink.argtypes = [UI32_T, UI32_T]
    clx_netif_destroyNetlink.restype = CLX_ERROR_NO_T

enum_anon_125 = c_int# ./clx_system/clx_sdk/include/clx_sec.h: 70

CLX_SEC_DOS_ACTION_DROP = 0# ./clx_system/clx_sdk/include/clx_sec.h: 70

CLX_SEC_DOS_ACTION_DROP_COPY2CPU = (CLX_SEC_DOS_ACTION_DROP + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 70

CLX_SEC_DOS_ACTION_NONE = (CLX_SEC_DOS_ACTION_DROP_COPY2CPU + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 70

CLX_SEC_DOS_ACTION_LAST = (CLX_SEC_DOS_ACTION_NONE + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 70

CLX_SEC_DOS_ACTION_T = enum_anon_125# ./clx_system/clx_sdk/include/clx_sec.h: 70

enum_anon_126 = c_int# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_MAC_DA_EQ_SA = 0# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_MAC_SA_INVALID = (CLX_SEC_DOS_CHECK_ITEM_MAC_DA_EQ_SA + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_MAC_ALL_ZEROS = (CLX_SEC_DOS_CHECK_ITEM_MAC_SA_INVALID + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_LEN_ENCAP_ERR = (CLX_SEC_DOS_CHECK_ITEM_MAC_ALL_ZEROS + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_MARTIAN_ADDR = (CLX_SEC_DOS_CHECK_ITEM_LEN_ENCAP_ERR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_LOOPBACK_ADDR = (CLX_SEC_DOS_CHECK_ITEM_IPV4_MARTIAN_ADDR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_CLASS_E_ADDR = (CLX_SEC_DOS_CHECK_ITEM_IPV4_LOOPBACK_ADDR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_MARTIAN_ADDR = (CLX_SEC_DOS_CHECK_ITEM_IPV4_CLASS_E_ADDR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_TCP_NULL_SCAN = (CLX_SEC_DOS_CHECK_ITEM_IPV6_MARTIAN_ADDR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_TCP_XMAS_SCAN = (CLX_SEC_DOS_CHECK_ITEM_TCP_NULL_SCAN + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_TCP_FIN_SCAN = (CLX_SEC_DOS_CHECK_ITEM_TCP_XMAS_SCAN + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_TCP_SYN_FIN_SCAN = (CLX_SEC_DOS_CHECK_ITEM_TCP_FIN_SCAN + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_FRAG_ICMP = (CLX_SEC_DOS_CHECK_ITEM_TCP_SYN_FIN_SCAN + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_FRAG_ICMP = (CLX_SEC_DOS_CHECK_ITEM_IPV4_FRAG_ICMP + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_BROADCAST_ICMP = (CLX_SEC_DOS_CHECK_ITEM_IPV6_FRAG_ICMP + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_MULTICAST_ICMP = (CLX_SEC_DOS_CHECK_ITEM_IPV4_BROADCAST_ICMP + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_ICMP_SIZE_EN = (CLX_SEC_DOS_CHECK_ITEM_IPV6_MULTICAST_ICMP + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_ICMP_SIZE_EN = (CLX_SEC_DOS_CHECK_ITEM_IPV4_ICMP_SIZE_EN + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_DIP_EQ_SIP = (CLX_SEC_DOS_CHECK_ITEM_IPV6_ICMP_SIZE_EN + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_DPORT_EQ_SPORT = (CLX_SEC_DOS_CHECK_ITEM_DIP_EQ_SIP + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_UDP_FRAGGLE = (CLX_SEC_DOS_CHECK_ITEM_DPORT_EQ_SPORT + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_UDP_SNORK = (CLX_SEC_DOS_CHECK_ITEM_UDP_FRAGGLE + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_UDP_BOMB = (CLX_SEC_DOS_CHECK_ITEM_UDP_SNORK + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_TCP_TINY_FRAG_EN = (CLX_SEC_DOS_CHECK_ITEM_UDP_BOMB + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_TCP_HDR_SIZE_EN = (CLX_SEC_DOS_CHECK_ITEM_TCP_TINY_FRAG_EN + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_FRAG_SIZE_EN = (CLX_SEC_DOS_CHECK_ITEM_TCP_HDR_SIZE_EN + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_ROUTING_TYPE_0 = (CLX_SEC_DOS_CHECK_ITEM_IPV6_FRAG_SIZE_EN + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_FRG_ERR = (CLX_SEC_DOS_CHECK_ITEM_IPV6_ROUTING_TYPE_0 + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_FRG_OFF_ERR = (CLX_SEC_DOS_CHECK_ITEM_IPV4_FRG_ERR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_FRG_OFF_ERR = (CLX_SEC_DOS_CHECK_ITEM_IPV4_FRG_OFF_ERR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_MIN_LEN_ERR = (CLX_SEC_DOS_CHECK_ITEM_IPV6_FRG_OFF_ERR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_MIN_LEN_ERR = (CLX_SEC_DOS_CHECK_ITEM_IPV4_MIN_LEN_ERR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_HDR_LEN_ERR = (CLX_SEC_DOS_CHECK_ITEM_IPV6_MIN_LEN_ERR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_NXT_HDR_MAX_ERR = (CLX_SEC_DOS_CHECK_ITEM_IPV4_HDR_LEN_ERR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_PT_MAX_ERR = (CLX_SEC_DOS_CHECK_ITEM_IPV6_NXT_HDR_MAX_ERR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_SCTP_MIN_SZ = (CLX_SEC_DOS_CHECK_ITEM_IPV4_PT_MAX_ERR + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_SCTP_MIN_SZ = (CLX_SEC_DOS_CHECK_ITEM_IPV4_SCTP_MIN_SZ + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_SCTP_TINY_FRG = (CLX_SEC_DOS_CHECK_ITEM_IPV6_SCTP_MIN_SZ + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_SCTP_TINY_FRG = (CLX_SEC_DOS_CHECK_ITEM_IPV4_SCTP_TINY_FRG + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_UDP_MIN_SZ = (CLX_SEC_DOS_CHECK_ITEM_IPV6_SCTP_TINY_FRG + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_UDP_MIN_SZ = (CLX_SEC_DOS_CHECK_ITEM_IPV4_UDP_MIN_SZ + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV4_UDP_TINY_FRG = (CLX_SEC_DOS_CHECK_ITEM_IPV6_UDP_MIN_SZ + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_IPV6_UDP_TINY_FRG = (CLX_SEC_DOS_CHECK_ITEM_IPV4_UDP_TINY_FRG + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_SUPP_UL2UL = (CLX_SEC_DOS_CHECK_ITEM_IPV6_UDP_TINY_FRG + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_LAND_ATTACK_UDP = (CLX_SEC_DOS_CHECK_ITEM_SUPP_UL2UL + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_LAND_ATTACK_TCP = (CLX_SEC_DOS_CHECK_ITEM_LAND_ATTACK_UDP + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_LAST = (CLX_SEC_DOS_CHECK_ITEM_LAND_ATTACK_TCP + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 121

CLX_SEC_DOS_CHECK_ITEM_T = enum_anon_126# ./clx_system/clx_sdk/include/clx_sec.h: 121

enum_anon_127 = c_int# ./clx_system/clx_sdk/include/clx_sec.h: 132

CLX_SEC_STORM_CTRL_TYPE_BC = 0# ./clx_system/clx_sdk/include/clx_sec.h: 132

CLX_SEC_STORM_CTRL_TYPE_UUC = (CLX_SEC_STORM_CTRL_TYPE_BC + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 132

CLX_SEC_STORM_CTRL_TYPE_UMC = (CLX_SEC_STORM_CTRL_TYPE_UUC + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 132

CLX_SEC_STORM_CTRL_TYPE_L2UMC = 2# ./clx_system/clx_sdk/include/clx_sec.h: 132

CLX_SEC_STORM_CTRL_TYPE_L2MC = (CLX_SEC_STORM_CTRL_TYPE_L2UMC + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 132

CLX_SEC_STORM_CTRL_TYPE_L3UMC = (CLX_SEC_STORM_CTRL_TYPE_L2MC + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 132

CLX_SEC_STORM_CTRL_TYPE_L3MC = (CLX_SEC_STORM_CTRL_TYPE_L3UMC + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 132

CLX_SEC_STORM_CTRL_TYPE_LAST = (CLX_SEC_STORM_CTRL_TYPE_L3MC + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 132

CLX_SEC_STORM_CTRL_TYPE_T = enum_anon_127# ./clx_system/clx_sdk/include/clx_sec.h: 132

enum_anon_128 = c_int# ./clx_system/clx_sdk/include/clx_sec.h: 142

CLX_SEC_SG_FAIL_ACTION_COPY2CPU = 0# ./clx_system/clx_sdk/include/clx_sec.h: 142

CLX_SEC_SG_FAIL_ACTION_DROP = (CLX_SEC_SG_FAIL_ACTION_COPY2CPU + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 142

CLX_SEC_SG_FAIL_ACTION_NONE = (CLX_SEC_SG_FAIL_ACTION_DROP + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 142

CLX_SEC_SG_FAIL_ACTION_LAST = (CLX_SEC_SG_FAIL_ACTION_NONE + 1)# ./clx_system/clx_sdk/include/clx_sec.h: 142

CLX_SEC_SG_FAIL_ACTION_T = enum_anon_128# ./clx_system/clx_sdk/include/clx_sec.h: 142

CLX_SEC_DOS_CHECK_ITEM_BITMAP_T = UI32_T * int((((CLX_SEC_DOS_CHECK_ITEM_LAST - 1) / 32) + 1))# ./clx_system/clx_sdk/include/clx_sec.h: 148

# ./clx_system/clx_sdk/include/clx_sec.h: 161
class struct_CLX_SEC_DOS_PORT_CONFIG_S(Structure):
    pass

struct_CLX_SEC_DOS_PORT_CONFIG_S.__slots__ = [
    'dos_check_item',
    'dos_action',
]
struct_CLX_SEC_DOS_PORT_CONFIG_S._fields_ = [
    ('dos_check_item', CLX_SEC_DOS_CHECK_ITEM_BITMAP_T),
    ('dos_action', CLX_SEC_DOS_ACTION_T),
]

CLX_SEC_DOS_PORT_CONFIG_T = struct_CLX_SEC_DOS_PORT_CONFIG_S# ./clx_system/clx_sdk/include/clx_sec.h: 161

# ./clx_system/clx_sdk/include/clx_sec.h: 177
class struct_CLX_SEC_DOS_CONFIG_S(Structure):
    pass

struct_CLX_SEC_DOS_CONFIG_S.__slots__ = [
    'max_icmpv4_size',
    'max_icmpv6_size',
    'min_ipv6_frag_size',
    'min_tcp_size',
    'min_tcp_frg_off',
    'min_sctp_size',
    'min_sctp_frg_off',
    'min_udp_size',
    'min_udp_frg_off',
    'max_l4_prot',
    'dos_action',
]
struct_CLX_SEC_DOS_CONFIG_S._fields_ = [
    ('max_icmpv4_size', UI16_T),
    ('max_icmpv6_size', UI16_T),
    ('min_ipv6_frag_size', UI16_T),
    ('min_tcp_size', UI16_T),
    ('min_tcp_frg_off', UI16_T),
    ('min_sctp_size', UI16_T),
    ('min_sctp_frg_off', UI16_T),
    ('min_udp_size', UI16_T),
    ('min_udp_frg_off', UI16_T),
    ('max_l4_prot', UI16_T),
    ('dos_action', CLX_SEC_DOS_ACTION_T * int(CLX_SEC_DOS_CHECK_ITEM_LAST)),
]

CLX_SEC_DOS_CONFIG_T = struct_CLX_SEC_DOS_CONFIG_S# ./clx_system/clx_sdk/include/clx_sec.h: 177

# ./clx_system/clx_sdk/include/clx_sec.h: 192
class struct_CLX_SEC_STORM_CTRL_ENTRY_S(Structure):
    pass

struct_CLX_SEC_STORM_CTRL_ENTRY_S.__slots__ = [
    'sc_rate',
    'flags',
]
struct_CLX_SEC_STORM_CTRL_ENTRY_S._fields_ = [
    ('sc_rate', UI32_T),
    ('flags', UI32_T),
]

CLX_SEC_STORM_CTRL_ENTRY_T = struct_CLX_SEC_STORM_CTRL_ENTRY_S# ./clx_system/clx_sdk/include/clx_sec.h: 192

# ./clx_system/clx_sdk/include/clx_sec.h: 214
class struct_CLX_SEC_STORM_CTRL_S(Structure):
    pass

struct_CLX_SEC_STORM_CTRL_S.__slots__ = [
    'sc_entry',
    'flags',
]
struct_CLX_SEC_STORM_CTRL_S._fields_ = [
    ('sc_entry', CLX_SEC_STORM_CTRL_ENTRY_T * int(6)),
    ('flags', UI32_T),
]

CLX_SEC_STORM_CTRL_T = struct_CLX_SEC_STORM_CTRL_S# ./clx_system/clx_sdk/include/clx_sec.h: 214

# ./clx_system/clx_sdk/include/clx_sec.h: 220
class struct_CLX_SEC_STORM_CTRL_CNT_S(Structure):
    pass

struct_CLX_SEC_STORM_CTRL_CNT_S.__slots__ = [
    'fwd_b_cnt',
    'fwd_p_cnt',
    'drop_p_cnt',
]
struct_CLX_SEC_STORM_CTRL_CNT_S._fields_ = [
    ('fwd_b_cnt', UI64_T),
    ('fwd_p_cnt', UI64_T),
    ('drop_p_cnt', UI64_T),
]

CLX_SEC_STORM_CTRL_CNT_T = struct_CLX_SEC_STORM_CTRL_CNT_S# ./clx_system/clx_sdk/include/clx_sec.h: 220

# ./clx_system/clx_sdk/include/clx_sec.h: 239
class struct_CLX_SEC_SG_PORT_CONFIG_S(Structure):
    pass

struct_CLX_SEC_SG_PORT_CONFIG_S.__slots__ = [
    'ipv4_miss_action',
    'ipv6_miss_action',
    'fcoe_miss_action',
    'flags',
]
struct_CLX_SEC_SG_PORT_CONFIG_S._fields_ = [
    ('ipv4_miss_action', CLX_SEC_SG_FAIL_ACTION_T),
    ('ipv6_miss_action', CLX_SEC_SG_FAIL_ACTION_T),
    ('fcoe_miss_action', CLX_SEC_SG_FAIL_ACTION_T),
    ('flags', UI32_T),
]

CLX_SEC_SG_PROPERTY_T = struct_CLX_SEC_SG_PORT_CONFIG_S# ./clx_system/clx_sdk/include/clx_sec.h: 239

# ./clx_system/clx_sdk/include/clx_sec.h: 244
class union_anon_129(Union):
    pass

union_anon_129.__slots__ = [
    'ip_addr',
    'fcoe_sid',
]
union_anon_129._fields_ = [
    ('ip_addr', CLX_IP_ADDR_T),
    ('fcoe_sid', UI32_T),
]

# ./clx_system/clx_sdk/include/clx_sec.h: 264
class struct_CLX_SEC_SG_ENTRY_S(Structure):
    pass

struct_CLX_SEC_SG_ENTRY_S.__slots__ = [
    'vrf_id',
    'unnamed_1',
    'mac',
    'bdid',
    'port',
    'seg0',
    'seg1',
    'pppoe_ses_id',
    'flags',
]
struct_CLX_SEC_SG_ENTRY_S._anonymous_ = [
    'unnamed_1',
]
struct_CLX_SEC_SG_ENTRY_S._fields_ = [
    ('vrf_id', UI32_T),
    ('unnamed_1', union_anon_129),
    ('mac', CLX_MAC_T),
    ('bdid', CLX_BRIDGE_DOMAIN_T),
    ('port', CLX_PORT_T),
    ('seg0', UI32_T),
    ('seg1', UI32_T),
    ('pppoe_ses_id', UI32_T),
    ('flags', UI32_T),
]

CLX_SEC_SG_ENTRY_T = struct_CLX_SEC_SG_ENTRY_S# ./clx_system/clx_sdk/include/clx_sec.h: 264

# ./clx_system/clx_sdk/include/clx_sec.h: 282
if _libs["libsai.so"].has("clx_sec_setDosPortConfig", "cdecl"):
    clx_sec_setDosPortConfig = _libs["libsai.so"].get("clx_sec_setDosPortConfig", "cdecl")
    clx_sec_setDosPortConfig.argtypes = [UI32_T, UI32_T, POINTER(CLX_SEC_DOS_PORT_CONFIG_T)]
    clx_sec_setDosPortConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 302
if _libs["libsai.so"].has("clx_sec_getDosPortConfig", "cdecl"):
    clx_sec_getDosPortConfig = _libs["libsai.so"].get("clx_sec_getDosPortConfig", "cdecl")
    clx_sec_getDosPortConfig.argtypes = [UI32_T, UI32_T, POINTER(CLX_SEC_DOS_PORT_CONFIG_T)]
    clx_sec_getDosPortConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 322
if _libs["libsai.so"].has("clx_sec_setDosConfig", "cdecl"):
    clx_sec_setDosConfig = _libs["libsai.so"].get("clx_sec_setDosConfig", "cdecl")
    clx_sec_setDosConfig.argtypes = [UI32_T, POINTER(CLX_SEC_DOS_CONFIG_T)]
    clx_sec_setDosConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 340
if _libs["libsai.so"].has("clx_sec_getDosConfig", "cdecl"):
    clx_sec_getDosConfig = _libs["libsai.so"].get("clx_sec_getDosConfig", "cdecl")
    clx_sec_getDosConfig.argtypes = [UI32_T, POINTER(CLX_SEC_DOS_CONFIG_T)]
    clx_sec_getDosConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 362
if _libs["libsai.so"].has("clx_sec_setStormCtrlProperty", "cdecl"):
    clx_sec_setStormCtrlProperty = _libs["libsai.so"].get("clx_sec_setStormCtrlProperty", "cdecl")
    clx_sec_setStormCtrlProperty.argtypes = [UI32_T, UI32_T, POINTER(CLX_SEC_STORM_CTRL_T)]
    clx_sec_setStormCtrlProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 383
if _libs["libsai.so"].has("clx_sec_getStormCtrlProperty", "cdecl"):
    clx_sec_getStormCtrlProperty = _libs["libsai.so"].get("clx_sec_getStormCtrlProperty", "cdecl")
    clx_sec_getStormCtrlProperty.argtypes = [UI32_T, UI32_T, POINTER(CLX_SEC_STORM_CTRL_T)]
    clx_sec_getStormCtrlProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 406
if _libs["libsai.so"].has("clx_sec_getStormCtrlCnt", "cdecl"):
    clx_sec_getStormCtrlCnt = _libs["libsai.so"].get("clx_sec_getStormCtrlCnt", "cdecl")
    clx_sec_getStormCtrlCnt.argtypes = [UI32_T, UI32_T, CLX_SEC_STORM_CTRL_TYPE_T, POINTER(CLX_SEC_STORM_CTRL_CNT_T)]
    clx_sec_getStormCtrlCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 430
if _libs["libsai.so"].has("clx_sec_setSourceGuardProperty", "cdecl"):
    clx_sec_setSourceGuardProperty = _libs["libsai.so"].get("clx_sec_setSourceGuardProperty", "cdecl")
    clx_sec_setSourceGuardProperty.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_SEC_SG_PROPERTY_T)]
    clx_sec_setSourceGuardProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 451
if _libs["libsai.so"].has("clx_sec_getSourceGuardProperty", "cdecl"):
    clx_sec_getSourceGuardProperty = _libs["libsai.so"].get("clx_sec_getSourceGuardProperty", "cdecl")
    clx_sec_getSourceGuardProperty.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_SEC_SG_PROPERTY_T)]
    clx_sec_getSourceGuardProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 474
if _libs["libsai.so"].has("clx_sec_addSourceGuardEntry", "cdecl"):
    clx_sec_addSourceGuardEntry = _libs["libsai.so"].get("clx_sec_addSourceGuardEntry", "cdecl")
    clx_sec_addSourceGuardEntry.argtypes = [UI32_T, POINTER(CLX_SEC_SG_ENTRY_T)]
    clx_sec_addSourceGuardEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 497
if _libs["libsai.so"].has("clx_sec_delSourceGuardEntry", "cdecl"):
    clx_sec_delSourceGuardEntry = _libs["libsai.so"].get("clx_sec_delSourceGuardEntry", "cdecl")
    clx_sec_delSourceGuardEntry.argtypes = [UI32_T, POINTER(CLX_SEC_SG_ENTRY_T)]
    clx_sec_delSourceGuardEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 518
if _libs["libsai.so"].has("clx_sec_getSourceGuardEntry", "cdecl"):
    clx_sec_getSourceGuardEntry = _libs["libsai.so"].get("clx_sec_getSourceGuardEntry", "cdecl")
    clx_sec_getSourceGuardEntry.argtypes = [UI32_T, POINTER(CLX_SEC_SG_ENTRY_T)]
    clx_sec_getSourceGuardEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 544
if _libs["libsai.so"].has("clx_sec_setEgressPort", "cdecl"):
    clx_sec_setEgressPort = _libs["libsai.so"].get("clx_sec_setEgressPort", "cdecl")
    clx_sec_setEgressPort.argtypes = [UI32_T, UI32_T, CLX_PORT_BITMAP_T]
    clx_sec_setEgressPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sec.h: 566
if _libs["libsai.so"].has("clx_sec_getEgressPort", "cdecl"):
    clx_sec_getEgressPort = _libs["libsai.so"].get("clx_sec_getEgressPort", "cdecl")
    clx_sec_getEgressPort.argtypes = [UI32_T, UI32_T, CLX_PORT_BITMAP_T]
    clx_sec_getEgressPort.restype = CLX_ERROR_NO_T

enum_CLX_STP_PORTSTATE_E = c_int# ./clx_system/clx_sdk/include/clx_stp.h: 73

CLX_STP_PORTSTATE_DISCARD = 0# ./clx_system/clx_sdk/include/clx_stp.h: 73

CLX_STP_PORTSTATE_LEARN = (CLX_STP_PORTSTATE_DISCARD + 1)# ./clx_system/clx_sdk/include/clx_stp.h: 73

CLX_STP_PORTSTATE_FORWARD = (CLX_STP_PORTSTATE_LEARN + 1)# ./clx_system/clx_sdk/include/clx_stp.h: 73

CLX_STP_PORTSTATE_LAST = (CLX_STP_PORTSTATE_FORWARD + 1)# ./clx_system/clx_sdk/include/clx_stp.h: 73

CLX_STP_PORTSTATE_T = enum_CLX_STP_PORTSTATE_E# ./clx_system/clx_sdk/include/clx_stp.h: 73

# ./clx_system/clx_sdk/include/clx_stp.h: 100
if _libs["libsai.so"].has("clx_stp_createStg", "cdecl"):
    clx_stp_createStg = _libs["libsai.so"].get("clx_stp_createStg", "cdecl")
    clx_stp_createStg.argtypes = [UI32_T, UI32_T]
    clx_stp_createStg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stp.h: 124
if _libs["libsai.so"].has("clx_stp_destroyStg", "cdecl"):
    clx_stp_destroyStg = _libs["libsai.so"].get("clx_stp_destroyStg", "cdecl")
    clx_stp_destroyStg.argtypes = [UI32_T, UI32_T]
    clx_stp_destroyStg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stp.h: 146
if _libs["libsai.so"].has("clx_stp_setBridgeDomainStg", "cdecl"):
    clx_stp_setBridgeDomainStg = _libs["libsai.so"].get("clx_stp_setBridgeDomainStg", "cdecl")
    clx_stp_setBridgeDomainStg.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, UI32_T]
    clx_stp_setBridgeDomainStg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stp.h: 168
if _libs["libsai.so"].has("clx_stp_getBridgeDomainStg", "cdecl"):
    clx_stp_getBridgeDomainStg = _libs["libsai.so"].get("clx_stp_getBridgeDomainStg", "cdecl")
    clx_stp_getBridgeDomainStg.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(UI32_T)]
    clx_stp_getBridgeDomainStg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stp.h: 192
if _libs["libsai.so"].has("clx_stp_setPortstate", "cdecl"):
    clx_stp_setPortstate = _libs["libsai.so"].get("clx_stp_setPortstate", "cdecl")
    clx_stp_setPortstate.argtypes = [UI32_T, UI32_T, UI32_T, CLX_STP_PORTSTATE_T]
    clx_stp_setPortstate.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stp.h: 216
if _libs["libsai.so"].has("clx_stp_getPortstate", "cdecl"):
    clx_stp_getPortstate = _libs["libsai.so"].get("clx_stp_getPortstate", "cdecl")
    clx_stp_getPortstate.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(CLX_STP_PORTSTATE_T)]
    clx_stp_getPortstate.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stp.h: 239
if _libs["libsai.so"].has("clx_stp_isStgValid", "cdecl"):
    clx_stp_isStgValid = _libs["libsai.so"].get("clx_stp_isStgValid", "cdecl")
    clx_stp_isStgValid.argtypes = [UI32_T, UI32_T]
    clx_stp_isStgValid.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 97
class struct_CLX_L3T_MAC_INFO_S(Structure):
    pass

struct_CLX_L3T_MAC_INFO_S.__slots__ = [
    'port',
    'cvid',
    'cvid_mask',
    'svid',
    'svid_mask',
    'tunnel_mac',
    'tunnel_mac_mask',
    'flags',
    'l3_intf_id',
    'mpls_namespace',
    'l3_mtu_size',
]
struct_CLX_L3T_MAC_INFO_S._fields_ = [
    ('port', CLX_PORT_T),
    ('cvid', CLX_VLAN_T),
    ('cvid_mask', CLX_VLAN_T),
    ('svid', CLX_VLAN_T),
    ('svid_mask', CLX_VLAN_T),
    ('tunnel_mac', CLX_MAC_T),
    ('tunnel_mac_mask', CLX_MAC_T),
    ('flags', UI32_T),
    ('l3_intf_id', UI32_T),
    ('mpls_namespace', UI8_T),
    ('l3_mtu_size', UI16_T),
]

CLX_L3T_MAC_INFO_T = struct_CLX_L3T_MAC_INFO_S# ./clx_system/clx_sdk/include/clx_l3t.h: 97

enum_anon_130 = c_int# ./clx_system/clx_sdk/include/clx_l3t.h: 107

CLX_L3T_ECN_NONE = 0# ./clx_system/clx_sdk/include/clx_l3t.h: 107

CLX_L3T_ECN_1 = (CLX_L3T_ECN_NONE + 1)# ./clx_system/clx_sdk/include/clx_l3t.h: 107

CLX_L3T_ECN_0 = (CLX_L3T_ECN_1 + 1)# ./clx_system/clx_sdk/include/clx_l3t.h: 107

CLX_L3T_ECN_CE = (CLX_L3T_ECN_0 + 1)# ./clx_system/clx_sdk/include/clx_l3t.h: 107

CLX_L3T_ECN_LAST = (CLX_L3T_ECN_CE + 1)# ./clx_system/clx_sdk/include/clx_l3t.h: 107

CLX_L3T_ECN_CODE_T = enum_anon_130# ./clx_system/clx_sdk/include/clx_l3t.h: 107

# ./clx_system/clx_sdk/include/clx_l3t.h: 207
class struct_CLX_L3T_INIT_INFO_S(Structure):
    pass

struct_CLX_L3T_INIT_INFO_S.__slots__ = [
    'key',
    'flags',
    'ipv6_flow_label',
    'phb_to_dscp_profile_id',
    'phb_to_pcp_dei_profile_id',
    'dscp',
    'pcp',
    'dei',
    'ecn',
    'ttl',
    'mir_session_bitmap',
    'group_label',
    'meter_id',
    'cnt_id',
    'dist_cnt_id',
    'l2_mtu_size',
    'sampling_rate',
    'sample_to_mir_session_id',
    'dtel_profile_id',
    'inner_vlan_tag',
]
struct_CLX_L3T_INIT_INFO_S._fields_ = [
    ('key', CLX_TUNNEL_KEY_T),
    ('flags', UI32_T),
    ('ipv6_flow_label', UI32_T),
    ('phb_to_dscp_profile_id', UI32_T),
    ('phb_to_pcp_dei_profile_id', UI32_T),
    ('dscp', UI8_T),
    ('pcp', UI8_T),
    ('dei', UI8_T),
    ('ecn', CLX_L3T_ECN_CODE_T),
    ('ttl', UI8_T),
    ('mir_session_bitmap', UI32_T),
    ('group_label', UI32_T),
    ('meter_id', UI32_T),
    ('cnt_id', UI32_T),
    ('dist_cnt_id', UI32_T),
    ('l2_mtu_size', UI16_T),
    ('sampling_rate', UI32_T),
    ('sample_to_mir_session_id', UI32_T),
    ('dtel_profile_id', UI32_T),
    ('inner_vlan_tag', CLX_PORT_VLAN_TAG_T),
]

CLX_L3T_INIT_INFO_T = struct_CLX_L3T_INIT_INFO_S# ./clx_system/clx_sdk/include/clx_l3t.h: 207

# ./clx_system/clx_sdk/include/clx_l3t.h: 299
class struct_CLX_L3T_TERM_INFO_S(Structure):
    pass

struct_CLX_L3T_TERM_INFO_S.__slots__ = [
    'key',
    'flags',
    'tunnel_term_miss_action',
    'intf_id',
    'default_pcp',
    'default_dei',
    'trust_mode',
    'dscp_to_phb_profile_id',
    'pcp_dei_to_phb_profile_id',
    'mir_session_bitmap',
    'group_label',
    'meter_id',
    'cnt_id',
    'dist_cnt_id',
    'port',
    'sampling_rate',
    'sample_to_mir_session_id',
    'dtel_profile_id',
    'l2_mtu_size',
    'mpls_namespace',
    'inner_vlan_tag',
    'l3_mc_id',
]
struct_CLX_L3T_TERM_INFO_S._fields_ = [
    ('key', CLX_TUNNEL_KEY_T),
    ('flags', UI32_T),
    ('tunnel_term_miss_action', CLX_FWD_ACTION_T),
    ('intf_id', UI32_T),
    ('default_pcp', UI8_T),
    ('default_dei', UI8_T),
    ('trust_mode', CLX_TRUST_MODE_T),
    ('dscp_to_phb_profile_id', UI32_T),
    ('pcp_dei_to_phb_profile_id', UI32_T),
    ('mir_session_bitmap', UI32_T),
    ('group_label', UI32_T),
    ('meter_id', UI32_T),
    ('cnt_id', UI32_T),
    ('dist_cnt_id', UI32_T),
    ('port', CLX_PORT_T),
    ('sampling_rate', UI32_T),
    ('sample_to_mir_session_id', UI32_T),
    ('dtel_profile_id', UI32_T),
    ('l2_mtu_size', UI16_T),
    ('mpls_namespace', UI8_T),
    ('inner_vlan_tag', CLX_PORT_VLAN_TAG_T),
    ('l3_mc_id', UI32_T),
]

CLX_L3T_TERM_INFO_T = struct_CLX_L3T_TERM_INFO_S# ./clx_system/clx_sdk/include/clx_l3t.h: 299

# ./clx_system/clx_sdk/include/clx_l3t.h: 307
class struct_CLX_L3T_NVO3_ROUTE_INFO_S(Structure):
    pass

struct_CLX_L3T_NVO3_ROUTE_INFO_S.__slots__ = [
    'key',
    'output_type',
    'output_id',
]
struct_CLX_L3T_NVO3_ROUTE_INFO_S._fields_ = [
    ('key', CLX_TUNNEL_KEY_T),
    ('output_type', CLX_L3_OUTPUT_TYPE_T),
    ('output_id', UI32_T),
]

CLX_L3T_NVO3_ROUTE_INFO_T = struct_CLX_L3T_NVO3_ROUTE_INFO_S# ./clx_system/clx_sdk/include/clx_l3t.h: 307

enum_anon_131 = c_int# ./clx_system/clx_sdk/include/clx_l3t.h: 315

CLX_L3T_FLEX_TUNNEL_TYPE_GENEVE = 0# ./clx_system/clx_sdk/include/clx_l3t.h: 315

CLX_L3T_FLEX_TUNNEL_TYPE_PIM = (CLX_L3T_FLEX_TUNNEL_TYPE_GENEVE + 1)# ./clx_system/clx_sdk/include/clx_l3t.h: 315

CLX_L3T_FLEX_TUNNEL_TYPE_GTP = (CLX_L3T_FLEX_TUNNEL_TYPE_PIM + 1)# ./clx_system/clx_sdk/include/clx_l3t.h: 315

CLX_L3T_FLEX_TUNNEL_TYPE_LAST = (CLX_L3T_FLEX_TUNNEL_TYPE_GTP + 1)# ./clx_system/clx_sdk/include/clx_l3t.h: 315

CLX_L3T_FLEX_TUNNEL_TYPE_T = enum_anon_131# ./clx_system/clx_sdk/include/clx_l3t.h: 315

CLX_L3T_TUNNEL_MAC_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, UI32_T, POINTER(CLX_L3T_MAC_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l3t.h: 318

CLX_L3T_INIT_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_L3T_INIT_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l3t.h: 325

CLX_L3T_TERM_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_L3T_TERM_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l3t.h: 331

CLX_L3T_NVO3_ROUTE_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_L3T_NVO3_ROUTE_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_l3t.h: 337

CLX_L3T_PORT_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_TUNNEL_KEY_T), CLX_PORT_T, POINTER(None))# ./clx_system/clx_sdk/include/clx_l3t.h: 343

# ./clx_system/clx_sdk/include/clx_l3t.h: 371
if _libs["libsai.so"].has("clx_l3t_setTunneling", "cdecl"):
    clx_l3t_setTunneling = _libs["libsai.so"].get("clx_l3t_setTunneling", "cdecl")
    clx_l3t_setTunneling.argtypes = [UI32_T, UI32_T, BOOL_T]
    clx_l3t_setTunneling.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 393
if _libs["libsai.so"].has("clx_l3t_getTunneling", "cdecl"):
    clx_l3t_getTunneling = _libs["libsai.so"].get("clx_l3t_getTunneling", "cdecl")
    clx_l3t_getTunneling.argtypes = [UI32_T, UI32_T, POINTER(BOOL_T)]
    clx_l3t_getTunneling.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 426
if _libs["libsai.so"].has("clx_l3t_addTunnelMac", "cdecl"):
    clx_l3t_addTunnelMac = _libs["libsai.so"].get("clx_l3t_addTunnelMac", "cdecl")
    clx_l3t_addTunnelMac.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3T_MAC_INFO_T)]
    clx_l3t_addTunnelMac.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 449
if _libs["libsai.so"].has("clx_l3t_delTunnelMac", "cdecl"):
    clx_l3t_delTunnelMac = _libs["libsai.so"].get("clx_l3t_delTunnelMac", "cdecl")
    clx_l3t_delTunnelMac.argtypes = [UI32_T, UI32_T]
    clx_l3t_delTunnelMac.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 471
if _libs["libsai.so"].has("clx_l3t_getTunnelMac", "cdecl"):
    clx_l3t_getTunnelMac = _libs["libsai.so"].get("clx_l3t_getTunnelMac", "cdecl")
    clx_l3t_getTunnelMac.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3T_MAC_INFO_T)]
    clx_l3t_getTunnelMac.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 491
if _libs["libsai.so"].has("clx_l3t_traverseTunnelMac", "cdecl"):
    clx_l3t_traverseTunnelMac = _libs["libsai.so"].get("clx_l3t_traverseTunnelMac", "cdecl")
    clx_l3t_traverseTunnelMac.argtypes = [UI32_T, CLX_L3T_TUNNEL_MAC_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l3t_traverseTunnelMac.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 521
if _libs["libsai.so"].has("clx_l3t_addInit", "cdecl"):
    clx_l3t_addInit = _libs["libsai.so"].get("clx_l3t_addInit", "cdecl")
    clx_l3t_addInit.argtypes = [UI32_T, POINTER(CLX_L3T_INIT_INFO_T)]
    clx_l3t_addInit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 544
if _libs["libsai.so"].has("clx_l3t_delInit", "cdecl"):
    clx_l3t_delInit = _libs["libsai.so"].get("clx_l3t_delInit", "cdecl")
    clx_l3t_delInit.argtypes = [UI32_T, POINTER(CLX_L3T_INIT_INFO_T)]
    clx_l3t_delInit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 566
if _libs["libsai.so"].has("clx_l3t_getInit", "cdecl"):
    clx_l3t_getInit = _libs["libsai.so"].get("clx_l3t_getInit", "cdecl")
    clx_l3t_getInit.argtypes = [UI32_T, POINTER(CLX_L3T_INIT_INFO_T)]
    clx_l3t_getInit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 585
if _libs["libsai.so"].has("clx_l3t_traverseInit", "cdecl"):
    clx_l3t_traverseInit = _libs["libsai.so"].get("clx_l3t_traverseInit", "cdecl")
    clx_l3t_traverseInit.argtypes = [UI32_T, CLX_L3T_INIT_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l3t_traverseInit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 610
if _libs["libsai.so"].has("clx_l3t_addTerm", "cdecl"):
    clx_l3t_addTerm = _libs["libsai.so"].get("clx_l3t_addTerm", "cdecl")
    clx_l3t_addTerm.argtypes = [UI32_T, POINTER(CLX_L3T_TERM_INFO_T)]
    clx_l3t_addTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 634
if _libs["libsai.so"].has("clx_l3t_delTerm", "cdecl"):
    clx_l3t_delTerm = _libs["libsai.so"].get("clx_l3t_delTerm", "cdecl")
    clx_l3t_delTerm.argtypes = [UI32_T, POINTER(CLX_L3T_TERM_INFO_T)]
    clx_l3t_delTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 655
if _libs["libsai.so"].has("clx_l3t_getTerm", "cdecl"):
    clx_l3t_getTerm = _libs["libsai.so"].get("clx_l3t_getTerm", "cdecl")
    clx_l3t_getTerm.argtypes = [UI32_T, POINTER(CLX_L3T_TERM_INFO_T)]
    clx_l3t_getTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 674
if _libs["libsai.so"].has("clx_l3t_traverseTerm", "cdecl"):
    clx_l3t_traverseTerm = _libs["libsai.so"].get("clx_l3t_traverseTerm", "cdecl")
    clx_l3t_traverseTerm.argtypes = [UI32_T, CLX_L3T_TERM_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l3t_traverseTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 698
if _libs["libsai.so"].has("clx_l3t_addNvo3Route", "cdecl"):
    clx_l3t_addNvo3Route = _libs["libsai.so"].get("clx_l3t_addNvo3Route", "cdecl")
    clx_l3t_addNvo3Route.argtypes = [UI32_T, POINTER(CLX_L3T_NVO3_ROUTE_INFO_T)]
    clx_l3t_addNvo3Route.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 719
if _libs["libsai.so"].has("clx_l3t_delNvo3Route", "cdecl"):
    clx_l3t_delNvo3Route = _libs["libsai.so"].get("clx_l3t_delNvo3Route", "cdecl")
    clx_l3t_delNvo3Route.argtypes = [UI32_T, POINTER(CLX_L3T_NVO3_ROUTE_INFO_T)]
    clx_l3t_delNvo3Route.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 741
if _libs["libsai.so"].has("clx_l3t_getNvo3Route", "cdecl"):
    clx_l3t_getNvo3Route = _libs["libsai.so"].get("clx_l3t_getNvo3Route", "cdecl")
    clx_l3t_getNvo3Route.argtypes = [UI32_T, POINTER(CLX_L3T_NVO3_ROUTE_INFO_T)]
    clx_l3t_getNvo3Route.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 760
if _libs["libsai.so"].has("clx_l3t_traverseNvo3Route", "cdecl"):
    clx_l3t_traverseNvo3Route = _libs["libsai.so"].get("clx_l3t_traverseNvo3Route", "cdecl")
    clx_l3t_traverseNvo3Route.argtypes = [UI32_T, CLX_L3T_NVO3_ROUTE_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l3t_traverseNvo3Route.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 779
if _libs["libsai.so"].has("clx_l3t_setUnusedEcnAction", "cdecl"):
    clx_l3t_setUnusedEcnAction = _libs["libsai.so"].get("clx_l3t_setUnusedEcnAction", "cdecl")
    clx_l3t_setUnusedEcnAction.argtypes = [UI32_T, CLX_FWD_ACTION_T]
    clx_l3t_setUnusedEcnAction.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 796
if _libs["libsai.so"].has("clx_l3t_getUnusedEcnAction", "cdecl"):
    clx_l3t_getUnusedEcnAction = _libs["libsai.so"].get("clx_l3t_getUnusedEcnAction", "cdecl")
    clx_l3t_getUnusedEcnAction.argtypes = [UI32_T, POINTER(CLX_FWD_ACTION_T)]
    clx_l3t_getUnusedEcnAction.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 815
if _libs["libsai.so"].has("clx_l3t_createPort", "cdecl"):
    clx_l3t_createPort = _libs["libsai.so"].get("clx_l3t_createPort", "cdecl")
    clx_l3t_createPort.argtypes = [UI32_T, POINTER(CLX_TUNNEL_KEY_T), UI32_T, POINTER(CLX_PORT_T)]
    clx_l3t_createPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 835
if _libs["libsai.so"].has("clx_l3t_destroyPort", "cdecl"):
    clx_l3t_destroyPort = _libs["libsai.so"].get("clx_l3t_destroyPort", "cdecl")
    clx_l3t_destroyPort.argtypes = [UI32_T, CLX_PORT_T]
    clx_l3t_destroyPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 853
if _libs["libsai.so"].has("clx_l3t_getPort", "cdecl"):
    clx_l3t_getPort = _libs["libsai.so"].get("clx_l3t_getPort", "cdecl")
    clx_l3t_getPort.argtypes = [UI32_T, POINTER(CLX_TUNNEL_KEY_T), POINTER(CLX_PORT_T)]
    clx_l3t_getPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 872
if _libs["libsai.so"].has("clx_l3t_getKey", "cdecl"):
    clx_l3t_getKey = _libs["libsai.so"].get("clx_l3t_getKey", "cdecl")
    clx_l3t_getKey.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_TUNNEL_KEY_T)]
    clx_l3t_getKey.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 892
if _libs["libsai.so"].has("clx_l3t_traversePort", "cdecl"):
    clx_l3t_traversePort = _libs["libsai.so"].get("clx_l3t_traversePort", "cdecl")
    clx_l3t_traversePort.argtypes = [UI32_T, CLX_L3T_PORT_TRAVERSE_FUNC_T, POINTER(None)]
    clx_l3t_traversePort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 913
if _libs["libsai.so"].has("clx_l3t_addFlexTunnel", "cdecl"):
    clx_l3t_addFlexTunnel = _libs["libsai.so"].get("clx_l3t_addFlexTunnel", "cdecl")
    clx_l3t_addFlexTunnel.argtypes = [UI32_T, UI32_T, CLX_L3T_FLEX_TUNNEL_TYPE_T, UI32_T]
    clx_l3t_addFlexTunnel.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 933
if _libs["libsai.so"].has("clx_l3t_delFlexTunnel", "cdecl"):
    clx_l3t_delFlexTunnel = _libs["libsai.so"].get("clx_l3t_delFlexTunnel", "cdecl")
    clx_l3t_delFlexTunnel.argtypes = [UI32_T, UI32_T]
    clx_l3t_delFlexTunnel.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_l3t.h: 952
if _libs["libsai.so"].has("clx_l3t_getFlexTunnel", "cdecl"):
    clx_l3t_getFlexTunnel = _libs["libsai.so"].get("clx_l3t_getFlexTunnel", "cdecl")
    clx_l3t_getFlexTunnel.argtypes = [UI32_T, UI32_T, POINTER(CLX_L3T_FLEX_TUNNEL_TYPE_T), POINTER(UI32_T)]
    clx_l3t_getFlexTunnel.restype = CLX_ERROR_NO_T

enum_CLX_SDN_PORT_NO_E = c_int# ./clx_system/clx_sdk/include/clx_sdn.h: 89

CLX_SDN_RSV_PORT_IN_PORT = 4294967288# ./clx_system/clx_sdk/include/clx_sdn.h: 89

CLX_SDN_RSV_PORT_TABLE = 4294967289# ./clx_system/clx_sdk/include/clx_sdn.h: 89

CLX_SDN_RSV_PORT_NORMAL = 4294967290# ./clx_system/clx_sdk/include/clx_sdn.h: 89

CLX_SDN_RSV_PORT_FLOOD = 4294967291# ./clx_system/clx_sdk/include/clx_sdn.h: 89

CLX_SDN_RSV_PORT_ALL = 4294967292# ./clx_system/clx_sdk/include/clx_sdn.h: 89

CLX_SDN_RSV_PORT_CONTROLLER = 4294967293# ./clx_system/clx_sdk/include/clx_sdn.h: 89

CLX_SDN_RSV_PORT_LOCAL = 4294967294# ./clx_system/clx_sdk/include/clx_sdn.h: 89

CLX_SDN_RSV_PORT_ANY = 4294967295# ./clx_system/clx_sdk/include/clx_sdn.h: 89

CLX_SDN_PORT_NO_T = enum_CLX_SDN_PORT_NO_E# ./clx_system/clx_sdk/include/clx_sdn.h: 89

enum_CLX_SDN_PORT_TYPE_E = c_int# ./clx_system/clx_sdk/include/clx_sdn.h: 100

CLX_SDN_PHY_PORT = 0# ./clx_system/clx_sdk/include/clx_sdn.h: 100

CLX_SDN_LAG_PORT = 1# ./clx_system/clx_sdk/include/clx_sdn.h: 100

CLX_SDN_TUNNEL_PORT = 2# ./clx_system/clx_sdk/include/clx_sdn.h: 100

CLX_SDN_RSV_PORT = 255# ./clx_system/clx_sdk/include/clx_sdn.h: 100

CLX_SDN_PORT_TYPE_LAST = (CLX_SDN_RSV_PORT + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 100

CLX_SDN_PORT_TYPE_T = enum_CLX_SDN_PORT_TYPE_E# ./clx_system/clx_sdk/include/clx_sdn.h: 100

# ./clx_system/clx_sdk/include/clx_sdn.h: 110
class struct_CLX_SDN_PORT_S(Structure):
    pass

struct_CLX_SDN_PORT_S.__slots__ = [
    'port_type',
    'port_no',
]
struct_CLX_SDN_PORT_S._fields_ = [
    ('port_type', CLX_SDN_PORT_TYPE_T),
    ('port_no', UI32_T),
]

CLX_SDN_PORT_T = struct_CLX_SDN_PORT_S# ./clx_system/clx_sdk/include/clx_sdn.h: 110

# ./clx_system/clx_sdk/include/clx_sdn.h: 123
class struct_CLX_SDN_TUNNEL_S(Structure):
    pass

struct_CLX_SDN_TUNNEL_S.__slots__ = [
    'tunnel_type',
    'tunnel_no',
]
struct_CLX_SDN_TUNNEL_S._fields_ = [
    ('tunnel_type', CLX_TUNNEL_TYPE_T),
    ('tunnel_no', UI32_T),
]

CLX_SDN_TUNNEL_T = struct_CLX_SDN_TUNNEL_S# ./clx_system/clx_sdk/include/clx_sdn.h: 123

# ./clx_system/clx_sdk/include/clx_sdn.h: 132
class struct_CLX_SDN_TUNNEL_ATTR_S(Structure):
    pass

struct_CLX_SDN_TUNNEL_ATTR_S.__slots__ = [
    'src_ip',
    'dst_ip',
    'tunnel_type',
    'pbm',
]
struct_CLX_SDN_TUNNEL_ATTR_S._fields_ = [
    ('src_ip', CLX_IP_ADDR_T),
    ('dst_ip', CLX_IP_ADDR_T),
    ('tunnel_type', CLX_TUNNEL_TYPE_T),
    ('pbm', CLX_PORT_BITMAP_T),
]

CLX_SDN_TUNNEL_ATTR_T = struct_CLX_SDN_TUNNEL_ATTR_S# ./clx_system/clx_sdk/include/clx_sdn.h: 132

# ./clx_system/clx_sdk/include/clx_sdn.h: 139
class struct_CLX_SDN_SFLOW_S(Structure):
    pass

struct_CLX_SDN_SFLOW_S.__slots__ = [
    'sample_rate',
    'sample_point',
]
struct_CLX_SDN_SFLOW_S._fields_ = [
    ('sample_rate', UI32_T),
    ('sample_point', UI32_T),
]

CLX_SDN_SFLOW_T = struct_CLX_SDN_SFLOW_S# ./clx_system/clx_sdk/include/clx_sdn.h: 139

# ./clx_system/clx_sdk/include/clx_sdn.h: 150
class struct_CLX_SDN_NSH_S(Structure):
    pass

struct_CLX_SDN_NSH_S.__slots__ = [
    'version',
    'oam_bit',
    'next_prot',
    'srv_path_id',
    'srv_idx',
    'context_hdr',
]
struct_CLX_SDN_NSH_S._fields_ = [
    ('version', UI8_T),
    ('oam_bit', UI8_T),
    ('next_prot', UI8_T),
    ('srv_path_id', UI32_T),
    ('srv_idx', UI32_T),
    ('context_hdr', UI32_T * int(4)),
]

CLX_SDN_NSH_T = struct_CLX_SDN_NSH_S# ./clx_system/clx_sdk/include/clx_sdn.h: 150

enum_CLX_SDN_PAYLOAD_TYPE_E = c_int# ./clx_system/clx_sdk/include/clx_sdn.h: 157

CLX_SDN_PAYLOAD_TYPE_IPV4 = 0# ./clx_system/clx_sdk/include/clx_sdn.h: 157

CLX_SDN_PAYLOAD_TYPE_IPV6 = (CLX_SDN_PAYLOAD_TYPE_IPV4 + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 157

CLX_SDN_PAYLOAD_TYPE_LAST = (CLX_SDN_PAYLOAD_TYPE_IPV6 + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 157

CLX_SDN_PAYLOAD_TYPE_T = enum_CLX_SDN_PAYLOAD_TYPE_E# ./clx_system/clx_sdk/include/clx_sdn.h: 157

# ./clx_system/clx_sdk/include/clx_sdn.h: 165
class struct_CLX_SDN_PPPOE_S(Structure):
    pass

struct_CLX_SDN_PPPOE_S.__slots__ = [
    'code',
    'session_id',
    'payload_type',
]
struct_CLX_SDN_PPPOE_S._fields_ = [
    ('code', UI32_T),
    ('session_id', UI32_T),
    ('payload_type', CLX_SDN_PAYLOAD_TYPE_T),
]

CLX_SDN_PPPOE_T = struct_CLX_SDN_PPPOE_S# ./clx_system/clx_sdk/include/clx_sdn.h: 165

# ./clx_system/clx_sdk/include/clx_sdn.h: 180
class union_CLX_SDN_FIELD_VALUE_U(Union):
    pass

union_CLX_SDN_FIELD_VALUE_U.__slots__ = [
    'data',
    'data64',
    'port',
    'tunnel',
    'sflow',
    'mac',
    'ipv4',
    'ipv6',
    'nsh_hdr',
    'pppoe_hdr',
]
union_CLX_SDN_FIELD_VALUE_U._fields_ = [
    ('data', UI32_T),
    ('data64', UI64_T),
    ('port', CLX_SDN_PORT_T),
    ('tunnel', CLX_SDN_TUNNEL_T),
    ('sflow', CLX_SDN_SFLOW_T),
    ('mac', CLX_MAC_T),
    ('ipv4', CLX_IPV4_T),
    ('ipv6', CLX_IPV6_T),
    ('nsh_hdr', CLX_SDN_NSH_T),
    ('pppoe_hdr', CLX_SDN_PPPOE_T),
]

CLX_SDN_FIELD_VALUE_T = union_CLX_SDN_FIELD_VALUE_U# ./clx_system/clx_sdk/include/clx_sdn.h: 180

enum_anon_132 = c_int# ./clx_system/clx_sdk/include/clx_sdn.h: 207

CLX_SDN_FLOW_TABLE_PROP_NEXT_TABLES = 2# ./clx_system/clx_sdk/include/clx_sdn.h: 207

CLX_SDN_FLOW_TABLE_PROP_MATCH = 8# ./clx_system/clx_sdk/include/clx_sdn.h: 207

CLX_SDN_FLOW_TABLE_PROP_WILDCARDS = 10# ./clx_system/clx_sdk/include/clx_sdn.h: 207

CLX_SDN_FLOW_TABLE_PROP_MAX_ENTRIES = 128# ./clx_system/clx_sdk/include/clx_sdn.h: 207

CLX_SDN_FLOW_TABLE_PROP_METADATA_MATCH = 129# ./clx_system/clx_sdk/include/clx_sdn.h: 207

CLX_SDN_FLOW_TABLE_PROP_METADATA_WRITE = 130# ./clx_system/clx_sdk/include/clx_sdn.h: 207

CLX_SDN_FLOW_TABLE_PROP_LAST = (CLX_SDN_FLOW_TABLE_PROP_METADATA_WRITE + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 207

CLX_SDN_FLOW_TABLE_PROP_TYPE_T = enum_anon_132# ./clx_system/clx_sdk/include/clx_sdn.h: 207

# ./clx_system/clx_sdk/include/clx_sdn.h: 217
class struct_CLX_SDN_FLOW_TABLE_PROP_S(Structure):
    pass

struct_CLX_SDN_FLOW_TABLE_PROP_S.__slots__ = [
    'type',
    'ptr_prop_data',
]
struct_CLX_SDN_FLOW_TABLE_PROP_S._fields_ = [
    ('type', CLX_SDN_FLOW_TABLE_PROP_TYPE_T),
    ('ptr_prop_data', POINTER(None)),
]

CLX_SDN_FLOW_TABLE_PROP_T = struct_CLX_SDN_FLOW_TABLE_PROP_S# ./clx_system/clx_sdk/include/clx_sdn.h: 217

# ./clx_system/clx_sdk/include/clx_sdn.h: 224
class struct_CLX_SDN_FLOW_TABLE_PROP_HEAD_S(Structure):
    pass

struct_CLX_SDN_FLOW_TABLE_PROP_HEAD_S.__slots__ = [
    'prop_num',
    'ptr_prop',
]
struct_CLX_SDN_FLOW_TABLE_PROP_HEAD_S._fields_ = [
    ('prop_num', UI8_T),
    ('ptr_prop', POINTER(CLX_SDN_FLOW_TABLE_PROP_T)),
]

CLX_SDN_FLOW_TABLE_PROP_HEAD_T = struct_CLX_SDN_FLOW_TABLE_PROP_HEAD_S# ./clx_system/clx_sdk/include/clx_sdn.h: 224

# ./clx_system/clx_sdk/include/clx_sdn.h: 232
class struct_CLX_SDN_FLOW_TABLE_PROP_NEXT_TABLE_S(Structure):
    pass

struct_CLX_SDN_FLOW_TABLE_PROP_NEXT_TABLE_S.__slots__ = [
    'next_table_num',
    'ptr_next_table_ids',
]
struct_CLX_SDN_FLOW_TABLE_PROP_NEXT_TABLE_S._fields_ = [
    ('next_table_num', UI16_T),
    ('ptr_next_table_ids', POINTER(UI8_T)),
]

CLX_SDN_FLOW_TABLE_PROP_NEXT_TABLE_T = struct_CLX_SDN_FLOW_TABLE_PROP_NEXT_TABLE_S# ./clx_system/clx_sdk/include/clx_sdn.h: 232

enum_anon_133 = c_int# ./clx_system/clx_sdk/include/clx_sdn.h: 245

CLX_SDN_FIELD_CLASS_NXM_0 = 0# ./clx_system/clx_sdk/include/clx_sdn.h: 245

CLX_SDN_FIELD_CLASS_NXM_1 = 1# ./clx_system/clx_sdk/include/clx_sdn.h: 245

CLX_SDN_FIELD_CLASS_OPENFLOW_BASIC = 2# ./clx_system/clx_sdk/include/clx_sdn.h: 245

CLX_SDN_FIELD_CLASS_EXPERIMENTER = 3# ./clx_system/clx_sdk/include/clx_sdn.h: 245

CLX_SDN_FIELD_CLASS_CLX_ONLY = 4# ./clx_system/clx_sdk/include/clx_sdn.h: 245

CLX_SDN_FIELD_CLASS_LAST = (CLX_SDN_FIELD_CLASS_CLX_ONLY + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 245

CLX_SDN_FIELD_CLASS_T = enum_anon_133# ./clx_system/clx_sdk/include/clx_sdn.h: 245

enum_anon_134 = c_int# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IN_PORT = 0# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IN_PHY_PORT = 1# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_METADATA = 2# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ETH_DST = 3# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ETH_SRC = 4# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ETH_TYPE = 5# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_VLAN_VID = 6# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_VLAN_PCP = 7# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IP_DSCP = 8# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IP_ECN = 9# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IP_PROTO = 10# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IPV4_SRC = 11# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IPV4_DST = 12# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_TCP_SRC = 13# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_TCP_DST = 14# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_UDP_SRC = 15# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_UDP_DST = 16# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_SCTP_SRC = 17# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_SCTP_DST = 18# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ICMPV4_TYPE = 19# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ICMPV4_CODE = 20# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ARP_OP = 21# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ARP_SPA = 22# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ARP_TPA = 23# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ARP_SHA = 24# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ARP_THA = 25# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IPV6_SRC = 26# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IPV6_DST = 27# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IPV6_FLABEL = 28# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ICMPV6_TYPE = 29# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_ICMPV6_CODE = 30# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IPV6_ND_TARGET = 31# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IPV6_ND_SLL = 32# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IPV6_ND_TLL = 33# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_MPLS_LABEL = 34# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_MPLS_TC = 35# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_MPLS_BOS = 36# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_PBB_ISID = 37# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_TUNNEL_ID = 38# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IPV6_EXTHDR = 39# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_INNER_VLAN_VID = 40# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_INNER_VLAN_PCP = 41# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_NW_TTL = 42# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_TCP_FLAGS = 43# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_TCP_SEQ_NUM = 44# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_TCP_ACK_NUM = 45# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_GTP_TEID = 46# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_PPPOE_CODE = 47# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_PPPOE_SESSION_ID = 48# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_PPP_PROTO = 49# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_IP_VER = 50# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_GTP_VER = 51# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_HTTP_METHOD = 52# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_LAST = (CLX_SDN_FIELD_HTTP_METHOD + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 305

CLX_SDN_FIELD_TYPE_T = enum_anon_134# ./clx_system/clx_sdk/include/clx_sdn.h: 305

# ./clx_system/clx_sdk/include/clx_sdn.h: 313
class struct_CLX_SDN_MATCH_FIELD_HEADER_S(Structure):
    pass

struct_CLX_SDN_MATCH_FIELD_HEADER_S.__slots__ = [
    'field_class',
    'field_type',
]
struct_CLX_SDN_MATCH_FIELD_HEADER_S._fields_ = [
    ('field_class', CLX_SDN_FIELD_CLASS_T),
    ('field_type', CLX_SDN_FIELD_TYPE_T),
]

CLX_SDN_MATCH_FIELD_HEADER_T = struct_CLX_SDN_MATCH_FIELD_HEADER_S# ./clx_system/clx_sdk/include/clx_sdn.h: 313

# ./clx_system/clx_sdk/include/clx_sdn.h: 321
class struct_CLX_SDN_FLOW_TABLE_PROP_FIELD_S(Structure):
    pass

struct_CLX_SDN_FLOW_TABLE_PROP_FIELD_S.__slots__ = [
    'match_field_num',
    'ptr_match_fields',
]
struct_CLX_SDN_FLOW_TABLE_PROP_FIELD_S._fields_ = [
    ('match_field_num', UI16_T),
    ('ptr_match_fields', POINTER(CLX_SDN_MATCH_FIELD_HEADER_T)),
]

CLX_SDN_FLOW_TABLE_PROP_FIELD_T = struct_CLX_SDN_FLOW_TABLE_PROP_FIELD_S# ./clx_system/clx_sdk/include/clx_sdn.h: 321

enum_anon_135 = c_int# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_OUTPUT = 0# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_COPY_TTL_OUT = 11# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_COPY_TTL_IN = 12# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_SET_MPLS_TTL = 15# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_DEC_MPLS_TTL = 16# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_PUSH_VLAN = 17# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_POP_VLAN = 18# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_PUSH_MPLS = 19# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_POP_MPLS = 20# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_SET_QUEUE = 21# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_GROUP = 22# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_SET_NW_TTL = 23# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_DEC_NW_TTL = 24# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_SET_FIELD = 25# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_PUSH_PBB = 26# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_POP_PBB = 27# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_SET_ENQUEUE = 128# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_SET_TC = 129# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_SET_SFLOW_SAMPLE = 130# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_SET_MIRROR = 131# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_PUSH_VLAN_S = 132# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_PUSH_VLAN_SC_OUTER = 133# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_PUSH_VLAN_SC_INNER = 134# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_PUSH_VLAN_CC_OUTER = 135# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_PUSH_VLAN_CC_INNER = 136# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_POP_VLAN_INNER = 137# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_PUSH_NSH = 138# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_POP_NSH = 139# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_ADD_FIELD = 140# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_SUB_FIELD = 141# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_KEEP_TUNNEL = 142# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_PUSH_TUNNEL_VLAN = 143# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_PUSH_PPPOE = 144# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_POP_PPPOE = 145# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_POP_GTP = 146# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_LAST = (CLX_SDN_ACTION_POP_GTP + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 370

CLX_SDN_ACTION_TYPE_T = enum_anon_135# ./clx_system/clx_sdk/include/clx_sdn.h: 370

# ./clx_system/clx_sdk/include/clx_sdn.h: 382
class struct_CLX_SDN_ACTION_S(Structure):
    pass

struct_CLX_SDN_ACTION_S.__slots__ = [
    'act_type',
    'field_type',
    'value',
]
struct_CLX_SDN_ACTION_S._fields_ = [
    ('act_type', CLX_SDN_ACTION_TYPE_T),
    ('field_type', CLX_SDN_FIELD_TYPE_T),
    ('value', CLX_SDN_FIELD_VALUE_T),
]

CLX_SDN_ACTION_T = struct_CLX_SDN_ACTION_S# ./clx_system/clx_sdk/include/clx_sdn.h: 382

enum_anon_136 = c_int# ./clx_system/clx_sdk/include/clx_sdn.h: 398

CLX_SDN_INST_GOTO_TABLE = 1# ./clx_system/clx_sdk/include/clx_sdn.h: 398

CLX_SDN_INST_WRITE_METADATA = (CLX_SDN_INST_GOTO_TABLE + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 398

CLX_SDN_INST_WRITE_ACTIONS = (CLX_SDN_INST_WRITE_METADATA + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 398

CLX_SDN_INST_APPLY_ACTIONS = (CLX_SDN_INST_WRITE_ACTIONS + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 398

CLX_SDN_INST_CLEAR_ACTIONS = (CLX_SDN_INST_APPLY_ACTIONS + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 398

CLX_SDN_INST_METER = (CLX_SDN_INST_CLEAR_ACTIONS + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 398

CLX_SDN_INST_COUNTER = 129# ./clx_system/clx_sdk/include/clx_sdn.h: 398

CLX_SDN_INST_LAST = (CLX_SDN_INST_COUNTER + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 398

CLX_SDN_INST_TYPE_T = enum_anon_136# ./clx_system/clx_sdk/include/clx_sdn.h: 398

# ./clx_system/clx_sdk/include/clx_sdn.h: 416
class struct_CLX_SDN_INST_S(Structure):
    pass

struct_CLX_SDN_INST_S.__slots__ = [
    'type',
    'ptr_data',
]
struct_CLX_SDN_INST_S._fields_ = [
    ('type', CLX_SDN_INST_TYPE_T),
    ('ptr_data', POINTER(None)),
]

CLX_SDN_INST_T = struct_CLX_SDN_INST_S# ./clx_system/clx_sdk/include/clx_sdn.h: 416

# ./clx_system/clx_sdk/include/clx_sdn.h: 423
class struct_CLX_SDN_INST_DATA_GOTO_TABLE_S(Structure):
    pass

struct_CLX_SDN_INST_DATA_GOTO_TABLE_S.__slots__ = [
    'table_id',
]
struct_CLX_SDN_INST_DATA_GOTO_TABLE_S._fields_ = [
    ('table_id', UI8_T),
]

CLX_SDN_INST_DATA_GOTO_TABLE_T = struct_CLX_SDN_INST_DATA_GOTO_TABLE_S# ./clx_system/clx_sdk/include/clx_sdn.h: 423

# ./clx_system/clx_sdk/include/clx_sdn.h: 430
class struct_CLX_SDN_INST_DATA_WRITE_METADATA_S(Structure):
    pass

struct_CLX_SDN_INST_DATA_WRITE_METADATA_S.__slots__ = [
    'metadata',
    'metadata_mask',
]
struct_CLX_SDN_INST_DATA_WRITE_METADATA_S._fields_ = [
    ('metadata', UI64_T),
    ('metadata_mask', CLX_BIT_MASK_64_T),
]

CLX_SDN_INST_DATA_WRITE_METADATA_T = struct_CLX_SDN_INST_DATA_WRITE_METADATA_S# ./clx_system/clx_sdk/include/clx_sdn.h: 430

# ./clx_system/clx_sdk/include/clx_sdn.h: 437
class struct_CLX_SDN_INST_DATA_WRITE_ACTIONS_S(Structure):
    pass

struct_CLX_SDN_INST_DATA_WRITE_ACTIONS_S.__slots__ = [
    'len_action_set',
    'ptr_action_set',
]
struct_CLX_SDN_INST_DATA_WRITE_ACTIONS_S._fields_ = [
    ('len_action_set', UI32_T),
    ('ptr_action_set', POINTER(CLX_SDN_ACTION_T)),
]

CLX_SDN_INST_DATA_WRITE_ACTIONS_T = struct_CLX_SDN_INST_DATA_WRITE_ACTIONS_S# ./clx_system/clx_sdk/include/clx_sdn.h: 437

# ./clx_system/clx_sdk/include/clx_sdn.h: 444
class struct_CLX_SDN_INST_DATA_APPLY_ACTIONS_S(Structure):
    pass

struct_CLX_SDN_INST_DATA_APPLY_ACTIONS_S.__slots__ = [
    'len_action_list',
    'ptr_action_list',
]
struct_CLX_SDN_INST_DATA_APPLY_ACTIONS_S._fields_ = [
    ('len_action_list', UI32_T),
    ('ptr_action_list', POINTER(CLX_SDN_ACTION_T)),
]

CLX_SDN_INST_DATA_APPLY_ACTIONS_T = struct_CLX_SDN_INST_DATA_APPLY_ACTIONS_S# ./clx_system/clx_sdk/include/clx_sdn.h: 444

# ./clx_system/clx_sdk/include/clx_sdn.h: 450
class struct_CLX_SDN_INST_DATA_METER_S(Structure):
    pass

struct_CLX_SDN_INST_DATA_METER_S.__slots__ = [
    'meter_id',
]
struct_CLX_SDN_INST_DATA_METER_S._fields_ = [
    ('meter_id', UI32_T),
]

CLX_SDN_INST_DATA_METER_T = struct_CLX_SDN_INST_DATA_METER_S# ./clx_system/clx_sdk/include/clx_sdn.h: 450

# ./clx_system/clx_sdk/include/clx_sdn.h: 456
class struct_CLX_SDN_INST_DATA_CNT_S(Structure):
    pass

struct_CLX_SDN_INST_DATA_CNT_S.__slots__ = [
    'cnt_id',
]
struct_CLX_SDN_INST_DATA_CNT_S._fields_ = [
    ('cnt_id', UI32_T),
]

CLX_SDN_INST_DATA_CNT_T = struct_CLX_SDN_INST_DATA_CNT_S# ./clx_system/clx_sdk/include/clx_sdn.h: 456

# ./clx_system/clx_sdk/include/clx_sdn.h: 466
class struct_CLX_SDN_MATCH_FIELD_S(Structure):
    pass

struct_CLX_SDN_MATCH_FIELD_S.__slots__ = [
    'field_class',
    'field_type',
    'mask',
    'value',
]
struct_CLX_SDN_MATCH_FIELD_S._fields_ = [
    ('field_class', CLX_SDN_FIELD_CLASS_T),
    ('field_type', CLX_SDN_FIELD_TYPE_T),
    ('mask', CLX_SDN_FIELD_VALUE_T),
    ('value', CLX_SDN_FIELD_VALUE_T),
]

CLX_SDN_MATCH_FIELD_T = struct_CLX_SDN_MATCH_FIELD_S# ./clx_system/clx_sdk/include/clx_sdn.h: 466

# ./clx_system/clx_sdk/include/clx_sdn.h: 477
class struct_CLX_SDN_FLOW_ENTRY_S(Structure):
    pass

struct_CLX_SDN_FLOW_ENTRY_S.__slots__ = [
    'pri',
    'len_match_fields',
    'ptr_match_fields',
    'len_inst',
    'ptr_inst',
]
struct_CLX_SDN_FLOW_ENTRY_S._fields_ = [
    ('pri', UI32_T),
    ('len_match_fields', UI32_T),
    ('ptr_match_fields', POINTER(CLX_SDN_MATCH_FIELD_T)),
    ('len_inst', UI32_T),
    ('ptr_inst', POINTER(CLX_SDN_INST_T)),
]

CLX_SDN_FLOW_ENTRY_T = struct_CLX_SDN_FLOW_ENTRY_S# ./clx_system/clx_sdk/include/clx_sdn.h: 477

enum_anon_137 = c_int# ./clx_system/clx_sdk/include/clx_sdn.h: 488

CLX_SDN_FLOW_SEARCH_TYPE_AUTO = 0# ./clx_system/clx_sdk/include/clx_sdn.h: 488

CLX_SDN_FLOW_SEARCH_TYPE_HASH_ONLY = (CLX_SDN_FLOW_SEARCH_TYPE_AUTO + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 488

CLX_SDN_FLOW_SEARCH_TYPE_TCAM_ONLY = (CLX_SDN_FLOW_SEARCH_TYPE_HASH_ONLY + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 488

CLX_SDN_FLOW_SEARCH_TYPE_HASH_AND_TCAM = (CLX_SDN_FLOW_SEARCH_TYPE_TCAM_ONLY + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 488

CLX_SDN_FLOW_SEARCH_TYPE_HASH_LPM = (CLX_SDN_FLOW_SEARCH_TYPE_HASH_AND_TCAM + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 488

CLX_SDN_FLOW_SEARCH_TYPE_LAST = (CLX_SDN_FLOW_SEARCH_TYPE_HASH_LPM + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 488

CLX_SDN_FLOW_SEARCH_MODE_T = enum_anon_137# ./clx_system/clx_sdk/include/clx_sdn.h: 488

# ./clx_system/clx_sdk/include/clx_sdn.h: 504
class struct_CLX_SDN_FLOW_TABLE_TUNNEL_QLI_CFG_S(Structure):
    pass

struct_CLX_SDN_FLOW_TABLE_TUNNEL_QLI_CFG_S.__slots__ = [
    'tun_qli',
    'inner_header_qli',
]
struct_CLX_SDN_FLOW_TABLE_TUNNEL_QLI_CFG_S._fields_ = [
    ('tun_qli', UI8_T),
    ('inner_header_qli', UI8_T),
]

CLX_SDN_FLOW_TABLE_TUNNEL_QLI_CFG_T = struct_CLX_SDN_FLOW_TABLE_TUNNEL_QLI_CFG_S# ./clx_system/clx_sdk/include/clx_sdn.h: 504

enum_CLX_SDN_GROUP_TYPE_S = c_int# ./clx_system/clx_sdk/include/clx_sdn.h: 516

CLX_SDN_GRP_TYPE_ALL = 0# ./clx_system/clx_sdk/include/clx_sdn.h: 516

CLX_SDN_GRP_TYPE_SELECT = 1# ./clx_system/clx_sdk/include/clx_sdn.h: 516

CLX_SDN_GRP_TYPE_INDIRECT = 2# ./clx_system/clx_sdk/include/clx_sdn.h: 516

CLX_SDN_GRP_TYPE_FF = 3# ./clx_system/clx_sdk/include/clx_sdn.h: 516

CLX_SDN_GRP_TYPE_LAST = (CLX_SDN_GRP_TYPE_FF + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 516

CLX_SDN_GROUP_TYPE_T = enum_CLX_SDN_GROUP_TYPE_S# ./clx_system/clx_sdk/include/clx_sdn.h: 516

# ./clx_system/clx_sdk/include/clx_sdn.h: 533
class struct_CLX_SDN_GROUP_BUCKET_S(Structure):
    pass

struct_CLX_SDN_GROUP_BUCKET_S.__slots__ = [
    'weight',
    'watch_port',
    'watch_group',
    'len_action_set',
    'ptr_action_set',
]
struct_CLX_SDN_GROUP_BUCKET_S._fields_ = [
    ('weight', UI16_T),
    ('watch_port', UI32_T),
    ('watch_group', UI32_T),
    ('len_action_set', UI32_T),
    ('ptr_action_set', POINTER(CLX_SDN_ACTION_T)),
]

CLX_SDN_GROUP_BUCKET_T = struct_CLX_SDN_GROUP_BUCKET_S# ./clx_system/clx_sdk/include/clx_sdn.h: 533

# ./clx_system/clx_sdk/include/clx_sdn.h: 542
class struct_CLX_SDN_GROUP_ENTRY_S(Structure):
    pass

struct_CLX_SDN_GROUP_ENTRY_S.__slots__ = [
    'group_id',
    'type',
    'len_buckets',
    'ptr_buckets',
]
struct_CLX_SDN_GROUP_ENTRY_S._fields_ = [
    ('group_id', UI32_T),
    ('type', CLX_SDN_GROUP_TYPE_T),
    ('len_buckets', UI32_T),
    ('ptr_buckets', POINTER(CLX_SDN_GROUP_BUCKET_T)),
]

CLX_SDN_GROUP_ENTRY_T = struct_CLX_SDN_GROUP_ENTRY_S# ./clx_system/clx_sdk/include/clx_sdn.h: 542

enum_CLX_SDN_METER_BAND_TYPE_S = c_int# ./clx_system/clx_sdk/include/clx_sdn.h: 551

CLX_SDN_METER_BAND_TYPE_DROP = 1# ./clx_system/clx_sdk/include/clx_sdn.h: 551

CLX_SDN_METER_BAND_TYPE_DSCP_REMARK = 2# ./clx_system/clx_sdk/include/clx_sdn.h: 551

CLX_SDN_METER_BAND_TYPE_COLOR_SET = 3# ./clx_system/clx_sdk/include/clx_sdn.h: 551

CLX_SDN_METER_BAND_TYPE_LAST = (CLX_SDN_METER_BAND_TYPE_COLOR_SET + 1)# ./clx_system/clx_sdk/include/clx_sdn.h: 551

CLX_SDN_METER_BAND_TYPE_T = enum_CLX_SDN_METER_BAND_TYPE_S# ./clx_system/clx_sdk/include/clx_sdn.h: 551

# ./clx_system/clx_sdk/include/clx_sdn.h: 564
class struct_CLX_SDN_METER_COLOR_POLICY_S(Structure):
    pass

struct_CLX_SDN_METER_COLOR_POLICY_S.__slots__ = [
    'dscp_value',
    'pcp_value',
    'flags',
]
struct_CLX_SDN_METER_COLOR_POLICY_S._fields_ = [
    ('dscp_value', UI32_T),
    ('pcp_value', UI32_T),
    ('flags', UI32_T),
]

CLX_SDN_METER_COLOR_POLICY_T = struct_CLX_SDN_METER_COLOR_POLICY_S# ./clx_system/clx_sdk/include/clx_sdn.h: 564

# ./clx_system/clx_sdk/include/clx_sdn.h: 572
class union_anon_138(Union):
    pass

union_anon_138.__slots__ = [
    'prec_level',
    'color_policy',
]
union_anon_138._fields_ = [
    ('prec_level', UI8_T),
    ('color_policy', CLX_SDN_METER_COLOR_POLICY_T),
]

# ./clx_system/clx_sdk/include/clx_sdn.h: 577
class struct_CLX_SDN_METER_BAND_S(Structure):
    pass

struct_CLX_SDN_METER_BAND_S.__slots__ = [
    'type',
    'rate',
    'burst_size',
    'unnamed_1',
]
struct_CLX_SDN_METER_BAND_S._anonymous_ = [
    'unnamed_1',
]
struct_CLX_SDN_METER_BAND_S._fields_ = [
    ('type', CLX_SDN_METER_BAND_TYPE_T),
    ('rate', UI32_T),
    ('burst_size', UI32_T),
    ('unnamed_1', union_anon_138),
]

CLX_SDN_METER_BAND_T = struct_CLX_SDN_METER_BAND_S# ./clx_system/clx_sdk/include/clx_sdn.h: 577

# ./clx_system/clx_sdk/include/clx_sdn.h: 594
class struct_CLX_SDN_METER_ENTRY_S(Structure):
    pass

struct_CLX_SDN_METER_ENTRY_S.__slots__ = [
    'meter_id',
    'flags',
    'algorithm',
    'band_num',
    'band',
]
struct_CLX_SDN_METER_ENTRY_S._fields_ = [
    ('meter_id', UI32_T),
    ('flags', UI32_T),
    ('algorithm', CLX_METER_ALGO_T),
    ('band_num', UI32_T),
    ('band', CLX_SDN_METER_BAND_T * int(2)),
]

CLX_SDN_METER_ENTRY_T = struct_CLX_SDN_METER_ENTRY_S# ./clx_system/clx_sdk/include/clx_sdn.h: 594

# ./clx_system/clx_sdk/include/clx_sdn.h: 602
class struct_CLX_SDN_STAT_S(Structure):
    pass

struct_CLX_SDN_STAT_S.__slots__ = [
    'fwd_byte_cnt',
    'fwd_pkt_cnt',
    'drop_pkt_cnt',
]
struct_CLX_SDN_STAT_S._fields_ = [
    ('fwd_byte_cnt', UI64_T),
    ('fwd_pkt_cnt', UI64_T),
    ('drop_pkt_cnt', UI64_T),
]

CLX_SDN_STAT_T = struct_CLX_SDN_STAT_S# ./clx_system/clx_sdk/include/clx_sdn.h: 602

# ./clx_system/clx_sdk/include/clx_sdn.h: 613
class struct_CLX_SDN_METER_STAT_S(Structure):
    pass

struct_CLX_SDN_METER_STAT_S.__slots__ = [
    'flow_num',
    'band_num',
    'fwd_byte_cnt',
    'fwd_pkt_cnt',
    'drop_pkt_cnt',
    'band_stat',
]
struct_CLX_SDN_METER_STAT_S._fields_ = [
    ('flow_num', UI32_T),
    ('band_num', UI32_T),
    ('fwd_byte_cnt', UI64_T),
    ('fwd_pkt_cnt', UI64_T),
    ('drop_pkt_cnt', UI64_T),
    ('band_stat', CLX_SDN_STAT_T * int(2)),
]

CLX_SDN_METER_STAT_T = struct_CLX_SDN_METER_STAT_S# ./clx_system/clx_sdk/include/clx_sdn.h: 613

# ./clx_system/clx_sdk/include/clx_sdn.h: 623
class struct_anon_139(Structure):
    pass

struct_anon_139.__slots__ = [
    'reason_bitmap',
    'qid',
]
struct_anon_139._fields_ = [
    ('reason_bitmap', CLX_PKT_RX_REASON_BITMAP_T),
    ('qid', UI8_T),
]

CLX_SDN_REASON_TO_QUEUE_T = struct_anon_139# ./clx_system/clx_sdk/include/clx_sdn.h: 623

# ./clx_system/clx_sdk/include/clx_sdn.h: 632
class struct_CLX_SDN_LOAD_BALANCE_S(Structure):
    pass

struct_CLX_SDN_LOAD_BALANCE_S.__slots__ = [
    'lb_field',
    'lb_mask',
]
struct_CLX_SDN_LOAD_BALANCE_S._fields_ = [
    ('lb_field', CLX_SDN_FIELD_TYPE_T),
    ('lb_mask', CLX_SDN_FIELD_VALUE_T),
]

CLX_SDN_LOAD_BALANCE_T = struct_CLX_SDN_LOAD_BALANCE_S# ./clx_system/clx_sdk/include/clx_sdn.h: 632

# ./clx_system/clx_sdk/include/clx_sdn.h: 658
if _libs["libsai.so"].has("clx_sdn_setFlowTableProp", "cdecl"):
    clx_sdn_setFlowTableProp = _libs["libsai.so"].get("clx_sdn_setFlowTableProp", "cdecl")
    clx_sdn_setFlowTableProp.argtypes = [UI32_T, UI8_T, POINTER(CLX_SDN_FLOW_TABLE_PROP_HEAD_T)]
    clx_sdn_setFlowTableProp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 680
if _libs["libsai.so"].has("clx_sdn_getFlowTableProp", "cdecl"):
    clx_sdn_getFlowTableProp = _libs["libsai.so"].get("clx_sdn_getFlowTableProp", "cdecl")
    clx_sdn_getFlowTableProp.argtypes = [UI32_T, UI8_T, UI32_T, POINTER(CLX_SDN_FLOW_TABLE_PROP_HEAD_T)]
    clx_sdn_getFlowTableProp.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 708
if _libs["libsai.so"].has("clx_sdn_createFlowEntry", "cdecl"):
    clx_sdn_createFlowEntry = _libs["libsai.so"].get("clx_sdn_createFlowEntry", "cdecl")
    clx_sdn_createFlowEntry.argtypes = [UI32_T, UI8_T, UI64_T, POINTER(CLX_SDN_FLOW_ENTRY_T)]
    clx_sdn_createFlowEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 730
if _libs["libsai.so"].has("clx_sdn_delFlowEntry", "cdecl"):
    clx_sdn_delFlowEntry = _libs["libsai.so"].get("clx_sdn_delFlowEntry", "cdecl")
    clx_sdn_delFlowEntry.argtypes = [UI32_T, UI8_T, UI64_T]
    clx_sdn_delFlowEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 753
if _libs["libsai.so"].has("clx_sdn_modifyFlowEntryInst", "cdecl"):
    clx_sdn_modifyFlowEntryInst = _libs["libsai.so"].get("clx_sdn_modifyFlowEntryInst", "cdecl")
    clx_sdn_modifyFlowEntryInst.argtypes = [UI32_T, UI8_T, UI64_T, UI32_T, POINTER(CLX_SDN_INST_T)]
    clx_sdn_modifyFlowEntryInst.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 777
if _libs["libsai.so"].has("clx_sdn_getFlowEntry", "cdecl"):
    clx_sdn_getFlowEntry = _libs["libsai.so"].get("clx_sdn_getFlowEntry", "cdecl")
    clx_sdn_getFlowEntry.argtypes = [UI32_T, UI8_T, UI64_T, UI32_T, POINTER(CLX_SDN_FLOW_ENTRY_T)]
    clx_sdn_getFlowEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 799
if _libs["libsai.so"].has("clx_sdn_setFlowTableSearchMode", "cdecl"):
    clx_sdn_setFlowTableSearchMode = _libs["libsai.so"].get("clx_sdn_setFlowTableSearchMode", "cdecl")
    clx_sdn_setFlowTableSearchMode.argtypes = [UI32_T, UI8_T, CLX_SDN_FLOW_SEARCH_MODE_T]
    clx_sdn_setFlowTableSearchMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 818
if _libs["libsai.so"].has("clx_sdn_getFlowTableSearchMode", "cdecl"):
    clx_sdn_getFlowTableSearchMode = _libs["libsai.so"].get("clx_sdn_getFlowTableSearchMode", "cdecl")
    clx_sdn_getFlowTableSearchMode.argtypes = [UI32_T, UI8_T, POINTER(CLX_SDN_FLOW_SEARCH_MODE_T)]
    clx_sdn_getFlowTableSearchMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 842
if _libs["libsai.so"].has("clx_sdn_setFlowMissInst", "cdecl"):
    clx_sdn_setFlowMissInst = _libs["libsai.so"].get("clx_sdn_setFlowMissInst", "cdecl")
    clx_sdn_setFlowMissInst.argtypes = [UI32_T, UI8_T, BOOL_T, UI32_T, POINTER(CLX_SDN_INST_T)]
    clx_sdn_setFlowMissInst.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 865
if _libs["libsai.so"].has("clx_sdn_getFlowMissInst", "cdecl"):
    clx_sdn_getFlowMissInst = _libs["libsai.so"].get("clx_sdn_getFlowMissInst", "cdecl")
    clx_sdn_getFlowMissInst.argtypes = [UI32_T, UI8_T, BOOL_T, UI32_T, POINTER(CLX_SDN_INST_T)]
    clx_sdn_getFlowMissInst.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 892
if _libs["libsai.so"].has("clx_sdn_setQliMissInst", "cdecl"):
    clx_sdn_setQliMissInst = _libs["libsai.so"].get("clx_sdn_setQliMissInst", "cdecl")
    clx_sdn_setQliMissInst.argtypes = [UI32_T, UI8_T, BOOL_T, UI32_T, POINTER(CLX_SDN_INST_T)]
    clx_sdn_setQliMissInst.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 916
if _libs["libsai.so"].has("clx_sdn_getQliMissInst", "cdecl"):
    clx_sdn_getQliMissInst = _libs["libsai.so"].get("clx_sdn_getQliMissInst", "cdecl")
    clx_sdn_getQliMissInst.argtypes = [UI32_T, UI8_T, BOOL_T, UI32_T, POINTER(CLX_SDN_INST_T)]
    clx_sdn_getQliMissInst.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 939
if _libs["libsai.so"].has("clx_sdn_setTunnelQli", "cdecl"):
    clx_sdn_setTunnelQli = _libs["libsai.so"].get("clx_sdn_setTunnelQli", "cdecl")
    clx_sdn_setTunnelQli.argtypes = [UI32_T, UI8_T, POINTER(CLX_SDN_FLOW_TABLE_TUNNEL_QLI_CFG_T)]
    clx_sdn_setTunnelQli.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 960
if _libs["libsai.so"].has("clx_sdn_getTunnelQli", "cdecl"):
    clx_sdn_getTunnelQli = _libs["libsai.so"].get("clx_sdn_getTunnelQli", "cdecl")
    clx_sdn_getTunnelQli.argtypes = [UI32_T, UI8_T, POINTER(CLX_SDN_FLOW_TABLE_TUNNEL_QLI_CFG_T)]
    clx_sdn_getTunnelQli.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 981
if _libs["libsai.so"].has("clx_sdn_createGroupEntry", "cdecl"):
    clx_sdn_createGroupEntry = _libs["libsai.so"].get("clx_sdn_createGroupEntry", "cdecl")
    clx_sdn_createGroupEntry.argtypes = [UI32_T, UI32_T, POINTER(CLX_SDN_GROUP_ENTRY_T)]
    clx_sdn_createGroupEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1000
if _libs["libsai.so"].has("clx_sdn_delGroupEntry", "cdecl"):
    clx_sdn_delGroupEntry = _libs["libsai.so"].get("clx_sdn_delGroupEntry", "cdecl")
    clx_sdn_delGroupEntry.argtypes = [UI32_T, UI32_T]
    clx_sdn_delGroupEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1019
if _libs["libsai.so"].has("clx_sdn_modifyGroupEntry", "cdecl"):
    clx_sdn_modifyGroupEntry = _libs["libsai.so"].get("clx_sdn_modifyGroupEntry", "cdecl")
    clx_sdn_modifyGroupEntry.argtypes = [UI32_T, UI32_T, POINTER(CLX_SDN_GROUP_ENTRY_T)]
    clx_sdn_modifyGroupEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1039
if _libs["libsai.so"].has("clx_sdn_getGroupEntry", "cdecl"):
    clx_sdn_getGroupEntry = _libs["libsai.so"].get("clx_sdn_getGroupEntry", "cdecl")
    clx_sdn_getGroupEntry.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(CLX_SDN_GROUP_ENTRY_T)]
    clx_sdn_getGroupEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1060
if _libs["libsai.so"].has("clx_sdn_addMeterEntry", "cdecl"):
    clx_sdn_addMeterEntry = _libs["libsai.so"].get("clx_sdn_addMeterEntry", "cdecl")
    clx_sdn_addMeterEntry.argtypes = [UI32_T, POINTER(CLX_SDN_METER_ENTRY_T)]
    clx_sdn_addMeterEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1078
if _libs["libsai.so"].has("clx_sdn_delMeterEntry", "cdecl"):
    clx_sdn_delMeterEntry = _libs["libsai.so"].get("clx_sdn_delMeterEntry", "cdecl")
    clx_sdn_delMeterEntry.argtypes = [UI32_T, UI32_T]
    clx_sdn_delMeterEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1096
if _libs["libsai.so"].has("clx_sdn_modifyMeterEntry", "cdecl"):
    clx_sdn_modifyMeterEntry = _libs["libsai.so"].get("clx_sdn_modifyMeterEntry", "cdecl")
    clx_sdn_modifyMeterEntry.argtypes = [UI32_T, POINTER(CLX_SDN_METER_ENTRY_T)]
    clx_sdn_modifyMeterEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1114
if _libs["libsai.so"].has("clx_sdn_getMeterEntry", "cdecl"):
    clx_sdn_getMeterEntry = _libs["libsai.so"].get("clx_sdn_getMeterEntry", "cdecl")
    clx_sdn_getMeterEntry.argtypes = [UI32_T, UI32_T, POINTER(CLX_SDN_METER_ENTRY_T)]
    clx_sdn_getMeterEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1132
if _libs["libsai.so"].has("clx_sdn_createCnt", "cdecl"):
    clx_sdn_createCnt = _libs["libsai.so"].get("clx_sdn_createCnt", "cdecl")
    clx_sdn_createCnt.argtypes = [UI32_T, POINTER(UI32_T)]
    clx_sdn_createCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1150
if _libs["libsai.so"].has("clx_sdn_delCnt", "cdecl"):
    clx_sdn_delCnt = _libs["libsai.so"].get("clx_sdn_delCnt", "cdecl")
    clx_sdn_delCnt.argtypes = [UI32_T, UI32_T]
    clx_sdn_delCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1168
if _libs["libsai.so"].has("clx_sdn_getStat", "cdecl"):
    clx_sdn_getStat = _libs["libsai.so"].get("clx_sdn_getStat", "cdecl")
    clx_sdn_getStat.argtypes = [UI32_T, UI32_T, POINTER(CLX_SDN_STAT_T)]
    clx_sdn_getStat.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1187
if _libs["libsai.so"].has("clx_sdn_clearStat", "cdecl"):
    clx_sdn_clearStat = _libs["libsai.so"].get("clx_sdn_clearStat", "cdecl")
    clx_sdn_clearStat.argtypes = [UI32_T, UI32_T]
    clx_sdn_clearStat.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1205
if _libs["libsai.so"].has("clx_sdn_getMeterStat", "cdecl"):
    clx_sdn_getMeterStat = _libs["libsai.so"].get("clx_sdn_getMeterStat", "cdecl")
    clx_sdn_getMeterStat.argtypes = [UI32_T, UI32_T, POINTER(CLX_SDN_METER_STAT_T)]
    clx_sdn_getMeterStat.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1224
if _libs["libsai.so"].has("clx_sdn_clearMeterStat", "cdecl"):
    clx_sdn_clearMeterStat = _libs["libsai.so"].get("clx_sdn_clearMeterStat", "cdecl")
    clx_sdn_clearMeterStat.argtypes = [UI32_T, UI32_T]
    clx_sdn_clearMeterStat.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1241
if _libs["libsai.so"].has("clx_sdn_clearAllStat", "cdecl"):
    clx_sdn_clearAllStat = _libs["libsai.so"].get("clx_sdn_clearAllStat", "cdecl")
    clx_sdn_clearAllStat.argtypes = [UI32_T]
    clx_sdn_clearAllStat.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1261
if _libs["libsai.so"].has("clx_sdn_setVlanPort", "cdecl"):
    clx_sdn_setVlanPort = _libs["libsai.so"].get("clx_sdn_setVlanPort", "cdecl")
    clx_sdn_setVlanPort.argtypes = [UI32_T, CLX_VLAN_T, CLX_PORT_BITMAP_T]
    clx_sdn_setVlanPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1281
if _libs["libsai.so"].has("clx_sdn_getVlanPort", "cdecl"):
    clx_sdn_getVlanPort = _libs["libsai.so"].get("clx_sdn_getVlanPort", "cdecl")
    clx_sdn_getVlanPort.argtypes = [UI32_T, CLX_VLAN_T, POINTER(CLX_PORT_BITMAP_T)]
    clx_sdn_getVlanPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1301
if _libs["libsai.so"].has("clx_sdn_setPort", "cdecl"):
    clx_sdn_setPort = _libs["libsai.so"].get("clx_sdn_setPort", "cdecl")
    clx_sdn_setPort.argtypes = [UI32_T, UI32_T, BOOL_T]
    clx_sdn_setPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1320
if _libs["libsai.so"].has("clx_sdn_getPort", "cdecl"):
    clx_sdn_getPort = _libs["libsai.so"].get("clx_sdn_getPort", "cdecl")
    clx_sdn_getPort.argtypes = [UI32_T, UI32_T, POINTER(BOOL_T)]
    clx_sdn_getPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1339
if _libs["libsai.so"].has("clx_sdn_setAllPortConfig", "cdecl"):
    clx_sdn_setAllPortConfig = _libs["libsai.so"].get("clx_sdn_setAllPortConfig", "cdecl")
    clx_sdn_setAllPortConfig.argtypes = [UI32_T, CLX_PORT_BITMAP_T]
    clx_sdn_setAllPortConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1356
if _libs["libsai.so"].has("clx_sdn_getAllPortConfig", "cdecl"):
    clx_sdn_getAllPortConfig = _libs["libsai.so"].get("clx_sdn_getAllPortConfig", "cdecl")
    clx_sdn_getAllPortConfig.argtypes = [UI32_T, POINTER(CLX_PORT_BITMAP_T)]
    clx_sdn_getAllPortConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1377
if _libs["libsai.so"].has("clx_sdn_bindFlowTable", "cdecl"):
    clx_sdn_bindFlowTable = _libs["libsai.so"].get("clx_sdn_bindFlowTable", "cdecl")
    clx_sdn_bindFlowTable.argtypes = [UI32_T, UI8_T, UI8_T, UI8_T]
    clx_sdn_bindFlowTable.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1397
if _libs["libsai.so"].has("clx_sdn_unbindFlowTable", "cdecl"):
    clx_sdn_unbindFlowTable = _libs["libsai.so"].get("clx_sdn_unbindFlowTable", "cdecl")
    clx_sdn_unbindFlowTable.argtypes = [UI32_T, UI8_T]
    clx_sdn_unbindFlowTable.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1416
if _libs["libsai.so"].has("clx_sdn_getFlowTableBindInfo", "cdecl"):
    clx_sdn_getFlowTableBindInfo = _libs["libsai.so"].get("clx_sdn_getFlowTableBindInfo", "cdecl")
    clx_sdn_getFlowTableBindInfo.argtypes = [UI32_T, UI8_T, POINTER(UI8_T), POINTER(UI8_T)]
    clx_sdn_getFlowTableBindInfo.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1437
if _libs["libsai.so"].has("clx_sdn_setEntranceFlowTable", "cdecl"):
    clx_sdn_setEntranceFlowTable = _libs["libsai.so"].get("clx_sdn_setEntranceFlowTable", "cdecl")
    clx_sdn_setEntranceFlowTable.argtypes = [UI32_T, UI32_T, UI8_T]
    clx_sdn_setEntranceFlowTable.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1456
if _libs["libsai.so"].has("clx_sdn_getEntranceFlowTable", "cdecl"):
    clx_sdn_getEntranceFlowTable = _libs["libsai.so"].get("clx_sdn_getEntranceFlowTable", "cdecl")
    clx_sdn_getEntranceFlowTable.argtypes = [UI32_T, UI32_T, POINTER(UI8_T)]
    clx_sdn_getEntranceFlowTable.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1476
if _libs["libsai.so"].has("clx_sdn_setCpuCfg", "cdecl"):
    clx_sdn_setCpuCfg = _libs["libsai.so"].get("clx_sdn_setCpuCfg", "cdecl")
    clx_sdn_setCpuCfg.argtypes = [UI32_T, BOOL_T]
    clx_sdn_setCpuCfg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1494
if _libs["libsai.so"].has("clx_sdn_getCpuCfg", "cdecl"):
    clx_sdn_getCpuCfg = _libs["libsai.so"].get("clx_sdn_getCpuCfg", "cdecl")
    clx_sdn_getCpuCfg.argtypes = [UI32_T, POINTER(BOOL_T)]
    clx_sdn_getCpuCfg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1513
if _libs["libsai.so"].has("clx_sdn_setRxQueueMapping", "cdecl"):
    clx_sdn_setRxQueueMapping = _libs["libsai.so"].get("clx_sdn_setRxQueueMapping", "cdecl")
    clx_sdn_setRxQueueMapping.argtypes = [UI32_T, UI32_T, POINTER(CLX_SDN_REASON_TO_QUEUE_T)]
    clx_sdn_setRxQueueMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1532
if _libs["libsai.so"].has("clx_sdn_getRxQueueMapping", "cdecl"):
    clx_sdn_getRxQueueMapping = _libs["libsai.so"].get("clx_sdn_getRxQueueMapping", "cdecl")
    clx_sdn_getRxQueueMapping.argtypes = [UI32_T, UI32_T, POINTER(CLX_SDN_REASON_TO_QUEUE_T)]
    clx_sdn_getRxQueueMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1552
if _libs["libsai.so"].has("clx_sdn_setTcToQid", "cdecl"):
    clx_sdn_setTcToQid = _libs["libsai.so"].get("clx_sdn_setTcToQid", "cdecl")
    clx_sdn_setTcToQid.argtypes = [UI32_T, UI8_T, UI8_T]
    clx_sdn_setTcToQid.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1571
if _libs["libsai.so"].has("clx_sdn_getTcToQid", "cdecl"):
    clx_sdn_getTcToQid = _libs["libsai.so"].get("clx_sdn_getTcToQid", "cdecl")
    clx_sdn_getTcToQid.argtypes = [UI32_T, UI8_T, POINTER(UI8_T)]
    clx_sdn_getTcToQid.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1593
if _libs["libsai.so"].has("clx_sdn_setTunnelAttr", "cdecl"):
    clx_sdn_setTunnelAttr = _libs["libsai.so"].get("clx_sdn_setTunnelAttr", "cdecl")
    clx_sdn_setTunnelAttr.argtypes = [UI32_T, UI32_T, POINTER(CLX_SDN_TUNNEL_ATTR_T)]
    clx_sdn_setTunnelAttr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1612
if _libs["libsai.so"].has("clx_sdn_getTunnelAttr", "cdecl"):
    clx_sdn_getTunnelAttr = _libs["libsai.so"].get("clx_sdn_getTunnelAttr", "cdecl")
    clx_sdn_getTunnelAttr.argtypes = [UI32_T, UI32_T, POINTER(CLX_SDN_TUNNEL_ATTR_T)]
    clx_sdn_getTunnelAttr.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1632
if _libs["libsai.so"].has("clx_sdn_addTerm", "cdecl"):
    clx_sdn_addTerm = _libs["libsai.so"].get("clx_sdn_addTerm", "cdecl")
    clx_sdn_addTerm.argtypes = [UI32_T, POINTER(CLX_L3T_TERM_INFO_T)]
    clx_sdn_addTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1650
if _libs["libsai.so"].has("clx_sdn_delAllFlowEntries", "cdecl"):
    clx_sdn_delAllFlowEntries = _libs["libsai.so"].get("clx_sdn_delAllFlowEntries", "cdecl")
    clx_sdn_delAllFlowEntries.argtypes = [UI32_T, UI8_T]
    clx_sdn_delAllFlowEntries.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1670
if _libs["libsai.so"].has("clx_sdn_getFlowEntryHitbit", "cdecl"):
    clx_sdn_getFlowEntryHitbit = _libs["libsai.so"].get("clx_sdn_getFlowEntryHitbit", "cdecl")
    clx_sdn_getFlowEntryHitbit.argtypes = [UI32_T, UI8_T, UI64_T, BOOL_T, POINTER(BOOL_T)]
    clx_sdn_getFlowEntryHitbit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1692
if _libs["libsai.so"].has("clx_sdn_clearFlowEntryHitbit", "cdecl"):
    clx_sdn_clearFlowEntryHitbit = _libs["libsai.so"].get("clx_sdn_clearFlowEntryHitbit", "cdecl")
    clx_sdn_clearFlowEntryHitbit.argtypes = [UI32_T, UI8_T, UI64_T]
    clx_sdn_clearFlowEntryHitbit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1712
if _libs["libsai.so"].has("clx_sdn_setLoadBalance", "cdecl"):
    clx_sdn_setLoadBalance = _libs["libsai.so"].get("clx_sdn_setLoadBalance", "cdecl")
    clx_sdn_setLoadBalance.argtypes = [UI32_T, UI32_T, POINTER(CLX_SDN_LOAD_BALANCE_T)]
    clx_sdn_setLoadBalance.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sdn.h: 1731
if _libs["libsai.so"].has("clx_sdn_getLoadBalance", "cdecl"):
    clx_sdn_getLoadBalance = _libs["libsai.so"].get("clx_sdn_getLoadBalance", "cdecl")
    clx_sdn_getLoadBalance.argtypes = [UI32_T, UI32_T, POINTER(CLX_SDN_LOAD_BALANCE_T)]
    clx_sdn_getLoadBalance.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 65
class struct_CLX_LAG_TRAVERSE_INFO_S(Structure):
    pass

struct_CLX_LAG_TRAVERSE_INFO_S.__slots__ = [
    'lag_id',
    'lag_port',
]
struct_CLX_LAG_TRAVERSE_INFO_S._fields_ = [
    ('lag_id', UI32_T),
    ('lag_port', CLX_PORT_T),
]

CLX_LAG_TRAVERSE_INFO_T = struct_CLX_LAG_TRAVERSE_INFO_S# ./clx_system/clx_sdk/include/clx_lag.h: 65

CLX_LAG_TRAVERSE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), UI32_T, POINTER(CLX_LAG_TRAVERSE_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_lag.h: 68

# ./clx_system/clx_sdk/include/clx_lag.h: 92
if _libs["libsai.so"].has("clx_lag_createPort", "cdecl"):
    clx_lag_createPort = _libs["libsai.so"].get("clx_lag_createPort", "cdecl")
    clx_lag_createPort.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_T)]
    clx_lag_createPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 113
if _libs["libsai.so"].has("clx_lag_destroyPort", "cdecl"):
    clx_lag_destroyPort = _libs["libsai.so"].get("clx_lag_destroyPort", "cdecl")
    clx_lag_destroyPort.argtypes = [UI32_T, CLX_PORT_T]
    clx_lag_destroyPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 134
if _libs["libsai.so"].has("clx_lag_setMember", "cdecl"):
    clx_lag_setMember = _libs["libsai.so"].get("clx_lag_setMember", "cdecl")
    clx_lag_setMember.argtypes = [UI32_T, CLX_PORT_T, UI32_T, POINTER(CLX_PORT_T)]
    clx_lag_setMember.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 157
if _libs["libsai.so"].has("clx_lag_getMember", "cdecl"):
    clx_lag_getMember = _libs["libsai.so"].get("clx_lag_getMember", "cdecl")
    clx_lag_getMember.argtypes = [UI32_T, CLX_PORT_T, UI32_T, POINTER(CLX_PORT_T), POINTER(UI32_T)]
    clx_lag_getMember.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 179
if _libs["libsai.so"].has("clx_lag_getMemberCnt", "cdecl"):
    clx_lag_getMemberCnt = _libs["libsai.so"].get("clx_lag_getMemberCnt", "cdecl")
    clx_lag_getMemberCnt.argtypes = [UI32_T, CLX_PORT_T, POINTER(UI32_T)]
    clx_lag_getMemberCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 201
if _libs["libsai.so"].has("clx_lag_traversePort", "cdecl"):
    clx_lag_traversePort = _libs["libsai.so"].get("clx_lag_traversePort", "cdecl")
    clx_lag_traversePort.argtypes = [UI32_T, CLX_LAG_TRAVERSE_FUNC_T, POINTER(None)]
    clx_lag_traversePort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 220
if _libs["libsai.so"].has("clx_lag_getRange", "cdecl"):
    clx_lag_getRange = _libs["libsai.so"].get("clx_lag_getRange", "cdecl")
    clx_lag_getRange.argtypes = [UI32_T, POINTER(CLX_RANGE_INFO_T)]
    clx_lag_getRange.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 239
if _libs["libsai.so"].has("clx_lag_getPort", "cdecl"):
    clx_lag_getPort = _libs["libsai.so"].get("clx_lag_getPort", "cdecl")
    clx_lag_getPort.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_T)]
    clx_lag_getPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 259
if _libs["libsai.so"].has("clx_lag_getKey", "cdecl"):
    clx_lag_getKey = _libs["libsai.so"].get("clx_lag_getKey", "cdecl")
    clx_lag_getKey.argtypes = [UI32_T, CLX_PORT_T, POINTER(UI32_T)]
    clx_lag_getKey.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 279
if _libs["libsai.so"].has("clx_lag_addFdlGroup", "cdecl"):
    clx_lag_addFdlGroup = _libs["libsai.so"].get("clx_lag_addFdlGroup", "cdecl")
    clx_lag_addFdlGroup.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_FDL_INFO_T)]
    clx_lag_addFdlGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 299
if _libs["libsai.so"].has("clx_lag_getFdlGroup", "cdecl"):
    clx_lag_getFdlGroup = _libs["libsai.so"].get("clx_lag_getFdlGroup", "cdecl")
    clx_lag_getFdlGroup.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_FDL_INFO_T)]
    clx_lag_getFdlGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_lag.h: 319
if _libs["libsai.so"].has("clx_lag_delFdlGroup", "cdecl"):
    clx_lag_delFdlGroup = _libs["libsai.so"].get("clx_lag_delFdlGroup", "cdecl")
    clx_lag_delFdlGroup.argtypes = [UI32_T, CLX_PORT_T]
    clx_lag_delFdlGroup.restype = CLX_ERROR_NO_T

enum_anon_140 = c_int# ./clx_system/clx_sdk/include/clx_mir.h: 65

CLX_MIR_DIRECTION_INGRESS = 0# ./clx_system/clx_sdk/include/clx_mir.h: 65

CLX_MIR_DIRECTION_EGRESS = (CLX_MIR_DIRECTION_INGRESS + 1)# ./clx_system/clx_sdk/include/clx_mir.h: 65

CLX_MIR_DIRECTION_LAST = (CLX_MIR_DIRECTION_EGRESS + 1)# ./clx_system/clx_sdk/include/clx_mir.h: 65

CLX_MIR_DIRECTION_T = enum_anon_140# ./clx_system/clx_sdk/include/clx_mir.h: 65

enum_anon_141 = c_int# ./clx_system/clx_sdk/include/clx_mir.h: 76

CLX_MIR_TYPE_LOCALSPAN = 0# ./clx_system/clx_sdk/include/clx_mir.h: 76

CLX_MIR_TYPE_RSPAN_SRC = (CLX_MIR_TYPE_LOCALSPAN + 1)# ./clx_system/clx_sdk/include/clx_mir.h: 76

CLX_MIR_TYPE_RSPAN_DST = (CLX_MIR_TYPE_RSPAN_SRC + 1)# ./clx_system/clx_sdk/include/clx_mir.h: 76

CLX_MIR_TYPE_ERSPAN_SRC = (CLX_MIR_TYPE_RSPAN_DST + 1)# ./clx_system/clx_sdk/include/clx_mir.h: 76

CLX_MIR_TYPE_ERSPAN_DST = (CLX_MIR_TYPE_ERSPAN_SRC + 1)# ./clx_system/clx_sdk/include/clx_mir.h: 76

CLX_MIR_TYPE_LAST = (CLX_MIR_TYPE_ERSPAN_DST + 1)# ./clx_system/clx_sdk/include/clx_mir.h: 76

CLX_MIR_TYPE_T = enum_anon_141# ./clx_system/clx_sdk/include/clx_mir.h: 76

# ./clx_system/clx_sdk/include/clx_mir.h: 85
class struct_CLX_MIR_ERSPAN_TERM_S(Structure):
    pass

struct_CLX_MIR_ERSPAN_TERM_S.__slots__ = [
    'src_ip',
    'dst_ip',
    'erspan_id',
    'session_bitmap',
]
struct_CLX_MIR_ERSPAN_TERM_S._fields_ = [
    ('src_ip', CLX_IP_ADDR_T),
    ('dst_ip', CLX_IP_ADDR_T),
    ('erspan_id', UI32_T),
    ('session_bitmap', UI32_T),
]

CLX_MIR_ERSPAN_TERM_T = struct_CLX_MIR_ERSPAN_TERM_S# ./clx_system/clx_sdk/include/clx_mir.h: 85

enum_anon_142 = c_int# ./clx_system/clx_sdk/include/clx_mir.h: 95

CLX_MIR_ERSPAN_HDR_TYPE_8BYTES = 0# ./clx_system/clx_sdk/include/clx_mir.h: 95

CLX_MIR_ERSPAN_HDR_TYPE_12BYTES = (CLX_MIR_ERSPAN_HDR_TYPE_8BYTES + 1)# ./clx_system/clx_sdk/include/clx_mir.h: 95

CLX_MIR_ERSPAN_HDR_TYPE_20BYTES = (CLX_MIR_ERSPAN_HDR_TYPE_12BYTES + 1)# ./clx_system/clx_sdk/include/clx_mir.h: 95

CLX_MIR_ERSPAN_HDR_TYPE_0BYTES = (CLX_MIR_ERSPAN_HDR_TYPE_20BYTES + 1)# ./clx_system/clx_sdk/include/clx_mir.h: 95

CLX_MIR_ERSPAN_HDR_TYPE_LAST = (CLX_MIR_ERSPAN_HDR_TYPE_0BYTES + 1)# ./clx_system/clx_sdk/include/clx_mir.h: 95

CLX_MIR_ERSPAN_HDR_TYPE_T = enum_anon_142# ./clx_system/clx_sdk/include/clx_mir.h: 95

# ./clx_system/clx_sdk/include/clx_mir.h: 111
class struct_CLX_MIR_ERSPAN_PKT_S(Structure):
    pass

struct_CLX_MIR_ERSPAN_PKT_S.__slots__ = [
    'src_mac',
    'dst_mac',
    'src_ip',
    'dst_ip',
    'dscp',
    'ttl',
    'ecn',
    'flow_label',
    'init_seq_num',
    'erspan_type',
    'erspan_id',
]
struct_CLX_MIR_ERSPAN_PKT_S._fields_ = [
    ('src_mac', CLX_MAC_T),
    ('dst_mac', CLX_MAC_T),
    ('src_ip', CLX_IP_ADDR_T),
    ('dst_ip', CLX_IP_ADDR_T),
    ('dscp', UI8_T),
    ('ttl', UI8_T),
    ('ecn', UI8_T),
    ('flow_label', UI32_T),
    ('init_seq_num', UI32_T),
    ('erspan_type', CLX_MIR_ERSPAN_HDR_TYPE_T),
    ('erspan_id', UI32_T),
]

CLX_MIR_ERSPAN_PKT_T = struct_CLX_MIR_ERSPAN_PKT_S# ./clx_system/clx_sdk/include/clx_mir.h: 111

# ./clx_system/clx_sdk/include/clx_mir.h: 147
class struct_CLX_MIR_SESSION_S(Structure):
    pass

struct_CLX_MIR_SESSION_S.__slots__ = [
    'session_id',
    'direction',
    'mir_type',
    'truncate_size',
    'meter_rate',
    'port',
    'cvid',
    'svid',
    'pcp',
    'dei',
    'tc',
    'erspan',
    'flags',
]
struct_CLX_MIR_SESSION_S._fields_ = [
    ('session_id', UI32_T),
    ('direction', CLX_MIR_DIRECTION_T),
    ('mir_type', CLX_MIR_TYPE_T),
    ('truncate_size', UI32_T),
    ('meter_rate', UI32_T),
    ('port', CLX_PORT_T),
    ('cvid', CLX_VLAN_T),
    ('svid', CLX_VLAN_T),
    ('pcp', UI8_T),
    ('dei', UI8_T),
    ('tc', UI8_T),
    ('erspan', CLX_MIR_ERSPAN_PKT_T),
    ('flags', UI32_T),
]

CLX_MIR_SESSION_T = struct_CLX_MIR_SESSION_S# ./clx_system/clx_sdk/include/clx_mir.h: 147

# ./clx_system/clx_sdk/include/clx_mir.h: 175
if _libs["libsai.so"].has("clx_mir_addSession", "cdecl"):
    clx_mir_addSession = _libs["libsai.so"].get("clx_mir_addSession", "cdecl")
    clx_mir_addSession.argtypes = [UI32_T, POINTER(CLX_MIR_SESSION_T)]
    clx_mir_addSession.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mir.h: 200
if _libs["libsai.so"].has("clx_mir_delSession", "cdecl"):
    clx_mir_delSession = _libs["libsai.so"].get("clx_mir_delSession", "cdecl")
    clx_mir_delSession.argtypes = [UI32_T, UI32_T, CLX_MIR_DIRECTION_T]
    clx_mir_delSession.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mir.h: 221
if _libs["libsai.so"].has("clx_mir_getSession", "cdecl"):
    clx_mir_getSession = _libs["libsai.so"].get("clx_mir_getSession", "cdecl")
    clx_mir_getSession.argtypes = [UI32_T, POINTER(CLX_MIR_SESSION_T)]
    clx_mir_getSession.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mir.h: 241
if _libs["libsai.so"].has("clx_mir_addErspanTerm", "cdecl"):
    clx_mir_addErspanTerm = _libs["libsai.so"].get("clx_mir_addErspanTerm", "cdecl")
    clx_mir_addErspanTerm.argtypes = [UI32_T, POINTER(CLX_MIR_ERSPAN_TERM_T)]
    clx_mir_addErspanTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mir.h: 261
if _libs["libsai.so"].has("clx_mir_delErspanTerm", "cdecl"):
    clx_mir_delErspanTerm = _libs["libsai.so"].get("clx_mir_delErspanTerm", "cdecl")
    clx_mir_delErspanTerm.argtypes = [UI32_T, POINTER(CLX_MIR_ERSPAN_TERM_T)]
    clx_mir_delErspanTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_mir.h: 281
if _libs["libsai.so"].has("clx_mir_getErspanTerm", "cdecl"):
    clx_mir_getErspanTerm = _libs["libsai.so"].get("clx_mir_getErspanTerm", "cdecl")
    clx_mir_getErspanTerm.argtypes = [UI32_T, POINTER(CLX_MIR_ERSPAN_TERM_T)]
    clx_mir_getErspanTerm.restype = CLX_ERROR_NO_T

enum_anon_143 = c_int# ./clx_system/clx_sdk/include/clx_nv.h: 70

CLX_NV_TYPE_VXLAN = 0# ./clx_system/clx_sdk/include/clx_nv.h: 70

CLX_NV_TYPE_NVGRE = (CLX_NV_TYPE_VXLAN + 1)# ./clx_system/clx_sdk/include/clx_nv.h: 70

CLX_NV_TYPE_LAST = (CLX_NV_TYPE_NVGRE + 1)# ./clx_system/clx_sdk/include/clx_nv.h: 70

CLX_NV_TYPE_T = enum_anon_143# ./clx_system/clx_sdk/include/clx_nv.h: 70

enum_anon_144 = c_int# ./clx_system/clx_sdk/include/clx_nv.h: 77

CLX_NV_P2P_PRUNE_BY_FDID_VTEP = 0# ./clx_system/clx_sdk/include/clx_nv.h: 77

CLX_NV_P2P_PRUNE_BY_FDID = (CLX_NV_P2P_PRUNE_BY_FDID_VTEP + 1)# ./clx_system/clx_sdk/include/clx_nv.h: 77

CLX_NV_P2P_PRUNE_LAST = (CLX_NV_P2P_PRUNE_BY_FDID + 1)# ./clx_system/clx_sdk/include/clx_nv.h: 77

CLX_NV_P2P_PRUNE_T = enum_anon_144# ./clx_system/clx_sdk/include/clx_nv.h: 77

enum_anon_145 = c_int# ./clx_system/clx_sdk/include/clx_nv.h: 84

CLX_NV_L3PAYLOAD = 0# ./clx_system/clx_sdk/include/clx_nv.h: 84

CLX_NV_L2PAYLOAD = (CLX_NV_L3PAYLOAD + 1)# ./clx_system/clx_sdk/include/clx_nv.h: 84

CLX_NV_PAYLOAD_TYPE_LAST = (CLX_NV_L2PAYLOAD + 1)# ./clx_system/clx_sdk/include/clx_nv.h: 84

CLX_NV_PAYLOAD_TYPE_T = enum_anon_145# ./clx_system/clx_sdk/include/clx_nv.h: 84

# ./clx_system/clx_sdk/include/clx_nv.h: 110
if _libs["libsai.so"].has("clx_nv_setP2pPruneControl", "cdecl"):
    clx_nv_setP2pPruneControl = _libs["libsai.so"].get("clx_nv_setP2pPruneControl", "cdecl")
    clx_nv_setP2pPruneControl.argtypes = [UI32_T, CLX_NV_P2P_PRUNE_T]
    clx_nv_setP2pPruneControl.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 135
if _libs["libsai.so"].has("clx_nv_getP2pPruneControl", "cdecl"):
    clx_nv_getP2pPruneControl = _libs["libsai.so"].get("clx_nv_getP2pPruneControl", "cdecl")
    clx_nv_getP2pPruneControl.argtypes = [UI32_T, POINTER(CLX_NV_P2P_PRUNE_T)]
    clx_nv_getP2pPruneControl.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 162
if _libs["libsai.so"].has("clx_nv_setPayloadType", "cdecl"):
    clx_nv_setPayloadType = _libs["libsai.so"].get("clx_nv_setPayloadType", "cdecl")
    clx_nv_setPayloadType.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, CLX_NV_PAYLOAD_TYPE_T]
    clx_nv_setPayloadType.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 187
if _libs["libsai.so"].has("clx_nv_getPayloadType", "cdecl"):
    clx_nv_getPayloadType = _libs["libsai.so"].get("clx_nv_getPayloadType", "cdecl")
    clx_nv_getPayloadType.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(CLX_NV_PAYLOAD_TYPE_T)]
    clx_nv_getPayloadType.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 213
if _libs["libsai.so"].has("clx_nv_setSplitHorizonCheck", "cdecl"):
    clx_nv_setSplitHorizonCheck = _libs["libsai.so"].get("clx_nv_setSplitHorizonCheck", "cdecl")
    clx_nv_setSplitHorizonCheck.argtypes = [UI32_T, POINTER(CLX_TUNNEL_KEY_T), BOOL_T]
    clx_nv_setSplitHorizonCheck.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 239
if _libs["libsai.so"].has("clx_nv_getSplitHorizonCheck", "cdecl"):
    clx_nv_getSplitHorizonCheck = _libs["libsai.so"].get("clx_nv_getSplitHorizonCheck", "cdecl")
    clx_nv_getSplitHorizonCheck.argtypes = [UI32_T, POINTER(CLX_TUNNEL_KEY_T), POINTER(BOOL_T)]
    clx_nv_getSplitHorizonCheck.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 267
if _libs["libsai.so"].has("clx_nv_bindMcastTunnel", "cdecl"):
    clx_nv_bindMcastTunnel = _libs["libsai.so"].get("clx_nv_bindMcastTunnel", "cdecl")
    clx_nv_bindMcastTunnel.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(CLX_IP_ADDR_T), POINTER(CLX_IP_ADDR_T), CLX_NV_TYPE_T]
    clx_nv_bindMcastTunnel.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 292
if _libs["libsai.so"].has("clx_nv_unbindMcastTunnel", "cdecl"):
    clx_nv_unbindMcastTunnel = _libs["libsai.so"].get("clx_nv_unbindMcastTunnel", "cdecl")
    clx_nv_unbindMcastTunnel.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_nv_unbindMcastTunnel.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 318
if _libs["libsai.so"].has("clx_nv_getMcastTunnelBinding", "cdecl"):
    clx_nv_getMcastTunnelBinding = _libs["libsai.so"].get("clx_nv_getMcastTunnelBinding", "cdecl")
    clx_nv_getMcastTunnelBinding.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(CLX_IP_ADDR_T), POINTER(CLX_IP_ADDR_T), POINTER(CLX_NV_TYPE_T)]
    clx_nv_getMcastTunnelBinding.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 344
if _libs["libsai.so"].has("clx_nv_addNvo3Group", "cdecl"):
    clx_nv_addNvo3Group = _libs["libsai.so"].get("clx_nv_addNvo3Group", "cdecl")
    clx_nv_addNvo3Group.argtypes = [UI32_T, POINTER(CLX_IP_ADDR_T)]
    clx_nv_addNvo3Group.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 366
if _libs["libsai.so"].has("clx_nv_delNvo3Group", "cdecl"):
    clx_nv_delNvo3Group = _libs["libsai.so"].get("clx_nv_delNvo3Group", "cdecl")
    clx_nv_delNvo3Group.argtypes = [UI32_T, POINTER(CLX_IP_ADDR_T)]
    clx_nv_delNvo3Group.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 392
if _libs["libsai.so"].has("clx_nv_addNvo3GroupEgrPort", "cdecl"):
    clx_nv_addNvo3GroupEgrPort = _libs["libsai.so"].get("clx_nv_addNvo3GroupEgrPort", "cdecl")
    clx_nv_addNvo3GroupEgrPort.argtypes = [UI32_T, POINTER(CLX_IP_ADDR_T), UI32_T, UI32_T]
    clx_nv_addNvo3GroupEgrPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 417
if _libs["libsai.so"].has("clx_nv_delNvo3GroupEgrPort", "cdecl"):
    clx_nv_delNvo3GroupEgrPort = _libs["libsai.so"].get("clx_nv_delNvo3GroupEgrPort", "cdecl")
    clx_nv_delNvo3GroupEgrPort.argtypes = [UI32_T, POINTER(CLX_IP_ADDR_T), UI32_T]
    clx_nv_delNvo3GroupEgrPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 441
if _libs["libsai.so"].has("clx_nv_getNvo3GroupEgrPortList", "cdecl"):
    clx_nv_getNvo3GroupEgrPortList = _libs["libsai.so"].get("clx_nv_getNvo3GroupEgrPortList", "cdecl")
    clx_nv_getNvo3GroupEgrPortList.argtypes = [UI32_T, POINTER(CLX_IP_ADDR_T), POINTER(CLX_PORT_BITMAP_T)]
    clx_nv_getNvo3GroupEgrPortList.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 464
if _libs["libsai.so"].has("clx_nv_getNvo3GroupEgrInfo", "cdecl"):
    clx_nv_getNvo3GroupEgrInfo = _libs["libsai.so"].get("clx_nv_getNvo3GroupEgrInfo", "cdecl")
    clx_nv_getNvo3GroupEgrInfo.argtypes = [UI32_T, POINTER(CLX_IP_ADDR_T), UI32_T, POINTER(UI32_T)]
    clx_nv_getNvo3GroupEgrInfo.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 490
if _libs["libsai.so"].has("clx_nv_setP2pUcastTunnelAdj", "cdecl"):
    clx_nv_setP2pUcastTunnelAdj = _libs["libsai.so"].get("clx_nv_setP2pUcastTunnelAdj", "cdecl")
    clx_nv_setP2pUcastTunnelAdj.argtypes = [UI32_T, POINTER(CLX_IP_ADDR_T), POINTER(CLX_IP_ADDR_T), UI32_T]
    clx_nv_setP2pUcastTunnelAdj.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 516
if _libs["libsai.so"].has("clx_nv_delP2pUcastTunnelAdj", "cdecl"):
    clx_nv_delP2pUcastTunnelAdj = _libs["libsai.so"].get("clx_nv_delP2pUcastTunnelAdj", "cdecl")
    clx_nv_delP2pUcastTunnelAdj.argtypes = [UI32_T, POINTER(CLX_IP_ADDR_T), POINTER(CLX_IP_ADDR_T)]
    clx_nv_delP2pUcastTunnelAdj.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 540
if _libs["libsai.so"].has("clx_nv_getP2pUcastTunnelAdj", "cdecl"):
    clx_nv_getP2pUcastTunnelAdj = _libs["libsai.so"].get("clx_nv_getP2pUcastTunnelAdj", "cdecl")
    clx_nv_getP2pUcastTunnelAdj.argtypes = [UI32_T, POINTER(CLX_IP_ADDR_T), POINTER(CLX_IP_ADDR_T), POINTER(UI32_T)]
    clx_nv_getP2pUcastTunnelAdj.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 567
if _libs["libsai.so"].has("clx_nv_setP2pSplitHorizonCheck", "cdecl"):
    clx_nv_setP2pSplitHorizonCheck = _libs["libsai.so"].get("clx_nv_setP2pSplitHorizonCheck", "cdecl")
    clx_nv_setP2pSplitHorizonCheck.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, BOOL_T]
    clx_nv_setP2pSplitHorizonCheck.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 592
if _libs["libsai.so"].has("clx_nv_getP2pSplitHorizonCheck", "cdecl"):
    clx_nv_getP2pSplitHorizonCheck = _libs["libsai.so"].get("clx_nv_getP2pSplitHorizonCheck", "cdecl")
    clx_nv_getP2pSplitHorizonCheck.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(BOOL_T)]
    clx_nv_getP2pSplitHorizonCheck.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 615
if _libs["libsai.so"].has("clx_nv_addVxlanVni", "cdecl"):
    clx_nv_addVxlanVni = _libs["libsai.so"].get("clx_nv_addVxlanVni", "cdecl")
    clx_nv_addVxlanVni.argtypes = [UI32_T, UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_nv_addVxlanVni.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 638
if _libs["libsai.so"].has("clx_nv_delVxlanVni", "cdecl"):
    clx_nv_delVxlanVni = _libs["libsai.so"].get("clx_nv_delVxlanVni", "cdecl")
    clx_nv_delVxlanVni.argtypes = [UI32_T, UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_nv_delVxlanVni.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 661
if _libs["libsai.so"].has("clx_nv_getVxlanVni", "cdecl"):
    clx_nv_getVxlanVni = _libs["libsai.so"].get("clx_nv_getVxlanVni", "cdecl")
    clx_nv_getVxlanVni.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(UI32_T)]
    clx_nv_getVxlanVni.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 684
if _libs["libsai.so"].has("clx_nv_addNvgreVsid", "cdecl"):
    clx_nv_addNvgreVsid = _libs["libsai.so"].get("clx_nv_addNvgreVsid", "cdecl")
    clx_nv_addNvgreVsid.argtypes = [UI32_T, UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_nv_addNvgreVsid.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 707
if _libs["libsai.so"].has("clx_nv_delNvgreVsid", "cdecl"):
    clx_nv_delNvgreVsid = _libs["libsai.so"].get("clx_nv_delNvgreVsid", "cdecl")
    clx_nv_delNvgreVsid.argtypes = [UI32_T, UI32_T, CLX_BRIDGE_DOMAIN_T]
    clx_nv_delNvgreVsid.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 730
if _libs["libsai.so"].has("clx_nv_getNvgreVsid", "cdecl"):
    clx_nv_getNvgreVsid = _libs["libsai.so"].get("clx_nv_getNvgreVsid", "cdecl")
    clx_nv_getNvgreVsid.argtypes = [UI32_T, CLX_BRIDGE_DOMAIN_T, POINTER(UI32_T)]
    clx_nv_getNvgreVsid.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 756
if _libs["libsai.so"].has("clx_nv_addSegService", "cdecl"):
    clx_nv_addSegService = _libs["libsai.so"].get("clx_nv_addSegService", "cdecl")
    clx_nv_addSegService.argtypes = [UI32_T, UI32_T, POINTER(CLX_TUNNEL_KEY_T), POINTER(CLX_PORT_SEG_SRV_T)]
    clx_nv_addSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 781
if _libs["libsai.so"].has("clx_nv_delSegService", "cdecl"):
    clx_nv_delSegService = _libs["libsai.so"].get("clx_nv_delSegService", "cdecl")
    clx_nv_delSegService.argtypes = [UI32_T, UI32_T, POINTER(CLX_TUNNEL_KEY_T)]
    clx_nv_delSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_nv.h: 805
if _libs["libsai.so"].has("clx_nv_getSegService", "cdecl"):
    clx_nv_getSegService = _libs["libsai.so"].get("clx_nv_getSegService", "cdecl")
    clx_nv_getSegService.argtypes = [UI32_T, UI32_T, POINTER(CLX_TUNNEL_KEY_T), POINTER(CLX_PORT_SEG_SRV_T)]
    clx_nv_getSegService.restype = CLX_ERROR_NO_T

CLX_TM_HANDLER_T = UI32_T# ./clx_system/clx_sdk/include/clx_tm.h: 70

enum_anon_146 = c_int# ./clx_system/clx_sdk/include/clx_tm.h: 81

CLX_TM_BUF_TYPE_IGR_PORT = 0# ./clx_system/clx_sdk/include/clx_tm.h: 81

CLX_TM_BUF_TYPE_IGR_QUEUE = (CLX_TM_BUF_TYPE_IGR_PORT + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 81

CLX_TM_BUF_TYPE_EGR_PORT = (CLX_TM_BUF_TYPE_IGR_QUEUE + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 81

CLX_TM_BUF_TYPE_EGR_QUEUE = (CLX_TM_BUF_TYPE_EGR_PORT + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 81

CLX_TM_BUF_TYPE_IGR_SYSTEM = (CLX_TM_BUF_TYPE_EGR_QUEUE + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 81

CLX_TM_BUF_TYPE_EGR_SYSTEM = (CLX_TM_BUF_TYPE_IGR_SYSTEM + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 81

CLX_TM_BUF_TYPE_LAST = (CLX_TM_BUF_TYPE_EGR_SYSTEM + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 81

CLX_TM_BUF_TYPE_T = enum_anon_146# ./clx_system/clx_sdk/include/clx_tm.h: 81

enum_anon_147 = c_int# ./clx_system/clx_sdk/include/clx_tm.h: 90

CLX_TM_HANDLER_TYPE_NONE = 0# ./clx_system/clx_sdk/include/clx_tm.h: 90

CLX_TM_HANDLER_TYPE_UNICAST_QUEUE = (CLX_TM_HANDLER_TYPE_NONE + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 90

CLX_TM_HANDLER_TYPE_MULTICAST_QUEUE = (CLX_TM_HANDLER_TYPE_UNICAST_QUEUE + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 90

CLX_TM_HANDLER_TYPE_SCHEDULE_NODE = (CLX_TM_HANDLER_TYPE_MULTICAST_QUEUE + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 90

CLX_TM_HANDLER_TYPE_LAST = (CLX_TM_HANDLER_TYPE_SCHEDULE_NODE + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 90

CLX_TM_HANDLER_TYPE_T = enum_anon_147# ./clx_system/clx_sdk/include/clx_tm.h: 90

enum_anon_148 = c_int# ./clx_system/clx_sdk/include/clx_tm.h: 97

CLX_TM_SCH_MODE_SP = 0# ./clx_system/clx_sdk/include/clx_tm.h: 97

CLX_TM_SCH_MODE_DWRR = (CLX_TM_SCH_MODE_SP + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 97

CLX_TM_SCH_MODE_LAST = (CLX_TM_SCH_MODE_DWRR + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 97

CLX_TM_SCH_MODE_T = enum_anon_148# ./clx_system/clx_sdk/include/clx_tm.h: 97

enum_anon_149 = c_int# ./clx_system/clx_sdk/include/clx_tm.h: 104

CLX_TM_BANDWIDTH_MODE_BYTE = 0# ./clx_system/clx_sdk/include/clx_tm.h: 104

CLX_TM_BANDWIDTH_MODE_PACKET = (CLX_TM_BANDWIDTH_MODE_BYTE + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 104

CLX_TM_BANDWIDTH_MODE_LAST = (CLX_TM_BANDWIDTH_MODE_PACKET + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 104

CLX_TM_BANDWIDTH_MODE_T = enum_anon_149# ./clx_system/clx_sdk/include/clx_tm.h: 104

enum_anon_150 = c_int# ./clx_system/clx_sdk/include/clx_tm.h: 111

CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_SEPARATE = 0# ./clx_system/clx_sdk/include/clx_tm.h: 111

CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_SHARE = (CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_SEPARATE + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 111

CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_LAST = (CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_SHARE + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 111

CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_T = enum_anon_150# ./clx_system/clx_sdk/include/clx_tm.h: 111

enum_anon_151 = c_int# ./clx_system/clx_sdk/include/clx_tm.h: 141

CLX_TM_PROPERTY_BANDWIDTH_SHAPER_LAYER = 0# ./clx_system/clx_sdk/include/clx_tm.h: 141

CLX_TM_PROPERTY_SCHEDULE_DWRR_MINBW_COMBINE_MODE = (CLX_TM_PROPERTY_BANDWIDTH_SHAPER_LAYER + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 141

CLX_TM_PROPERTY_SYSTEM_ECN = (CLX_TM_PROPERTY_SCHEDULE_DWRR_MINBW_COMBINE_MODE + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 141

CLX_TM_PROPERTY_SNAPSHOT_THRESHOLD_EGR_GLOBAL = (CLX_TM_PROPERTY_SYSTEM_ECN + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 141

CLX_TM_PROPERTY_CPI_QUEUE_TRUNCATE_SIZE = (CLX_TM_PROPERTY_SNAPSHOT_THRESHOLD_EGR_GLOBAL + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 141

CLX_TM_PROPERTY_LAST = (CLX_TM_PROPERTY_CPI_QUEUE_TRUNCATE_SIZE + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 141

CLX_TM_PROPERTY_T = enum_anon_151# ./clx_system/clx_sdk/include/clx_tm.h: 141

enum_anon_152 = c_int# ./clx_system/clx_sdk/include/clx_tm.h: 159

CLX_TM_CNG_TAILDROP = 0# ./clx_system/clx_sdk/include/clx_tm.h: 159

CLX_TM_CNG_WRED = (CLX_TM_CNG_TAILDROP + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 159

CLX_TM_CNG_WRED_TCP = (CLX_TM_CNG_WRED + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 159

CLX_TM_CNG_WRED_ECN = (CLX_TM_CNG_WRED_TCP + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 159

CLX_TM_CNG_WRED_TCP_ECN = (CLX_TM_CNG_WRED_ECN + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 159

CLX_TM_CNG_DCTCP = (CLX_TM_CNG_WRED_TCP_ECN + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 159

CLX_TM_CNG_LAST = (CLX_TM_CNG_DCTCP + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 159

CLX_TM_CNG_T = enum_anon_152# ./clx_system/clx_sdk/include/clx_tm.h: 159

enum_anon_153 = c_int# ./clx_system/clx_sdk/include/clx_tm.h: 167

CLX_TM_TRAFFIC_TYPE_TCP = 0# ./clx_system/clx_sdk/include/clx_tm.h: 167

CLX_TM_TRAFFIC_TYPE_NON_TCP = (CLX_TM_TRAFFIC_TYPE_TCP + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 167

CLX_TM_TRAFFIC_TYPE_LAST = (CLX_TM_TRAFFIC_TYPE_NON_TCP + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 167

CLX_TM_TRAFFIC_TYPE_T = enum_anon_153# ./clx_system/clx_sdk/include/clx_tm.h: 167

enum_anon_154 = c_int# ./clx_system/clx_sdk/include/clx_tm.h: 175

CLX_TM_MIR_TYPE_IGR = 0# ./clx_system/clx_sdk/include/clx_tm.h: 175

CLX_TM_MIR_TYPE_EGR = (CLX_TM_MIR_TYPE_IGR + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 175

CLX_TM_MIR_TYPE_SDN = (CLX_TM_MIR_TYPE_EGR + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 175

CLX_TM_MIR_TYPE_LAST = (CLX_TM_MIR_TYPE_SDN + 1)# ./clx_system/clx_sdk/include/clx_tm.h: 175

CLX_TM_MIR_TYPE_T = enum_anon_154# ./clx_system/clx_sdk/include/clx_tm.h: 175

enum_anon_155 = c_int# ./clx_system/clx_sdk/include/clx_tm.h: 182

CLX_TM_SNAPSHOT_TYPE_PERIODIC = (1 << 0)# ./clx_system/clx_sdk/include/clx_tm.h: 182

CLX_TM_SNAPSHOT_TYPE_THRESHOLD_EGR_GLOBAL = (1 << 1)# ./clx_system/clx_sdk/include/clx_tm.h: 182

CLX_TM_SNAPSHOT_TYPE_THRESHOLD_EGR_GLOBAL_HYS = (1 << 2)# ./clx_system/clx_sdk/include/clx_tm.h: 182

CLX_TM_SNAPSHOT_BITMAP_TYPE_T = enum_anon_155# ./clx_system/clx_sdk/include/clx_tm.h: 182

# ./clx_system/clx_sdk/include/clx_tm.h: 189
class struct_CLX_TM_BUF_OCCUPANCY_S(Structure):
    pass

struct_CLX_TM_BUF_OCCUPANCY_S.__slots__ = [
    'queue_depth',
    'headroom_depth',
]
struct_CLX_TM_BUF_OCCUPANCY_S._fields_ = [
    ('queue_depth', UI32_T),
    ('headroom_depth', UI32_T),
]

CLX_TM_BUF_OCCUPANCY_T = struct_CLX_TM_BUF_OCCUPANCY_S# ./clx_system/clx_sdk/include/clx_tm.h: 189

# ./clx_system/clx_sdk/include/clx_tm.h: 196
class struct_CLX_TM_BUF_WATERMARK_S(Structure):
    pass

struct_CLX_TM_BUF_WATERMARK_S.__slots__ = [
    'queue',
    'headroom',
]
struct_CLX_TM_BUF_WATERMARK_S._fields_ = [
    ('queue', UI32_T),
    ('headroom', UI32_T),
]

CLX_TM_BUF_WATERMARK_T = struct_CLX_TM_BUF_WATERMARK_S# ./clx_system/clx_sdk/include/clx_tm.h: 196

# ./clx_system/clx_sdk/include/clx_tm.h: 219
class struct_CLX_TM_BUF_THRESHOLD_S(Structure):
    pass

struct_CLX_TM_BUF_THRESHOLD_S.__slots__ = [
    'flags',
    'min',
    'headroom',
    'hysteresis',
    'max',
]
struct_CLX_TM_BUF_THRESHOLD_S._fields_ = [
    ('flags', UI32_T),
    ('min', UI32_T),
    ('headroom', UI32_T),
    ('hysteresis', UI32_T),
    ('max', UI32_T),
]

CLX_TM_BUF_THRESHOLD_T = struct_CLX_TM_BUF_THRESHOLD_S# ./clx_system/clx_sdk/include/clx_tm.h: 219

# ./clx_system/clx_sdk/include/clx_tm.h: 228
class struct_CLX_TM_SCH_TOPOLOGY_ENTRY_S(Structure):
    pass

struct_CLX_TM_SCH_TOPOLOGY_ENTRY_S.__slots__ = [
    'handler',
    'parent_handler',
    'schedule_sequence',
]
struct_CLX_TM_SCH_TOPOLOGY_ENTRY_S._fields_ = [
    ('handler', CLX_TM_HANDLER_T),
    ('parent_handler', CLX_TM_HANDLER_T),
    ('schedule_sequence', UI32_T),
]

CLX_TM_SCH_TOPOLOGY_ENTRY_T = struct_CLX_TM_SCH_TOPOLOGY_ENTRY_S# ./clx_system/clx_sdk/include/clx_tm.h: 228

# ./clx_system/clx_sdk/include/clx_tm.h: 237
class struct_CLX_TM_BANDWIDTH_S(Structure):
    pass

struct_CLX_TM_BANDWIDTH_S.__slots__ = [
    'min_bandwidth',
    'min_burst_size',
    'max_bandwidth',
    'max_burst_size',
    'bandwidth_mode',
]
struct_CLX_TM_BANDWIDTH_S._fields_ = [
    ('min_bandwidth', UI32_T),
    ('min_burst_size', UI32_T),
    ('max_bandwidth', UI32_T),
    ('max_burst_size', UI32_T),
    ('bandwidth_mode', CLX_TM_BANDWIDTH_MODE_T),
]

CLX_TM_BANDWIDTH_T = struct_CLX_TM_BANDWIDTH_S# ./clx_system/clx_sdk/include/clx_tm.h: 237

# ./clx_system/clx_sdk/include/clx_tm.h: 245
class struct_CLX_TM_WRED_ENTRY_S(Structure):
    pass

struct_CLX_TM_WRED_ENTRY_S.__slots__ = [
    'min_threshold',
    'max_threshold',
    'max_drop_rate',
]
struct_CLX_TM_WRED_ENTRY_S._fields_ = [
    ('min_threshold', UI32_T),
    ('max_threshold', UI32_T),
    ('max_drop_rate', UI32_T),
]

CLX_TM_WRED_ENTRY_T = struct_CLX_TM_WRED_ENTRY_S# ./clx_system/clx_sdk/include/clx_tm.h: 245

# ./clx_system/clx_sdk/include/clx_tm.h: 257
class struct_CLX_TM_WRED_QUEUE_CFG_S(Structure):
    pass

struct_CLX_TM_WRED_QUEUE_CFG_S.__slots__ = [
    'profile_id',
    'weight',
]
struct_CLX_TM_WRED_QUEUE_CFG_S._fields_ = [
    ('profile_id', UI32_T),
    ('weight', UI32_T),
]

CLX_TM_WRED_QUEUE_CFG_T = struct_CLX_TM_WRED_QUEUE_CFG_S# ./clx_system/clx_sdk/include/clx_tm.h: 257

# ./clx_system/clx_sdk/include/clx_tm.h: 274
class struct_CLX_TM_DCTCP_PROFILE_S(Structure):
    pass

struct_CLX_TM_DCTCP_PROFILE_S.__slots__ = [
    'offset_green',
    'offset_yellow',
    'offset_red',
]
struct_CLX_TM_DCTCP_PROFILE_S._fields_ = [
    ('offset_green', UI32_T),
    ('offset_yellow', UI32_T),
    ('offset_red', UI32_T),
]

CLX_TM_DCTCP_PROFILE_T = struct_CLX_TM_DCTCP_PROFILE_S# ./clx_system/clx_sdk/include/clx_tm.h: 274

# ./clx_system/clx_sdk/include/clx_tm.h: 289
class struct_CLX_TM_IGR_PORT_BUF_SNAPSHOT_S(Structure):
    pass

struct_CLX_TM_IGR_PORT_BUF_SNAPSHOT_S.__slots__ = [
    'port_id',
    'pcp_group0',
    'pcp_group1',
    'pcp_group2',
    'pcp_group3',
    'pcp_group4',
    'pcp_group5',
    'pcp_group6',
    'pcp_group7',
]
struct_CLX_TM_IGR_PORT_BUF_SNAPSHOT_S._fields_ = [
    ('port_id', UI32_T),
    ('pcp_group0', UI32_T),
    ('pcp_group1', UI32_T),
    ('pcp_group2', UI32_T),
    ('pcp_group3', UI32_T),
    ('pcp_group4', UI32_T),
    ('pcp_group5', UI32_T),
    ('pcp_group6', UI32_T),
    ('pcp_group7', UI32_T),
]

CLX_TM_IGR_PORT_BUF_SNAPSHOT_T = struct_CLX_TM_IGR_PORT_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 289

# ./clx_system/clx_sdk/include/clx_tm.h: 298
class struct_CLX_TM_IGR_BUF_SNAPSHOT_S(Structure):
    pass

struct_CLX_TM_IGR_BUF_SNAPSHOT_S.__slots__ = [
    'global_lossless',
    'global_headroom',
    'port_cnt',
    'ptr_port_buf',
]
struct_CLX_TM_IGR_BUF_SNAPSHOT_S._fields_ = [
    ('global_lossless', UI32_T),
    ('global_headroom', UI32_T),
    ('port_cnt', UI32_T),
    ('ptr_port_buf', POINTER(CLX_TM_IGR_PORT_BUF_SNAPSHOT_T)),
]

CLX_TM_IGR_BUF_SNAPSHOT_T = struct_CLX_TM_IGR_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 298

# ./clx_system/clx_sdk/include/clx_tm.h: 320
class struct_CLX_TM_EGR_PORT_BUF_SNAPSHOT_S(Structure):
    pass

struct_CLX_TM_EGR_PORT_BUF_SNAPSHOT_S.__slots__ = [
    'port_id',
    'uc_group0',
    'uc_group1',
    'uc_group2',
    'uc_group3',
    'uc_group4',
    'uc_group5',
    'uc_group6',
    'uc_group7',
    'mc_group0',
    'mc_group1',
    'mc_group2',
    'mc_group3',
    'mc_group4',
    'mc_group5',
    'mc_group6',
    'mc_group7',
]
struct_CLX_TM_EGR_PORT_BUF_SNAPSHOT_S._fields_ = [
    ('port_id', UI32_T),
    ('uc_group0', UI32_T),
    ('uc_group1', UI32_T),
    ('uc_group2', UI32_T),
    ('uc_group3', UI32_T),
    ('uc_group4', UI32_T),
    ('uc_group5', UI32_T),
    ('uc_group6', UI32_T),
    ('uc_group7', UI32_T),
    ('mc_group0', UI32_T),
    ('mc_group1', UI32_T),
    ('mc_group2', UI32_T),
    ('mc_group3', UI32_T),
    ('mc_group4', UI32_T),
    ('mc_group5', UI32_T),
    ('mc_group6', UI32_T),
    ('mc_group7', UI32_T),
]

CLX_TM_EGR_PORT_BUF_SNAPSHOT_T = struct_CLX_TM_EGR_PORT_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 320

# ./clx_system/clx_sdk/include/clx_tm.h: 327
class struct_CLX_TM_EGR_CPU_QUEUE_BUF_SNAPSHOT_S(Structure):
    pass

struct_CLX_TM_EGR_CPU_QUEUE_BUF_SNAPSHOT_S.__slots__ = [
    'id',
    'depth',
]
struct_CLX_TM_EGR_CPU_QUEUE_BUF_SNAPSHOT_S._fields_ = [
    ('id', UI32_T),
    ('depth', UI32_T),
]

CLX_TM_EGR_CPU_QUEUE_BUF_SNAPSHOT_T = struct_CLX_TM_EGR_CPU_QUEUE_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 327

# ./clx_system/clx_sdk/include/clx_tm.h: 337
class struct_CLX_TM_EGR_BUF_SNAPSHOT_S(Structure):
    pass

struct_CLX_TM_EGR_BUF_SNAPSHOT_S.__slots__ = [
    'global_share',
    'cpu_queue_cnt',
    'ptr_cpu_queue_buf',
    'port_cnt',
    'ptr_port_buf',
]
struct_CLX_TM_EGR_BUF_SNAPSHOT_S._fields_ = [
    ('global_share', UI32_T),
    ('cpu_queue_cnt', UI32_T),
    ('ptr_cpu_queue_buf', POINTER(CLX_TM_EGR_CPU_QUEUE_BUF_SNAPSHOT_T)),
    ('port_cnt', UI32_T),
    ('ptr_port_buf', POINTER(CLX_TM_EGR_PORT_BUF_SNAPSHOT_T)),
]

CLX_TM_EGR_BUF_SNAPSHOT_T = struct_CLX_TM_EGR_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 337

# ./clx_system/clx_sdk/include/clx_tm.h: 344
class struct_CLX_TM_POOL_BUF_SNAPSHOT_S(Structure):
    pass

struct_CLX_TM_POOL_BUF_SNAPSHOT_S.__slots__ = [
    'pool_id',
    'igr_buf',
    'egr_buf',
]
struct_CLX_TM_POOL_BUF_SNAPSHOT_S._fields_ = [
    ('pool_id', UI32_T),
    ('igr_buf', CLX_TM_IGR_BUF_SNAPSHOT_T),
    ('egr_buf', CLX_TM_EGR_BUF_SNAPSHOT_T),
]

CLX_TM_POOL_BUF_SNAPSHOT_T = struct_CLX_TM_POOL_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 344

CLX_TM_SNAPSHOT_FUNC_T = CFUNCTYPE(UNCHECKED(None), UI32_T, CLX_TM_SNAPSHOT_BITMAP_TYPE_T, UI32_T, POINTER(CLX_TM_POOL_BUF_SNAPSHOT_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_tm.h: 347

# ./clx_system/clx_sdk/include/clx_tm.h: 384
if _libs["libsai.so"].has("clx_tm_createHandler", "cdecl"):
    clx_tm_createHandler = _libs["libsai.so"].get("clx_tm_createHandler", "cdecl")
    clx_tm_createHandler.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_TYPE_T, UI32_T, POINTER(CLX_TM_HANDLER_T)]
    clx_tm_createHandler.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 413
if _libs["libsai.so"].has("clx_tm_deleteHandler", "cdecl"):
    clx_tm_deleteHandler = _libs["libsai.so"].get("clx_tm_deleteHandler", "cdecl")
    clx_tm_deleteHandler.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T]
    clx_tm_deleteHandler.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 439
if _libs["libsai.so"].has("clx_tm_setScheduleTopology", "cdecl"):
    clx_tm_setScheduleTopology = _libs["libsai.so"].get("clx_tm_setScheduleTopology", "cdecl")
    clx_tm_setScheduleTopology.argtypes = [UI32_T, UI32_T, POINTER(CLX_TM_SCH_TOPOLOGY_ENTRY_T), UI32_T]
    clx_tm_setScheduleTopology.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 464
if _libs["libsai.so"].has("clx_tm_getScheduleTopology", "cdecl"):
    clx_tm_getScheduleTopology = _libs["libsai.so"].get("clx_tm_getScheduleTopology", "cdecl")
    clx_tm_getScheduleTopology.argtypes = [UI32_T, UI32_T, POINTER(CLX_TM_SCH_TOPOLOGY_ENTRY_T), UI32_T, POINTER(UI32_T)]
    clx_tm_getScheduleTopology.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 491
if _libs["libsai.so"].has("clx_tm_setScheduleMode", "cdecl"):
    clx_tm_setScheduleMode = _libs["libsai.so"].get("clx_tm_setScheduleMode", "cdecl")
    clx_tm_setScheduleMode.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, CLX_TM_SCH_MODE_T, UI32_T]
    clx_tm_setScheduleMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 517
if _libs["libsai.so"].has("clx_tm_getScheduleMode", "cdecl"):
    clx_tm_getScheduleMode = _libs["libsai.so"].get("clx_tm_getScheduleMode", "cdecl")
    clx_tm_getScheduleMode.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(CLX_TM_SCH_MODE_T), POINTER(UI32_T)]
    clx_tm_getScheduleMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 545
if _libs["libsai.so"].has("clx_tm_setBandwidth", "cdecl"):
    clx_tm_setBandwidth = _libs["libsai.so"].get("clx_tm_setBandwidth", "cdecl")
    clx_tm_setBandwidth.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(CLX_TM_BANDWIDTH_T)]
    clx_tm_setBandwidth.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 568
if _libs["libsai.so"].has("clx_tm_getBandwidth", "cdecl"):
    clx_tm_getBandwidth = _libs["libsai.so"].get("clx_tm_getBandwidth", "cdecl")
    clx_tm_getBandwidth.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(CLX_TM_BANDWIDTH_T)]
    clx_tm_getBandwidth.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 597
if _libs["libsai.so"].has("clx_tm_setTcQueueMapping", "cdecl"):
    clx_tm_setTcQueueMapping = _libs["libsai.so"].get("clx_tm_setTcQueueMapping", "cdecl")
    clx_tm_setTcQueueMapping.argtypes = [UI32_T, UI32_T, UI32_T, CLX_TM_HANDLER_TYPE_T, CLX_TM_HANDLER_T]
    clx_tm_setTcQueueMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 626
if _libs["libsai.so"].has("clx_tm_getTcQueueMapping", "cdecl"):
    clx_tm_getTcQueueMapping = _libs["libsai.so"].get("clx_tm_getTcQueueMapping", "cdecl")
    clx_tm_getTcQueueMapping.argtypes = [UI32_T, UI32_T, UI32_T, CLX_TM_HANDLER_TYPE_T, POINTER(CLX_TM_HANDLER_T)]
    clx_tm_getTcQueueMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 651
if _libs["libsai.so"].has("clx_tm_setIgrBufPcpRemap", "cdecl"):
    clx_tm_setIgrBufPcpRemap = _libs["libsai.so"].get("clx_tm_setIgrBufPcpRemap", "cdecl")
    clx_tm_setIgrBufPcpRemap.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T]
    clx_tm_setIgrBufPcpRemap.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 675
if _libs["libsai.so"].has("clx_tm_getIgrBufPcpRemap", "cdecl"):
    clx_tm_getIgrBufPcpRemap = _libs["libsai.so"].get("clx_tm_getIgrBufPcpRemap", "cdecl")
    clx_tm_getIgrBufPcpRemap.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(UI32_T)]
    clx_tm_getIgrBufPcpRemap.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 700
if _libs["libsai.so"].has("clx_tm_setEgrBufPfcPcpRemapQueue", "cdecl"):
    clx_tm_setEgrBufPfcPcpRemapQueue = _libs["libsai.so"].get("clx_tm_setEgrBufPfcPcpRemapQueue", "cdecl")
    clx_tm_setEgrBufPfcPcpRemapQueue.argtypes = [UI32_T, UI32_T, UI32_T, CLX_TM_HANDLER_T]
    clx_tm_setEgrBufPfcPcpRemapQueue.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 724
if _libs["libsai.so"].has("clx_tm_getEgrBufPfcPcpRemapQueue", "cdecl"):
    clx_tm_getEgrBufPfcPcpRemapQueue = _libs["libsai.so"].get("clx_tm_getEgrBufPfcPcpRemapQueue", "cdecl")
    clx_tm_getEgrBufPfcPcpRemapQueue.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(CLX_TM_HANDLER_T)]
    clx_tm_getEgrBufPfcPcpRemapQueue.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 756
if _libs["libsai.so"].has("clx_tm_setProperty", "cdecl"):
    clx_tm_setProperty = _libs["libsai.so"].get("clx_tm_setProperty", "cdecl")
    clx_tm_setProperty.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, CLX_TM_PROPERTY_T, UI32_T, UI32_T]
    clx_tm_setProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 789
if _libs["libsai.so"].has("clx_tm_getProperty", "cdecl"):
    clx_tm_getProperty = _libs["libsai.so"].get("clx_tm_getProperty", "cdecl")
    clx_tm_getProperty.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, CLX_TM_PROPERTY_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_tm_getProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 815
if _libs["libsai.so"].has("clx_tm_setCngCtrl", "cdecl"):
    clx_tm_setCngCtrl = _libs["libsai.so"].get("clx_tm_setCngCtrl", "cdecl")
    clx_tm_setCngCtrl.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, CLX_TM_CNG_T]
    clx_tm_setCngCtrl.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 838
if _libs["libsai.so"].has("clx_tm_getCngCtrl", "cdecl"):
    clx_tm_getCngCtrl = _libs["libsai.so"].get("clx_tm_getCngCtrl", "cdecl")
    clx_tm_getCngCtrl.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(CLX_TM_CNG_T)]
    clx_tm_getCngCtrl.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 861
if _libs["libsai.so"].has("clx_tm_createWredProfile", "cdecl"):
    clx_tm_createWredProfile = _libs["libsai.so"].get("clx_tm_createWredProfile", "cdecl")
    clx_tm_createWredProfile.argtypes = [UI32_T, UI32_T]
    clx_tm_createWredProfile.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 882
if _libs["libsai.so"].has("clx_tm_delWredProfile", "cdecl"):
    clx_tm_delWredProfile = _libs["libsai.so"].get("clx_tm_delWredProfile", "cdecl")
    clx_tm_delWredProfile.argtypes = [UI32_T, UI32_T]
    clx_tm_delWredProfile.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 908
if _libs["libsai.so"].has("clx_tm_setWredProfile", "cdecl"):
    clx_tm_setWredProfile = _libs["libsai.so"].get("clx_tm_setWredProfile", "cdecl")
    clx_tm_setWredProfile.argtypes = [UI32_T, UI32_T, CLX_TM_TRAFFIC_TYPE_T, CLX_COLOR_T, POINTER(CLX_TM_WRED_ENTRY_T)]
    clx_tm_setWredProfile.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 936
if _libs["libsai.so"].has("clx_tm_getWredProfile", "cdecl"):
    clx_tm_getWredProfile = _libs["libsai.so"].get("clx_tm_getWredProfile", "cdecl")
    clx_tm_getWredProfile.argtypes = [UI32_T, UI32_T, CLX_TM_TRAFFIC_TYPE_T, CLX_COLOR_T, POINTER(CLX_TM_WRED_ENTRY_T)]
    clx_tm_getWredProfile.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 962
if _libs["libsai.so"].has("clx_tm_setWredQueueConfig", "cdecl"):
    clx_tm_setWredQueueConfig = _libs["libsai.so"].get("clx_tm_setWredQueueConfig", "cdecl")
    clx_tm_setWredQueueConfig.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(CLX_TM_WRED_QUEUE_CFG_T)]
    clx_tm_setWredQueueConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 986
if _libs["libsai.so"].has("clx_tm_getWredQueueConfig", "cdecl"):
    clx_tm_getWredQueueConfig = _libs["libsai.so"].get("clx_tm_getWredQueueConfig", "cdecl")
    clx_tm_getWredQueueConfig.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(CLX_TM_WRED_QUEUE_CFG_T)]
    clx_tm_getWredQueueConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1009
if _libs["libsai.so"].has("clx_tm_createDctcpProfile", "cdecl"):
    clx_tm_createDctcpProfile = _libs["libsai.so"].get("clx_tm_createDctcpProfile", "cdecl")
    clx_tm_createDctcpProfile.argtypes = [UI32_T, UI32_T]
    clx_tm_createDctcpProfile.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1030
if _libs["libsai.so"].has("clx_tm_delDctcpProfile", "cdecl"):
    clx_tm_delDctcpProfile = _libs["libsai.so"].get("clx_tm_delDctcpProfile", "cdecl")
    clx_tm_delDctcpProfile.argtypes = [UI32_T, UI32_T]
    clx_tm_delDctcpProfile.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1052
if _libs["libsai.so"].has("clx_tm_setDctcpProfile", "cdecl"):
    clx_tm_setDctcpProfile = _libs["libsai.so"].get("clx_tm_setDctcpProfile", "cdecl")
    clx_tm_setDctcpProfile.argtypes = [UI32_T, UI32_T, POINTER(CLX_TM_DCTCP_PROFILE_T)]
    clx_tm_setDctcpProfile.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1074
if _libs["libsai.so"].has("clx_tm_getDctcpProfile", "cdecl"):
    clx_tm_getDctcpProfile = _libs["libsai.so"].get("clx_tm_getDctcpProfile", "cdecl")
    clx_tm_getDctcpProfile.argtypes = [UI32_T, UI32_T, POINTER(CLX_TM_DCTCP_PROFILE_T)]
    clx_tm_getDctcpProfile.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1098
if _libs["libsai.so"].has("clx_tm_setDctcpQueueConfig", "cdecl"):
    clx_tm_setDctcpQueueConfig = _libs["libsai.so"].get("clx_tm_setDctcpQueueConfig", "cdecl")
    clx_tm_setDctcpQueueConfig.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, UI32_T]
    clx_tm_setDctcpQueueConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1122
if _libs["libsai.so"].has("clx_tm_getDctcpQueueConfig", "cdecl"):
    clx_tm_getDctcpQueueConfig = _libs["libsai.so"].get("clx_tm_getDctcpQueueConfig", "cdecl")
    clx_tm_getDctcpQueueConfig.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(UI32_T)]
    clx_tm_getDctcpQueueConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1144
if _libs["libsai.so"].has("clx_tm_setPfcMapping", "cdecl"):
    clx_tm_setPfcMapping = _libs["libsai.so"].get("clx_tm_setPfcMapping", "cdecl")
    clx_tm_setPfcMapping.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, UI32_T]
    clx_tm_setPfcMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1165
if _libs["libsai.so"].has("clx_tm_getPfcMapping", "cdecl"):
    clx_tm_getPfcMapping = _libs["libsai.so"].get("clx_tm_getPfcMapping", "cdecl")
    clx_tm_getPfcMapping.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(UI32_T)]
    clx_tm_getPfcMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1189
if _libs["libsai.so"].has("clx_tm_setPcpPfcMapping", "cdecl"):
    clx_tm_setPcpPfcMapping = _libs["libsai.so"].get("clx_tm_setPcpPfcMapping", "cdecl")
    clx_tm_setPcpPfcMapping.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, UI32_T]
    clx_tm_setPcpPfcMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1211
if _libs["libsai.so"].has("clx_tm_getPcpPfcMapping", "cdecl"):
    clx_tm_getPcpPfcMapping = _libs["libsai.so"].get("clx_tm_getPcpPfcMapping", "cdecl")
    clx_tm_getPcpPfcMapping.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(UI32_T)]
    clx_tm_getPcpPfcMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1235
if _libs["libsai.so"].has("clx_tm_setDscpPfcMapping", "cdecl"):
    clx_tm_setDscpPfcMapping = _libs["libsai.so"].get("clx_tm_setDscpPfcMapping", "cdecl")
    clx_tm_setDscpPfcMapping.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, UI32_T, POINTER(UI32_T)]
    clx_tm_setDscpPfcMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1259
if _libs["libsai.so"].has("clx_tm_getDscpPfcMapping", "cdecl"):
    clx_tm_getDscpPfcMapping = _libs["libsai.so"].get("clx_tm_getDscpPfcMapping", "cdecl")
    clx_tm_getDscpPfcMapping.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_tm_getDscpPfcMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1283
if _libs["libsai.so"].has("clx_tm_setQueuePfcPriMapping", "cdecl"):
    clx_tm_setQueuePfcPriMapping = _libs["libsai.so"].get("clx_tm_setQueuePfcPriMapping", "cdecl")
    clx_tm_setQueuePfcPriMapping.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, UI32_T]
    clx_tm_setQueuePfcPriMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1305
if _libs["libsai.so"].has("clx_tm_getQueuePfcPriMapping", "cdecl"):
    clx_tm_getQueuePfcPriMapping = _libs["libsai.so"].get("clx_tm_getQueuePfcPriMapping", "cdecl")
    clx_tm_getQueuePfcPriMapping.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(UI32_T)]
    clx_tm_getQueuePfcPriMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1328
if _libs["libsai.so"].has("clx_tm_setPfcPriQueueMapping", "cdecl"):
    clx_tm_setPfcPriQueueMapping = _libs["libsai.so"].get("clx_tm_setPfcPriQueueMapping", "cdecl")
    clx_tm_setPfcPriQueueMapping.argtypes = [UI32_T, UI32_T, UI32_T, CLX_TM_HANDLER_T]
    clx_tm_setPfcPriQueueMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1350
if _libs["libsai.so"].has("clx_tm_getPfcPriQueueMapping", "cdecl"):
    clx_tm_getPfcPriQueueMapping = _libs["libsai.so"].get("clx_tm_getPfcPriQueueMapping", "cdecl")
    clx_tm_getPfcPriQueueMapping.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(UI32_T)]
    clx_tm_getPfcPriQueueMapping.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1373
if _libs["libsai.so"].has("clx_tm_setBufThreshold", "cdecl"):
    clx_tm_setBufThreshold = _libs["libsai.so"].get("clx_tm_setBufThreshold", "cdecl")
    clx_tm_setBufThreshold.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, CLX_TM_BUF_TYPE_T, POINTER(CLX_TM_BUF_THRESHOLD_T)]
    clx_tm_setBufThreshold.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1400
if _libs["libsai.so"].has("clx_tm_getBufThreshold", "cdecl"):
    clx_tm_getBufThreshold = _libs["libsai.so"].get("clx_tm_getBufThreshold", "cdecl")
    clx_tm_getBufThreshold.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, CLX_TM_BUF_TYPE_T, POINTER(CLX_TM_BUF_THRESHOLD_T)]
    clx_tm_getBufThreshold.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1427
if _libs["libsai.so"].has("clx_tm_getBufOccupancy", "cdecl"):
    clx_tm_getBufOccupancy = _libs["libsai.so"].get("clx_tm_getBufOccupancy", "cdecl")
    clx_tm_getBufOccupancy.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, CLX_TM_BUF_TYPE_T, POINTER(CLX_TM_BUF_OCCUPANCY_T)]
    clx_tm_getBufOccupancy.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1454
if _libs["libsai.so"].has("clx_tm_getBufWatermark", "cdecl"):
    clx_tm_getBufWatermark = _libs["libsai.so"].get("clx_tm_getBufWatermark", "cdecl")
    clx_tm_getBufWatermark.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, CLX_TM_BUF_TYPE_T, POINTER(CLX_TM_BUF_WATERMARK_T)]
    clx_tm_getBufWatermark.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1481
if _libs["libsai.so"].has("clx_tm_clearBufWatermark", "cdecl"):
    clx_tm_clearBufWatermark = _libs["libsai.so"].get("clx_tm_clearBufWatermark", "cdecl")
    clx_tm_clearBufWatermark.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, CLX_TM_BUF_TYPE_T]
    clx_tm_clearBufWatermark.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1508
if _libs["libsai.so"].has("clx_tm_getBufWatermarkList", "cdecl"):
    clx_tm_getBufWatermarkList = _libs["libsai.so"].get("clx_tm_getBufWatermarkList", "cdecl")
    clx_tm_getBufWatermarkList.argtypes = [UI32_T, UI32_T, POINTER(CLX_TM_HANDLER_T), CLX_TM_BUF_TYPE_T, UI32_T, POINTER(CLX_TM_BUF_WATERMARK_T)]
    clx_tm_getBufWatermarkList.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1537
if _libs["libsai.so"].has("clx_tm_clearBufWatermarkList", "cdecl"):
    clx_tm_clearBufWatermarkList = _libs["libsai.so"].get("clx_tm_clearBufWatermarkList", "cdecl")
    clx_tm_clearBufWatermarkList.argtypes = [UI32_T, UI32_T, POINTER(CLX_TM_HANDLER_T), CLX_TM_BUF_TYPE_T, UI32_T]
    clx_tm_clearBufWatermarkList.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1564
if _libs["libsai.so"].has("clx_tm_registerBufSnapshotCallback", "cdecl"):
    clx_tm_registerBufSnapshotCallback = _libs["libsai.so"].get("clx_tm_registerBufSnapshotCallback", "cdecl")
    clx_tm_registerBufSnapshotCallback.argtypes = [UI32_T, CLX_TM_SNAPSHOT_FUNC_T, POINTER(None)]
    clx_tm_registerBufSnapshotCallback.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1586
if _libs["libsai.so"].has("clx_tm_deregisterBufSnapshotCallback", "cdecl"):
    clx_tm_deregisterBufSnapshotCallback = _libs["libsai.so"].get("clx_tm_deregisterBufSnapshotCallback", "cdecl")
    clx_tm_deregisterBufSnapshotCallback.argtypes = [UI32_T, CLX_TM_SNAPSHOT_FUNC_T, POINTER(None)]
    clx_tm_deregisterBufSnapshotCallback.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_tm.h: 1610
if _libs["libsai.so"].has("clx_tm_getPauseStatus", "cdecl"):
    clx_tm_getPauseStatus = _libs["libsai.so"].get("clx_tm_getPauseStatus", "cdecl")
    clx_tm_getPauseStatus.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, POINTER(UI32_T)]
    clx_tm_getPauseStatus.restype = CLX_ERROR_NO_T

enum_anon_156 = c_int# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_IPV4_HDR_ERROR = 0# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_IPV6_HDR_ERROR = (CLX_SWC_PROPERTY_IPV4_HDR_ERROR + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_TCP_HDR_ERROR = (CLX_SWC_PROPERTY_IPV6_HDR_ERROR + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_UDP_HDR_ERROR = (CLX_SWC_PROPERTY_TCP_HDR_ERROR + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_ETHER_LEN_ERROR = (CLX_SWC_PROPERTY_UDP_HDR_ERROR + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_GLOBAL_ROUTE_MISS_ACTION = (CLX_SWC_PROPERTY_ETHER_LEN_ERROR + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_METER_COLOR_RESOLVE_MODE = (CLX_SWC_PROPERTY_GLOBAL_ROUTE_MISS_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L2_AGING_TIME = (CLX_SWC_PROPERTY_METER_COLOR_RESOLVE_MODE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_PENDING_LEARN = (CLX_SWC_PROPERTY_L2_AGING_TIME + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_ICMP_REDIRECT = (CLX_SWC_PROPERTY_PENDING_LEARN + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_SELF_FORWARD = (CLX_SWC_PROPERTY_ICMP_REDIRECT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_URPF = (CLX_SWC_PROPERTY_L3_SELF_FORWARD + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_MCAST_ADDR_VALIDATE = (CLX_SWC_PROPERTY_L3_URPF + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_VXLAN_ROUTER_ALERT = (CLX_SWC_PROPERTY_L3_MCAST_ADDR_VALIDATE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_VXLAN_UDP_PORT = (CLX_SWC_PROPERTY_VXLAN_ROUTER_ALERT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_VXLAN_PROTOCOL = (CLX_SWC_PROPERTY_VXLAN_UDP_PORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_VXLAN_GPE = (CLX_SWC_PROPERTY_VXLAN_PROTOCOL + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_VXLAN_PING = (CLX_SWC_PROPERTY_VXLAN_GPE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_NVGRE_ROUTER_ALERT = (CLX_SWC_PROPERTY_VXLAN_PING + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_NIV_SRC_VIF = (CLX_SWC_PROPERTY_NVGRE_ROUTER_ALERT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_VM_FCOE_TRANS_MODE = (CLX_SWC_PROPERTY_NIV_SRC_VIF + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_MIR_ERSPAN_MISS_ACTION = (CLX_SWC_PROPERTY_VM_FCOE_TRANS_MODE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_MIR_METER_LAYER = (CLX_SWC_PROPERTY_MIR_ERSPAN_MISS_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_STORM_CTRL_METER_LAYER = (CLX_SWC_PROPERTY_MIR_METER_LAYER + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_STORM_CTRL_CTRL_PKT_CHECK = (CLX_SWC_PROPERTY_STORM_CTRL_METER_LAYER + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_SOURCE_GUARD_DHCP_PKT_CHECK = (CLX_SWC_PROPERTY_STORM_CTRL_CTRL_PKT_CHECK + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_FCOE_CLV_SWITCH_ENABLE = (CLX_SWC_PROPERTY_SOURCE_GUARD_DHCP_PKT_CHECK + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_FCOE_DROP_UNKNOWN_MAC = (CLX_SWC_PROPERTY_FCOE_CLV_SWITCH_ENABLE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_STEERING_EN = (CLX_SWC_PROPERTY_FCOE_DROP_UNKNOWN_MAC + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L2_SA_MOVE_ACTION = (CLX_SWC_PROPERTY_STEERING_EN + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_IPV4_MC_MISS_ACTION = (CLX_SWC_PROPERTY_L2_SA_MOVE_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_IPV6_MC_MISS_ACTION = (CLX_SWC_PROPERTY_L3_IPV4_MC_MISS_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_IPV4_OPT_HDR_ACTION = (CLX_SWC_PROPERTY_L3_IPV6_MC_MISS_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_IPV6_OPT_HDR_ACTION = (CLX_SWC_PROPERTY_L3_IPV4_OPT_HDR_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_IGR_MTU_FAIL_ACTION = (CLX_SWC_PROPERTY_L3_IPV6_OPT_HDR_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_EGR_MTU_FAIL_ACTION = (CLX_SWC_PROPERTY_L3_IGR_MTU_FAIL_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_TTL0_ACTION = (CLX_SWC_PROPERTY_L3_EGR_MTU_FAIL_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_IGR_TTL1_ACTION = (CLX_SWC_PROPERTY_L3_TTL0_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_EGR_TTL1_ACTION = (CLX_SWC_PROPERTY_L3_IGR_TTL1_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3T_TTL0_ACTION = (CLX_SWC_PROPERTY_L3_EGR_TTL1_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3T_TTL1_ACTION = (CLX_SWC_PROPERTY_L3T_TTL0_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3_ECMP_BLOCK_SIZE = (CLX_SWC_PROPERTY_L3T_TTL1_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_KEEP_DEI = (CLX_SWC_PROPERTY_L3_ECMP_BLOCK_SIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_SAMPLE_HIGH_LATENCY_THRESHOLD = (CLX_SWC_PROPERTY_KEEP_DEI + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_DTEL_IFA_MIR_ID = (CLX_SWC_PROPERTY_SAMPLE_HIGH_LATENCY_THRESHOLD + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_DTEL_IFA_STEER_MIR = (CLX_SWC_PROPERTY_DTEL_IFA_MIR_ID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_DTEL_IOAM_COPY_TO_CPU = (CLX_SWC_PROPERTY_DTEL_IFA_STEER_MIR + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_DTEL_IOAM_LOOPBACK_TO_CPU = (CLX_SWC_PROPERTY_DTEL_IOAM_COPY_TO_CPU + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_DTEL_IOAM_EXCEPTION_TO_CPU = (CLX_SWC_PROPERTY_DTEL_IOAM_LOOPBACK_TO_CPU + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_ECN_REMARK_USE_INNER_TCP = (CLX_SWC_PROPERTY_DTEL_IOAM_EXCEPTION_TO_CPU + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_L3T_LINK_LOCAL_ACTION = (CLX_SWC_PROPERTY_ECN_REMARK_USE_INNER_TCP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_DTEL_IFA_ENABLE = (CLX_SWC_PROPERTY_L3T_LINK_LOCAL_ACTION + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_DTEL_DPP_ENABLE = (CLX_SWC_PROPERTY_DTEL_IFA_ENABLE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_LAST = (CLX_SWC_PROPERTY_DTEL_DPP_ENABLE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 120

CLX_SWC_PROPERTY_T = enum_anon_156# ./clx_system/clx_sdk/include/clx_swc.h: 120

enum_anon_157 = c_int# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_L2_OUTER_VID = 0# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_L2_INNER_VID = (CLX_SWC_HASH_KEY_TYPE_OUTER_L2_OUTER_VID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_L2_ETHERTYPE = (CLX_SWC_HASH_KEY_TYPE_OUTER_L2_INNER_VID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_L2_DMAC = (CLX_SWC_HASH_KEY_TYPE_OUTER_L2_ETHERTYPE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_L2_SMAC = (CLX_SWC_HASH_KEY_TYPE_OUTER_L2_DMAC + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_L2_MAC_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_OUTER_L2_SMAC + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_FLOW_LABEL = (CLX_SWC_HASH_KEY_TYPE_OUTER_L2_MAC_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_NEXT_HEADER = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_FLOW_LABEL + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_DIP = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_NEXT_HEADER + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_SIP = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_DIP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_IP_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_SIP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_DPORT = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_IP_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_SPORT = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_DPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_PORT_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_SPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_PROTOCOL = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_PORT_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_DIP = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_PROTOCOL + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_SIP = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_DIP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_IP_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_SIP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_DPORT = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_IP_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_SPORT = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_DPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_PORT_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_SPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_TRILL_FGL = (CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_PORT_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_TRILL_VL = (CLX_SWC_HASH_KEY_TYPE_TRILL_FGL + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_TRILL_EGR_RN = (CLX_SWC_HASH_KEY_TYPE_TRILL_VL + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_TRILL_IGR_RN = (CLX_SWC_HASH_KEY_TYPE_TRILL_EGR_RN + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_TRILL_RN_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_TRILL_IGR_RN + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_GENEVE_VNI_IPV6 = (CLX_SWC_HASH_KEY_TYPE_TRILL_RN_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_GENEVE_VNI_IPV4 = (CLX_SWC_HASH_KEY_TYPE_GENEVE_VNI_IPV6 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_GRE_FLOWID_IPV4 = (CLX_SWC_HASH_KEY_TYPE_GENEVE_VNI_IPV4 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_GRE_FLOWID_IPV6 = (CLX_SWC_HASH_KEY_TYPE_GRE_FLOWID_IPV4 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_VXLAN_VNI_IPV4 = (CLX_SWC_HASH_KEY_TYPE_GRE_FLOWID_IPV6 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_VXLAN_VNI_IPV6 = (CLX_SWC_HASH_KEY_TYPE_VXLAN_VNI_IPV4 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_NVGRE_VSID_IPV4 = (CLX_SWC_HASH_KEY_TYPE_VXLAN_VNI_IPV6 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_NVGRE_VSID_IPV6 = (CLX_SWC_HASH_KEY_TYPE_NVGRE_VSID_IPV4 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL0 = (CLX_SWC_HASH_KEY_TYPE_NVGRE_VSID_IPV6 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL1 = (CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL0 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL2 = (CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL1 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL3 = (CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL2 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL4 = (CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL3 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_NSH_SRV_IDX = (CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL4 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_NSH_SRV_PATH = (CLX_SWC_HASH_KEY_TYPE_NSH_SRV_IDX + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_VNTAG_SVMID = (CLX_SWC_HASH_KEY_TYPE_NSH_SRV_PATH + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_VNTAG_DVMID = (CLX_SWC_HASH_KEY_TYPE_VNTAG_SVMID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_ETAG_SVMID = (CLX_SWC_HASH_KEY_TYPE_VNTAG_DVMID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_ETAG_DVMID = (CLX_SWC_HASH_KEY_TYPE_ETAG_SVMID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_VEPA_SVID = (CLX_SWC_HASH_KEY_TYPE_ETAG_DVMID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_L2_OUTER_VID = (CLX_SWC_HASH_KEY_TYPE_VEPA_SVID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_L2_INNER_VID = (CLX_SWC_HASH_KEY_TYPE_L2_OUTER_VID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_L2_ETHERTYPE = (CLX_SWC_HASH_KEY_TYPE_L2_INNER_VID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_L2_DMAC = (CLX_SWC_HASH_KEY_TYPE_L2_ETHERTYPE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_L2_SMAC = (CLX_SWC_HASH_KEY_TYPE_L2_DMAC + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_L2_MAC_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_L2_SMAC + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_FLOW_LABEL = (CLX_SWC_HASH_KEY_TYPE_L2_MAC_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_NEXT_HEADER = (CLX_SWC_HASH_KEY_TYPE_IPV6_FLOW_LABEL + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_DIP = (CLX_SWC_HASH_KEY_TYPE_IPV6_NEXT_HEADER + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_SIP = (CLX_SWC_HASH_KEY_TYPE_IPV6_DIP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_IP_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_IPV6_SIP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_DPORT = (CLX_SWC_HASH_KEY_TYPE_IPV6_IP_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_SPORT = (CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_DPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_PORT_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_SPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_DPORT = (CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_PORT_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_SPORT = (CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_DPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_PORT_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_SPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_DPORT = (CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_PORT_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_SPORT = (CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_DPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_PORT_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_SPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_PROTOCOL = (CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_PORT_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_DIP = (CLX_SWC_HASH_KEY_TYPE_IPV4_PROTOCOL + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_SIP = (CLX_SWC_HASH_KEY_TYPE_IPV4_DIP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_IP_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_IPV4_SIP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_DPORT = (CLX_SWC_HASH_KEY_TYPE_IPV4_IP_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_SPORT = (CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_DPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_PORT_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_SPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_DPORT = (CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_PORT_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_SPORT = (CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_DPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_PORT_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_SPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_DPORT = (CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_PORT_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_SPORT = (CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_DPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_PORT_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_SPORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_FCOE_VFID = (CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_PORT_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_FCOE_SEQID = (CLX_SWC_HASH_KEY_TYPE_FCOE_VFID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_FCOE_DID = (CLX_SWC_HASH_KEY_TYPE_FCOE_SEQID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_FCOE_SID = (CLX_SWC_HASH_KEY_TYPE_FCOE_DID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_FCOE_ID_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_FCOE_SID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_FCOE_RXID = (CLX_SWC_HASH_KEY_TYPE_FCOE_ID_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_FCOE_OXID = (CLX_SWC_HASH_KEY_TYPE_FCOE_RXID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_FCOE_XID_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_FCOE_OXID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL0 = (CLX_SWC_HASH_KEY_TYPE_FCOE_XID_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL1 = (CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL0 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL2 = (CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL1 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL3 = (CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL2 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL4 = (CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL3 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_IGR_PORT = (CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL4 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_EGR_PORT = (CLX_SWC_HASH_KEY_TYPE_IGR_PORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_L2 = (CLX_SWC_HASH_KEY_TYPE_EGR_PORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_L3 = (CLX_SWC_HASH_KEY_TYPE_L2 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_VM_TUNNEL = (CLX_SWC_HASH_KEY_TYPE_L3 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_USE_INNER = (CLX_SWC_HASH_KEY_TYPE_VM_TUNNEL + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_COMPRESS_IP = (CLX_SWC_HASH_KEY_TYPE_USE_INNER + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_NORMALIZE = (CLX_SWC_HASH_KEY_TYPE_COMPRESS_IP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_LAST = (CLX_SWC_HASH_KEY_TYPE_NORMALIZE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 227

CLX_SWC_HASH_KEY_TYPE_T = enum_anon_157# ./clx_system/clx_sdk/include/clx_swc.h: 227

enum_anon_158 = c_int# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_L2_UC_ADDR = 0# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_L3_ECMP_GROUP = (CLX_SWC_RSRC_L2_UC_ADDR + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_L3_ECMP_PATH = (CLX_SWC_RSRC_L3_ECMP_GROUP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_L3_ECMP_HASH = (CLX_SWC_RSRC_L3_ECMP_PATH + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_L3_INTF = (CLX_SWC_RSRC_L3_ECMP_HASH + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_L3_ADJ = (CLX_SWC_RSRC_L3_INTF + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_L3_ROUTER_MAC = (CLX_SWC_RSRC_L3_ADJ + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_L3_HOST = (CLX_SWC_RSRC_L3_ROUTER_MAC + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_L3_ROUTE = (CLX_SWC_RSRC_L3_HOST + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_ACL_INGRESS_UCP = (CLX_SWC_RSRC_L3_ROUTE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_ACL_INGRESS_GROUP_ENTRY = (CLX_SWC_RSRC_ACL_INGRESS_UCP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_ACL_INGRESS_UDF_KEY_PROFILE = (CLX_SWC_RSRC_ACL_INGRESS_GROUP_ENTRY + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_ACL_INGRESS_UDF_KEY_PROFILE_LOU = (CLX_SWC_RSRC_ACL_INGRESS_UDF_KEY_PROFILE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_ACL_EGRESS_UCP = (CLX_SWC_RSRC_ACL_INGRESS_UDF_KEY_PROFILE_LOU + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_ACL_EGRESS_GROUP_ENTRY = (CLX_SWC_RSRC_ACL_EGRESS_UCP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_ACL_EGRESS_UDF_KEY_PROFILE = (CLX_SWC_RSRC_ACL_EGRESS_GROUP_ENTRY + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_ACL_EGRESS_UDF_KEY_PROFILE_LOU = (CLX_SWC_RSRC_ACL_EGRESS_UDF_KEY_PROFILE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_LAG_GROUP = (CLX_SWC_RSRC_ACL_EGRESS_UDF_KEY_PROFILE_LOU + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_VLAN_BDID = (CLX_SWC_RSRC_LAG_GROUP + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_LAST = (CLX_SWC_RSRC_VLAN_BDID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 251

CLX_SWC_RSRC_T = enum_anon_158# ./clx_system/clx_sdk/include/clx_swc.h: 251

# ./clx_system/clx_sdk/include/clx_swc.h: 267
class struct_CLX_SWC_STEERING_ENTRY_S(Structure):
    pass

struct_CLX_SWC_STEERING_ENTRY_S.__slots__ = [
    'hdr_size',
    'flags',
    'port',
    'handler',
    'tc',
    'color',
    'hdr',
    'vid_num',
    'ipv4_tlen_bidx',
    'ipv4_checksum',
    'ipv6_plen_bidx',
]
struct_CLX_SWC_STEERING_ENTRY_S._fields_ = [
    ('hdr_size', UI32_T),
    ('flags', UI32_T),
    ('port', UI32_T),
    ('handler', CLX_TM_HANDLER_T),
    ('tc', UI32_T),
    ('color', UI32_T),
    ('hdr', UI32_T * int(16)),
    ('vid_num', UI32_T),
    ('ipv4_tlen_bidx', UI32_T),
    ('ipv4_checksum', UI16_T),
    ('ipv6_plen_bidx', UI32_T),
]

CLX_SWC_STEERING_ENTRY_T = struct_CLX_SWC_STEERING_ENTRY_S# ./clx_system/clx_sdk/include/clx_swc.h: 267

CLX_SWC_HASH_KEY_BITMAP_T = UI32_T * int((((CLX_SWC_HASH_KEY_TYPE_LAST - 1) / 32) + 1))# ./clx_system/clx_sdk/include/clx_swc.h: 273

enum_anon_159 = c_int# ./clx_system/clx_sdk/include/clx_swc.h: 294

CLX_SWC_HASH_TYPE_ECMP_L3 = 0# ./clx_system/clx_sdk/include/clx_swc.h: 294

CLX_SWC_HASH_TYPE_ECMP_NVO3 = (CLX_SWC_HASH_TYPE_ECMP_L3 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 294

CLX_SWC_HASH_TYPE_LAG = (CLX_SWC_HASH_TYPE_ECMP_NVO3 + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 294

CLX_SWC_HASH_TYPE_LAG_FABRIC = (CLX_SWC_HASH_TYPE_LAG + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 294

CLX_SWC_HASH_TYPE_VXLAN_UDP_SRC_PORT = (CLX_SWC_HASH_TYPE_LAG_FABRIC + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 294

CLX_SWC_HASH_TYPE_NVGRE_FLOW_ID = (CLX_SWC_HASH_TYPE_VXLAN_UDP_SRC_PORT + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 294

CLX_SWC_HASH_TYPE_L3T_IPV6_FLOW_LABEL = (CLX_SWC_HASH_TYPE_NVGRE_FLOW_ID + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 294

CLX_SWC_HASH_TYPE_MPLS_ENTROPY_LABEL = (CLX_SWC_HASH_TYPE_L3T_IPV6_FLOW_LABEL + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 294

CLX_SWC_HASH_TYPE_MPLS_FLOW_LABEL = (CLX_SWC_HASH_TYPE_MPLS_ENTROPY_LABEL + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 294

CLX_SWC_HASH_TYPE_LAST = (CLX_SWC_HASH_TYPE_MPLS_FLOW_LABEL + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 294

CLX_SWC_HASH_TYPE_T = enum_anon_159# ./clx_system/clx_sdk/include/clx_swc.h: 294

enum_anon_160 = c_int# ./clx_system/clx_sdk/include/clx_swc.h: 300

CLX_SWC_ERROR_SRC_ECC = 0# ./clx_system/clx_sdk/include/clx_swc.h: 300

CLX_SWC_ERROR_SRC_LAST = (CLX_SWC_ERROR_SRC_ECC + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 300

CLX_SWC_ERROR_SRC_T = enum_anon_160# ./clx_system/clx_sdk/include/clx_swc.h: 300

enum_anon_161 = c_int# ./clx_system/clx_sdk/include/clx_swc.h: 306

CLX_SWC_ECC_NON_CORRECTABLE = 0# ./clx_system/clx_sdk/include/clx_swc.h: 306

CLX_SWC_ECC_CORRECTED = (CLX_SWC_ECC_NON_CORRECTABLE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 306

CLX_SWC_ECC_CORRECTION_T = enum_anon_161# ./clx_system/clx_sdk/include/clx_swc.h: 306

# ./clx_system/clx_sdk/include/clx_swc.h: 332
class struct_anon_162(Structure):
    pass

struct_anon_162.__slots__ = [
    'hub',
    'memory',
    'single_error_addr',
    'double_error_addr',
    'inst',
    'sub_inst',
    'table_id',
    'single_error_table_entry_start',
    'single_error_table_entry_end',
    'double_error_table_entry_start',
    'double_error_table_entry_end',
    'single_error_cnt',
    'double_error_cnt',
    'single_error_correction',
    'double_error_correction',
]
struct_anon_162._fields_ = [
    ('hub', UI32_T),
    ('memory', UI32_T),
    ('single_error_addr', UI32_T),
    ('double_error_addr', UI32_T),
    ('inst', UI32_T),
    ('sub_inst', UI32_T),
    ('table_id', UI32_T),
    ('single_error_table_entry_start', UI32_T),
    ('single_error_table_entry_end', UI32_T),
    ('double_error_table_entry_start', UI32_T),
    ('double_error_table_entry_end', UI32_T),
    ('single_error_cnt', UI32_T),
    ('double_error_cnt', UI32_T),
    ('single_error_correction', CLX_SWC_ECC_CORRECTION_T),
    ('double_error_correction', CLX_SWC_ECC_CORRECTION_T),
]

CLX_SWC_ERROR_INFO_ECC_T = struct_anon_162# ./clx_system/clx_sdk/include/clx_swc.h: 332

# ./clx_system/clx_sdk/include/clx_swc.h: 336
class union_anon_163(Union):
    pass

union_anon_163.__slots__ = [
    'ecc_info',
]
union_anon_163._fields_ = [
    ('ecc_info', CLX_SWC_ERROR_INFO_ECC_T),
]

# ./clx_system/clx_sdk/include/clx_swc.h: 340
class struct_anon_164(Structure):
    pass

struct_anon_164.__slots__ = [
    'unnamed_1',
]
struct_anon_164._anonymous_ = [
    'unnamed_1',
]
struct_anon_164._fields_ = [
    ('unnamed_1', union_anon_163),
]

CLX_SWC_ERROR_INFO_T = struct_anon_164# ./clx_system/clx_sdk/include/clx_swc.h: 340

CLX_SWC_ERROR_FUNC_T = CFUNCTYPE(UNCHECKED(None), UI32_T, POINTER(CLX_SWC_ERROR_INFO_T), POINTER(None))# ./clx_system/clx_sdk/include/clx_swc.h: 343

# ./clx_system/clx_sdk/include/clx_swc.h: 354
class struct_CLX_SWC_DEVICE_INFO_S(Structure):
    pass

struct_CLX_SWC_DEVICE_INFO_S.__slots__ = [
    'vendor_id',
    'device_id',
    'revision_id',
    'fwd_capacity',
]
struct_CLX_SWC_DEVICE_INFO_S._fields_ = [
    ('vendor_id', UI32_T),
    ('device_id', UI32_T),
    ('revision_id', UI32_T),
    ('fwd_capacity', UI32_T),
]

CLX_SWC_DEVICE_INFO_T = struct_CLX_SWC_DEVICE_INFO_S# ./clx_system/clx_sdk/include/clx_swc.h: 354

# ./clx_system/clx_sdk/include/clx_swc.h: 373
class struct_CLX_SWC_PORT_CONFIG_S(Structure):
    pass

struct_CLX_SWC_PORT_CONFIG_S.__slots__ = [
    'bitmap_all',
    'bitmap_active',
    'bitmap_mxlink',
    'bitmap_breakout',
    'bitmap_cpu',
    'bitmap_cpi',
    'bitmap_rcp',
    'bitmap_1g',
    'bitmap_10g',
    'bitmap_25g',
    'bitmap_40g',
    'bitmap_50g',
    'bitmap_100g',
    'bitmap_200g',
    'bitmap_400g',
]
struct_CLX_SWC_PORT_CONFIG_S._fields_ = [
    ('bitmap_all', CLX_PORT_BITMAP_T),
    ('bitmap_active', CLX_PORT_BITMAP_T),
    ('bitmap_mxlink', CLX_PORT_BITMAP_T),
    ('bitmap_breakout', CLX_PORT_BITMAP_T),
    ('bitmap_cpu', CLX_PORT_BITMAP_T),
    ('bitmap_cpi', CLX_PORT_BITMAP_T),
    ('bitmap_rcp', CLX_PORT_BITMAP_T),
    ('bitmap_1g', CLX_PORT_BITMAP_T),
    ('bitmap_10g', CLX_PORT_BITMAP_T),
    ('bitmap_25g', CLX_PORT_BITMAP_T),
    ('bitmap_40g', CLX_PORT_BITMAP_T),
    ('bitmap_50g', CLX_PORT_BITMAP_T),
    ('bitmap_100g', CLX_PORT_BITMAP_T),
    ('bitmap_200g', CLX_PORT_BITMAP_T),
    ('bitmap_400g', CLX_PORT_BITMAP_T),
]

CLX_SWC_PORT_CONFIG_T = struct_CLX_SWC_PORT_CONFIG_S# ./clx_system/clx_sdk/include/clx_swc.h: 373

enum_anon_165 = c_int# ./clx_system/clx_sdk/include/clx_swc.h: 380

CLX_SWC_CSO_MODE_SLAVE = 0# ./clx_system/clx_sdk/include/clx_swc.h: 380

CLX_SWC_CSO_MODE_MASTER = (CLX_SWC_CSO_MODE_SLAVE + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 380

CLX_SWC_CSO_MODE_LAST = (CLX_SWC_CSO_MODE_MASTER + 1)# ./clx_system/clx_sdk/include/clx_swc.h: 380

CLX_SWC_CSO_MODE_T = enum_anon_165# ./clx_system/clx_sdk/include/clx_swc.h: 380

# ./clx_system/clx_sdk/include/clx_swc.h: 397
class struct_CLX_SWC_CPI_ENCAP_HDR_S(Structure):
    pass

struct_CLX_SWC_CPI_ENCAP_HDR_S.__slots__ = [
    'flags',
    'encap_size',
    'hdr',
    'ipv4_tlen_bidx',
    'ipv4_checksum',
    'udp_source_port',
]
struct_CLX_SWC_CPI_ENCAP_HDR_S._fields_ = [
    ('flags', UI32_T),
    ('encap_size', UI32_T),
    ('hdr', UI8_T * int(64)),
    ('ipv4_tlen_bidx', UI32_T),
    ('ipv4_checksum', UI16_T),
    ('udp_source_port', UI16_T),
]

CLX_SWC_CPI_ENCAP_HDR_T = struct_CLX_SWC_CPI_ENCAP_HDR_S# ./clx_system/clx_sdk/include/clx_swc.h: 397

# ./clx_system/clx_sdk/include/clx_swc.h: 421
if _libs["libsai.so"].has("clx_swc_setHashKey", "cdecl"):
    clx_swc_setHashKey = _libs["libsai.so"].get("clx_swc_setHashKey", "cdecl")
    clx_swc_setHashKey.argtypes = [UI32_T, CLX_SWC_HASH_TYPE_T, CLX_SWC_HASH_KEY_BITMAP_T]
    clx_swc_setHashKey.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 441
if _libs["libsai.so"].has("clx_swc_getHashKey", "cdecl"):
    clx_swc_getHashKey = _libs["libsai.so"].get("clx_swc_getHashKey", "cdecl")
    clx_swc_getHashKey.argtypes = [UI32_T, CLX_SWC_HASH_TYPE_T, POINTER(CLX_SWC_HASH_KEY_BITMAP_T)]
    clx_swc_getHashKey.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 463
if _libs["libsai.so"].has("clx_swc_setProperty", "cdecl"):
    clx_swc_setProperty = _libs["libsai.so"].get("clx_swc_setProperty", "cdecl")
    clx_swc_setProperty.argtypes = [UI32_T, CLX_SWC_PROPERTY_T, UI32_T, UI32_T]
    clx_swc_setProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 486
if _libs["libsai.so"].has("clx_swc_getProperty", "cdecl"):
    clx_swc_getProperty = _libs["libsai.so"].get("clx_swc_getProperty", "cdecl")
    clx_swc_getProperty.argtypes = [UI32_T, CLX_SWC_PROPERTY_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_swc_getProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 509
if _libs["libsai.so"].has("clx_swc_setTsValue", "cdecl"):
    clx_swc_setTsValue = _libs["libsai.so"].get("clx_swc_setTsValue", "cdecl")
    clx_swc_setTsValue.argtypes = [UI32_T, UI16_T, UI32_T, UI32_T]
    clx_swc_setTsValue.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 531
if _libs["libsai.so"].has("clx_swc_getTsValue", "cdecl"):
    clx_swc_getTsValue = _libs["libsai.so"].get("clx_swc_getTsValue", "cdecl")
    clx_swc_getTsValue.argtypes = [UI32_T, POINTER(UI16_T), POINTER(UI32_T), POINTER(UI32_T)]
    clx_swc_getTsValue.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 552
if _libs["libsai.so"].has("clx_swc_setTsOffset", "cdecl"):
    clx_swc_setTsOffset = _libs["libsai.so"].get("clx_swc_setTsOffset", "cdecl")
    clx_swc_setTsOffset.argtypes = [UI32_T, I32_T]
    clx_swc_setTsOffset.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 571
if _libs["libsai.so"].has("clx_swc_setSteering", "cdecl"):
    clx_swc_setSteering = _libs["libsai.so"].get("clx_swc_setSteering", "cdecl")
    clx_swc_setSteering.argtypes = [UI32_T, POINTER(CLX_SWC_STEERING_ENTRY_T)]
    clx_swc_setSteering.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 589
if _libs["libsai.so"].has("clx_swc_getSteering", "cdecl"):
    clx_swc_getSteering = _libs["libsai.so"].get("clx_swc_getSteering", "cdecl")
    clx_swc_getSteering.argtypes = [UI32_T, POINTER(CLX_SWC_STEERING_ENTRY_T)]
    clx_swc_getSteering.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 615
if _libs["libsai.so"].has("clx_swc_setHashConstant", "cdecl"):
    clx_swc_setHashConstant = _libs["libsai.so"].get("clx_swc_setHashConstant", "cdecl")
    clx_swc_setHashConstant.argtypes = [UI32_T, CLX_SWC_HASH_TYPE_T, UI32_T, POINTER(UI32_T)]
    clx_swc_setHashConstant.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 641
if _libs["libsai.so"].has("clx_swc_getHashConstant", "cdecl"):
    clx_swc_getHashConstant = _libs["libsai.so"].get("clx_swc_getHashConstant", "cdecl")
    clx_swc_getHashConstant.argtypes = [UI32_T, CLX_SWC_HASH_TYPE_T, UI32_T, POINTER(UI32_T)]
    clx_swc_getHashConstant.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 669
if _libs["libsai.so"].has("clx_swc_setHashConstantByKey", "cdecl"):
    clx_swc_setHashConstantByKey = _libs["libsai.so"].get("clx_swc_setHashConstantByKey", "cdecl")
    clx_swc_setHashConstantByKey.argtypes = [UI32_T, CLX_SWC_HASH_TYPE_T, CLX_SWC_HASH_KEY_TYPE_T, POINTER(UI32_T)]
    clx_swc_setHashConstantByKey.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 695
if _libs["libsai.so"].has("clx_swc_getHashConstantByKey", "cdecl"):
    clx_swc_getHashConstantByKey = _libs["libsai.so"].get("clx_swc_getHashConstantByKey", "cdecl")
    clx_swc_getHashConstantByKey.argtypes = [UI32_T, CLX_SWC_HASH_TYPE_T, CLX_SWC_HASH_KEY_TYPE_T, POINTER(UI32_T)]
    clx_swc_getHashConstantByKey.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 718
if _libs["libsai.so"].has("clx_swc_registerErrorCallback", "cdecl"):
    clx_swc_registerErrorCallback = _libs["libsai.so"].get("clx_swc_registerErrorCallback", "cdecl")
    clx_swc_registerErrorCallback.argtypes = [UI32_T, CLX_SWC_ERROR_SRC_T, CLX_SWC_ERROR_FUNC_T, POINTER(None)]
    clx_swc_registerErrorCallback.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 741
if _libs["libsai.so"].has("clx_swc_deregisterErrorCallback", "cdecl"):
    clx_swc_deregisterErrorCallback = _libs["libsai.so"].get("clx_swc_deregisterErrorCallback", "cdecl")
    clx_swc_deregisterErrorCallback.argtypes = [UI32_T, CLX_SWC_ERROR_SRC_T, CLX_SWC_ERROR_FUNC_T, POINTER(None)]
    clx_swc_deregisterErrorCallback.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 765
if _libs["libsai.so"].has("clx_swc_getDeviceInfo", "cdecl"):
    clx_swc_getDeviceInfo = _libs["libsai.so"].get("clx_swc_getDeviceInfo", "cdecl")
    clx_swc_getDeviceInfo.argtypes = [UI32_T, POINTER(CLX_SWC_DEVICE_INFO_T)]
    clx_swc_getDeviceInfo.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 783
if _libs["libsai.so"].has("clx_swc_getPortConfig", "cdecl"):
    clx_swc_getPortConfig = _libs["libsai.so"].get("clx_swc_getPortConfig", "cdecl")
    clx_swc_getPortConfig.argtypes = [UI32_T, POINTER(CLX_SWC_PORT_CONFIG_T)]
    clx_swc_getPortConfig.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 803
if _libs["libsai.so"].has("clx_swc_getCapacity", "cdecl"):
    clx_swc_getCapacity = _libs["libsai.so"].get("clx_swc_getCapacity", "cdecl")
    clx_swc_getCapacity.argtypes = [UI32_T, CLX_SWC_RSRC_T, UI32_T, POINTER(UI32_T)]
    clx_swc_getCapacity.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 825
if _libs["libsai.so"].has("clx_swc_getUsage", "cdecl"):
    clx_swc_getUsage = _libs["libsai.so"].get("clx_swc_getUsage", "cdecl")
    clx_swc_getUsage.argtypes = [UI32_T, CLX_SWC_RSRC_T, UI32_T, POINTER(UI32_T)]
    clx_swc_getUsage.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 846
if _libs["libsai.so"].has("clx_swc_setCsoMode", "cdecl"):
    clx_swc_setCsoMode = _libs["libsai.so"].get("clx_swc_setCsoMode", "cdecl")
    clx_swc_setCsoMode.argtypes = [UI32_T, CLX_SWC_CSO_MODE_T]
    clx_swc_setCsoMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 864
if _libs["libsai.so"].has("clx_swc_getCsoMode", "cdecl"):
    clx_swc_getCsoMode = _libs["libsai.so"].get("clx_swc_getCsoMode", "cdecl")
    clx_swc_getCsoMode.argtypes = [UI32_T, POINTER(CLX_SWC_CSO_MODE_T)]
    clx_swc_getCsoMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 882
if _libs["libsai.so"].has("clx_swc_getChipTemperature", "cdecl"):
    clx_swc_getChipTemperature = _libs["libsai.so"].get("clx_swc_getChipTemperature", "cdecl")
    clx_swc_getChipTemperature.argtypes = [UI32_T, POINTER(I32_T)]
    clx_swc_getChipTemperature.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 903
if _libs["libsai.so"].has("clx_swc_setCpiEncap", "cdecl"):
    clx_swc_setCpiEncap = _libs["libsai.so"].get("clx_swc_setCpiEncap", "cdecl")
    clx_swc_setCpiEncap.argtypes = [UI32_T, UI32_T, POINTER(CLX_SWC_CPI_ENCAP_HDR_T)]
    clx_swc_setCpiEncap.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_swc.h: 924
if _libs["libsai.so"].has("clx_swc_getCpiEncap", "cdecl"):
    clx_swc_getCpiEncap = _libs["libsai.so"].get("clx_swc_getCpiEncap", "cdecl")
    clx_swc_getCpiEncap.argtypes = [UI32_T, UI32_T, POINTER(CLX_SWC_CPI_ENCAP_HDR_T)]
    clx_swc_getCpiEncap.restype = CLX_ERROR_NO_T

CLX_INIT_WRITE_FUNC_T = CFUNCTYPE(UNCHECKED(None), POINTER(None), UI32_T)# ./clx_system/clx_sdk/include/clx_init.h: 63

CLX_INIT_OPEN_NONVOLATILE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), )# ./clx_system/clx_sdk/include/clx_init.h: 68

CLX_INIT_CLOSE_NONVOLATILE_FUNC_T = CFUNCTYPE(UNCHECKED(CLX_ERROR_NO_T), )# ./clx_system/clx_sdk/include/clx_init.h: 72

CLX_INIT_WRITE_NONVOLATILE_FUNC_T = CFUNCTYPE(UNCHECKED(I32_T), POINTER(None), UI32_T)# ./clx_system/clx_sdk/include/clx_init.h: 76

CLX_INIT_READ_NONVOLATILE_FUNC_T = CFUNCTYPE(UNCHECKED(I32_T), POINTER(None), UI32_T)# ./clx_system/clx_sdk/include/clx_init.h: 81

# ./clx_system/clx_sdk/include/clx_init.h: 93
class struct_CLX_INIT_PARAM_S(Structure):
    pass

struct_CLX_INIT_PARAM_S.__slots__ = [
    'dsh_write_func',
    'debug_write_func',
    'open_nv_func',
    'close_nv_func',
    'write_nv_func',
    'read_nv_func',
]
struct_CLX_INIT_PARAM_S._fields_ = [
    ('dsh_write_func', CLX_INIT_WRITE_FUNC_T),
    ('debug_write_func', CLX_INIT_WRITE_FUNC_T),
    ('open_nv_func', CLX_INIT_OPEN_NONVOLATILE_FUNC_T),
    ('close_nv_func', CLX_INIT_CLOSE_NONVOLATILE_FUNC_T),
    ('write_nv_func', CLX_INIT_WRITE_NONVOLATILE_FUNC_T),
    ('read_nv_func', CLX_INIT_READ_NONVOLATILE_FUNC_T),
]

CLX_INIT_PARAM_T = struct_CLX_INIT_PARAM_S# ./clx_system/clx_sdk/include/clx_init.h: 93

enum_anon_166 = c_int# ./clx_system/clx_sdk/include/clx_init.h: 100

CLX_INIT_MODE_WARM_INIT = 0# ./clx_system/clx_sdk/include/clx_init.h: 100

CLX_INIT_MODE_WARM_DEINIT = (CLX_INIT_MODE_WARM_INIT + 1)# ./clx_system/clx_sdk/include/clx_init.h: 100

CLX_INIT_MODE_LAST = (CLX_INIT_MODE_WARM_DEINIT + 1)# ./clx_system/clx_sdk/include/clx_init.h: 100

CLX_INIT_MODE_T = enum_anon_166# ./clx_system/clx_sdk/include/clx_init.h: 100

# ./clx_system/clx_sdk/include/clx_init.h: 120
if _libs["libsai.so"].has("clx_init_initCmnModule", "cdecl"):
    clx_init_initCmnModule = _libs["libsai.so"].get("clx_init_initCmnModule", "cdecl")
    clx_init_initCmnModule.argtypes = [POINTER(CLX_INIT_PARAM_T)]
    clx_init_initCmnModule.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 138
if _libs["libsai.so"].has("clx_init_deinitCmnModule", "cdecl"):
    clx_init_deinitCmnModule = _libs["libsai.so"].get("clx_init_deinitCmnModule", "cdecl")
    clx_init_deinitCmnModule.argtypes = []
    clx_init_deinitCmnModule.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 156
if _libs["libsai.so"].has("clx_init_initLowLevel", "cdecl"):
    clx_init_initLowLevel = _libs["libsai.so"].get("clx_init_initLowLevel", "cdecl")
    clx_init_initLowLevel.argtypes = [UI32_T]
    clx_init_initLowLevel.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 174
if _libs["libsai.so"].has("clx_init_deinitLowLevel", "cdecl"):
    clx_init_deinitLowLevel = _libs["libsai.so"].get("clx_init_deinitLowLevel", "cdecl")
    clx_init_deinitLowLevel.argtypes = [UI32_T]
    clx_init_deinitLowLevel.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 192
if _libs["libsai.so"].has("clx_init_initTaskRsrc", "cdecl"):
    clx_init_initTaskRsrc = _libs["libsai.so"].get("clx_init_initTaskRsrc", "cdecl")
    clx_init_initTaskRsrc.argtypes = [UI32_T]
    clx_init_initTaskRsrc.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 210
if _libs["libsai.so"].has("clx_init_deinitTaskRsrc", "cdecl"):
    clx_init_deinitTaskRsrc = _libs["libsai.so"].get("clx_init_deinitTaskRsrc", "cdecl")
    clx_init_deinitTaskRsrc.argtypes = [UI32_T]
    clx_init_deinitTaskRsrc.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 228
if _libs["libsai.so"].has("clx_init_initModule", "cdecl"):
    clx_init_initModule = _libs["libsai.so"].get("clx_init_initModule", "cdecl")
    clx_init_initModule.argtypes = [UI32_T]
    clx_init_initModule.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 246
if _libs["libsai.so"].has("clx_init_deinitModule", "cdecl"):
    clx_init_deinitModule = _libs["libsai.so"].get("clx_init_deinitModule", "cdecl")
    clx_init_deinitModule.argtypes = [UI32_T]
    clx_init_deinitModule.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 264
if _libs["libsai.so"].has("clx_init_initTask", "cdecl"):
    clx_init_initTask = _libs["libsai.so"].get("clx_init_initTask", "cdecl")
    clx_init_initTask.argtypes = [UI32_T]
    clx_init_initTask.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 282
if _libs["libsai.so"].has("clx_init_deinitTask", "cdecl"):
    clx_init_deinitTask = _libs["libsai.so"].get("clx_init_deinitTask", "cdecl")
    clx_init_deinitTask.argtypes = [UI32_T]
    clx_init_deinitTask.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 300
if _libs["libsai.so"].has("clx_init_getUnitNum", "cdecl"):
    clx_init_getUnitNum = _libs["libsai.so"].get("clx_init_getUnitNum", "cdecl")
    clx_init_getUnitNum.argtypes = [POINTER(UI32_T)]
    clx_init_getUnitNum.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 318
if _libs["libsai.so"].has("clx_deinit", "cdecl"):
    clx_deinit = _libs["libsai.so"].get("clx_deinit", "cdecl")
    clx_deinit.argtypes = []
    clx_deinit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 338
if _libs["libsai.so"].has("clx_init_setInitMode", "cdecl"):
    clx_init_setInitMode = _libs["libsai.so"].get("clx_init_setInitMode", "cdecl")
    clx_init_setInitMode.argtypes = [UI32_T, CLX_INIT_MODE_T, BOOL_T]
    clx_init_setInitMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 359
if _libs["libsai.so"].has("clx_init_getInitMode", "cdecl"):
    clx_init_getInitMode = _libs["libsai.so"].get("clx_init_getInitMode", "cdecl")
    clx_init_getInitMode.argtypes = [UI32_T, CLX_INIT_MODE_T, POINTER(BOOL_T)]
    clx_init_getInitMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 383
if _libs["libsai.so"].has("clx_init_setModuleDebugFlag", "cdecl"):
    clx_init_setModuleDebugFlag = _libs["libsai.so"].get("clx_init_setModuleDebugFlag", "cdecl")
    clx_init_setModuleDebugFlag.argtypes = [UI32_T, CLX_MODULE_T, UI32_T]
    clx_init_setModuleDebugFlag.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_init.h: 404
if _libs["libsai.so"].has("clx_init_getModuleDebugFlag", "cdecl"):
    clx_init_getModuleDebugFlag = _libs["libsai.so"].get("clx_init_getModuleDebugFlag", "cdecl")
    clx_init_getModuleDebugFlag.argtypes = [UI32_T, CLX_MODULE_T, POINTER(UI32_T)]
    clx_init_getModuleDebugFlag.restype = CLX_ERROR_NO_T

enum_anon_167 = c_int# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_IN_OCTETS = 0# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_IN_UCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_IN_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_IN_NUCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_IN_UCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_IN_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_IF_IN_NUCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_IN_ERRORS = (CLX_STAT_PORT_CNT_TYPE_IF_IN_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_IN_UNKNOWN_PROTOS = (CLX_STAT_PORT_CNT_TYPE_IF_IN_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_OUT_OCTETS = (CLX_STAT_PORT_CNT_TYPE_IF_IN_UNKNOWN_PROTOS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_OUT_UCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_OUT_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_OUT_NUCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_OUT_UCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_OUT_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_IF_OUT_NUCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_OUT_ERRORS = (CLX_STAT_PORT_CNT_TYPE_IF_OUT_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_IN_MULTICAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_OUT_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_IN_BROADCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_IN_MULTICAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_OUT_MULTICAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_IN_BROADCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_OUT_BROADCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_OUT_MULTICAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_OCTETS = (CLX_STAT_PORT_CNT_TYPE_IF_OUT_BROADCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_UCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_MULTICAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_UCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_BROADCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_MULTICAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_OCTETS = (CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_BROADCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_UCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_MULTICAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_UCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_BROADCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_MULTICAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_DROP_EVENTS = (CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_BROADCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_DROP_EVENTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_BROADCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_MULTICAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_BROADCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_CRC_ALIGN_ERRORS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_MULTICAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_UNDERSIZE_PKTS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_CRC_ALIGN_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_OVERSIZE_PKTS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_UNDERSIZE_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_FRAGMENTS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_OVERSIZE_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_JABBERS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_FRAGMENTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_COLLISIONS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_JABBERS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_64_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_COLLISIONS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_65_TO_127_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_64_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_128_TO_255_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_65_TO_127_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_256_TO_511_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_128_TO_255_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_512_TO_1023_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_256_TO_511_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_1024_TO_1518_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_512_TO_1023_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_ALIGNMENT_ERRORS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_1024_TO_1518_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_FCS_ERRORS = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_ALIGNMENT_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SINGLE_COLLISION_FRAMES = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_FCS_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_MULTIPLE_COLLISION_FRAMES = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SINGLE_COLLISION_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SQE_TEST_ERRORS = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_MULTIPLE_COLLISION_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_DEFERRED_TRANSMISSIONS = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SQE_TEST_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_LATE_COLLISIONS = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_DEFERRED_TRANSMISSIONS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_EXCESSIVE_COLLISIONS = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_LATE_COLLISIONS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_INTERNAL_MAC_TRANSMIT_ERRORS = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_EXCESSIVE_COLLISIONS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_CARRIER_SENSE_ERRORS = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_INTERNAL_MAC_TRANSMIT_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_FRAME_TOO_LONGS = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_CARRIER_SENSE_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_INTERNAL_MAC_RECEIVE_ERRORS = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_FRAME_TOO_LONGS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SYMBOL_ERRORS = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_INTERNAL_MAC_RECEIVE_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_ALIGNMENT_ERRORS = (CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SYMBOL_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_FCS_ERRORS = (CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_ALIGNMENT_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_INTERNAL_MAC_TRANSMIT_ERRORS = (CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_FCS_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_FRAME_TOO_LONGS = (CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_INTERNAL_MAC_TRANSMIT_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_INTERNAL_MAC_RECEIVE_ERRORS = (CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_FRAME_TOO_LONGS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_SYMBOL_ERRORS = (CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_INTERNAL_MAC_RECEIVE_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_CONTROL_IN_UNKNOWN_OPCODES = (CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_SYMBOL_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_HC_CONTROL_IN_UNKNOWN_OPCODES = (CLX_STAT_PORT_CNT_TYPE_DOT3_CONTROL_IN_UNKNOWN_OPCODES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_IN_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_DOT3_HC_CONTROL_IN_UNKNOWN_OPCODES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_OUT_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_DOT3_IN_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_HC_IN_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_DOT3_OUT_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DOT3_HC_OUT_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_DOT3_HC_IN_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DROP_EVENTS = (CLX_STAT_PORT_CNT_TYPE_DOT3_HC_OUT_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DROPPED_FRAMES = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DROP_EVENTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DROPPED_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OVERFLOW_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_HIGH_CAPACITY_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OVERFLOW_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_HIGH_CAPACITY_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OVERFLOW_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_HIGH_CAPACITY_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OVERFLOW_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OCTETS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_HIGH_CAPACITY_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OVERFLOW_OCTETS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_HIGH_CAPACITY_OCTETS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OVERFLOW_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OCTETS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_HIGH_CAPACITY_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OVERFLOW_OCTETS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_HIGH_CAPACITY_OCTETS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OVERFLOW_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_HIGH_CAPACITY_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_OVERFLOW_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_HIGH_CAPACITY_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_OVERFLOW_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_HIGH_CAPACITY_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_OVERFLOW_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_HIGH_CAPACITY_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_OVERFLOW_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_ERRORS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_HIGH_CAPACITY_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_ERRORS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DUPLEX_CHANGES = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_ERRORS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS = (CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DUPLEX_CHANGES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_64_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_64_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_64_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_65_TO_127_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_64_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_65_TO_127_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_65_TO_127_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_128_TO_255_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_65_TO_127_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_128_TO_255_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_128_TO_255_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_256_TO_511_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_128_TO_255_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_256_TO_511_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_256_TO_511_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_512_TO_1023_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_256_TO_511_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_512_TO_1023_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_512_TO_1023_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_1024_TO_1518_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_512_TO_1023_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_1024_TO_1518_OCTETS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_1024_TO_1518_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RP_MAU_MEDIA_AVAILABLE_STATE_EXITS = (CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_1024_TO_1518_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RP_MAU_FALSE_CARRIERS = (CLX_STAT_PORT_CNT_TYPE_RP_MAU_MEDIA_AVAILABLE_STATE_EXITS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_MAU_MEDIA_AVAILABLE_STATE_EXITS = (CLX_STAT_PORT_CNT_TYPE_RP_MAU_FALSE_CARRIERS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_MAU_FALSE_CARRIERS = (CLX_STAT_PORT_CNT_TYPE_IF_MAU_MEDIA_AVAILABLE_STATE_EXITS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IF_MAU_HC_FALSE_CARRIERS = (CLX_STAT_PORT_CNT_TYPE_IF_MAU_FALSE_CARRIERS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_REQUESTS = (CLX_STAT_PORT_CNT_TYPE_IF_MAU_HC_FALSE_CARRIERS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_INDICATIONS = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_REQUESTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E0_IN_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_INDICATIONS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E0_OUT_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E0_IN_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E1_IN_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E0_OUT_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E1_OUT_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E1_IN_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E2_IN_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E1_OUT_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E2_OUT_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E2_IN_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E3_IN_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E2_OUT_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E3_OUT_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E3_IN_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E4_IN_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E3_OUT_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E4_OUT_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E4_IN_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E5_IN_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E4_OUT_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E5_OUT_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E5_IN_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E6_IN_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E5_OUT_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E6_OUT_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E6_IN_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E7_IN_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E6_OUT_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E7_OUT_PAUSE_FRAMES = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E7_IN_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RX_FRAMES_RECEIVED_OK = (CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E7_OUT_PAUSE_FRAMES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RX_PAUSE_MAC_CTRL_FRAMES_RECEIVED = (CLX_STAT_PORT_CNT_TYPE_RX_FRAMES_RECEIVED_OK + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RX_MAC_CONTROL_FRAMES_RECEIVED = (CLX_STAT_PORT_CNT_TYPE_RX_PAUSE_MAC_CTRL_FRAMES_RECEIVED + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RX_IN_RANGE_LENGTH_ERROES = (CLX_STAT_PORT_CNT_TYPE_RX_MAC_CONTROL_FRAMES_RECEIVED + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RX_PKTS_1519_TO_2560_OCTETS = (CLX_STAT_PORT_CNT_TYPE_RX_IN_RANGE_LENGTH_ERROES + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RX_PKTS_2561_TO_MAX_OCTETS = (CLX_STAT_PORT_CNT_TYPE_RX_PKTS_1519_TO_2560_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RX_PKTS_1519_TO_2047_OCTETS = (CLX_STAT_PORT_CNT_TYPE_RX_PKTS_2561_TO_MAX_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RX_PKTS_2048_TO_4095_OCTETS = (CLX_STAT_PORT_CNT_TYPE_RX_PKTS_1519_TO_2047_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RX_PKTS_4096_TO_9216_OCTETS = (CLX_STAT_PORT_CNT_TYPE_RX_PKTS_2048_TO_4095_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_RX_PKTS_9217_TO_16383_OCTETS = (CLX_STAT_PORT_CNT_TYPE_RX_PKTS_4096_TO_9216_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_FRAMES_TRANSMITTED_OK = (CLX_STAT_PORT_CNT_TYPE_RX_PKTS_9217_TO_16383_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PAUSE_MAC_CTRL_FRAMES_TRANSMITTED = (CLX_STAT_PORT_CNT_TYPE_TX_FRAMES_TRANSMITTED_OK + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_CRC_ERR = (CLX_STAT_PORT_CNT_TYPE_TX_PAUSE_MAC_CTRL_FRAMES_TRANSMITTED + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_64_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_CRC_ERR + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_65_TO_127_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_64_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_128_TO_255_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_65_TO_127_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_256_TO_511_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_128_TO_255_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_512_TO_1023_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_256_TO_511_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1024_TO_1518_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_512_TO_1023_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1519_TO_2560_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1024_TO_1518_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_2561_TO_MAX_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1519_TO_2560_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1519_TO_2047_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_2561_TO_MAX_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_2048_TO_4095_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1519_TO_2047_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_4096_TO_9216_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_2048_TO_4095_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_PKTS_9217_TO_16383_OCTETS = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_4096_TO_9216_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DROP_CNT_RECEIVE = (CLX_STAT_PORT_CNT_TYPE_TX_PKTS_9217_TO_16383_OCTETS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_DROP_CNT_TRANSMIT = (CLX_STAT_PORT_CNT_TYPE_DROP_CNT_RECEIVE + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_TX_OVERSIZE_PKTS = (CLX_STAT_PORT_CNT_TYPE_DROP_CNT_TRANSMIT + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_L3_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_TX_OVERSIZE_PKTS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_INGRESS_L3_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_L3_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_EGRESS_L3_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_INGRESS_L3_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_L3_BLACKHOLE_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_EGRESS_L3_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_INGRESS_PARITY_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_L3_BLACKHOLE_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_EGRESS_NON_QUEUE_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_INGRESS_PARITY_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_EGRESS_INVALID_VLAN_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_EGRESS_NON_QUEUE_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_INGRESS_L2_MTU_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_EGRESS_INVALID_VLAN_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_BUFFER_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_INGRESS_L2_MTU_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_INGRESS_NON_QUEUE_DISCARDS = (CLX_STAT_PORT_CNT_TYPE_BUFFER_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_LAST = (CLX_STAT_PORT_CNT_TYPE_INGRESS_NON_QUEUE_DISCARDS + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 238

CLX_STAT_PORT_CNT_TYPE_T = enum_anon_167# ./clx_system/clx_sdk/include/clx_stat.h: 238

enum_anon_168 = c_int# ./clx_system/clx_sdk/include/clx_stat.h: 250

CLX_STAT_TM_CNT_TYPE_PORT_DROP_RECEIVE = 0# ./clx_system/clx_sdk/include/clx_stat.h: 250

CLX_STAT_TM_CNT_TYPE_PORT_DROP_TRANSMIT = (CLX_STAT_TM_CNT_TYPE_PORT_DROP_RECEIVE + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 250

CLX_STAT_TM_CNT_TYPE_PORT_CNT_RECEIVE = (CLX_STAT_TM_CNT_TYPE_PORT_DROP_TRANSMIT + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 250

CLX_STAT_TM_CNT_TYPE_PORT_CNT_TRANSMIT = (CLX_STAT_TM_CNT_TYPE_PORT_CNT_RECEIVE + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 250

CLX_STAT_TM_CNT_TYPE_QUEUE_CNT = (CLX_STAT_TM_CNT_TYPE_PORT_CNT_TRANSMIT + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 250

CLX_STAT_TM_CNT_TYPE_QUEUE_DROP_IGR_BUF = (CLX_STAT_TM_CNT_TYPE_QUEUE_CNT + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 250

CLX_STAT_TM_CNT_TYPE_QUEUE_DROP_EGR_BUF = (CLX_STAT_TM_CNT_TYPE_QUEUE_DROP_IGR_BUF + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 250

CLX_STAT_TM_CNT_TYPE_LAST = (CLX_STAT_TM_CNT_TYPE_QUEUE_DROP_EGR_BUF + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 250

CLX_STAT_TM_CNT_TYPE_T = enum_anon_168# ./clx_system/clx_sdk/include/clx_stat.h: 250

# ./clx_system/clx_sdk/include/clx_stat.h: 256
class struct_CLX_STAT_TM_CNT_S(Structure):
    pass

struct_CLX_STAT_TM_CNT_S.__slots__ = [
    'pkt_cnt',
    'byte_cnt',
]
struct_CLX_STAT_TM_CNT_S._fields_ = [
    ('pkt_cnt', UI64_T),
    ('byte_cnt', UI64_T),
]

CLX_STAT_TM_CNT_T = struct_CLX_STAT_TM_CNT_S# ./clx_system/clx_sdk/include/clx_stat.h: 256

CLX_STAT_TM_QUEUE_CNT_T = CLX_STAT_TM_CNT_T# ./clx_system/clx_sdk/include/clx_stat.h: 258

# ./clx_system/clx_sdk/include/clx_stat.h: 286
class struct_CLX_STAT_DIST_CNT_S(Structure):
    pass

struct_CLX_STAT_DIST_CNT_S.__slots__ = [
    'total_byte_cnt',
    'total_pkt_cnt',
    'good_pkt_cnt_bc',
    'good_pkt_cnt_mc',
    'pkt_cnt_len_less_equal_64',
    'pkt_cnt_len_65_to_127',
    'pkt_cnt_len_128_to_255',
    'pkt_cnt_len_256_to_511',
    'pkt_cnt_len_512_to_1023',
    'pkt_cnt_len_1024_to_1518',
    'pkt_cnt_len_1519_to_2560',
    'pkt_cnt_len_2561_to_9216',
    'pkt_cnt_len_1519_to_2047',
    'pkt_cnt_len_2048_to_9216',
]
struct_CLX_STAT_DIST_CNT_S._fields_ = [
    ('total_byte_cnt', UI64_T),
    ('total_pkt_cnt', UI64_T),
    ('good_pkt_cnt_bc', UI64_T),
    ('good_pkt_cnt_mc', UI64_T),
    ('pkt_cnt_len_less_equal_64', UI64_T),
    ('pkt_cnt_len_65_to_127', UI64_T),
    ('pkt_cnt_len_128_to_255', UI64_T),
    ('pkt_cnt_len_256_to_511', UI64_T),
    ('pkt_cnt_len_512_to_1023', UI64_T),
    ('pkt_cnt_len_1024_to_1518', UI64_T),
    ('pkt_cnt_len_1519_to_2560', UI64_T),
    ('pkt_cnt_len_2561_to_9216', UI64_T),
    ('pkt_cnt_len_1519_to_2047', UI64_T),
    ('pkt_cnt_len_2048_to_9216', UI64_T),
]

CLX_STAT_DIST_CNT_T = struct_CLX_STAT_DIST_CNT_S# ./clx_system/clx_sdk/include/clx_stat.h: 286

enum_anon_169 = c_int# ./clx_system/clx_sdk/include/clx_stat.h: 297

CLX_STAT_CNT_MODE_SINGLE = 0# ./clx_system/clx_sdk/include/clx_stat.h: 297

CLX_STAT_CNT_MODE_DOUBLE = (CLX_STAT_CNT_MODE_SINGLE + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 297

CLX_STAT_CNT_MODE_TRIPLE = (CLX_STAT_CNT_MODE_DOUBLE + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 297

CLX_STAT_CNT_MODE_SIXFOLD = (CLX_STAT_CNT_MODE_TRIPLE + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 297

CLX_STAT_CNT_MODE_LAST = (CLX_STAT_CNT_MODE_SIXFOLD + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 297

CLX_STAT_CNT_MODE_T = enum_anon_169# ./clx_system/clx_sdk/include/clx_stat.h: 297

# ./clx_system/clx_sdk/include/clx_stat.h: 311
class struct_CLX_STAT_CNT_CFG_S(Structure):
    pass

struct_CLX_STAT_CNT_CFG_S.__slots__ = [
    'mode',
    'flags',
]
struct_CLX_STAT_CNT_CFG_S._fields_ = [
    ('mode', CLX_STAT_CNT_MODE_T),
    ('flags', UI32_T * int(6)),
]

CLX_STAT_CNT_CFG_T = struct_CLX_STAT_CNT_CFG_S# ./clx_system/clx_sdk/include/clx_stat.h: 311

# ./clx_system/clx_sdk/include/clx_stat.h: 316
class struct_CLX_STAT_CNT_S(Structure):
    pass

struct_CLX_STAT_CNT_S.__slots__ = [
    'cnt',
]
struct_CLX_STAT_CNT_S._fields_ = [
    ('cnt', UI64_T * int(6)),
]

CLX_STAT_CNT_T = struct_CLX_STAT_CNT_S# ./clx_system/clx_sdk/include/clx_stat.h: 316

enum_anon_170 = c_int# ./clx_system/clx_sdk/include/clx_stat.h: 324

CLX_STAT_CNT_GROUP_MODE_SERVICE = 0# ./clx_system/clx_sdk/include/clx_stat.h: 324

CLX_STAT_CNT_GROUP_MODE_FLOW = (CLX_STAT_CNT_GROUP_MODE_SERVICE + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 324

CLX_STAT_CNT_GROUP_MODE_SDN = (CLX_STAT_CNT_GROUP_MODE_FLOW + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 324

CLX_STAT_CNT_GROUP_MODE_LAST = (CLX_STAT_CNT_GROUP_MODE_SDN + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 324

CLX_STAT_CNT_GROUP_MODE_T = enum_anon_170# ./clx_system/clx_sdk/include/clx_stat.h: 324

enum_anon_171 = c_int# ./clx_system/clx_sdk/include/clx_stat.h: 333

CLX_STAT_RATE_RX_BYTE = 0# ./clx_system/clx_sdk/include/clx_stat.h: 333

CLX_STAT_RATE_RX_PKT = (CLX_STAT_RATE_RX_BYTE + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 333

CLX_STAT_RATE_TX_BYTE = (CLX_STAT_RATE_RX_PKT + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 333

CLX_STAT_RATE_TX_PKT = (CLX_STAT_RATE_TX_BYTE + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 333

CLX_STAT_RATE_TYPE_LAST = (CLX_STAT_RATE_TX_PKT + 1)# ./clx_system/clx_sdk/include/clx_stat.h: 333

CLX_STAT_RATE_TYPE_T = enum_anon_171# ./clx_system/clx_sdk/include/clx_stat.h: 333

# ./clx_system/clx_sdk/include/clx_stat.h: 354
if _libs["libsai.so"].has("clx_stat_getPortCnt", "cdecl"):
    clx_stat_getPortCnt = _libs["libsai.so"].get("clx_stat_getPortCnt", "cdecl")
    clx_stat_getPortCnt.argtypes = [UI32_T, UI32_T, CLX_STAT_PORT_CNT_TYPE_T, POINTER(UI64_T)]
    clx_stat_getPortCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 378
if _libs["libsai.so"].has("clx_stat_clearPortCnt", "cdecl"):
    clx_stat_clearPortCnt = _libs["libsai.so"].get("clx_stat_clearPortCnt", "cdecl")
    clx_stat_clearPortCnt.argtypes = [UI32_T, UI32_T, CLX_STAT_PORT_CNT_TYPE_T]
    clx_stat_clearPortCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 403
if _libs["libsai.so"].has("clx_stat_getPortCntList", "cdecl"):
    clx_stat_getPortCntList = _libs["libsai.so"].get("clx_stat_getPortCntList", "cdecl")
    clx_stat_getPortCntList.argtypes = [UI32_T, UI32_T, POINTER(CLX_STAT_PORT_CNT_TYPE_T), UI32_T, POINTER(UI64_T)]
    clx_stat_getPortCntList.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 429
if _libs["libsai.so"].has("clx_stat_clearPortCntList", "cdecl"):
    clx_stat_clearPortCntList = _libs["libsai.so"].get("clx_stat_clearPortCntList", "cdecl")
    clx_stat_clearPortCntList.argtypes = [UI32_T, UI32_T, POINTER(CLX_STAT_PORT_CNT_TYPE_T), UI32_T]
    clx_stat_clearPortCntList.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 455
if _libs["libsai.so"].has("clx_stat_setTmQueueCntForPort", "cdecl"):
    clx_stat_setTmQueueCntForPort = _libs["libsai.so"].get("clx_stat_setTmQueueCntForPort", "cdecl")
    clx_stat_setTmQueueCntForPort.argtypes = [UI32_T, UI32_T]
    clx_stat_setTmQueueCntForPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 476
if _libs["libsai.so"].has("clx_stat_getTmQueueCntForPort", "cdecl"):
    clx_stat_getTmQueueCntForPort = _libs["libsai.so"].get("clx_stat_getTmQueueCntForPort", "cdecl")
    clx_stat_getTmQueueCntForPort.argtypes = [UI32_T, POINTER(UI32_T)]
    clx_stat_getTmQueueCntForPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 500
if _libs["libsai.so"].has("clx_stat_setTmQueueCntForCpu", "cdecl"):
    clx_stat_setTmQueueCntForCpu = _libs["libsai.so"].get("clx_stat_setTmQueueCntForCpu", "cdecl")
    clx_stat_setTmQueueCntForCpu.argtypes = [UI32_T, CLX_TM_HANDLER_T, CLX_TM_HANDLER_T]
    clx_stat_setTmQueueCntForCpu.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 523
if _libs["libsai.so"].has("clx_stat_getTmQueueCntForCpu", "cdecl"):
    clx_stat_getTmQueueCntForCpu = _libs["libsai.so"].get("clx_stat_getTmQueueCntForCpu", "cdecl")
    clx_stat_getTmQueueCntForCpu.argtypes = [UI32_T, CLX_TM_HANDLER_T, POINTER(CLX_TM_HANDLER_T)]
    clx_stat_getTmQueueCntForCpu.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 546
if _libs["libsai.so"].has("clx_stat_getTmQueueCnt", "cdecl"):
    clx_stat_getTmQueueCnt = _libs["libsai.so"].get("clx_stat_getTmQueueCnt", "cdecl")
    clx_stat_getTmQueueCnt.argtypes = [UI32_T, CLX_TM_HANDLER_T, POINTER(CLX_STAT_TM_QUEUE_CNT_T)]
    clx_stat_getTmQueueCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 570
if _libs["libsai.so"].has("clx_stat_clearTmQueueCnt", "cdecl"):
    clx_stat_clearTmQueueCnt = _libs["libsai.so"].get("clx_stat_clearTmQueueCnt", "cdecl")
    clx_stat_clearTmQueueCnt.argtypes = [UI32_T, CLX_TM_HANDLER_T]
    clx_stat_clearTmQueueCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 596
if _libs["libsai.so"].has("clx_stat_getTmCnt", "cdecl"):
    clx_stat_getTmCnt = _libs["libsai.so"].get("clx_stat_getTmCnt", "cdecl")
    clx_stat_getTmCnt.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, CLX_STAT_TM_CNT_TYPE_T, POINTER(CLX_STAT_TM_CNT_T)]
    clx_stat_getTmCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 625
if _libs["libsai.so"].has("clx_stat_clearTmCnt", "cdecl"):
    clx_stat_clearTmCnt = _libs["libsai.so"].get("clx_stat_clearTmCnt", "cdecl")
    clx_stat_clearTmCnt.argtypes = [UI32_T, UI32_T, CLX_TM_HANDLER_T, CLX_STAT_TM_CNT_TYPE_T]
    clx_stat_clearTmCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 652
if _libs["libsai.so"].has("clx_stat_createDistCnt", "cdecl"):
    clx_stat_createDistCnt = _libs["libsai.so"].get("clx_stat_createDistCnt", "cdecl")
    clx_stat_createDistCnt.argtypes = [UI32_T, POINTER(UI32_T)]
    clx_stat_createDistCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 675
if _libs["libsai.so"].has("clx_stat_destroyDistCnt", "cdecl"):
    clx_stat_destroyDistCnt = _libs["libsai.so"].get("clx_stat_destroyDistCnt", "cdecl")
    clx_stat_destroyDistCnt.argtypes = [UI32_T, UI32_T]
    clx_stat_destroyDistCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 699
if _libs["libsai.so"].has("clx_stat_getDistCnt", "cdecl"):
    clx_stat_getDistCnt = _libs["libsai.so"].get("clx_stat_getDistCnt", "cdecl")
    clx_stat_getDistCnt.argtypes = [UI32_T, UI32_T, POINTER(CLX_STAT_DIST_CNT_T)]
    clx_stat_getDistCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 722
if _libs["libsai.so"].has("clx_stat_clearDistCnt", "cdecl"):
    clx_stat_clearDistCnt = _libs["libsai.so"].get("clx_stat_clearDistCnt", "cdecl")
    clx_stat_clearDistCnt.argtypes = [UI32_T, UI32_T]
    clx_stat_clearDistCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 748
if _libs["libsai.so"].has("clx_stat_createCnt", "cdecl"):
    clx_stat_createCnt = _libs["libsai.so"].get("clx_stat_createCnt", "cdecl")
    clx_stat_createCnt.argtypes = [UI32_T, POINTER(CLX_STAT_CNT_CFG_T), POINTER(UI32_T)]
    clx_stat_createCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 773
if _libs["libsai.so"].has("clx_stat_destroyCnt", "cdecl"):
    clx_stat_destroyCnt = _libs["libsai.so"].get("clx_stat_destroyCnt", "cdecl")
    clx_stat_destroyCnt.argtypes = [UI32_T, UI32_T]
    clx_stat_destroyCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 798
if _libs["libsai.so"].has("clx_stat_getCnt", "cdecl"):
    clx_stat_getCnt = _libs["libsai.so"].get("clx_stat_getCnt", "cdecl")
    clx_stat_getCnt.argtypes = [UI32_T, UI32_T, POINTER(CLX_STAT_CNT_T)]
    clx_stat_getCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 823
if _libs["libsai.so"].has("clx_stat_clearCnt", "cdecl"):
    clx_stat_clearCnt = _libs["libsai.so"].get("clx_stat_clearCnt", "cdecl")
    clx_stat_clearCnt.argtypes = [UI32_T, UI32_T]
    clx_stat_clearCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 848
if _libs["libsai.so"].has("clx_stat_getCntCfg", "cdecl"):
    clx_stat_getCntCfg = _libs["libsai.so"].get("clx_stat_getCntCfg", "cdecl")
    clx_stat_getCntCfg.argtypes = [UI32_T, UI32_T, POINTER(CLX_STAT_CNT_CFG_T)]
    clx_stat_getCntCfg.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 872
if _libs["libsai.so"].has("clx_stat_getPortRate", "cdecl"):
    clx_stat_getPortRate = _libs["libsai.so"].get("clx_stat_getPortRate", "cdecl")
    clx_stat_getPortRate.argtypes = [UI32_T, UI32_T, CLX_STAT_RATE_TYPE_T, POINTER(UI64_T)]
    clx_stat_getPortRate.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 898
if _libs["libsai.so"].has("clx_stat_refreshCnt", "cdecl"):
    clx_stat_refreshCnt = _libs["libsai.so"].get("clx_stat_refreshCnt", "cdecl")
    clx_stat_refreshCnt.argtypes = [UI32_T]
    clx_stat_refreshCnt.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 924
if _libs["libsai.so"].has("clx_stat_setFlowGroupMode", "cdecl"):
    clx_stat_setFlowGroupMode = _libs["libsai.so"].get("clx_stat_setFlowGroupMode", "cdecl")
    clx_stat_setFlowGroupMode.argtypes = [UI32_T, CLX_DIR_T, UI32_T, CLX_STAT_CNT_GROUP_MODE_T]
    clx_stat_setFlowGroupMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 952
if _libs["libsai.so"].has("clx_stat_getFlowGroupMode", "cdecl"):
    clx_stat_getFlowGroupMode = _libs["libsai.so"].get("clx_stat_getFlowGroupMode", "cdecl")
    clx_stat_getFlowGroupMode.argtypes = [UI32_T, CLX_DIR_T, UI32_T, POINTER(CLX_STAT_CNT_GROUP_MODE_T)]
    clx_stat_getFlowGroupMode.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 980
if _libs["libsai.so"].has("clx_stat_getFlowGroupCapacity", "cdecl"):
    clx_stat_getFlowGroupCapacity = _libs["libsai.so"].get("clx_stat_getFlowGroupCapacity", "cdecl")
    clx_stat_getFlowGroupCapacity.argtypes = [UI32_T, CLX_DIR_T, UI32_T, POINTER(UI32_T)]
    clx_stat_getFlowGroupCapacity.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_stat.h: 1010
if _libs["libsai.so"].has("clx_stat_getCntIdByFlowGroup", "cdecl"):
    clx_stat_getCntIdByFlowGroup = _libs["libsai.so"].get("clx_stat_getCntIdByFlowGroup", "cdecl")
    clx_stat_getCntIdByFlowGroup.argtypes = [UI32_T, CLX_DIR_T, UI32_T, UI32_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_stat_getCntIdByFlowGroup.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 78
class struct_CLX_TRILL_PKT_HANDLING_S(Structure):
    pass

struct_CLX_TRILL_PKT_HANDLING_S.__slots__ = [
    'multi_dst_bit_error',
    'option_len_error',
    'ver_field_error',
    'decap_ttl0_action',
    'decap_ttl1_action',
    'transit_ttl0_action',
    'transit_ttl1_action',
    'uc_adj_chk_fail_action',
    'mc_adj_chk_fail_action',
    'rpf_chk_fail_action',
]
struct_CLX_TRILL_PKT_HANDLING_S._fields_ = [
    ('multi_dst_bit_error', CLX_FWD_ACTION_T),
    ('option_len_error', CLX_FWD_ACTION_T),
    ('ver_field_error', CLX_FWD_ACTION_T),
    ('decap_ttl0_action', CLX_FWD_ACTION_T),
    ('decap_ttl1_action', CLX_FWD_ACTION_T),
    ('transit_ttl0_action', CLX_FWD_ACTION_T),
    ('transit_ttl1_action', CLX_FWD_ACTION_T),
    ('uc_adj_chk_fail_action', CLX_FWD_ACTION_T),
    ('mc_adj_chk_fail_action', CLX_FWD_ACTION_T),
    ('rpf_chk_fail_action', CLX_FWD_ACTION_T),
]

CLX_TRILL_PKT_HANDLING_T = struct_CLX_TRILL_PKT_HANDLING_S# ./clx_system/clx_sdk/include/clx_trill.h: 78

# ./clx_system/clx_sdk/include/clx_trill.h: 116
class struct_CLX_TRILL_INIT_INFO_S(Structure):
    pass

struct_CLX_TRILL_INIT_INFO_S.__slots__ = [
    'egr_nickname',
    'multi_dst',
    'flags',
    'outer_pcp',
    'outer_dei',
    'pcp',
    'dei',
    'ttl',
    'phb_to_pcp_dei_profile_id',
    'phb_to_dscp_profile_id',
    'mir_session_bitmap',
    'group_label',
    'meter_id',
    'cnt_id',
    'dist_cnt_id',
    'sampling_rate',
    'sample_to_mir_session_id',
    'dtel_profile_id',
]
struct_CLX_TRILL_INIT_INFO_S._fields_ = [
    ('egr_nickname', CLX_TRILL_NICKNAME_T),
    ('multi_dst', BOOL_T),
    ('flags', UI32_T),
    ('outer_pcp', UI8_T),
    ('outer_dei', UI8_T),
    ('pcp', UI8_T),
    ('dei', UI8_T),
    ('ttl', UI32_T),
    ('phb_to_pcp_dei_profile_id', UI32_T),
    ('phb_to_dscp_profile_id', UI32_T),
    ('mir_session_bitmap', UI32_T),
    ('group_label', UI32_T),
    ('meter_id', UI32_T),
    ('cnt_id', UI32_T),
    ('dist_cnt_id', UI32_T),
    ('sampling_rate', UI32_T),
    ('sample_to_mir_session_id', UI32_T),
    ('dtel_profile_id', UI32_T),
]

CLX_TRILL_INIT_INFO_T = struct_CLX_TRILL_INIT_INFO_S# ./clx_system/clx_sdk/include/clx_trill.h: 116

enum_anon_172 = c_int# ./clx_system/clx_sdk/include/clx_trill.h: 123

CLX_TRILL_TUNNEL_NORMAL = 0# ./clx_system/clx_sdk/include/clx_trill.h: 123

CLX_TRILL_TUNNEL_TREE = (CLX_TRILL_TUNNEL_NORMAL + 1)# ./clx_system/clx_sdk/include/clx_trill.h: 123

CLX_TRILL_TUNNEL_LAST = (CLX_TRILL_TUNNEL_TREE + 1)# ./clx_system/clx_sdk/include/clx_trill.h: 123

CLX_TRILL_TUNNEL_TYPE_T = enum_anon_172# ./clx_system/clx_sdk/include/clx_trill.h: 123

# ./clx_system/clx_sdk/include/clx_trill.h: 155
class struct_CLX_TRILL_TERM_INFO_S(Structure):
    pass

struct_CLX_TRILL_TERM_INFO_S.__slots__ = [
    'igr_nickname',
    'egr_nickname',
    'multi_dst',
    'flags',
    'learned_port',
    'pcp_dei_to_phb_profile_id',
    'dscp_to_phb_profile_id',
    'mir_session_bitmap',
    'group_label',
    'meter_id',
    'cnt_id',
    'dist_cnt_id',
    'sampling_rate',
    'sample_to_mir_session_id',
    'dtel_profile_id',
    'l2_mtu_size',
]
struct_CLX_TRILL_TERM_INFO_S._fields_ = [
    ('igr_nickname', CLX_TRILL_NICKNAME_T),
    ('egr_nickname', CLX_TRILL_NICKNAME_T),
    ('multi_dst', BOOL_T),
    ('flags', UI32_T),
    ('learned_port', CLX_PORT_T),
    ('pcp_dei_to_phb_profile_id', UI32_T),
    ('dscp_to_phb_profile_id', UI32_T),
    ('mir_session_bitmap', UI32_T),
    ('group_label', UI32_T),
    ('meter_id', UI32_T),
    ('cnt_id', UI32_T),
    ('dist_cnt_id', UI32_T),
    ('sampling_rate', UI32_T),
    ('sample_to_mir_session_id', UI32_T),
    ('dtel_profile_id', UI32_T),
    ('l2_mtu_size', UI16_T),
]

CLX_TRILL_TERM_INFO_T = struct_CLX_TRILL_TERM_INFO_S# ./clx_system/clx_sdk/include/clx_trill.h: 155

enum_anon_173 = c_int# ./clx_system/clx_sdk/include/clx_trill.h: 162

CLX_TRILL_FWD_INIT = 0# ./clx_system/clx_sdk/include/clx_trill.h: 162

CLX_TRILL_FWD_TRANSIT = (CLX_TRILL_FWD_INIT + 1)# ./clx_system/clx_sdk/include/clx_trill.h: 162

CLX_TRILL_FWD_LAST = (CLX_TRILL_FWD_TRANSIT + 1)# ./clx_system/clx_sdk/include/clx_trill.h: 162

CLX_TRILL_FWD_T = enum_anon_173# ./clx_system/clx_sdk/include/clx_trill.h: 162

# ./clx_system/clx_sdk/include/clx_trill.h: 174
class struct_CLX_TRILL_ROUTE_INFO_S(Structure):
    pass

struct_CLX_TRILL_ROUTE_INFO_S.__slots__ = [
    'egr_nickname',
    'fwd_type',
    'output_type',
    'output_id',
    'flags',
]
struct_CLX_TRILL_ROUTE_INFO_S._fields_ = [
    ('egr_nickname', CLX_TRILL_NICKNAME_T),
    ('fwd_type', CLX_TRILL_FWD_T),
    ('output_type', CLX_L3_OUTPUT_TYPE_T),
    ('output_id', UI32_T),
    ('flags', UI32_T),
]

CLX_TRILL_ROUTE_INFO_T = struct_CLX_TRILL_ROUTE_INFO_S# ./clx_system/clx_sdk/include/clx_trill.h: 174

enum_anon_174 = c_int# ./clx_system/clx_sdk/include/clx_trill.h: 184

CLX_TRILL_PRUNE_NORMAL = 0# ./clx_system/clx_sdk/include/clx_trill.h: 184

CLX_TRILL_PRUNE_VLAN = (CLX_TRILL_PRUNE_NORMAL + 1)# ./clx_system/clx_sdk/include/clx_trill.h: 184

CLX_TRILL_PRUNE_VLAN_MAC = (CLX_TRILL_PRUNE_VLAN + 1)# ./clx_system/clx_sdk/include/clx_trill.h: 184

CLX_TRILL_PRUNE_VLAN_IP = (CLX_TRILL_PRUNE_VLAN_MAC + 1)# ./clx_system/clx_sdk/include/clx_trill.h: 184

CLX_TRILL_PRUNE_LAST = (CLX_TRILL_PRUNE_VLAN_IP + 1)# ./clx_system/clx_sdk/include/clx_trill.h: 184

CLX_TRILL_PRUNE_T = enum_anon_174# ./clx_system/clx_sdk/include/clx_trill.h: 184

# ./clx_system/clx_sdk/include/clx_trill.h: 198
class union_anon_175(Union):
    pass

union_anon_175.__slots__ = [
    'mac',
    'ip_addr',
]
union_anon_175._fields_ = [
    ('mac', CLX_MAC_T),
    ('ip_addr', CLX_IP_ADDR_T),
]

# ./clx_system/clx_sdk/include/clx_trill.h: 203
class struct_CLX_TRILL_TREE_S(Structure):
    pass

struct_CLX_TRILL_TREE_S.__slots__ = [
    'egr_nickname',
    'fwd_type',
    'prune_type',
    'mcast_id',
    'flags',
    'vl_fgl_high',
    'fgl_low',
    'unnamed_1',
]
struct_CLX_TRILL_TREE_S._anonymous_ = [
    'unnamed_1',
]
struct_CLX_TRILL_TREE_S._fields_ = [
    ('egr_nickname', CLX_TRILL_NICKNAME_T),
    ('fwd_type', CLX_TRILL_FWD_T),
    ('prune_type', CLX_TRILL_PRUNE_T),
    ('mcast_id', UI32_T),
    ('flags', UI32_T),
    ('vl_fgl_high', UI32_T),
    ('fgl_low', UI32_T),
    ('unnamed_1', union_anon_175),
]

CLX_TRILL_TREE_INFO_T = struct_CLX_TRILL_TREE_S# ./clx_system/clx_sdk/include/clx_trill.h: 203

# ./clx_system/clx_sdk/include/clx_trill.h: 211
class struct_CLX_TRILL_ADJ_CHECK_S(Structure):
    pass

struct_CLX_TRILL_ADJ_CHECK_S.__slots__ = [
    'port',
    'src_mac',
    'multi_dst',
    'egr_nickname',
]
struct_CLX_TRILL_ADJ_CHECK_S._fields_ = [
    ('port', UI32_T),
    ('src_mac', CLX_MAC_T),
    ('multi_dst', BOOL_T),
    ('egr_nickname', CLX_TRILL_NICKNAME_T),
]

CLX_TRILL_ADJ_CHECK_T = struct_CLX_TRILL_ADJ_CHECK_S# ./clx_system/clx_sdk/include/clx_trill.h: 211

# ./clx_system/clx_sdk/include/clx_trill.h: 218
class struct_CLX_TRILL_RPF_CHECK_S(Structure):
    pass

struct_CLX_TRILL_RPF_CHECK_S.__slots__ = [
    'port',
    'igr_nickname',
    'egr_nickname',
]
struct_CLX_TRILL_RPF_CHECK_S._fields_ = [
    ('port', UI32_T),
    ('igr_nickname', CLX_TRILL_NICKNAME_T),
    ('egr_nickname', CLX_TRILL_NICKNAME_T),
]

CLX_TRILL_RPF_CHECK_T = struct_CLX_TRILL_RPF_CHECK_S# ./clx_system/clx_sdk/include/clx_trill.h: 218

# ./clx_system/clx_sdk/include/clx_trill.h: 227
class struct_CLX_TRILL_PORT_PROPERTY_S(Structure):
    pass

struct_CLX_TRILL_PORT_PROPERTY_S.__slots__ = [
    'flags',
    'rbv_id',
]
struct_CLX_TRILL_PORT_PROPERTY_S._fields_ = [
    ('flags', UI32_T),
    ('rbv_id', UI32_T),
]

CLX_TRILL_PORT_PROPERTY_T = struct_CLX_TRILL_PORT_PROPERTY_S# ./clx_system/clx_sdk/include/clx_trill.h: 227

# ./clx_system/clx_sdk/include/clx_trill.h: 251
if _libs["libsai.so"].has("clx_trill_setMyNickname", "cdecl"):
    clx_trill_setMyNickname = _libs["libsai.so"].get("clx_trill_setMyNickname", "cdecl")
    clx_trill_setMyNickname.argtypes = [UI32_T, CLX_TRILL_NICKNAME_T]
    clx_trill_setMyNickname.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 270
if _libs["libsai.so"].has("clx_trill_getMyNickname", "cdecl"):
    clx_trill_getMyNickname = _libs["libsai.so"].get("clx_trill_getMyNickname", "cdecl")
    clx_trill_getMyNickname.argtypes = [UI32_T, POINTER(CLX_TRILL_NICKNAME_T)]
    clx_trill_getMyNickname.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 291
if _libs["libsai.so"].has("clx_trill_setPktHandling", "cdecl"):
    clx_trill_setPktHandling = _libs["libsai.so"].get("clx_trill_setPktHandling", "cdecl")
    clx_trill_setPktHandling.argtypes = [UI32_T, POINTER(CLX_TRILL_PKT_HANDLING_T)]
    clx_trill_setPktHandling.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 310
if _libs["libsai.so"].has("clx_trill_getPktHandling", "cdecl"):
    clx_trill_getPktHandling = _libs["libsai.so"].get("clx_trill_getPktHandling", "cdecl")
    clx_trill_getPktHandling.argtypes = [UI32_T, POINTER(CLX_TRILL_PKT_HANDLING_T)]
    clx_trill_getPktHandling.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 331
if _libs["libsai.so"].has("clx_trill_createPort", "cdecl"):
    clx_trill_createPort = _libs["libsai.so"].get("clx_trill_createPort", "cdecl")
    clx_trill_createPort.argtypes = [UI32_T, CLX_TRILL_NICKNAME_T, UI32_T, POINTER(CLX_PORT_T)]
    clx_trill_createPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 353
if _libs["libsai.so"].has("clx_trill_destroyPort", "cdecl"):
    clx_trill_destroyPort = _libs["libsai.so"].get("clx_trill_destroyPort", "cdecl")
    clx_trill_destroyPort.argtypes = [UI32_T, CLX_PORT_T]
    clx_trill_destroyPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 375
if _libs["libsai.so"].has("clx_trill_addInit", "cdecl"):
    clx_trill_addInit = _libs["libsai.so"].get("clx_trill_addInit", "cdecl")
    clx_trill_addInit.argtypes = [UI32_T, POINTER(CLX_TRILL_INIT_INFO_T)]
    clx_trill_addInit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 395
if _libs["libsai.so"].has("clx_trill_delInit", "cdecl"):
    clx_trill_delInit = _libs["libsai.so"].get("clx_trill_delInit", "cdecl")
    clx_trill_delInit.argtypes = [UI32_T, POINTER(CLX_TRILL_INIT_INFO_T)]
    clx_trill_delInit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 415
if _libs["libsai.so"].has("clx_trill_getInit", "cdecl"):
    clx_trill_getInit = _libs["libsai.so"].get("clx_trill_getInit", "cdecl")
    clx_trill_getInit.argtypes = [UI32_T, POINTER(CLX_TRILL_INIT_INFO_T)]
    clx_trill_getInit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 436
if _libs["libsai.so"].has("clx_trill_addTerm", "cdecl"):
    clx_trill_addTerm = _libs["libsai.so"].get("clx_trill_addTerm", "cdecl")
    clx_trill_addTerm.argtypes = [UI32_T, POINTER(CLX_TRILL_TERM_INFO_T)]
    clx_trill_addTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 456
if _libs["libsai.so"].has("clx_trill_delTerm", "cdecl"):
    clx_trill_delTerm = _libs["libsai.so"].get("clx_trill_delTerm", "cdecl")
    clx_trill_delTerm.argtypes = [UI32_T, POINTER(CLX_TRILL_TERM_INFO_T)]
    clx_trill_delTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 476
if _libs["libsai.so"].has("clx_trill_getTerm", "cdecl"):
    clx_trill_getTerm = _libs["libsai.so"].get("clx_trill_getTerm", "cdecl")
    clx_trill_getTerm.argtypes = [UI32_T, POINTER(CLX_TRILL_TERM_INFO_T)]
    clx_trill_getTerm.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 502
if _libs["libsai.so"].has("clx_trill_addSegService", "cdecl"):
    clx_trill_addSegService = _libs["libsai.so"].get("clx_trill_addSegService", "cdecl")
    clx_trill_addSegService.argtypes = [UI32_T, CLX_TRILL_NICKNAME_T, CLX_TRILL_NICKNAME_T, UI32_T, UI32_T, POINTER(CLX_PORT_SEG_SRV_T)]
    clx_trill_addSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 529
if _libs["libsai.so"].has("clx_trill_delSegService", "cdecl"):
    clx_trill_delSegService = _libs["libsai.so"].get("clx_trill_delSegService", "cdecl")
    clx_trill_delSegService.argtypes = [UI32_T, CLX_TRILL_NICKNAME_T, CLX_TRILL_NICKNAME_T, UI32_T, UI32_T]
    clx_trill_delSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 555
if _libs["libsai.so"].has("clx_trill_getSegService", "cdecl"):
    clx_trill_getSegService = _libs["libsai.so"].get("clx_trill_getSegService", "cdecl")
    clx_trill_getSegService.argtypes = [UI32_T, CLX_TRILL_NICKNAME_T, CLX_TRILL_NICKNAME_T, UI32_T, UI32_T, POINTER(CLX_PORT_SEG_SRV_T)]
    clx_trill_getSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 581
if _libs["libsai.so"].has("clx_trill_addRoute", "cdecl"):
    clx_trill_addRoute = _libs["libsai.so"].get("clx_trill_addRoute", "cdecl")
    clx_trill_addRoute.argtypes = [UI32_T, POINTER(CLX_TRILL_ROUTE_INFO_T)]
    clx_trill_addRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 602
if _libs["libsai.so"].has("clx_trill_delRoute", "cdecl"):
    clx_trill_delRoute = _libs["libsai.so"].get("clx_trill_delRoute", "cdecl")
    clx_trill_delRoute.argtypes = [UI32_T, POINTER(CLX_TRILL_ROUTE_INFO_T)]
    clx_trill_delRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 623
if _libs["libsai.so"].has("clx_trill_getRoute", "cdecl"):
    clx_trill_getRoute = _libs["libsai.so"].get("clx_trill_getRoute", "cdecl")
    clx_trill_getRoute.argtypes = [UI32_T, POINTER(CLX_TRILL_ROUTE_INFO_T)]
    clx_trill_getRoute.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 652
if _libs["libsai.so"].has("clx_trill_addTree", "cdecl"):
    clx_trill_addTree = _libs["libsai.so"].get("clx_trill_addTree", "cdecl")
    clx_trill_addTree.argtypes = [UI32_T, POINTER(CLX_TRILL_TREE_INFO_T)]
    clx_trill_addTree.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 673
if _libs["libsai.so"].has("clx_trill_delTree", "cdecl"):
    clx_trill_delTree = _libs["libsai.so"].get("clx_trill_delTree", "cdecl")
    clx_trill_delTree.argtypes = [UI32_T, POINTER(CLX_TRILL_TREE_INFO_T)]
    clx_trill_delTree.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 694
if _libs["libsai.so"].has("clx_trill_getTree", "cdecl"):
    clx_trill_getTree = _libs["libsai.so"].get("clx_trill_getTree", "cdecl")
    clx_trill_getTree.argtypes = [UI32_T, POINTER(CLX_TRILL_TREE_INFO_T)]
    clx_trill_getTree.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 714
if _libs["libsai.so"].has("clx_trill_addAdjCheckEntry", "cdecl"):
    clx_trill_addAdjCheckEntry = _libs["libsai.so"].get("clx_trill_addAdjCheckEntry", "cdecl")
    clx_trill_addAdjCheckEntry.argtypes = [UI32_T, POINTER(CLX_TRILL_ADJ_CHECK_T)]
    clx_trill_addAdjCheckEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 734
if _libs["libsai.so"].has("clx_trill_delAdjCheckEntry", "cdecl"):
    clx_trill_delAdjCheckEntry = _libs["libsai.so"].get("clx_trill_delAdjCheckEntry", "cdecl")
    clx_trill_delAdjCheckEntry.argtypes = [UI32_T, POINTER(CLX_TRILL_ADJ_CHECK_T)]
    clx_trill_delAdjCheckEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 754
if _libs["libsai.so"].has("clx_trill_getAdjCheckEntry", "cdecl"):
    clx_trill_getAdjCheckEntry = _libs["libsai.so"].get("clx_trill_getAdjCheckEntry", "cdecl")
    clx_trill_getAdjCheckEntry.argtypes = [UI32_T, POINTER(CLX_TRILL_ADJ_CHECK_T)]
    clx_trill_getAdjCheckEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 774
if _libs["libsai.so"].has("clx_trill_addRpfCheckEntry", "cdecl"):
    clx_trill_addRpfCheckEntry = _libs["libsai.so"].get("clx_trill_addRpfCheckEntry", "cdecl")
    clx_trill_addRpfCheckEntry.argtypes = [UI32_T, POINTER(CLX_TRILL_RPF_CHECK_T)]
    clx_trill_addRpfCheckEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 794
if _libs["libsai.so"].has("clx_trill_delRpfCheckEntry", "cdecl"):
    clx_trill_delRpfCheckEntry = _libs["libsai.so"].get("clx_trill_delRpfCheckEntry", "cdecl")
    clx_trill_delRpfCheckEntry.argtypes = [UI32_T, POINTER(CLX_TRILL_RPF_CHECK_T)]
    clx_trill_delRpfCheckEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 814
if _libs["libsai.so"].has("clx_trill_getRpfCheckEntry", "cdecl"):
    clx_trill_getRpfCheckEntry = _libs["libsai.so"].get("clx_trill_getRpfCheckEntry", "cdecl")
    clx_trill_getRpfCheckEntry.argtypes = [UI32_T, POINTER(CLX_TRILL_RPF_CHECK_T)]
    clx_trill_getRpfCheckEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 836
if _libs["libsai.so"].has("clx_trill_addVirtualRb", "cdecl"):
    clx_trill_addVirtualRb = _libs["libsai.so"].get("clx_trill_addVirtualRb", "cdecl")
    clx_trill_addVirtualRb.argtypes = [UI32_T, CLX_TRILL_NICKNAME_T, UI32_T, POINTER(UI32_T)]
    clx_trill_addVirtualRb.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 858
if _libs["libsai.so"].has("clx_trill_delVirtualRb", "cdecl"):
    clx_trill_delVirtualRb = _libs["libsai.so"].get("clx_trill_delVirtualRb", "cdecl")
    clx_trill_delVirtualRb.argtypes = [UI32_T, UI32_T]
    clx_trill_delVirtualRb.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 878
if _libs["libsai.so"].has("clx_trill_getVirtualRb", "cdecl"):
    clx_trill_getVirtualRb = _libs["libsai.so"].get("clx_trill_getVirtualRb", "cdecl")
    clx_trill_getVirtualRb.argtypes = [UI32_T, UI32_T, POINTER(CLX_TRILL_NICKNAME_T)]
    clx_trill_getVirtualRb.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 900
if _libs["libsai.so"].has("clx_trill_setPortProperty", "cdecl"):
    clx_trill_setPortProperty = _libs["libsai.so"].get("clx_trill_setPortProperty", "cdecl")
    clx_trill_setPortProperty.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_TRILL_PORT_PROPERTY_T)]
    clx_trill_setPortProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_trill.h: 921
if _libs["libsai.so"].has("clx_trill_getPortProperty", "cdecl"):
    clx_trill_getPortProperty = _libs["libsai.so"].get("clx_trill_getPortProperty", "cdecl")
    clx_trill_getPortProperty.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_TRILL_PORT_PROPERTY_T)]
    clx_trill_getPortProperty.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sfc.h: 70
class struct_CLX_SFC_ENCAP_KEY_S(Structure):
    pass

struct_CLX_SFC_ENCAP_KEY_S.__slots__ = [
    'spi',
    'si',
    'length',
    'metadata_type',
    'context_hdr',
    'underlay_port',
    'adj_id',
]
struct_CLX_SFC_ENCAP_KEY_S._fields_ = [
    ('spi', UI32_T),
    ('si', UI32_T),
    ('length', UI32_T),
    ('metadata_type', UI32_T),
    ('context_hdr', UI32_T * int(4)),
    ('underlay_port', CLX_PORT_T),
    ('adj_id', UI32_T),
]

CLX_SFC_ENCAP_KEY_T = struct_CLX_SFC_ENCAP_KEY_S# ./clx_system/clx_sdk/include/clx_sfc.h: 70

# ./clx_system/clx_sdk/include/clx_sfc.h: 81
class struct_CLX_SFC_FORWARDER_S(Structure):
    pass

struct_CLX_SFC_FORWARDER_S.__slots__ = [
    'spi',
    'si',
    'output_type',
    'output_id',
    'flags',
]
struct_CLX_SFC_FORWARDER_S._fields_ = [
    ('spi', UI32_T),
    ('si', UI32_T),
    ('output_type', CLX_L3_OUTPUT_TYPE_T),
    ('output_id', UI32_T),
    ('flags', UI32_T),
]

CLX_SFC_FORWARDER_T = struct_CLX_SFC_FORWARDER_S# ./clx_system/clx_sdk/include/clx_sfc.h: 81

# ./clx_system/clx_sdk/include/clx_sfc.h: 101
if _libs["libsai.so"].has("clx_sfc_createPort", "cdecl"):
    clx_sfc_createPort = _libs["libsai.so"].get("clx_sfc_createPort", "cdecl")
    clx_sfc_createPort.argtypes = [UI32_T, POINTER(CLX_SFC_ENCAP_KEY_T), POINTER(CLX_PORT_T)]
    clx_sfc_createPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sfc.h: 120
if _libs["libsai.so"].has("clx_sfc_destroyPort", "cdecl"):
    clx_sfc_destroyPort = _libs["libsai.so"].get("clx_sfc_destroyPort", "cdecl")
    clx_sfc_destroyPort.argtypes = [UI32_T, CLX_PORT_T]
    clx_sfc_destroyPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sfc.h: 138
if _libs["libsai.so"].has("clx_sfc_getPort", "cdecl"):
    clx_sfc_getPort = _libs["libsai.so"].get("clx_sfc_getPort", "cdecl")
    clx_sfc_getPort.argtypes = [UI32_T, POINTER(CLX_SFC_ENCAP_KEY_T), POINTER(CLX_PORT_T)]
    clx_sfc_getPort.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sfc.h: 157
if _libs["libsai.so"].has("clx_sfc_getKey", "cdecl"):
    clx_sfc_getKey = _libs["libsai.so"].get("clx_sfc_getKey", "cdecl")
    clx_sfc_getKey.argtypes = [UI32_T, CLX_PORT_T, POINTER(CLX_SFC_ENCAP_KEY_T)]
    clx_sfc_getKey.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sfc.h: 176
if _libs["libsai.so"].has("clx_sfc_addForwarder", "cdecl"):
    clx_sfc_addForwarder = _libs["libsai.so"].get("clx_sfc_addForwarder", "cdecl")
    clx_sfc_addForwarder.argtypes = [UI32_T, POINTER(CLX_SFC_FORWARDER_T)]
    clx_sfc_addForwarder.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sfc.h: 194
if _libs["libsai.so"].has("clx_sfc_delForwarder", "cdecl"):
    clx_sfc_delForwarder = _libs["libsai.so"].get("clx_sfc_delForwarder", "cdecl")
    clx_sfc_delForwarder.argtypes = [UI32_T, POINTER(CLX_SFC_FORWARDER_T)]
    clx_sfc_delForwarder.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_sfc.h: 212
if _libs["libsai.so"].has("clx_sfc_getForwarder", "cdecl"):
    clx_sfc_getForwarder = _libs["libsai.so"].get("clx_sfc_getForwarder", "cdecl")
    clx_sfc_getForwarder.argtypes = [UI32_T, POINTER(CLX_SFC_FORWARDER_T)]
    clx_sfc_getForwarder.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pppoe.h: 78
if _libs["libsai.so"].has("clx_pppoe_setServerMac", "cdecl"):
    clx_pppoe_setServerMac = _libs["libsai.so"].get("clx_pppoe_setServerMac", "cdecl")
    clx_pppoe_setServerMac.argtypes = [UI32_T, CLX_MAC_T]
    clx_pppoe_setServerMac.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pppoe.h: 95
if _libs["libsai.so"].has("clx_pppoe_getServerMac", "cdecl"):
    clx_pppoe_getServerMac = _libs["libsai.so"].get("clx_pppoe_getServerMac", "cdecl")
    clx_pppoe_getServerMac.argtypes = [UI32_T, POINTER(CLX_MAC_T)]
    clx_pppoe_getServerMac.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pppoe.h: 117
if _libs["libsai.so"].has("clx_pppoe_addSegService", "cdecl"):
    clx_pppoe_addSegService = _libs["libsai.so"].get("clx_pppoe_addSegService", "cdecl")
    clx_pppoe_addSegService.argtypes = [UI32_T, CLX_PORT_T, UI32_T, UI32_T, UI32_T, POINTER(CLX_PORT_SEG_SRV_T)]
    clx_pppoe_addSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pppoe.h: 142
if _libs["libsai.so"].has("clx_pppoe_delSegService", "cdecl"):
    clx_pppoe_delSegService = _libs["libsai.so"].get("clx_pppoe_delSegService", "cdecl")
    clx_pppoe_delSegService.argtypes = [UI32_T, CLX_PORT_T, UI32_T, UI32_T, UI32_T]
    clx_pppoe_delSegService.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/clx_pppoe.h: 166
if _libs["libsai.so"].has("clx_pppoe_getSegService", "cdecl"):
    clx_pppoe_getSegService = _libs["libsai.so"].get("clx_pppoe_getSegService", "cdecl")
    clx_pppoe_getSegService.argtypes = [UI32_T, CLX_PORT_T, UI32_T, UI32_T, UI32_T, POINTER(CLX_PORT_SEG_SRV_T)]
    clx_pppoe_getSegService.restype = CLX_ERROR_NO_T

OSAL_VA_LIST = c_void_p# ./clx_system/clx_sdk/include/osal/osal_lib.h: 74

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 94
if _libs["libsai.so"].has("osal_memset", "cdecl"):
    osal_memset = _libs["libsai.so"].get("osal_memset", "cdecl")
    osal_memset.argtypes = [POINTER(None), I32_T, UI32_T]
    osal_memset.restype = POINTER(c_ubyte)
    osal_memset.errcheck = lambda v,*a : cast(v, c_void_p)

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 115
if _libs["libsai.so"].has("osal_memcpy", "cdecl"):
    osal_memcpy = _libs["libsai.so"].get("osal_memcpy", "cdecl")
    osal_memcpy.argtypes = [POINTER(None), POINTER(None), UI32_T]
    osal_memcpy.restype = POINTER(c_ubyte)
    osal_memcpy.errcheck = lambda v,*a : cast(v, c_void_p)

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 142
if _libs["libsai.so"].has("osal_memcmp", "cdecl"):
    osal_memcmp = _libs["libsai.so"].get("osal_memcmp", "cdecl")
    osal_memcmp.argtypes = [POINTER(None), POINTER(None), UI32_T]
    osal_memcmp.restype = I32_T

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 165
if _libs["libsai.so"].has("osal_strncpy", "cdecl"):
    osal_strncpy = _libs["libsai.so"].get("osal_strncpy", "cdecl")
    osal_strncpy.argtypes = [POINTER(C8_T), POINTER(C8_T), UI32_T]
    osal_strncpy.restype = POINTER(C8_T)

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 189
if _libs["libsai.so"].has("osal_strncmp", "cdecl"):
    osal_strncmp = _libs["libsai.so"].get("osal_strncmp", "cdecl")
    osal_strncmp.argtypes = [POINTER(C8_T), POINTER(C8_T), UI32_T]
    osal_strncmp.restype = I32_T

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 207
if _libs["libsai.so"].has("osal_strlen", "cdecl"):
    osal_strlen = _libs["libsai.so"].get("osal_strlen", "cdecl")
    osal_strlen.argtypes = [POINTER(C8_T)]
    osal_strlen.restype = UI32_T

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 227
if _libs["libsai.so"].has("osal_strcat", "cdecl"):
    osal_strcat = _libs["libsai.so"].get("osal_strcat", "cdecl")
    osal_strcat.argtypes = [POINTER(C8_T), POINTER(C8_T)]
    osal_strcat.restype = POINTER(C8_T)

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 252
if _libs["libsai.so"].has("osal_strncat", "cdecl"):
    osal_strncat = _libs["libsai.so"].get("osal_strncat", "cdecl")
    osal_strncat.argtypes = [POINTER(C8_T), POINTER(C8_T), UI32_T]
    osal_strncat.restype = POINTER(C8_T)

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 338
if _libs["libsai.so"].has("osal_printf", "cdecl"):
    _func = _libs["libsai.so"].get("osal_printf", "cdecl")
    _restype = None
    _errcheck = None
    _argtypes = [POINTER(C8_T)]
    osal_printf = _variadic_function(_func,_restype,_argtypes,_errcheck)

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 362
if _libs["libsai.so"].has("osal_snprintf", "cdecl"):
    _func = _libs["libsai.so"].get("osal_snprintf", "cdecl")
    _restype = I32_T
    _errcheck = None
    _argtypes = [POINTER(C8_T), UI32_T, POINTER(C8_T)]
    osal_snprintf = _variadic_function(_func,_restype,_argtypes,_errcheck)

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 389
if _libs["libsai.so"].has("osal_vsnprintf", "cdecl"):
    osal_vsnprintf = _libs["libsai.so"].get("osal_vsnprintf", "cdecl")
    osal_vsnprintf.argtypes = [POINTER(C8_T), UI32_T, POINTER(C8_T), OSAL_VA_LIST]
    osal_vsnprintf.restype = I32_T

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 409
if _libs["libsai.so"].has("osal_srand", "cdecl"):
    osal_srand = _libs["libsai.so"].get("osal_srand", "cdecl")
    osal_srand.argtypes = [UI32_T]
    osal_srand.restype = None

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 425
if _libs["libsai.so"].has("osal_rand", "cdecl"):
    osal_rand = _libs["libsai.so"].get("osal_rand", "cdecl")
    osal_rand.argtypes = []
    osal_rand.restype = UI32_T

# ./clx_system/clx_sdk/include/osal/osal_lib.h: 443
if _libs["libsai.so"].has("osal_assert", "cdecl"):
    osal_assert = _libs["libsai.so"].get("osal_assert", "cdecl")
    osal_assert.argtypes = [POINTER(C8_T), POINTER(C8_T), UI32_T]
    osal_assert.restype = UI32_T

# ./clx_system/clx_sdk/include/osal/osal.h: 71
class struct_OSAL_TM_S(Structure):
    pass

struct_OSAL_TM_S.__slots__ = [
    'year',
    'month',
    'day',
    'hour',
    'min',
    'sec',
]
struct_OSAL_TM_S._fields_ = [
    ('year', UI32_T),
    ('month', UI32_T),
    ('day', UI32_T),
    ('hour', UI32_T),
    ('min', UI32_T),
    ('sec', UI32_T),
]

OSAL_TM_T = struct_OSAL_TM_S# ./clx_system/clx_sdk/include/osal/osal.h: 71

# ./clx_system/clx_sdk/include/osal/osal.h: 89
if _libs["libsai.so"].has("osal_init", "cdecl"):
    osal_init = _libs["libsai.so"].get("osal_init", "cdecl")
    osal_init.argtypes = []
    osal_init.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 103
if _libs["libsai.so"].has("osal_deinit", "cdecl"):
    osal_deinit = _libs["libsai.so"].get("osal_deinit", "cdecl")
    osal_deinit.argtypes = []
    osal_deinit.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 118
if _libs["libsai.so"].has("osal_alloc", "cdecl"):
    osal_alloc = _libs["libsai.so"].get("osal_alloc", "cdecl")
    osal_alloc.argtypes = [UI32_T]
    osal_alloc.restype = POINTER(c_ubyte)
    osal_alloc.errcheck = lambda v,*a : cast(v, c_void_p)

# ./clx_system/clx_sdk/include/osal/osal.h: 135
if _libs["libsai.so"].has("osal_free", "cdecl"):
    osal_free = _libs["libsai.so"].get("osal_free", "cdecl")
    osal_free.argtypes = [POINTER(None)]
    osal_free.restype = None

# ./clx_system/clx_sdk/include/osal/osal.h: 151
if _libs["libsai.so"].has("osal_initRunThread", "cdecl"):
    osal_initRunThread = _libs["libsai.so"].get("osal_initRunThread", "cdecl")
    osal_initRunThread.argtypes = []
    osal_initRunThread.restype = None

# ./clx_system/clx_sdk/include/osal/osal.h: 174
if _libs["libsai.so"].has("osal_createThread", "cdecl"):
    osal_createThread = _libs["libsai.so"].get("osal_createThread", "cdecl")
    osal_createThread.argtypes = [POINTER(C8_T), UI32_T, UI32_T, CFUNCTYPE(UNCHECKED(None), POINTER(None)), POINTER(None), POINTER(CLX_THREAD_ID_T)]
    osal_createThread.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 196
if _libs["libsai.so"].has("osal_stopThread", "cdecl"):
    osal_stopThread = _libs["libsai.so"].get("osal_stopThread", "cdecl")
    osal_stopThread.argtypes = [POINTER(CLX_THREAD_ID_T)]
    osal_stopThread.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 213
if _libs["libsai.so"].has("osal_destroyThread", "cdecl"):
    osal_destroyThread = _libs["libsai.so"].get("osal_destroyThread", "cdecl")
    osal_destroyThread.argtypes = [POINTER(CLX_THREAD_ID_T)]
    osal_destroyThread.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 230
if _libs["libsai.so"].has("osal_isRunThread", "cdecl"):
    osal_isRunThread = _libs["libsai.so"].get("osal_isRunThread", "cdecl")
    osal_isRunThread.argtypes = []
    osal_isRunThread.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 246
if _libs["libsai.so"].has("osal_exitRunThread", "cdecl"):
    osal_exitRunThread = _libs["libsai.so"].get("osal_exitRunThread", "cdecl")
    osal_exitRunThread.argtypes = []
    osal_exitRunThread.restype = None

# ./clx_system/clx_sdk/include/osal/osal.h: 263
if _libs["libsai.so"].has("osal_sleepThread", "cdecl"):
    osal_sleepThread = _libs["libsai.so"].get("osal_sleepThread", "cdecl")
    osal_sleepThread.argtypes = [UI32_T]
    osal_sleepThread.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 279
if _libs["libsai.so"].has("osal_delayUs", "cdecl"):
    osal_delayUs = _libs["libsai.so"].get("osal_delayUs", "cdecl")
    osal_delayUs.argtypes = [UI32_T]
    osal_delayUs.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 303
if _libs["libsai.so"].has("osal_createSemaphore", "cdecl"):
    osal_createSemaphore = _libs["libsai.so"].get("osal_createSemaphore", "cdecl")
    osal_createSemaphore.argtypes = [POINTER(C8_T), UI32_T, POINTER(CLX_SEMAPHORE_ID_T)]
    osal_createSemaphore.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 323
if _libs["libsai.so"].has("osal_destroySemaphore", "cdecl"):
    osal_destroySemaphore = _libs["libsai.so"].get("osal_destroySemaphore", "cdecl")
    osal_destroySemaphore.argtypes = [POINTER(CLX_SEMAPHORE_ID_T)]
    osal_destroySemaphore.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 342
if _libs["libsai.so"].has("osal_takeSemaphore", "cdecl"):
    osal_takeSemaphore = _libs["libsai.so"].get("osal_takeSemaphore", "cdecl")
    osal_takeSemaphore.argtypes = [POINTER(CLX_SEMAPHORE_ID_T), UI32_T]
    osal_takeSemaphore.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 359
if _libs["libsai.so"].has("osal_giveSemaphore", "cdecl"):
    osal_giveSemaphore = _libs["libsai.so"].get("osal_giveSemaphore", "cdecl")
    osal_giveSemaphore.argtypes = [POINTER(CLX_SEMAPHORE_ID_T)]
    osal_giveSemaphore.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 380
if _libs["libsai.so"].has("osal_createIsrLock", "cdecl"):
    osal_createIsrLock = _libs["libsai.so"].get("osal_createIsrLock", "cdecl")
    osal_createIsrLock.argtypes = [POINTER(C8_T), POINTER(CLX_ISRLOCK_ID_T)]
    osal_createIsrLock.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 398
if _libs["libsai.so"].has("osal_destroyIsrLock", "cdecl"):
    osal_destroyIsrLock = _libs["libsai.so"].get("osal_destroyIsrLock", "cdecl")
    osal_destroyIsrLock.argtypes = [POINTER(CLX_ISRLOCK_ID_T)]
    osal_destroyIsrLock.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 416
if _libs["libsai.so"].has("osal_takeIsrLock", "cdecl"):
    osal_takeIsrLock = _libs["libsai.so"].get("osal_takeIsrLock", "cdecl")
    osal_takeIsrLock.argtypes = [POINTER(CLX_ISRLOCK_ID_T), POINTER(CLX_IRQ_FLAGS_T)]
    osal_takeIsrLock.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 437
if _libs["libsai.so"].has("osal_giveIsrLock", "cdecl"):
    osal_giveIsrLock = _libs["libsai.so"].get("osal_giveIsrLock", "cdecl")
    osal_giveIsrLock.argtypes = [POINTER(CLX_ISRLOCK_ID_T), POINTER(CLX_IRQ_FLAGS_T)]
    osal_giveIsrLock.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 455
if _libs["libsai.so"].has("osal_getTime", "cdecl"):
    osal_getTime = _libs["libsai.so"].get("osal_getTime", "cdecl")
    osal_getTime.argtypes = [POINTER(CLX_TIME_T)]
    osal_getTime.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/osal/osal.h: 472
if _libs["libsai.so"].has("osal_getCalendarTime", "cdecl"):
    osal_getCalendarTime = _libs["libsai.so"].get("osal_getCalendarTime", "cdecl")
    osal_getCalendarTime.argtypes = [POINTER(OSAL_TM_T)]
    osal_getCalendarTime.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/cdb/cdb.h: 163
class union_anon_25942(Union):
    pass

union_anon_25942.__slots__ = [
    'ptr_value',
    'value',
]
union_anon_25942._fields_ = [
    ('ptr_value', POINTER(UI32_T)),
    ('value', UI32_T),
]

# ./clx_system/clx_sdk/include/cdb/cdb.h: 168
class struct_anon_25943(Structure):
    pass

struct_anon_25943.__slots__ = [
    'field_id',
    'unnamed_1',
]
struct_anon_25943._anonymous_ = [
    'unnamed_1',
]
struct_anon_25943._fields_ = [
    ('field_id', UI32_T),
    ('unnamed_1', union_anon_25942),
]

CDB_FVP_T = struct_anon_25943# ./clx_system/clx_sdk/include/cdb/cdb.h: 168

# ./clx_system/clx_sdk/include/cdb/cdb.h: 189
if _libs["libsai.so"].has("cdb_packField", "cdecl"):
    cdb_packField = _libs["libsai.so"].get("cdb_packField", "cdecl")
    cdb_packField.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(UI32_T), POINTER(UI32_T)]
    cdb_packField.restype = None

# ./clx_system/clx_sdk/include/cdb/cdb.h: 210
if _libs["libsai.so"].has("cdb_unpackField", "cdecl"):
    cdb_unpackField = _libs["libsai.so"].get("cdb_unpackField", "cdecl")
    cdb_unpackField.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(UI32_T), POINTER(UI32_T)]
    cdb_unpackField.restype = None

# ./clx_system/clx_sdk/include/cdb/cdb.h: 233
if _libs["libsai.so"].has("cdb_packUi32Field", "cdecl"):
    cdb_packUi32Field = _libs["libsai.so"].get("cdb_packUi32Field", "cdecl")
    cdb_packUi32Field.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(UI32_T), UI32_T]
    cdb_packUi32Field.restype = None

# ./clx_system/clx_sdk/include/cdb/cdb.h: 254
if _libs["libsai.so"].has("cdb_unpackUi32Field", "cdecl"):
    cdb_unpackUi32Field = _libs["libsai.so"].get("cdb_unpackUi32Field", "cdecl")
    cdb_unpackUi32Field.argtypes = [UI32_T, UI32_T, UI32_T, POINTER(UI32_T)]
    cdb_unpackUi32Field.restype = UI32_T

# ./clx_system/clx_sdk/include/cdb/cdb.h: 275
if _libs["libsai.so"].has("cdb_readMmio", "cdecl"):
    cdb_readMmio = _libs["libsai.so"].get("cdb_readMmio", "cdecl")
    cdb_readMmio.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, UI32_T]
    cdb_readMmio.restype = UI32_T

# ./clx_system/clx_sdk/include/cdb/cdb.h: 298
if _libs["libsai.so"].has("cdb_writeMmio", "cdecl"):
    cdb_writeMmio = _libs["libsai.so"].get("cdb_writeMmio", "cdecl")
    cdb_writeMmio.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, UI32_T]
    cdb_writeMmio.restype = None

# ./clx_system/clx_sdk/include/cdb/cdb.h: 325
if _libs["libsai.so"].has("cdb_readEntry", "cdecl"):
    cdb_readEntry = _libs["libsai.so"].get("cdb_readEntry", "cdecl")
    cdb_readEntry.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, POINTER(UI32_T)]
    cdb_readEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/cdb/cdb.h: 352
if _libs["libsai.so"].has("cdb_writeEntry", "cdecl"):
    cdb_writeEntry = _libs["libsai.so"].get("cdb_writeEntry", "cdecl")
    cdb_writeEntry.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, POINTER(UI32_T)]
    cdb_writeEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/cdb/cdb.h: 379
if _libs["libsai.so"].has("cdb_modifyField", "cdecl"):
    cdb_modifyField = _libs["libsai.so"].get("cdb_modifyField", "cdecl")
    cdb_modifyField.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, POINTER(UI32_T)]
    cdb_modifyField.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/cdb/cdb.h: 408
if _libs["libsai.so"].has("cdb_modifyUi32Field", "cdecl"):
    cdb_modifyUi32Field = _libs["libsai.so"].get("cdb_modifyUi32Field", "cdecl")
    cdb_modifyUi32Field.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, UI32_T]
    cdb_modifyUi32Field.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/cdb/cdb.h: 435
if _libs["libsai.so"].has("cdb_modifyMultiFields", "cdecl"):
    cdb_modifyMultiFields = _libs["libsai.so"].get("cdb_modifyMultiFields", "cdecl")
    cdb_modifyMultiFields.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, POINTER(CDB_FVP_T)]
    cdb_modifyMultiFields.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/cdb/cdb.h: 461
if _libs["libsai.so"].has("cdb_addHashEntry", "cdecl"):
    cdb_addHashEntry = _libs["libsai.so"].get("cdb_addHashEntry", "cdecl")
    cdb_addHashEntry.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, POINTER(UI32_T), POINTER(UI32_T)]
    cdb_addHashEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/cdb/cdb.h: 487
if _libs["libsai.so"].has("cdb_lookupHashEntry", "cdecl"):
    cdb_lookupHashEntry = _libs["libsai.so"].get("cdb_lookupHashEntry", "cdecl")
    cdb_lookupHashEntry.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, POINTER(UI32_T), POINTER(UI32_T)]
    cdb_lookupHashEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/cdb/cdb.h: 513
if _libs["libsai.so"].has("cdb_delHashEntry", "cdecl"):
    cdb_delHashEntry = _libs["libsai.so"].get("cdb_delHashEntry", "cdecl")
    cdb_delHashEntry.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, UI32_T, POINTER(UI32_T), POINTER(UI32_T)]
    cdb_delHashEntry.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/include/cdb/cdb.h: 543
if _libs["libsai.so"].has("cdb_resetTable", "cdecl"):
    cdb_resetTable = _libs["libsai.so"].get("cdb_resetTable", "cdecl")
    cdb_resetTable.argtypes = [UI32_T, UI32_T, UI32_T, UI32_T, POINTER(UI32_T)]
    cdb_resetTable.restype = CLX_ERROR_NO_T

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 567
class struct_HAL_PORT_MAP_S(Structure):
    pass

struct_HAL_PORT_MAP_S.__slots__ = [
    'valid',
    'flags',
    'eth_macro',
    'lane',
    'max_speed',
    'die',
    'bin',
    'plane',
    'hw_mac_macro',
    'tm_mac_macro',
    'serdes_mac_macro',
    'mpid',
    'ppid',
]
struct_HAL_PORT_MAP_S._fields_ = [
    ('valid', UI32_T),
    ('flags', UI32_T),
    ('eth_macro', UI32_T),
    ('lane', UI32_T),
    ('max_speed', CLX_PORT_SPEED_T),
    ('die', UI32_T),
    ('bin', UI32_T),
    ('plane', UI32_T),
    ('hw_mac_macro', UI32_T),
    ('tm_mac_macro', UI32_T),
    ('serdes_mac_macro', UI32_T),
    ('mpid', UI32_T),
    ('ppid', UI32_T),
]

HAL_PORT_MAP_T = struct_HAL_PORT_MAP_S# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 567

HAL_MAC_MACRO_BITMAP_T = UI32_T * int((((64 - 1) / 32) + 1))# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 570

HAL_PLANE_PORT_BITMAP_T = UI32_T * int((((96 - 1) / 32) + 1))# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 573

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 616
class struct_anon_26811(Structure):
    pass

struct_anon_26811.__slots__ = [
    'vendor_id',
    'device_id',
    'revision_id',
    'hw_chip_id',
    'lag_epoch_id',
    'bandwidth',
    'frequency',
    'mode',
    'flags',
    'die_bmp',
    'bin_bmp',
    'plane_bmp',
    'mac_macro_bmp',
    'mac_macro_100g_bmp',
    'plane_mac_macro_num',
    'plane_fp_num',
    'plane_eth_port_num',
    'plane_max_port_num',
    'cpu_port',
    'total_port',
    'port_bitmap',
    'port_bitmap_eth',
    'port_bitmap_pp',
    'port_bitmap_phy',
    'port_bitmap_total',
    'ptr_port_map_info',
    'cpi_port',
    'pptr_pport_map_info',
    'ppptr_serdes_port_map_info',
    'ptr_plane_port_bitmap',
    'phy_di_num',
    'lcl_di',
    'di_map',
    'ptr_plane_mode',
    'rc_port',
]
struct_anon_26811._fields_ = [
    ('vendor_id', UI32_T),
    ('device_id', UI32_T),
    ('revision_id', UI32_T),
    ('hw_chip_id', UI32_T),
    ('lag_epoch_id', UI32_T),
    ('bandwidth', UI32_T),
    ('frequency', UI32_T),
    ('mode', UI32_T),
    ('flags', UI32_T),
    ('die_bmp', UI32_T * int(1)),
    ('bin_bmp', UI32_T * int(1)),
    ('plane_bmp', UI32_T * int(1)),
    ('mac_macro_bmp', HAL_MAC_MACRO_BITMAP_T),
    ('mac_macro_100g_bmp', HAL_MAC_MACRO_BITMAP_T),
    ('plane_mac_macro_num', UI32_T),
    ('plane_fp_num', UI32_T),
    ('plane_eth_port_num', UI32_T),
    ('plane_max_port_num', UI32_T),
    ('cpu_port', UI32_T),
    ('total_port', UI32_T),
    ('port_bitmap', CLX_PORT_BITMAP_T),
    ('port_bitmap_eth', CLX_PORT_BITMAP_T),
    ('port_bitmap_pp', CLX_PORT_BITMAP_T),
    ('port_bitmap_phy', CLX_PORT_BITMAP_T),
    ('port_bitmap_total', CLX_PORT_BITMAP_T),
    ('ptr_port_map_info', POINTER(HAL_PORT_MAP_T)),
    ('cpi_port', UI32_T * int(2)),
    ('pptr_pport_map_info', POINTER(POINTER(UI32_T))),
    ('ppptr_serdes_port_map_info', POINTER(POINTER(POINTER(UI32_T)))),
    ('ptr_plane_port_bitmap', POINTER(HAL_PLANE_PORT_BITMAP_T)),
    ('phy_di_num', UI32_T),
    ('lcl_di', UI32_T * int(288)),
    ('di_map', UI32_T * int(288)),
    ('ptr_plane_mode', POINTER(UI32_T)),
    ('rc_port', UI32_T * int(2)),
]

HAL_CHIP_INFO_T = struct_anon_26811# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 616

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 1511
try:
    _ext_ptr_chip_info = (POINTER(HAL_CHIP_INFO_T) * int(16)).in_dll(_libs["libsai.so"], "_ext_ptr_chip_info")
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 747
if _libs["libsai.so"].has("clx_ifmap_initUserPortMap", "cdecl"):
    clx_ifmap_initUserPortMap = _libs["libsai.so"].get("clx_ifmap_initUserPortMap", "cdecl")
    clx_ifmap_initUserPortMap.argtypes = [UI32_T, UI32_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_ifmap_initUserPortMap.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 770
if _libs["libsai.so"].has("clx_ifmap_setUserPortMap", "cdecl"):
    clx_ifmap_setUserPortMap = _libs["libsai.so"].get("clx_ifmap_setUserPortMap", "cdecl")
    clx_ifmap_setUserPortMap.argtypes = [UI32_T, UI32_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_ifmap_setUserPortMap.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 793
if _libs["libsai.so"].has("clx_ifmap_getUserPortMap", "cdecl"):
    clx_ifmap_getUserPortMap = _libs["libsai.so"].get("clx_ifmap_getUserPortMap", "cdecl")
    clx_ifmap_getUserPortMap.argtypes = [UI32_T, UI32_T, POINTER(UI32_T), POINTER(UI32_T)]
    clx_ifmap_getUserPortMap.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 79
if _libs["libsai.so"].has("clx_stk_setMyChipId", "cdecl"):
    clx_stk_setMyChipId = _libs["libsai.so"].get("clx_stk_setMyChipId", "cdecl")
    clx_stk_setMyChipId.argtypes = [UI32_T, UI32_T]
    clx_stk_setMyChipId.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 97
if _libs["libsai.so"].has("clx_stk_getMyChipId", "cdecl"):
    clx_stk_getMyChipId = _libs["libsai.so"].get("clx_stk_getMyChipId", "cdecl")
    clx_stk_getMyChipId.argtypes = [UI32_T, POINTER(UI32_T)]
    clx_stk_getMyChipId.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 117
if _libs["libsai.so"].has("clx_stk_setNeighborChipId", "cdecl"):
    clx_stk_setNeighborChipId = _libs["libsai.so"].get("clx_stk_setNeighborChipId", "cdecl")
    clx_stk_setNeighborChipId.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_stk_setNeighborChipId.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 137
if _libs["libsai.so"].has("clx_stk_getNeighborChipId", "cdecl"):
    clx_stk_getNeighborChipId = _libs["libsai.so"].get("clx_stk_getNeighborChipId", "cdecl")
    clx_stk_getNeighborChipId.argtypes = [UI32_T, UI32_T, POINTER(UI32_T)]
    clx_stk_getNeighborChipId.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 158
if _libs["libsai.so"].has("clx_stk_setCutOffChipId", "cdecl"):
    clx_stk_setCutOffChipId = _libs["libsai.so"].get("clx_stk_setCutOffChipId", "cdecl")
    clx_stk_setCutOffChipId.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_stk_setCutOffChipId.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 178
if _libs["libsai.so"].has("clx_stk_getCutOffChipId", "cdecl"):
    clx_stk_getCutOffChipId = _libs["libsai.so"].get("clx_stk_getCutOffChipId", "cdecl")
    clx_stk_getCutOffChipId.argtypes = [UI32_T, UI32_T, POINTER(UI32_T)]
    clx_stk_getCutOffChipId.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 199
if _libs["libsai.so"].has("clx_stk_addStackingPort", "cdecl"):
    clx_stk_addStackingPort = _libs["libsai.so"].get("clx_stk_addStackingPort", "cdecl")
    clx_stk_addStackingPort.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_stk_addStackingPort.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 220
if _libs["libsai.so"].has("clx_stk_delStackingPort", "cdecl"):
    clx_stk_delStackingPort = _libs["libsai.so"].get("clx_stk_delStackingPort", "cdecl")
    clx_stk_delStackingPort.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_stk_delStackingPort.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 241
if _libs["libsai.so"].has("clx_stk_getStackingPort", "cdecl"):
    clx_stk_getStackingPort = _libs["libsai.so"].get("clx_stk_getStackingPort", "cdecl")
    clx_stk_getStackingPort.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_BITMAP_T)]
    clx_stk_getStackingPort.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 262
if _libs["libsai.so"].has("clx_stk_setPathToRemoteChip", "cdecl"):
    clx_stk_setPathToRemoteChip = _libs["libsai.so"].get("clx_stk_setPathToRemoteChip", "cdecl")
    clx_stk_setPathToRemoteChip.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_stk_setPathToRemoteChip.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 283
if _libs["libsai.so"].has("clx_stk_setReasonMapping", "cdecl"):
    clx_stk_setReasonMapping = _libs["libsai.so"].get("clx_stk_setReasonMapping", "cdecl")
    clx_stk_setReasonMapping.argtypes = [UI32_T, UI32_T, CLX_PKT_RX_REASON_BITMAP_T]
    clx_stk_setReasonMapping.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 303
if _libs["libsai.so"].has("clx_stk_getReasonMapping", "cdecl"):
    clx_stk_getReasonMapping = _libs["libsai.so"].get("clx_stk_getReasonMapping", "cdecl")
    clx_stk_getReasonMapping.argtypes = [UI32_T, UI32_T, POINTER(CLX_PKT_RX_REASON_BITMAP_T)]
    clx_stk_getReasonMapping.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 324
if _libs["libsai.so"].has("clx_stk_addStackingPortToCpu", "cdecl"):
    clx_stk_addStackingPortToCpu = _libs["libsai.so"].get("clx_stk_addStackingPortToCpu", "cdecl")
    clx_stk_addStackingPortToCpu.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_stk_addStackingPortToCpu.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 345
if _libs["libsai.so"].has("clx_stk_delStackingPortToCpu", "cdecl"):
    clx_stk_delStackingPortToCpu = _libs["libsai.so"].get("clx_stk_delStackingPortToCpu", "cdecl")
    clx_stk_delStackingPortToCpu.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_stk_delStackingPortToCpu.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 365
if _libs["libsai.so"].has("clx_stk_getStackingPortToCpu", "cdecl"):
    clx_stk_getStackingPortToCpu = _libs["libsai.so"].get("clx_stk_getStackingPortToCpu", "cdecl")
    clx_stk_getStackingPortToCpu.argtypes = [UI32_T, UI32_T, POINTER(CLX_PORT_BITMAP_T)]
    clx_stk_getStackingPortToCpu.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 386
if _libs["libsai.so"].has("clx_stk_setCpuPathToRemoteChip", "cdecl"):
    clx_stk_setCpuPathToRemoteChip = _libs["libsai.so"].get("clx_stk_setCpuPathToRemoteChip", "cdecl")
    clx_stk_setCpuPathToRemoteChip.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_stk_setCpuPathToRemoteChip.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 408
if _libs["libsai.so"].has("clx_stk_setStackingPortQueueMapping", "cdecl"):
    clx_stk_setStackingPortQueueMapping = _libs["libsai.so"].get("clx_stk_setStackingPortQueueMapping", "cdecl")
    clx_stk_setStackingPortQueueMapping.argtypes = [UI32_T, UI32_T, UI32_T]
    clx_stk_setStackingPortQueueMapping.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_stk.h: 429
if _libs["libsai.so"].has("clx_stk_getStackingPortQueueMapping", "cdecl"):
    clx_stk_getStackingPortQueueMapping = _libs["libsai.so"].get("clx_stk_getStackingPortQueueMapping", "cdecl")
    clx_stk_getStackingPortQueueMapping.argtypes = [UI32_T, UI32_T, POINTER(UI32_T)]
    clx_stk_getStackingPortQueueMapping.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 69
class struct_OSAL_DMA_MPOOL_CONFIG_S(Structure):
    pass

struct_OSAL_DMA_MPOOL_CONFIG_S.__slots__ = [
    'alloc_size',
    'entry_cnt',
    'init_alloc',
]
struct_OSAL_DMA_MPOOL_CONFIG_S._fields_ = [
    ('alloc_size', UI32_T),
    ('entry_cnt', UI32_T),
    ('init_alloc', UI32_T),
]

OSAL_DMA_MPOOL_CONFIG_T = struct_OSAL_DMA_MPOOL_CONFIG_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 69

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 73
if _libs["libsai.so"].has("osal_dma_freePkt", "cdecl"):
    osal_dma_freePkt = _libs["libsai.so"].get("osal_dma_freePkt", "cdecl")
    osal_dma_freePkt.argtypes = [POINTER(None)]
    osal_dma_freePkt.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 77
if _libs["libsai.so"].has("osal_dma_configTxPktPool", "cdecl"):
    osal_dma_configTxPktPool = _libs["libsai.so"].get("osal_dma_configTxPktPool", "cdecl")
    osal_dma_configTxPktPool.argtypes = [UI32_T]
    osal_dma_configTxPktPool.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 81
if _libs["libsai.so"].has("osal_dma_configRxPktPool", "cdecl"):
    osal_dma_configRxPktPool = _libs["libsai.so"].get("osal_dma_configRxPktPool", "cdecl")
    osal_dma_configRxPktPool.argtypes = [UI32_T, POINTER(OSAL_DMA_MPOOL_CONFIG_T)]
    osal_dma_configRxPktPool.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 85
if _libs["libsai.so"].has("osal_dma_allocTxPkt", "cdecl"):
    osal_dma_allocTxPkt = _libs["libsai.so"].get("osal_dma_allocTxPkt", "cdecl")
    osal_dma_allocTxPkt.argtypes = [UI32_T]
    osal_dma_allocTxPkt.restype = POINTER(c_ubyte)
    osal_dma_allocTxPkt.errcheck = lambda v,*a : cast(v, c_void_p)

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 89
if _libs["libsai.so"].has("osal_dma_allocRxPkt", "cdecl"):
    osal_dma_allocRxPkt = _libs["libsai.so"].get("osal_dma_allocRxPkt", "cdecl")
    osal_dma_allocRxPkt.argtypes = []
    osal_dma_allocRxPkt.restype = POINTER(c_ubyte)
    osal_dma_allocRxPkt.errcheck = lambda v,*a : cast(v, c_void_p)

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 93
if _libs["libsai.so"].has("osal_dma_convertVirtToPhy", "cdecl"):
    osal_dma_convertVirtToPhy = _libs["libsai.so"].get("osal_dma_convertVirtToPhy", "cdecl")
    osal_dma_convertVirtToPhy.argtypes = [POINTER(None), POINTER(CLX_ADDR_T)]
    osal_dma_convertVirtToPhy.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 119
if _libs["libsai.so"].has("osal_dma_initDmaMem", "cdecl"):
    osal_dma_initDmaMem = _libs["libsai.so"].get("osal_dma_initDmaMem", "cdecl")
    osal_dma_initDmaMem.argtypes = [UI32_T]
    osal_dma_initDmaMem.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 141
if _libs["libsai.so"].has("osal_dma_deInitDmaMem", "cdecl"):
    osal_dma_deInitDmaMem = _libs["libsai.so"].get("osal_dma_deInitDmaMem", "cdecl")
    osal_dma_deInitDmaMem.argtypes = [UI32_T]
    osal_dma_deInitDmaMem.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 161
if _libs["libsai.so"].has("osal_dma_alloc", "cdecl"):
    osal_dma_alloc = _libs["libsai.so"].get("osal_dma_alloc", "cdecl")
    osal_dma_alloc.argtypes = [UI32_T]
    osal_dma_alloc.restype = POINTER(c_ubyte)
    osal_dma_alloc.errcheck = lambda v,*a : cast(v, c_void_p)

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 182
if _libs["libsai.so"].has("osal_dma_free", "cdecl"):
    osal_dma_free = _libs["libsai.so"].get("osal_dma_free", "cdecl")
    osal_dma_free.argtypes = [POINTER(None)]
    osal_dma_free.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 186
if _libs["libsai.so"].has("osal_dma_showDmaUsage", "cdecl"):
    osal_dma_showDmaUsage = _libs["libsai.so"].get("osal_dma_showDmaUsage", "cdecl")
    osal_dma_showDmaUsage.argtypes = [UI32_T]
    osal_dma_showDmaUsage.restype = CLX_ERROR_NO_T

OSAL_FILE = UI32_T# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_file.h: 51

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_file.h: 53
if _libs["libsai.so"].has("osal_openFile", "cdecl"):
    osal_openFile = _libs["libsai.so"].get("osal_openFile", "cdecl")
    osal_openFile.argtypes = [POINTER(C8_T)]
    osal_openFile.restype = POINTER(OSAL_FILE)

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_file.h: 58
if _libs["libsai.so"].has("osal_closeFile", "cdecl"):
    osal_closeFile = _libs["libsai.so"].get("osal_closeFile", "cdecl")
    osal_closeFile.argtypes = [POINTER(OSAL_FILE)]
    osal_closeFile.restype = None

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_file.h: 62
if _libs["libsai.so"].has("osal_writeFile", "cdecl"):
    osal_writeFile = _libs["libsai.so"].get("osal_writeFile", "cdecl")
    osal_writeFile.argtypes = [POINTER(OSAL_FILE), POINTER(C8_T), I32_T]
    osal_writeFile.restype = I32_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_file.h: 68
if _libs["libsai.so"].has("osal_readFile", "cdecl"):
    osal_readFile = _libs["libsai.so"].get("osal_readFile", "cdecl")
    osal_readFile.argtypes = [POINTER(OSAL_FILE), POINTER(C8_T), I32_T]
    osal_readFile.restype = I32_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_file.h: 74
if _libs["libsai.so"].has("osal_removeFile", "cdecl"):
    osal_removeFile = _libs["libsai.so"].get("osal_removeFile", "cdecl")
    osal_removeFile.argtypes = [POINTER(C8_T)]
    osal_removeFile.restype = CLX_ERROR_NO_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_file.h: 79
if _libs["libsai.so"].has("osal_isExistedFile", "cdecl"):
    osal_isExistedFile = _libs["libsai.so"].get("osal_isExistedFile", "cdecl")
    osal_isExistedFile.argtypes = [POINTER(C8_T)]
    osal_isExistedFile.restype = BOOL_T

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_file.h: 84
if _libs["libsai.so"].has("osal_renameFile", "cdecl"):
    osal_renameFile = _libs["libsai.so"].get("osal_renameFile", "cdecl")
    osal_renameFile.argtypes = [POINTER(C8_T), POINTER(C8_T)]
    osal_renameFile.restype = BOOL_T

# ./clx_system/clx_sdk/include/osal/osal_types.h: 52
try:
    FALSE = 0
except:
    pass

# ./clx_system/clx_sdk/include/osal/osal_types.h: 56
try:
    TRUE = 1
except:
    pass

# ./clx_system/clx_sdk/include/osal/osal_types.h: 67
try:
    UI64_MSW = 1
except:
    pass

# ./clx_system/clx_sdk/include/osal/osal_types.h: 68
try:
    UI64_LSW = 0
except:
    pass

# ./clx_system/clx_sdk/include/osal/osal_types.h: 123
def UI64_HI(dst):
    return ((dst.ui64) [UI64_MSW])

# ./clx_system/clx_sdk/include/osal/osal_types.h: 124
def UI64_LOW(dst):
    return ((dst.ui64) [UI64_LSW])

# ./clx_system/clx_sdk/include/osal/osal_types.h: 216
def UI64_CMP(data1, data2):
    return ((((data1.ui64).value) [UI64_MSW]) > (((data2.ui64).value) [UI64_MSW])) and 1 or ((((data1.ui64).value) [UI64_MSW]) == (((data2.ui64).value) [UI64_MSW])) and ((((data1.ui64).value) [UI64_LSW]) == (((data2.ui64).value) [UI64_LSW])) and 0 or ((((data1.ui64).value) [UI64_LSW]) > (((data2.ui64).value) [UI64_LSW])) and 1 or (-1) or (-1)

# ./clx_system/clx_sdk/include/clx_types.h: 53
try:
    CLX_BIT_OFF = 0
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 54
try:
    CLX_BIT_ON = 1
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 56
try:
    CLX_INVALID_ID = 4294967295
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 57
try:
    CLX_PORT_INVALID = CLX_INVALID_ID
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 58
try:
    CLX_SEG_INVALID = CLX_INVALID_ID
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 63
try:
    CLX_PATH_INVALID = CLX_INVALID_ID
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 65
try:
    CLX_SEMAPHORE_BINARY = 1
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 66
try:
    CLX_SEMAPHORE_SYNC = 0
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 67
try:
    CLX_SEMAPHORE_WAIT_FOREVER = 4294967295
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 86
try:
    CLX_ADDR_PRINT = '0x%llx'
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 92
def CLX_ADDR_64_HI(__addr__):
    return (UI32_T (ord_if_char((__addr__ >> 32)))).value

# ./clx_system/clx_sdk/include/clx_types.h: 93
def CLX_ADDR_64_LOW(__addr__):
    return (UI32_T (ord_if_char((__addr__ & 4294967295)))).value

# ./clx_system/clx_sdk/include/clx_types.h: 94
def CLX_ADDR_32_TO_64(__hi32__, __low32__):
    return ((c_ulonglong (ord_if_char(__low32__))).value | ((c_ulonglong (ord_if_char(__hi32__))).value << 32))

# ./clx_system/clx_sdk/include/clx_types.h: 102
def CLX_BITMAP_SIZE(bit_num):
    return (((bit_num - 1) / 32) + 1)

# ./clx_system/clx_sdk/include/clx_types.h: 103
def CLX_IPV4_IS_MULTICAST(addr):
    return (3758096384 == (addr & 4026531840))

# ./clx_system/clx_sdk/include/clx_types.h: 104
def CLX_IPV6_IS_MULTICAST(addr):
    return (255 == (cast(addr, POINTER(UI8_T)) [0]))

# ./clx_system/clx_sdk/include/clx_types.h: 105
def CLX_MAC_IS_MULTICAST(mac):
    return ((mac [0]) & 1)

# ./clx_system/clx_sdk/include/clx_types.h: 293
try:
    CLX_BUM_INFO_FLAGS_MCAST_VALID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 294
try:
    CLX_BUM_INFO_FLAGS_TO_CPU = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 295
try:
    CLX_BUM_INFO_FLAGS_ADD_VID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 296
try:
    CLX_BUM_INFO_FLAGS_TRILL_ALL_TREE = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_types.h: 334
try:
    CLX_RANGE_INFO_FLAGS_MAX_MEMBER_CNT = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_qos.h: 56
try:
    CLX_QOS_INVALID_PROFILE_ID = 4294967295
except:
    pass

# ./clx_system/clx_sdk/include/clx_qos.h: 97
try:
    CLX_QOS_MAPPING_FLAGS_TC_STICKY = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_meter.h: 56
try:
    CLX_METER_INVALID_METER_ID = 4294967295
except:
    pass

# ./clx_system/clx_sdk/include/clx_meter.h: 97
try:
    CLX_METER_CFG_FLAGS_COLOR_AWARE = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_meter.h: 98
try:
    CLX_METER_CFG_FLAGS_LAYER1 = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_meter.h: 99
try:
    CLX_METER_CFG_FLAGS_PORT_BASED = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_meter.h: 100
try:
    CLX_METER_CFG_FLAGS_PACKET_RATE = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_meter.h: 122
try:
    CLX_METER_PORT_CFG_FLAGS_METER_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_meter.h: 123
try:
    CLX_METER_PORT_CFG_FLAGS_LAYER2 = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_meter.h: 124
try:
    CLX_METER_PORT_CFG_FLAGS_PACKET_RATE = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 54
try:
    CLX_PORT_NUM = 288
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 55
try:
    CLX_PORT_BITMAP_SIZE = (CLX_BITMAP_SIZE (CLX_PORT_NUM))
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 56
try:
    CLX_PORT_PROFILE_INVALID = (UI32_T (ord_if_char((-1)))).value
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 59
try:
    CLX_PORT_FLAGS_INIT_ACTIVE = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 60
try:
    CLX_PORT_FLAGS_GUARANTEED = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 61
try:
    CLX_PORT_FLAGS_SET_MAP_DONE = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 62
try:
    CLX_PORT_FLAGS_CPI = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 63
try:
    CLX_PORT_FLAGS_RCP = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 65
try:
    CLX_PORT_ANLT_DISABLE = 0
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 66
try:
    CLX_PORT_ANLT_ENABLE = 1
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 67
try:
    CLX_PORT_ANLT_ENABLE_LT = 2
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 68
try:
    CLX_PORT_ANLT_LAST = 3
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 70
try:
    CLX_PORT_FEC_DISABLE = 0
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 71
try:
    CLX_PORT_FEC_ENABLE = 1
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 72
try:
    CLX_PORT_FEC_RS528 = 2
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 73
try:
    CLX_PORT_FEC_RS544 = 3
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 74
try:
    CLX_PORT_FEC_RS272 = 4
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 75
try:
    CLX_PORT_FEC_LAST = 5
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 76
try:
    CLX_PORT_FEC_RS = CLX_PORT_FEC_RS528
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 78
try:
    CLX_PORT_LINK_DOWN = 0
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 79
try:
    CLX_PORT_LINK_UP = 1
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 81
try:
    CLX_PORT_FAULT_NONE = 0
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 82
try:
    CLX_PORT_FAULT_LOCAL = 1
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 83
try:
    CLX_PORT_FAULT_REMOTE = 2
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 85
try:
    CLX_PORT_FC_STATUS_OFF = 0
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 86
try:
    CLX_PORT_FC_STATUS_ON = 1
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 88
try:
    CLX_PORT_TS_REPLACE_MAC_SA_WITH_IGR = 0
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 89
try:
    CLX_PORT_TS_REPLACE_MAC_SA_WITH_EGR = 1
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 90
try:
    CLX_PORT_TS_REPLACE_MAC_DA_WITH_IGR = 2
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 91
try:
    CLX_PORT_TS_REPLACE_MAC_DA_WITH_EGR = 3
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 95
def CLX_PORT_ADD(bitmap, port):
    return ((bitmap [(port / 32)]) | (1 << (port % 32)))

# ./clx_system/clx_sdk/include/clx_port.h: 96
def CLX_PORT_DEL(bitmap, port):
    return ((bitmap [(port / 32)]) & (~(1 << (port % 32))))

# ./clx_system/clx_sdk/include/clx_port.h: 97
def CLX_PORT_CHK(bitmap, port):
    return (((bitmap [(port / 32)]) & (1 << (port % 32))) != 0)

# ./clx_system/clx_sdk/include/clx_port.h: 103
def CLX_PORT_BITMAP_CLEAR(bitmap):
    return 0

# ./clx_system/clx_sdk/include/clx_port.h: 114
def CLX_PORT_BITMAP_EMPTY(bitmap):
    return ((((((((((bitmap [0]) == 0) and ((bitmap [1]) == 0)) and ((bitmap [2]) == 0)) and ((bitmap [3]) == 0)) and ((bitmap [4]) == 0)) and ((bitmap [5]) == 0)) and ((bitmap [6]) == 0)) and ((bitmap [7]) == 0)) and ((bitmap [8]) == 0))

# ./clx_system/clx_sdk/include/clx_port.h: 125
def CLX_PORT_BITMAP_EQUAL(bitmap_a, bitmap_b):
    return ((((((((((bitmap_a [0]) == (bitmap_b [0])) and ((bitmap_a [1]) == (bitmap_b [1]))) and ((bitmap_a [2]) == (bitmap_b [2]))) and ((bitmap_a [3]) == (bitmap_b [3]))) and ((bitmap_a [4]) == (bitmap_b [4]))) and ((bitmap_a [5]) == (bitmap_b [5]))) and ((bitmap_a [6]) == (bitmap_b [6]))) and ((bitmap_a [7]) == (bitmap_b [7]))) and ((bitmap_a [8]) == (bitmap_b [8])))

# ./clx_system/clx_sdk/include/clx_port.h: 210
try:
    CLX_PORT_ABILITY_SPEED_50GBASE_CR2 = CLX_PORT_ABILITY_SPEED_50GBASE_KR2_CR2
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 483
try:
    CLX_PORT_ABILITY_FLAGS_AUTONEG = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 530
try:
    CLX_PORT_SEG_SRV_FLAGS_ENABLE_LEARN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 531
try:
    CLX_PORT_SEG_SRV_FLAGS_SA_MOVE_EXCEPTION = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 532
try:
    CLX_PORT_SEG_SRV_FLAGS_SA_MISS_EXCEPTION = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 533
try:
    CLX_PORT_SEG_SRV_FLAGS_REMOVE_VLAN_TAG = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 534
try:
    CLX_PORT_SEG_SRV_FLAGS_QOS_DO_NOT_MODIFY = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 535
try:
    CLX_PORT_SEG_SRV_FLAGS_QOS_USE_INNER = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 536
try:
    CLX_PORT_SEG_SRV_FLAGS_PCP_DEI_TO_PHB_PROFILE_VALID = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 537
try:
    CLX_PORT_SEG_SRV_FLAGS_DSCP_TO_PHB_PROFILE_VALID = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 538
try:
    CLX_PORT_SEG_SRV_FLAGS_PHB_TO_PCP_DEI_PROFILE_VALID = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 539
try:
    CLX_PORT_SEG_SRV_FLAGS_PHB_TO_DSCP_PROFILE_VALID = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 540
try:
    CLX_PORT_SEG_SRV_FLAGS_IGR_METER_VALID = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 541
try:
    CLX_PORT_SEG_SRV_FLAGS_EGR_METER_VALID = (1 << 11)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 542
try:
    CLX_PORT_SEG_SRV_FLAGS_IGR_COUNTER_VALID = (1 << 12)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 543
try:
    CLX_PORT_SEG_SRV_FLAGS_EGR_COUNTER_VALID = (1 << 13)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 544
try:
    CLX_PORT_SEG_SRV_FLAGS_IGR_DIST_COUNTER_VALID = (1 << 14)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 545
try:
    CLX_PORT_SEG_SRV_FLAGS_EGR_DIST_COUNTER_VALID = (1 << 15)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 546
try:
    CLX_PORT_SEG_SRV_FLAGS_TRILL_AF_EN = (1 << 16)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 547
try:
    CLX_PORT_SEG_SRV_FLAGS_TRILL_DF_EN = (1 << 17)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 549
try:
    CLX_PORT_SEG_SRV_FLAGS_L3_ONLY = (1 << 18)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 550
try:
    CLX_PORT_SEG_SRV_FLAGS_IGR_SAMPLE_TO_MIR = (1 << 19)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 551
try:
    CLX_PORT_SEG_SRV_FLAGS_EGR_SAMPLE_TO_MIR = (1 << 20)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 552
try:
    CLX_PORT_SEG_SRV_FLAGS_EGR_SAMPLE_HIGH_LATENCY = (1 << 21)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 553
try:
    CLX_PORT_SEG_SRV_FLAGS_QINQ_TRANSPARENT_CVID = (1 << 22)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 554
try:
    CLX_PORT_SEG_SRV_FLAGS_DTEL = (1 << 23)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 588
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_TRUST_1P = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 589
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_TRUST_VLAN = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 590
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_PCP_DEI_TO_PHB_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 591
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_PHB_TO_PCP_DEI_VALID = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 592
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_DSCP_TO_PHB_VALID = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 593
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_PHB_TO_DSCP_VALID = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 594
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_EXP_TO_PHB_VALID = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 595
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_PHB_TO_EXP_VALID = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 596
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_IGR_METER_VALID = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 597
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_EGR_METER_VALID = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 598
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_IGR_COUNTER_VALID = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 599
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_EGR_COUNTER_VALID = (1 << 11)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 600
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_IGR_DIST_COUNTER_VALID = (1 << 12)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 601
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_EGR_DIST_COUNTER_VALID = (1 << 13)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 602
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_IGR_SAMPLE_TO_MIR = (1 << 14)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 603
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_EGR_SAMPLE_TO_MIR = (1 << 15)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 604
try:
    CLX_PORT_INTF_PROPERTY_FLAGS_EGR_SAMPLE_HIGH_LATENCY = (1 << 16)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 639
try:
    CLX_PORT_TX_COEF_FLAGS_C0 = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 640
try:
    CLX_PORT_TX_COEF_FLAGS_C1 = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 641
try:
    CLX_PORT_TX_COEF_FLAGS_CN1 = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 642
try:
    CLX_PORT_TX_COEF_FLAGS_C2 = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_port.h: 643
try:
    CLX_PORT_TX_COEF_FLAGS_CN2 = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 188
try:
    CLX_VLAN_SUBNET_VLAN_FLAGS_IPV6 = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 189
try:
    CLX_VLAN_SUBNET_VLAN_FLAGS_PORT_VALID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 216
try:
    CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_VID_VALID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 217
try:
    CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_VID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 218
try:
    CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_PCP_DEI_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 219
try:
    CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_PCP_DEI = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 221
try:
    CLX_VLAN_CLASSIFY_TYPE_FLAGS_STAG_EXIST_VALID = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 222
try:
    CLX_VLAN_CLASSIFY_TYPE_FLAGS_STAG_EXIST = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 223
try:
    CLX_VLAN_CLASSIFY_TYPE_FLAGS_CTAG_EXIST_VALID = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 224
try:
    CLX_VLAN_CLASSIFY_TYPE_FLAGS_CTAG_EXIST = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 226
try:
    CLX_VLAN_CLASSIFY_TYPE_FLAGS_PORT_VALID = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 228
try:
    CLX_VLAN_CLASSIFY_TYPE_FLAGS_VLAN_TAG_MODE_1Q = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 257
try:
    CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_VID_VALID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 258
try:
    CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_VID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 259
try:
    CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_PCP_DEI_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 260
try:
    CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_PCP_DEI = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 262
try:
    CLX_VLAN_CLASSIFY_ADDR_FLAGS_STAG_EXIST_VALID = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 263
try:
    CLX_VLAN_CLASSIFY_ADDR_FLAGS_STAG_EXIST = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 264
try:
    CLX_VLAN_CLASSIFY_ADDR_FLAGS_CTAG_EXIST_VALID = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 265
try:
    CLX_VLAN_CLASSIFY_ADDR_FLAGS_CTAG_EXIST = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 267
try:
    CLX_VLAN_CLASSIFY_ADDR_FLAGS_PORT_VALID = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 269
try:
    CLX_VLAN_CLASSIFY_ADDR_FLAGS_IPV6_ENTRY = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 270
try:
    CLX_VLAN_CLASSIFY_ADDR_FLAGS_VLAN_TAG_MODE_1Q = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 281
try:
    CLX_VLAN_TAG_ACTION_FLAGS_SVID_VALID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 282
try:
    CLX_VLAN_TAG_ACTION_FLAGS_CVID_VALID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vlan.h: 283
try:
    CLX_VLAN_TAG_ACTION_FLAGS_PCP_DEI_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vm.h: 105
try:
    CLX_VM_PORT_PRTY_FLAGS_REMOVE_EGR_SCID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vm.h: 106
try:
    CLX_VM_PORT_PRTY_FLAGS_ECID_USE_DEFAULT = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vm.h: 117
try:
    CLX_VM_PE_UCAST_ADDR_FLAGS_DROP = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_vm.h: 129
try:
    CLX_VM_PE_MCAST_ADDR_FLAGS_DROP = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 60
try:
    CLX_L3_MCAST_FLAGS_WITH_ID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 143
try:
    CLX_L3_INTF_FLAGS_IPV4_UC = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 144
try:
    CLX_L3_INTF_FLAGS_IPV6_UC = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 145
try:
    CLX_L3_INTF_FLAGS_IPV4_MC = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 146
try:
    CLX_L3_INTF_FLAGS_IPV6_MC = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 147
try:
    CLX_L3_INTF_FLAGS_NO_MOD_SA = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 148
try:
    CLX_L3_INTF_FLAGS_NO_MOD_DA = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 149
try:
    CLX_L3_INTF_FLAGS_NO_MOD_VLAN = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 150
try:
    CLX_L3_INTF_FLAGS_ICMPV4_REDIR_EN = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 151
try:
    CLX_L3_INTF_FLAGS_ICMPV6_REDIR_EN = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 152
try:
    CLX_L3_INTF_FLAGS_IPV4_OPTION_HEADER_SW_FWD_EN = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 153
try:
    CLX_L3_INTF_FLAGS_IPV6_OPTION_HEADER_SW_FWD_EN = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 154
try:
    CLX_L3_INTF_FLAGS_WITH_ID = (1 << 11)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 155
try:
    CLX_L3_INTF_FLAGS_IGR_METER_VALID = (1 << 12)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 156
try:
    CLX_L3_INTF_FLAGS_EGR_METER_VALID = (1 << 13)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 157
try:
    CLX_L3_INTF_FLAGS_IGR_CNT_VALID = (1 << 14)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 158
try:
    CLX_L3_INTF_FLAGS_EGR_CNT_VALID = (1 << 15)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 159
try:
    CLX_L3_INTF_FLAGS_IGR_DIST_CNT_VALID = (1 << 16)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 160
try:
    CLX_L3_INTF_FLAGS_EGR_DIST_CNT_VALID = (1 << 17)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 189
try:
    CLX_L3_HOST_FLAGS_DROP = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 190
try:
    CLX_L3_HOST_FLAGS_KEEP_TTL = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 191
try:
    CLX_L3_HOST_FLAGS_SIP_TC_REMARK = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 192
try:
    CLX_L3_HOST_FLAGS_DIP_TC_REMARK = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 193
try:
    CLX_L3_HOST_FLAGS_TC_STICKY = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 194
try:
    CLX_L3_HOST_FLAGS_DST_HIT = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 195
try:
    CLX_L3_HOST_FLAGS_SRC_HIT = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 196
try:
    CLX_L3_HOST_FLAGS_MPLS_LABEL_EN = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 211
try:
    CLX_L3_SUBNET_BCAST_FLAGS_KEEP_TTL = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 224
try:
    CLX_L3_ROUTE_FLAGS_DROP = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 225
try:
    CLX_L3_ROUTE_FLAGS_KEEP_TTL = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 226
try:
    CLX_L3_ROUTE_FLAGS_SIP_TC_REMARK = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 227
try:
    CLX_L3_ROUTE_FLAGS_DIP_TC_REMARK = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 228
try:
    CLX_L3_ROUTE_FLAGS_TC_STICKY = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 229
try:
    CLX_L3_ROUTE_FLAGS_DST_HIT = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 230
try:
    CLX_L3_ROUTE_FLAGS_SRC_HIT = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 231
try:
    CLX_L3_ROUTE_FLAGS_MPLS_LABEL_EN = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 232
try:
    CLX_L3_ROUTE_FLAGS_GLOBAL_ROUTE = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 272
try:
    CLX_L3_ECMP_DLB_FLAGS_DLB = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 277
try:
    CLX_L3_ECMP_DLB_FLAGS_ET = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 313
try:
    CLX_L3_ECMP_GRP_FLAGS_KEEP_TTL = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 314
try:
    CLX_L3_ECMP_GRP_FLAGS_URPF_STRICT_EN = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 315
try:
    CLX_L3_ECMP_GRP_FLAGS_WECMP_EN = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 331
try:
    CLX_L3_ECMP_PATH_FLAGS_MPLS_LABEL_VALID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 357
try:
    CLX_L3_VRF_FLAGS_FALL_BACK_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 358
try:
    CLX_L3_VRF_FLAGS_SIP_FAVOR = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 363
try:
    CLX_L3_VRF_FLAGS_METER_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 364
try:
    CLX_L3_VRF_FLAGS_CNT_VALID = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 365
try:
    CLX_L3_VRF_FLAGS_DIST_CNT_VALID = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 381
try:
    CLX_L3_MCAST_FLAGS_PIM_BIDIR = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 385
try:
    CLX_L3_MCAST_FLAGS_DROP = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 389
try:
    CLX_L3_MCAST_FLAGS_NO_MODIFY_TTL = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 393
try:
    CLX_L3_MCAST_FLAGS_SPT_READY = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 405
try:
    CLX_L3_MCAST_FLAGS_HIT = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 406
try:
    CLX_L3_MCAST_FLAGS_TO_CPU = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 452
try:
    CLX_L3_MCAST_EGR_MPLS_FLAGS_LABEL = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 453
try:
    CLX_L3_MCAST_EGR_MPLS_FLAGS_TUNNEL = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 474
try:
    CLX_L3_MCAST_EGR_FLAGS_SVID_VALID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 475
try:
    CLX_L3_MCAST_EGR_FLAGS_CVID_VALID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 476
try:
    CLX_L3_MCAST_EGR_FLAGS_KEEP_DMAC = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 477
try:
    CLX_L3_MCAST_EGR_FLAGS_KEEP_SMAC = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 478
try:
    CLX_L3_MCAST_EGR_FLAGS_KEEP_TTL = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 489
try:
    CLX_L3_BFD_FLAGS_ICMPV4_REDIR_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 490
try:
    CLX_L3_BFD_FLAGS_ICMPV6_REDIR_EN = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 491
try:
    CLX_L3_BFD_FLAGS_CHECK_EN = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 492
try:
    CLX_L3_BFD_FLAGS_BYPASS_SOURCE_CHECK = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 517
try:
    CLX_L3_ADJ_FLAGS_SVID_VALID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 518
try:
    CLX_L3_ADJ_FLAGS_CVID_VALID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 519
try:
    CLX_L3_ADJ_FLAGS_DST_MAC_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 520
try:
    CLX_L3_ADJ_FLAGS_KEEP_SA = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 521
try:
    CLX_L3_ADJ_FLAGS_KEEP_VLAN = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 524
try:
    CLX_L3_ADJ_FLAGS_FRR_EN = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 525
try:
    CLX_L3_ADJ_FLAGS_WITH_ID = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 528
try:
    CLX_L3_ADJ_FLAGS_KEEP_TTL = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 529
try:
    CLX_L3_ADJ_FLAGS_URPF_STRICT_EN = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 530
try:
    CLX_L3_ADJ_FLAGS_DROP = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 534
try:
    CLX_L3_ADJ_FLAGS_SEG_ID_VALID = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3.h: 566
try:
    CLX_L3_PIM_REG_INFO_FLAGS_TO_CPU = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 56
try:
    CLX_MPLS_MAX_LABEL_NUM = 4
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 72
try:
    CLX_MPLS_LSE_FLAGS_SET_TTL = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 77
try:
    CLX_MPLS_LSE_FLAGS_SET_EXP = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 82
try:
    CLX_MPLS_LSE_FLAGS_EL = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 93
try:
    CLX_MPLS_ENCAP_FLAGS_UNDERLAY_INTF = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 94
try:
    CLX_MPLS_ENCAP_FLAGS_WITH_ID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 95
try:
    CLX_MPLS_ENCAP_FLAGS_SR = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 127
try:
    CLX_MPLS_INIT_FLAGS_P2MP = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 128
try:
    CLX_MPLS_INIT_FLAGS_PCP = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 129
try:
    CLX_MPLS_INIT_FLAGS_DEI = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 130
try:
    CLX_MPLS_INIT_FLAGS_METER = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 131
try:
    CLX_MPLS_INIT_FLAGS_CNT = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 132
try:
    CLX_MPLS_INIT_FLAGS_DIST_CNT = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 133
try:
    CLX_MPLS_INIT_FLAGS_PHB_TO_EXP_PROFILE = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 134
try:
    CLX_MPLS_INIT_FLAGS_PHB_TO_PCP_PROFILE = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 135
try:
    CLX_MPLS_INIT_FLAGS_FRR = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 136
try:
    CLX_MPLS_INIT_FLAGS_VLAN_TAG = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 137
try:
    CLX_MPLS_INIT_FLAGS_SAMPLE_TO_MIR = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 138
try:
    CLX_MPLS_INIT_FLAGS_SAMPLE_HIGH_LATENCY = (1 << 11)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 139
try:
    CLX_MPLS_INIT_PROPERTY_FLAGS_DTEL = (1 << 12)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 163
try:
    CLX_MPLS_TERM_FLAGS_COPY_TTL_TO_INNER = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 167
try:
    CLX_MPLS_TERM_FLAGS_KEEP_INNER_QOS = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 168
try:
    CLX_MPLS_TERM_FLAGS_USE_INNER_PHB = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 169
try:
    CLX_MPLS_TERM_FLAGS_DEFAULT_PCP = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 170
try:
    CLX_MPLS_TERM_FLAGS_DEFAULT_DEI = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 171
try:
    CLX_MPLS_TERM_FLAGS_METER = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 172
try:
    CLX_MPLS_TERM_FLAGS_CNT = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 173
try:
    CLX_MPLS_TERM_FLAGS_DIST_CNT = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 174
try:
    CLX_MPLS_TERM_FLAGS_EXP_TO_PHB_PROFILE = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 175
try:
    CLX_MPLS_TERM_FLAGS_PCP_TO_PHB_PROFILE = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 176
try:
    CLX_MPLS_TERM_FLAGS_DSCP_TO_PHB_PROFILE = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 177
try:
    CLX_MPLS_TERM_FLAGS_VLAN_TAG = (1 << 11)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 178
try:
    CLX_MPLS_TERM_FLAGS_USE_OUTER_SRV = (1 << 12)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 179
try:
    CLX_MPLS_TERM_FLAGS_SAMPLE_TO_MIR = (1 << 13)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 180
try:
    CLX_MPLS_TERM_PROPERTY_FLAGS_DTEL = (1 << 14)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 210
try:
    CLX_MPLS_NH_FLAGS_REMARK_TC = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 211
try:
    CLX_MPLS_NH_FLAGS_KEEP_INNER_QOS = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 212
try:
    CLX_MPLS_NH_FLAGS_COPY_TTL_TO_INNER = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 213
try:
    CLX_MPLS_NH_FLAGS_FRR = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 214
try:
    CLX_MPLS_NH_FLAGS_NO_DEC_TTL = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 215
try:
    CLX_MPLS_NH_FLAGS_P2MP = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 238
try:
    CLX_MPLS_PW_KEY_FLAGS_OUT_VALID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 239
try:
    CLX_MPLS_PW_KEY_FLAGS_CW = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 240
try:
    CLX_MPLS_PW_KEY_FLAGS_PWEL = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 241
try:
    CLX_MPLS_PW_KEY_FLAGS_TRUNK = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 242
try:
    CLX_MPLS_PW_KEY_FLAGS_SVID = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 243
try:
    CLX_MPLS_PW_KEY_FLAGS_CVID = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 271
try:
    CLX_MPLS_PW_FALGS_INBOUND_METER = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 272
try:
    CLX_MPLS_PW_FALGS_OUTBOUND_METER = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 273
try:
    CLX_MPLS_PW_FLAGS_INBOUND_CNT = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 274
try:
    CLX_MPLS_PW_FLAGS_OUTBOUND_CNT = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 275
try:
    CLX_MPLS_PW_FLAGS_INBOUND_DIST_CNT = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 276
try:
    CLX_MPLS_PW_FLAGS_OUTBOUND_DIST_CNT = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 277
try:
    CLX_MPLS_PW_FLAGS_PHB_TO_EXP_PROFILE = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 278
try:
    CLX_MPLS_PW_FLAGS_PHB_TO_PCP_PROFILE = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 279
try:
    CLX_MPLS_PW_FLAGS_EXP_TO_PHB_PROFILE = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 280
try:
    CLX_MPLS_PW_FLAGS_PCP_TO_PHB_PROFILE = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 281
try:
    CLX_MPLS_PW_FLAGS_DSCP_TO_PHB_PROFILE = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 282
try:
    CLX_MPLS_PW_FLAGS_KEEP_INNER_QOS = (1 << 11)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 283
try:
    CLX_MPLS_PW_FLAGS_USE_INNER_PHB = (1 << 12)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 284
try:
    CLX_MPLS_PW_FLAGS_FRR = (1 << 13)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 285
try:
    CLX_MPLS_PW_FLAGS_COPY_TTL_TO_INNER = (1 << 14)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 286
try:
    CLX_MPLS_PW_FLAGS_ENABLE_LEARN = (1 << 15)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 287
try:
    CLX_MPLS_PW_FLAGS_BC_MCAST_VALID = (1 << 16)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 288
try:
    CLX_MPLS_PW_FLAGS_UUC_MCAST_VALID = (1 << 17)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 289
try:
    CLX_MPLS_PW_FLAGS_UMC_MCAST_VALID = (1 << 18)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 290
try:
    CLX_MPLS_PW_FLAGS_BUD_MCAST_VALID = (1 << 19)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 291
try:
    CLX_MPLS_PW_FLAGS_L3_INTF_VALID = (1 << 20)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 303
try:
    CLX_MPLS_AC_FLAGS_SVID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mpls.h: 304
try:
    CLX_MPLS_AC_FLAGS_CVID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 349
try:
    CLX_PKT_RX_REASON_BITMAP_SIZE = (CLX_BITMAP_SIZE (CLX_PKT_RX_REASON_LAST))
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 354
def CLX_PKT_SET_REASONTBIT(reason_bmp, reason):
    return ((cast(reason_bmp, POINTER(UI32_T)) [(reason / 32)]) | (1 << (reason % 32)))

# ./clx_system/clx_sdk/include/clx_pkt.h: 356
def CLX_PKT_CLR_REASONTBIT(reason_bmp, reason):
    return ((cast(reason_bmp, POINTER(UI32_T)) [(reason / 32)]) & (~(1 << (reason % 32))))

# ./clx_system/clx_sdk/include/clx_pkt.h: 358
def CLX_PKT_CHK_REASONTBIT(reason_bmp, reason):
    return ((cast(reason_bmp, POINTER(UI32_T)) [(reason / 32)]) & (1 << (reason % 32)))

# ./clx_system/clx_sdk/include/clx_pkt.h: 382
try:
    CLX_PKT_CTRL_TO_CPU_IPV6_FLAGS_MY_ROUTER_MAC_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 383
try:
    CLX_PKT_CTRL_TO_CPU_IPV6_FLAGS_MY_ROUTER_MAC_CHECK = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 384
try:
    CLX_PKT_CTRL_TO_CPU_IPV6_FLAGS_ROUTE_EN = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 385
try:
    CLX_PKT_CTRL_TO_CPU_IPV6_FLAGS_ROUTE_CHECK = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 386
try:
    CLX_PKT_CTRL_TO_CPU_IPV6_FLAGS_ICMP_EN = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 387
try:
    CLX_PKT_CTRL_TO_CPU_IPV6_FLAGS_DIP_RANGE_EN = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 414
try:
    CLX_PKT_CTRL_TO_CPU_IPV4_FLAGS_MY_ROUTER_MAC_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 415
try:
    CLX_PKT_CTRL_TO_CPU_IPV4_FLAGS_MY_ROUTER_MAC_CHECK = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 416
try:
    CLX_PKT_CTRL_TO_CPU_IPV4_FLAGS_ROUTE_EN = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 417
try:
    CLX_PKT_CTRL_TO_CPU_IPV4_FLAGS_ROUTE_CHECK = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 418
try:
    CLX_PKT_CTRL_TO_CPU_IPV4_FLAGS_HEADER_OPTION_EN = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 419
try:
    CLX_PKT_CTRL_TO_CPU_IPV4_FLAGS_HEADER_OPTION_CHECK = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 420
try:
    CLX_PKT_CTRL_TO_CPU_IPV4_FLAGS_HEADER_FRAGMENT_EN = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 421
try:
    CLX_PKT_CTRL_TO_CPU_IPV4_FLAGS_HEADER_FRAGMENT_CHECK = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 422
try:
    CLX_PKT_CTRL_TO_CPU_IPV4_FLAGS_ICMP_EN = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 423
try:
    CLX_PKT_CTRL_TO_CPU_IPV4_FLAGS_DIP_RANGE_EN = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 441
try:
    CLX_PKT_CTRL_TO_CPU_ARP_FLAGS_MY_ROUTER_MAC_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 442
try:
    CLX_PKT_CTRL_TO_CPU_ARP_FLAGS_MY_ROUTER_MAC_CHECK = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 460
try:
    CLX_PKT_CTRL_TO_CPU_L2_FLAGS_MY_ROUTER_MAC_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 461
try:
    CLX_PKT_CTRL_TO_CPU_L2_FLAGS_MY_ROUTER_MAC_CHECK = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 462
try:
    CLX_PKT_CTRL_TO_CPU_L2_FLAGS_LLC_EN = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 463
try:
    CLX_PKT_CTRL_TO_CPU_L2_FLAGS_LLC_CHECK = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 474
try:
    CLX_PKT_CTRL_TO_CPU_MATCH_SIZE = 25
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 617
try:
    CLX_PKT_RX_PKT_FLAGS_ROUTE = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 618
try:
    CLX_PKT_RX_PKT_FLAGS_BPDU = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 619
try:
    CLX_PKT_RX_PKT_FLAGS_TUNNEL_TERM = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 620
try:
    CLX_PKT_RX_PKT_FLAGS_SPAN_TERM = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 621
try:
    CLX_PKT_RX_PKT_FLAGS_TRUNCATE = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 622
try:
    CLX_PKT_RX_PKT_FLAGS_DROP = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 652
try:
    CLX_PKT_RX_CFG_FLAGS_DEINIT = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 685
try:
    CLX_PKT_TX_RAW_CPU_NEIGHBOR = 4294967294
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 686
try:
    CLX_PKT_TX_RAW_CPU_BROADCAST = 4294967295
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 722
try:
    CLX_PKT_TX_PKT_FLAGS_PTP_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 723
try:
    CLX_PKT_TX_PKT_FLAGS_PTP_2STEP_SYNC_MESSAGE = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 724
try:
    CLX_PKT_TX_PKT_FLAGS_PTP_1STEP_SYNC_MESSAGE = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 725
try:
    CLX_PKT_TX_PKT_FLAGS_PTP_DELAY_REQUEST = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 726
try:
    CLX_PKT_TX_PKT_FLAGS_PTP_TC_EN = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 727
try:
    CLX_PKT_TX_PKT_FLAGS_PTP_PEER_DELAY_REQUEST = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_pkt.h: 728
try:
    CLX_PKT_TX_PKT_FLAGS_PTP_PEER_DELAY_RESPONSE = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 58
try:
    CLX_L2_MCAST_FLAGS_REPLICATION = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 63
try:
    CLX_L2_MCAST_FLAGS_ADD_WITH_ID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 64
try:
    CLX_L2_MCAST_FLAGS_BYPASS_LAG_PRUNE = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 83
try:
    CLX_L2_ADDR_FLAGS_STATIC = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 84
try:
    CLX_L2_ADDR_FLAGS_PENDING = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 85
try:
    CLX_L2_ADDR_FLAGS_DROP = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 86
try:
    CLX_L2_ADDR_FLAGS_SECURE = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 87
try:
    CLX_L2_ADDR_FLAGS_HIT = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 88
try:
    CLX_L2_ADDR_FLAGS_SVID_VALID = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 89
try:
    CLX_L2_ADDR_FLAGS_CVID_VALID = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 90
try:
    CLX_L2_ADDR_FLAGS_TC_MODE_SA = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 91
try:
    CLX_L2_ADDR_FLAGS_TC_MODE_DA = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 92
try:
    CLX_L2_ADDR_FLAGS_TC_STICKY = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 93
try:
    CLX_L2_ADDR_FLAGS_TO_CPU = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 94
try:
    CLX_L2_ADDR_FLAGS_NO_CALLBACK = (1 << 11)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 95
try:
    CLX_L2_ADDR_FLAGS_OVERWRITE_DYNAMIC = (1 << 12)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 200
try:
    CLX_L2_MCAST_EGR_INTF_FLAGS_SVID_VALID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 201
try:
    CLX_L2_MCAST_EGR_INTF_FLAGS_CVID_VALID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 214
try:
    CLX_L2_MCAST_ADDR_FLAGS_DROP = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 215
try:
    CLX_L2_MCAST_ADDR_FLAGS_TC_MODE_SA = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 216
try:
    CLX_L2_MCAST_ADDR_FLAGS_TC_MODE_DA = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 217
try:
    CLX_L2_MCAST_ADDR_FLAGS_TC_STICKY = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 218
try:
    CLX_L2_MCAST_ADDR_FLAGS_TO_CPU = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 219
try:
    CLX_L2_MCAST_ADDR_FLAGS_SVID_VALID = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 240
try:
    CLX_L2_IP_MCAST_GROUP_FLAGS_DROP = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 241
try:
    CLX_L2_IP_MCAST_GROUP_FLAGS_TO_CPU = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l2.h: 242
try:
    CLX_L2_IP_MCAST_GROUP_FLAGS_SVID_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 72
try:
    CLX_FCOE_INTF_FLAGS_ROUTING_ENABLE = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 73
try:
    CLX_FCOE_INTF_FLAGS_IGR_METER_VALID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 74
try:
    CLX_FCOE_INTF_FLAGS_EGR_METER_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 75
try:
    CLX_FCOE_INTF_FLAGS_IGR_COUNTER_VALID = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 76
try:
    CLX_FCOE_INTF_FLAGS_EGR_COUNTER_VALID = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 77
try:
    CLX_FCOE_INTF_FLAGS_IGR_DIST_COUNTER_VALID = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 78
try:
    CLX_FCOE_INTF_FLAGS_EGR_DIST_COUNTER_VALID = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 103
try:
    CLX_FCOE_HOST_FLAGS_KEEP_TTL = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 104
try:
    CLX_FCOE_HOST_FLAGS_SID_TC_REMARK = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 105
try:
    CLX_FCOE_HOST_FLAGS_DID_TC_REMARK = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 106
try:
    CLX_FCOE_HOST_FLAGS_TC_STICKY = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 121
try:
    CLX_FCOE_ROUTE_FLAGS_KEEP_TTL = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 122
try:
    CLX_FCOE_ROUTE_FLAGS_SID_TC_REMARK = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 123
try:
    CLX_FCOE_ROUTE_FLAGS_DID_TC_REMARK = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 124
try:
    CLX_FCOE_ROUTE_FLAGS_TC_STICKY = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 152
try:
    CLX_FCOE_FC_FRAME_ACTION_FLAGS_VFT_TIMEEXCEED_TOCPU = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 153
try:
    CLX_FCOE_FC_FRAME_ACTION_FLAGS_UNKNOWN_HDR_DROP = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 154
try:
    CLX_FCOE_FC_FRAME_ACTION_FLAGS_CLASS2_TOCPU = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 155
try:
    CLX_FCOE_FC_FRAME_ACTION_FLAGS_CLASSF_TOCPU = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 156
try:
    CLX_FCOE_FC_FRAME_ACTION_FLAGS_IFR_HDR_DROP = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_fcoe.h: 157
try:
    CLX_FCOE_FC_FRAME_ACTION_FLAGS_IFR_HDR_TOCPU = (1 << 5)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 57
try:
    CLX_ACL_PKG_NUM = 46
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 58
try:
    CLX_ACL_FLOW_PKG_NUM = 31
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 59
try:
    CLX_ACL_FLOW_1_PKG_NUM = 16
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 60
try:
    CLX_ACL_LOU_NUM = 16
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 61
try:
    CLX_ACL_REWRITE_NUM = 9
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 62
try:
    CLX_ACL_REWRITE_DATA_NUM = 16
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 63
try:
    CLX_ACL_REWRITE_MASK_NUM = 8
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 209
try:
    CLX_ACL_GROUP_PROFILE_FLAGS_PORT_BITMAP = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 214
try:
    CLX_ACL_GROUP_PROFILE_FLAGS_FLOW = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 233
try:
    CLX_ACL_PKT_FORMAT_FLAGS_IS_LAG = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 234
try:
    CLX_ACL_PKT_FORMAT_FLAGS_ACL_FRAME_TYPE_VALID = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 235
try:
    CLX_ACL_PKT_FORMAT_FLAGS_L2_FRAME_TYPE_VALID = (1 << 2)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 236
try:
    CLX_ACL_PKT_FORMAT_FLAGS_VM_TAG_TYPE_VALID = (1 << 3)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 237
try:
    CLX_ACL_PKT_FORMAT_FLAGS_TNL_TYPE_VALID = (1 << 4)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 238
try:
    CLX_ACL_PKT_FORMAT_FLAGS_STAG_VALID = (1 << 5)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 239
try:
    CLX_ACL_PKT_FORMAT_FLAGS_CTAG_VALID = (1 << 6)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 240
try:
    CLX_ACL_PKT_FORMAT_FLAGS_TNL_TERM = (1 << 7)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 241
try:
    CLX_ACL_PKT_FORMAT_FLAGS_TNL_OPT_HDR_EXIST = (1 << 8)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 242
try:
    CLX_ACL_PKT_FORMAT_FLAGS_TNL_FRG_FIRST = (1 << 9)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 243
try:
    CLX_ACL_PKT_FORMAT_FLAGS_OPT_HDR_EXIST = (1 << 10)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 244
try:
    CLX_ACL_PKT_FORMAT_FLAGS_FRG_FIRST = (1 << 11)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 245
try:
    CLX_ACL_PKT_FORMAT_FLAGS_VLAN_TAG_MODE_1Q = (1 << 12)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 271
try:
    CLX_ACL_PKG_CFG_FLAGS_OPT = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 272
try:
    CLX_ACL_PKG_CFG_FLAGS_EXTRACT_TWO_BYTES = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 314
try:
    CLX_ACL_UDF_KEY_PROFILE_FLAGS_FLOW_PROFILE_ID_VALID = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 315
try:
    CLX_ACL_UDF_KEY_PROFILE_FLAGS_FLOW_1_PROFILE_ID_VALID = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 342
try:
    CLX_ACL_LOU_CFG_FLAGS_INVERSE = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 343
try:
    CLX_ACL_LOU_CFG_FLAGS_VLAN_TAG_MODE_1Q = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 344
try:
    CLX_ACL_LOU_CFG_FLAGS_ACL_VALID = (1 << 2)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 345
try:
    CLX_ACL_LOU_CFG_FLAGS_FLOW_VALID = (1 << 3)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 346
try:
    CLX_ACL_LOU_CFG_FLAGS_FLOW_1_VALID = (1 << 4)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 383
try:
    CLX_ACL_ARP_FRAME_TYPE_VALID = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 410
try:
    CLX_ACL_IPV4_KEY_FLAGS_FRG_TYPE_VALID = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 411
try:
    CLX_ACL_IPV4_KEY_FLAGS_TTL_TYPE_VALID = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 412
try:
    CLX_ACL_IPV4_KEY_FLAGS_AUTH_HDR_EXIST = (1 << 2)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 413
try:
    CLX_ACL_IPV4_KEY_FLAGS_OPT_HDR_EXIST = (1 << 3)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 447
try:
    CLX_ACL_IPV6_KEY_FLAGS_FRG_TYPE_VALID = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 448
try:
    CLX_ACL_IPV6_KEY_FLAGS_TTL_TYPE_VALID = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 449
try:
    CLX_ACL_IPV6_KEY_FLAGS_AUTH_HDR_EXIST = (1 << 2)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 450
try:
    CLX_ACL_IPV6_KEY_FLAGS_HBH_HDR_EXIST = (1 << 3)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 451
try:
    CLX_ACL_IPV6_KEY_FLAGS_DEST_HDR_EXIST = (1 << 4)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 452
try:
    CLX_ACL_IPV6_KEY_FLAGS_ROUTING_HDR_EXIST = (1 << 5)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 453
try:
    CLX_ACL_IPV6_KEY_FLAGS_OTHER_HDR_EXIST = (1 << 6)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 485
try:
    CLX_ACL_FCOE_KEY_FLAGS_FIRST_HDR_TYPE_VALID = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 486
try:
    CLX_ACL_FCOE_KEY_FLAGS_SECOND_HDR_TYPE_VALID = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 504
try:
    CLX_ACL_QOS_KEY_FLAGS_TNL_STAG_PCP_DEI = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 505
try:
    CLX_ACL_QOS_KEY_FLAGS_TNL_CTAG_PCP_DEI = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 506
try:
    CLX_ACL_QOS_KEY_FLAGS_TNL_DSCP_ECN = (1 << 2)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 507
try:
    CLX_ACL_QOS_KEY_FLAGS_STAG_PCP_DEI = (1 << 3)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 508
try:
    CLX_ACL_QOS_KEY_FLAGS_CTAG_PCP_DEI = (1 << 4)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 509
try:
    CLX_ACL_QOS_KEY_FLAGS_DSCP_ECN = (1 << 5)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 510
try:
    CLX_ACL_QOS_KEY_FLAGS_TC_COLOR = (1 << 6)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 511
try:
    CLX_ACL_QOS_KEY_FLAGS_COLOR_VALID = (1 << 7)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 512
try:
    CLX_ACL_QOS_KEY_FLAGS_VLAN_TAG_MODE_1Q = (1 << 8)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 556
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_L2_FRAME_TYPE_VALID = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 557
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_FWD_TYPE_VALID = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 558
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_L2_DA_LOOKUP_TYPE_VALID = (1 << 2)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 559
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_L2_SA_LOOKUP_TYPE_VALID = (1 << 3)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 560
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_L3_ROUTE_DA_HIT = (1 << 4)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 561
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_L3_ROUTE_SA_HIT = (1 << 5)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 562
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_L3_HOST_DA_HIT = (1 << 6)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 563
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_L3_HOST_SA_HIT = (1 << 7)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 564
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_L3_DEFAULT_ROUTE = (1 << 8)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 565
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_L3_ROUTE = (1 << 9)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 566
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_STAG_VALID = (1 << 10)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 567
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_CTAG_VALID = (1 << 11)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 568
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_BPDU = (1 << 12)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 569
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_CONTROL = (1 << 13)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 570
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_DROP = (1 << 14)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 571
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_RPF_CHK_FAIL = (1 << 15)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 572
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_TNL_TERM = (1 << 16)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 573
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_TNL_INIT = (1 << 17)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 574
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q = (1 << 18)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 575
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_SA_LEARN = (1 << 19)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 576
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_TNL_MAC = (1 << 20)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 577
try:
    CLX_ACL_PP_INFO_KEY_FLAGS_TNL_TERM_TO_IFIDX = (1 << 21)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 618
try:
    CLX_ACL_PKG_KEY_FLAGS_VLAN_TAG_MODE_1Q = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 619
try:
    CLX_ACL_PKG_KEY_FLAGS_L3_ROUTE = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 660
try:
    CLX_ACL_CLASSIFY_FLAGS_MAC_KEY = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 661
try:
    CLX_ACL_CLASSIFY_FLAGS_ARP_KEY = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 662
try:
    CLX_ACL_CLASSIFY_FLAGS_IPV4_KEY = (1 << 2)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 663
try:
    CLX_ACL_CLASSIFY_FLAGS_IPV6_KEY = (1 << 3)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 664
try:
    CLX_ACL_CLASSIFY_FLAGS_FCOE_KEY = (1 << 4)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 665
try:
    CLX_ACL_CLASSIFY_FLAGS_QOS_KEY = (1 << 5)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 666
try:
    CLX_ACL_CLASSIFY_FLAGS_PP_INFO_KEY = (1 << 6)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 667
try:
    CLX_ACL_CLASSIFY_FLAGS_PKG_KEY = (1 << 7)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 668
try:
    CLX_ACL_CLASSIFY_FLAGS_LOU_KEY = (1 << 8)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 669
try:
    CLX_ACL_CLASSIFY_FLAGS_UDF_VALID = (1 << 9)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 682
try:
    CLX_ACL_QOS_ACTION_FLAGS_REMARK_PCP = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 683
try:
    CLX_ACL_QOS_ACTION_FLAGS_REMARK_DEI = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 684
try:
    CLX_ACL_QOS_ACTION_FLAGS_REMARK_DSCP = (1 << 2)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 685
try:
    CLX_ACL_QOS_ACTION_FLAGS_REMARK_ECN = (1 << 3)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 686
try:
    CLX_ACL_QOS_ACTION_FLAGS_REMARK_TC = (1 << 4)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 687
try:
    CLX_ACL_QOS_ACTION_FLAGS_REMARK_COLOR = (1 << 5)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 688
try:
    CLX_ACL_QOS_ACTION_FLAGS_DROP = (1 << 6)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 689
try:
    CLX_ACL_QOS_ACTION_FLAGS_TO_CPU_DROP = (1 << 7)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 714
try:
    CLX_ACL_REDIRECT_ACTION_FLAGS_BYPASS_PRUNE = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 766
try:
    CLX_ACL_ACTION_FLAGS_METER_VALID = (1 << 0)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 767
try:
    CLX_ACL_ACTION_FLAGS_COUNTER_VALID = (1 << 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 768
try:
    CLX_ACL_ACTION_FLAGS_DIST_COUNTER_VALID = (1 << 2)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 769
try:
    CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_BLIND = (1 << 3)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 770
try:
    CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_GREEN = (1 << 4)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 771
try:
    CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_YELLOW = (1 << 5)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 772
try:
    CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_RED = (1 << 6)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 773
try:
    CLX_ACL_ACTION_FLAGS_CANCEL_DROP = (1 << 7)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 774
try:
    CLX_ACL_ACTION_FLAGS_CANCEL_LEARN = (1 << 8)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 775
try:
    CLX_ACL_ACTION_FLAGS_BYPASS_RPF_CHECK_FAIL = (1 << 9)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 776
try:
    CLX_ACL_ACTION_FLAGS_BYPASS_PRUNE_CHECK_FAIL = (1 << 10)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 777
try:
    CLX_ACL_ACTION_FLAGS_BYPASS_VLAN_ISOLATION_CHECK_FAIL = (1 << 11)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 778
try:
    CLX_ACL_ACTION_FLAGS_BYPASS_FCOE_ZONE_CHECK_FAIL = (1 << 12)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 779
try:
    CLX_ACL_ACTION_FLAGS_COPY_TO_CPU = (1 << 13)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 780
try:
    CLX_ACL_ACTION_FLAGS_REDIRECT = (1 << 14)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 781
try:
    CLX_ACL_ACTION_FLAGS_DROP = (1 << 15)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 782
try:
    CLX_ACL_ACTION_FLAGS_TO_CPU_DROP = (1 << 16)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 783
try:
    CLX_ACL_ACTION_FLAGS_PKT_REWRITE = (1 << 17)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 784
try:
    CLX_ACL_ACTION_FLAGS_L3_DA_GROUP_LABEL = (1 << 18)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 785
try:
    CLX_ACL_ACTION_FLAGS_ALLOW_STEERING = (1 << 19)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 786
try:
    CLX_ACL_ACTION_FLAGS_BYPASS_TTL_CHECK_FAIL = (1 << 20)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 787
try:
    CLX_ACL_ACTION_FLAGS_SAMPLE_TO_MIR = (1 << 21)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 788
try:
    CLX_ACL_ACTION_FLAGS_SAMPLE_HIGH_LATENCY = (1 << 22)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 789
try:
    CLX_ACL_ACTION_FLAGS_KEEP_TTL = (1 << 23)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 791
try:
    CLX_ACL_ACTION_FLAGS_TS_REPLACE_MAC = (1 << 26)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 792
try:
    CLX_ACL_ACTION_FLAGS_DTEL_VALID = (1 << 27)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 793
try:
    CLX_ACL_ACTION_FLAGS_QOS_ACTION_INVALID = (1 << 28)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 794
try:
    CLX_ACL_ACTION_FLAGS_FWD_ACTION_INVALID = (1 << 29)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 57
try:
    CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM = 16
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 58
try:
    CLX_CFG_USER_PORT_NUM = 96
except:
    pass

# ./clx_system/clx_sdk/include/clx_module.h: 53
try:
    CLX_MODULE_MAX_LENGTH_OF_NAME = 8
except:
    pass

# ./clx_system/clx_sdk/include/clx_module.h: 104
try:
    CLX_MODULE_NUMER_OF_MODULES = CLX_MODULE_LAST
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 48
try:
    CLX_NETIF_NAME_LEN = 16
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 49
try:
    CLX_NETIF_PROFILE_NUM_MAX = 256
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 50
try:
    CLX_NETIF_PROFILE_PATTERN_NUM = 4
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 51
try:
    CLX_NETIF_PROFILE_PATTERN_LEN = 8
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 75
try:
    CLX_NETIF_INTF_FLAGS_MAC = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 113
try:
    CLX_NETIF_PROFILE_FLAGS_PORT = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 114
try:
    CLX_NETIF_PROFILE_FLAGS_REASON = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 115
try:
    CLX_NETIF_PROFILE_FLAGS_PATTERN_0 = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 116
try:
    CLX_NETIF_PROFILE_FLAGS_PATTERN_1 = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 117
try:
    CLX_NETIF_PROFILE_FLAGS_PATTERN_2 = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 118
try:
    CLX_NETIF_PROFILE_FLAGS_PATTERN_3 = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 221
try:
    CLX_NETIF_NETLINK_NUM_MAX = 256
except:
    pass

# ./clx_system/clx_sdk/include/clx_netif.h: 222
try:
    CLX_NETIF_NETLINK_MC_GROUP_NUM_MAX = 32
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 134
try:
    CLX_SEC_STORM_CTRL_RATE_NUM = 6
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 144
try:
    CLX_SEC_DOS_CHECK_ITEM_NUM = CLX_SEC_DOS_CHECK_ITEM_LAST
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 145
try:
    CLX_SEC_WORD_WIDTH = 32
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 146
try:
    CLX_SEC_DOS_CHECK_ITEM_BITMAP_SIZE = (((CLX_SEC_DOS_CHECK_ITEM_NUM - 1) / CLX_SEC_WORD_WIDTH) + 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 150
def CLX_SEC_SET_DOS_ITEM_BIT(bitmap, dos_check_item):
    return ((cast(bitmap, POINTER(UI32_T)) [(dos_check_item / CLX_SEC_WORD_WIDTH)]) | (1 << (dos_check_item % CLX_SEC_WORD_WIDTH)))

# ./clx_system/clx_sdk/include/clx_sec.h: 152
def CLX_SEC_CLR_DOS_ITEM_BIT(bitmap, dos_check_item):
    return ((cast(bitmap, POINTER(UI32_T)) [(dos_check_item / CLX_SEC_WORD_WIDTH)]) & (~(1 << (dos_check_item % CLX_SEC_WORD_WIDTH))))

# ./clx_system/clx_sdk/include/clx_sec.h: 154
def CLX_SEC_CHK_DOS_ITEM_BIT(bitmap, dos_check_item):
    return ((cast(bitmap, POINTER(UI32_T)) [(dos_check_item / CLX_SEC_WORD_WIDTH)]) & (1 << (dos_check_item % CLX_SEC_WORD_WIDTH)))

# ./clx_system/clx_sdk/include/clx_sec.h: 183
try:
    CLX_SEC_STORM_CTRL_ENTRY_FLAGS_BC = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 184
try:
    CLX_SEC_STORM_CTRL_ENTRY_FLAGS_UUC = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 185
try:
    CLX_SEC_STORM_CTRL_ENTRY_FLAGS_UMC = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 186
try:
    CLX_SEC_STORM_CTRL_ENTRY_FLAGS_L2UMC = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 187
try:
    CLX_SEC_STORM_CTRL_ENTRY_FLAGS_L2MC = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 188
try:
    CLX_SEC_STORM_CTRL_ENTRY_FLAGS_L3UMC = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 189
try:
    CLX_SEC_STORM_CTRL_ENTRY_FLAGS_L3MC = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 198
try:
    CLX_SEC_STORM_CTRL_FLAGS_PACKET_RATE = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 199
try:
    CLX_SEC_STORM_CTRL_FLAGS_BC_EN = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 200
try:
    CLX_SEC_STORM_CTRL_FLAGS_BC_CNT_EN = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 201
try:
    CLX_SEC_STORM_CTRL_FLAGS_UUC_EN = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 202
try:
    CLX_SEC_STORM_CTRL_FLAGS_UUC_CNT_EN = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 203
try:
    CLX_SEC_STORM_CTRL_FLAGS_UMC_EN = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 204
try:
    CLX_SEC_STORM_CTRL_FLAGS_UMC_CNT_EN = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 205
try:
    CLX_SEC_STORM_CTRL_FLAGS_L2UMC_EN = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 206
try:
    CLX_SEC_STORM_CTRL_FLAGS_L2UMC_CNT_EN = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 207
try:
    CLX_SEC_STORM_CTRL_FLAGS_L2MC_EN = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 208
try:
    CLX_SEC_STORM_CTRL_FLAGS_L2MC_CNT_EN = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 209
try:
    CLX_SEC_STORM_CTRL_FLAGS_L3UMC_EN = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 210
try:
    CLX_SEC_STORM_CTRL_FLAGS_L3UMC_CNT_EN = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 211
try:
    CLX_SEC_STORM_CTRL_FLAGS_L3MC_EN = (1 << 11)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 212
try:
    CLX_SEC_STORM_CTRL_FLAGS_L3MC_CNT_EN = (1 << 12)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 228
try:
    CLX_SEC_SG_PROPERTY_FLAGS_IP_SRC_PHY_LAG_CHECK = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 229
try:
    CLX_SEC_SG_PROPERTY_FLAGS_IP_MAC_ADDR_CHECK = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 230
try:
    CLX_SEC_SG_PROPERTY_FLAGS_IP_VID_BDID_CHECK = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 231
try:
    CLX_SEC_SG_PROPERTY_FLAGS_FCOE_SRC_PHY_LAG_CHECK = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 232
try:
    CLX_SEC_SG_PROPERTY_FLAGS_FCOE_MAC_ADDR_CHECK = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 233
try:
    CLX_SEC_SG_PROPERTY_FLAGS_FCOE_VID_BDID_CHECK = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 234
try:
    CLX_SEC_SG_PROPERTY_FLAGS_ARP_PKT_CHECK = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 235
try:
    CLX_SEC_SG_PROPERTY_FLAGS_IPV6_NS_NA_CHECK = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 236
try:
    CLX_SEC_SG_PROPERTY_FLAGS_IPV6_LINK_LOCAL_PKT_CHECK = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 257
try:
    CLX_SEC_SG_ENTRY_FLAGS_IP_ENTRY = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 258
try:
    CLX_SEC_SG_ENTRY_FLAGS_MAC = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 259
try:
    CLX_SEC_SG_ENTRY_FLAGS_VLAN = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 260
try:
    CLX_SEC_SG_ENTRY_FLAGS_PORT = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sec.h: 261
try:
    CLX_SEC_SG_ENTRY_FLAGS_PPPoE = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 57
try:
    CLX_L3T_FLAGS_WITH_ID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 59
try:
    CLX_L3T_FLAGS_FLEX_TUNNEL_UDP_IPV4_CHKSUM0_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 60
try:
    CLX_L3T_FLAGS_FLEX_TUNNEL_UDP_IPV6_CHKSUM0_EN = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 79
try:
    CLX_L3T_MAC_INFO_FLAGS_PORT_VALID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 83
try:
    CLX_L3T_MAC_FLAGS_SVID_VALID = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 84
try:
    CLX_L3T_MAC_FLAGS_CVID_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 85
try:
    CLX_L3T_MAC_FLAGS_VLAN_TAG_MODE_1Q = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 86
try:
    CLX_L3T_MAC_FLAGS_MPLS_EN = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 87
try:
    CLX_L3T_MAC_FLAGS_TRILL_EN = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 88
try:
    CLX_L3T_MAC_FLAGS_IP_TUNNEL_EN = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 89
try:
    CLX_L3T_MAC_FLAGS_NSH_EN = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 90
try:
    CLX_L3T_MAC_FLAGS_TRILL_MC_RPF_CHK_EN = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 91
try:
    CLX_L3T_MAC_FLAGS_TRILL_MC_ADJ_CHK_EN = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 92
try:
    CLX_L3T_MAC_FLAGS_TRILL_UC_ADJ_CHK_EN = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 113
try:
    CLX_L3T_INIT_FLAGS_DST_IP_FROM_IPV6 = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 118
try:
    CLX_L3T_INIT_FLAGS_TTL_FROM_INNER = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 122
try:
    CLX_L3T_INIT_FLAGS_FLOWLABEL_FROM_INNER = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 126
try:
    CLX_L3T_INIT_FLAGS_SET_DF = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 130
try:
    CLX_L3T_INIT_FLAGS_QOS_FROM_INNER = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 134
try:
    CLX_L3T_INIT_FLAGS_ECN_FROM_INNER = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 138
try:
    CLX_L3T_INIT_FLAGS_KEEP_INNER_TAG = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 142
try:
    CLX_L3T_INIT_FLAGS_PHB_TO_DSCP_PROFILE_VALID = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 146
try:
    CLX_L3T_INIT_FLAGS_PHB_TO_PCP_DEI_PROFILE_VALID = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 150
try:
    CLX_L3T_INIT_FLAGS_METER_VALID = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 153
try:
    CLX_L3T_INIT_FLAGS_CNT_VALID = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 156
try:
    CLX_L3T_INIT_FLAGS_DIST_CNT_VALID = (1 << 11)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 159
try:
    CLX_L3T_INIT_FLAGS_SAMPLE_TO_MIR = (1 << 12)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 163
try:
    CLX_L3T_INIT_FLAGS_SAMPLE_HIGH_LATENCY = (1 << 13)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 166
try:
    CLX_L3T_INIT_FLAGS_IOAM_VALID = (1 << 14)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 167
try:
    CLX_L3T_INIT_FLAGS_DTEL = (1 << 15)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 213
try:
    CLX_L3T_TERM_FLAGS_AUTO_TUNNEL_SIP_CHECK = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 217
try:
    CLX_L3T_TERM_FLAGS_AUTO_TUNNEL_DIP_CHECK = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 221
try:
    CLX_L3T_TERM_FLAGS_USE_INNER_PHB = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 225
try:
    CLX_L3T_TERM_FLAGS_KEEP_INNER_QOS = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 229
try:
    CLX_L3T_TERM_FLAGS_COPY_OUTER_TTL_2_INNER = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 232
try:
    CLX_L3T_TERM_FLAGS_FORWARD_INNER_TAGGED_PACKET = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 236
try:
    CLX_L3T_TERM_FLAGS_DSCP_TO_PHB_PROFILE_VALID = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 240
try:
    CLX_L3T_TERM_FLAGS_PCP_DEI_TO_PHB_PROFILE_VALID = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 244
try:
    CLX_L3T_TERM_FLAGS_METER_VALID = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 247
try:
    CLX_L3T_TERM_FLAGS_CNT_VALID = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 250
try:
    CLX_L3T_TERM_FLAGS_DIST_CNT_VALID = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 253
try:
    CLX_L3T_TERM_FLAGS_ECN_DISABLE = (1 << 11)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 256
try:
    CLX_L3T_TERM_FLAGS_ADDR_DONT_LEARN = (1 << 12)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 259
try:
    CLX_L3T_TERM_FLAGS_SAMPLE_TO_MIR = (1 << 13)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 263
try:
    CLX_L3T_TERM_FLAGS_DTEL = (1 << 14)
except:
    pass

# ./clx_system/clx_sdk/include/clx_l3t.h: 264
try:
    CLX_L3T_TERM_FLAGS_L3_MC_ID_VALID = (1 << 15)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sdn.h: 64
try:
    CLX_SDN_UNION_NUM = 13
except:
    pass

# ./clx_system/clx_sdk/include/clx_sdn.h: 68
try:
    CLX_SDN_METER_MAX_BAND = 2
except:
    pass

# ./clx_system/clx_sdk/include/clx_sdn.h: 561
try:
    CLX_SDN_METER_POLICY_FLAGS_SET_DSCP = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sdn.h: 562
try:
    CLX_SDN_METER_POLICY_FLAGS_SET_PCP = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sdn.h: 586
try:
    CLX_SDN_METER_FLAGS_KBPS = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sdn.h: 587
try:
    CLX_SDN_METER_FLAGS_BURST = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sdn.h: 588
try:
    CLX_SDN_METER_FLAGS_STATS = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sdn.h: 589
try:
    CLX_SDN_METER_FLAGS_COLOR_AWARE = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 129
try:
    CLX_MIR_SESSION_FLAGS_METER_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 130
try:
    CLX_MIR_SESSION_FLAGS_USE_NEW_TC = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 133
try:
    CLX_MIR_SESSION_FLAGS_CVID_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 134
try:
    CLX_MIR_SESSION_FLAGS_SVID_VALID = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 135
try:
    CLX_MIR_SESSION_FLAGS_RSPAN_REPLACE_TAG = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 136
try:
    CLX_MIR_SESSION_FLAGS_RSPAN_DROP_BPDU = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 137
try:
    CLX_MIR_SESSION_FLAGS_RSPAN_DROP_CTRL_PKT = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 138
try:
    CLX_MIR_SESSION_FLAGS_ERSPAN_SEQ_NUM = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 139
try:
    CLX_MIR_SESSION_FLAGS_NO_DECAP = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 142
try:
    CLX_MIR_SESSION_FLAGS_ERSPAN_TO_RSPAN_TRAN = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 143
try:
    CLX_MIR_SESSION_FLAGS_RSPAN_TO_ERSPAN_TRAN = (1 << 10)
except:
    pass

# ./clx_system/clx_sdk/include/clx_mir.h: 144
try:
    CLX_MIR_SESSION_FLAGS_METER_PACKET_RATE = (1 << 11)
except:
    pass

# ./clx_system/clx_sdk/include/clx_tm.h: 57
try:
    CLX_TM_HANDLER_PORT = 4294967295
except:
    pass

# ./clx_system/clx_sdk/include/clx_tm.h: 58
try:
    CLX_TM_HANDLER_NONE = CLX_INVALID_ID
except:
    pass

# ./clx_system/clx_sdk/include/clx_tm.h: 62
try:
    CLX_TM_BANDWIDTH_NONE = 0
except:
    pass

# ./clx_system/clx_sdk/include/clx_tm.h: 202
try:
    CLX_TM_BUF_THRESHOLD_FLAGS_HYSTERESIS_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_tm.h: 204
try:
    CLX_TM_BUF_THRESHOLD_FLAGS_MAX_STATIC_EN = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 255
try:
    CLX_SWC_FLAGS_STEERING_HDR_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 256
try:
    CLX_SWC_FLAGS_STEERING_HDR_UDP_EN = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 269
try:
    CLX_SWC_HASH_KEY_NUM = CLX_SWC_HASH_KEY_TYPE_LAST
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 270
try:
    CLX_SWC_HASH_KEY_WORD_WIDTH = 32
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 271
try:
    CLX_SWC_HASH_KEY_BITMAP_SIZE = (((CLX_SWC_HASH_KEY_NUM - 1) / CLX_SWC_HASH_KEY_WORD_WIDTH) + 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 275
def CLX_SWC_SET_HASHKEYBIT(key_bitmap, hash_key):
    return ((cast(key_bitmap, POINTER(UI32_T)) [(hash_key / CLX_SWC_HASH_KEY_WORD_WIDTH)]) | (1 << (hash_key % CLX_SWC_HASH_KEY_WORD_WIDTH)))

# ./clx_system/clx_sdk/include/clx_swc.h: 277
def CLX_SWC_CLEAR_HASHKEYBIT(key_bitmap, hash_key):
    return ((cast(key_bitmap, POINTER(UI32_T)) [(hash_key / CLX_SWC_HASH_KEY_WORD_WIDTH)]) & (~(1 << (hash_key % CLX_SWC_HASH_KEY_WORD_WIDTH))))

# ./clx_system/clx_sdk/include/clx_swc.h: 279
def CLX_SWC_CHK_HASHKEYBIT(key_bitmap, hash_key):
    return ((cast(key_bitmap, POINTER(UI32_T)) [(hash_key / CLX_SWC_HASH_KEY_WORD_WIDTH)]) & (1 << (hash_key % CLX_SWC_HASH_KEY_WORD_WIDTH)))

# ./clx_system/clx_sdk/include/clx_swc.h: 308
try:
    CLX_SWC_ECC_ERROR_INFO_INVALID_HUB = 4294967295
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 309
try:
    CLX_SWC_ECC_ERROR_INFO_INVALID_MEMORY = 4294967295
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 310
try:
    CLX_SWC_ECC_ERROR_INFO_INVALID_TABLE_ID = 4294967295
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 383
try:
    CLX_SWC_FLAGS_CPI_ENCAP_UDP_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 384
try:
    CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_FIX_EN = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 385
try:
    CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_CPU_QUEUE_EN = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_swc.h: 388
try:
    CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_PORT_EN = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_init.h: 52
try:
    CLX_INIT_DBG_FLAG_ERR = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_init.h: 53
try:
    CLX_INIT_DBG_FLAG_WARN = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_init.h: 54
try:
    CLX_INIT_DBG_FLAG_INFO = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_stat.h: 52
try:
    CLX_STAT_INVALID_CNT_ID = 4294967295
except:
    pass

# ./clx_system/clx_sdk/include/clx_stat.h: 288
try:
    CLX_STAT_CNT_NUM = 6
except:
    pass

# ./clx_system/clx_sdk/include/clx_stat.h: 302
try:
    CLX_STAT_CNT_FLAGS_FORWARD = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_stat.h: 303
try:
    CLX_STAT_CNT_FLAGS_DROP = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_stat.h: 304
try:
    CLX_STAT_CNT_FLAGS_BYTE = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_stat.h: 305
try:
    CLX_STAT_CNT_FLAGS_COLOR_RED = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_stat.h: 306
try:
    CLX_STAT_CNT_FLAGS_COLOR_YELLOW = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_stat.h: 307
try:
    CLX_STAT_CNT_FLAGS_COLOR_GREEN = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_stat.h: 308
try:
    CLX_STAT_CNT_FLAGS_COLOR_ALL = ((CLX_STAT_CNT_FLAGS_COLOR_GREEN | CLX_STAT_CNT_FLAGS_COLOR_YELLOW) | CLX_STAT_CNT_FLAGS_COLOR_RED)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 58
try:
    CLX_TRILL_PORT_WITH_ID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 59
try:
    CLX_TRILL_VIRTUAL_RB_WITH_ID = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 85
try:
    CLX_TRILL_INIT_FLAGS_FGL_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 86
try:
    CLX_TRILL_INIT_FLAGS_QOS_FROM_INNER = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 87
try:
    CLX_TRILL_INIT_FLAGS_METER_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 88
try:
    CLX_TRILL_INIT_FLAGS_CNT_VALID = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 89
try:
    CLX_TRILL_INIT_FLAGS_DIST_CNT_VALID = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 90
try:
    CLX_TRILL_INIT_FLAGS_PHB_TO_PCP_DEI_PROFILE_VALID = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 91
try:
    CLX_TRILL_INIT_FLAGS_PHB_TO_DSCP_PROFILE_VALID = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 92
try:
    CLX_TRILL_INIT_FLAGS_SAMPLE_TO_MIR = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 93
try:
    CLX_TRILL_INIT_FLAGS_SAMPLE_HIGH_LATENCY = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 94
try:
    CLX_TRILL_INIT_FLAGS_DTEL = (1 << 9)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 132
try:
    CLX_TRILL_TERM_FLAGS_USE_INNER_PHB = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 133
try:
    CLX_TRILL_TERM_FLAGS_ECN_DISABLE = (1 << 1)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 134
try:
    CLX_TRILL_TERM_FLAGS_METER_VALID = (1 << 2)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 135
try:
    CLX_TRILL_TERM_FLAGS_CNT_VALID = (1 << 3)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 136
try:
    CLX_TRILL_TERM_FLAGS_DIST_CNT_VALID = (1 << 4)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 137
try:
    CLX_TRILL_TERM_FLAGS_PCP_DEI_TO_PHB_PROFILE_VALID = (1 << 5)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 138
try:
    CLX_TRILL_TERM_FLAGS_DSCP_TO_PHB_PROFILE_VALID = (1 << 6)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 139
try:
    CLX_TRILL_TERM_FLAGS_SAMPLE_TO_MIR = (1 << 7)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 140
try:
    CLX_TRILL_TERM_FLAGS_DTEL = (1 << 8)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 172
try:
    CLX_TRILL_ROUTE_FLAGS_DROP = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 192
try:
    CLX_TRILL_TREE_FLAGS_DROP = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_trill.h: 223
try:
    CLX_TRILL_PORT_PROPERTY_FLAGS_RBV_EN = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/include/clx_sfc.h: 79
try:
    CLX_SFC_FORWARDER_FLAGS_RM_SFC = (1 << 0)
except:
    pass

# ./clx_system/clx_sdk/src/inc/cmlib/cmlib_bitmap.h: 63
def CMLIB_BITMAP_BIT_CHK(bitmap, bit):
    return (((bitmap [(bit / 32)]) & (1 << (bit % 32))) != 0)

# ./clx_system/clx_sdk/include/cdb/cdb.h: 54
try:
    CDB_INST_IDX_BCAST = 4294967295
except:
    pass

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 97
def PTR_HAL_EXT_CHIP_INFO(unit):
    return (_ext_ptr_chip_info [unit])

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 108
def HAL_IS_ETH_PORT_VALID(__unit__, __port__):
    return ((__port__ < CLX_PORT_NUM) and (CMLIB_BITMAP_BIT_CHK ((HAL_PORT_BMP_ETH (__unit__)), __port__)))

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 112
def HAL_IS_PORT_VALID(__unit__, __port__):
    return ((__port__ < CLX_PORT_NUM) and (CMLIB_BITMAP_BIT_CHK ((HAL_PORT_BMP (__unit__)), __port__)))

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 415
def HAL_CPU_PORT(unit):
    return ((PTR_HAL_EXT_CHIP_INFO (unit)).contents.cpu_port)

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 417
def HAL_PORT_BMP(unit):
    return ((PTR_HAL_EXT_CHIP_INFO (unit)).contents.port_bitmap)

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 418
def HAL_PORT_BMP_ETH(unit):
    return ((PTR_HAL_EXT_CHIP_INFO (unit)).contents.port_bitmap_eth)

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 419
def HAL_PORT_BMP_PP(unit):
    return ((PTR_HAL_EXT_CHIP_INFO (unit)).contents.port_bitmap_pp)

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 420
def HAL_PORT_BMP_PHY(unit):
    return ((PTR_HAL_EXT_CHIP_INFO (unit)).contents.port_bitmap_phy)

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 421
def HAL_PORT_BMP_TOTAL(unit):
    return ((PTR_HAL_EXT_CHIP_INFO (unit)).contents.port_bitmap_total)

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 426
def HAL_CPI_PORT(unit, cpi_idx):
    return (((PTR_HAL_EXT_CHIP_INFO (unit)).contents.cpi_port) [cpi_idx])

# ./clx_system/clx_sdk/src/inc/hal/common/hal.h: 431
def HAL_RC_PORT(unit, rcp_idx):
    return (((PTR_HAL_EXT_CHIP_INFO (unit)).contents.rc_port) [rcp_idx])

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 87
try:
    CLX_IFMAP_PORT_ID_CPU = (CLX_PORT_INVALID - 1)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 88
try:
    CLX_IFMAP_PORT_ID_CPI_0 = (CLX_PORT_INVALID - 2)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 89
try:
    CLX_IFMAP_PORT_ID_CPI_1 = (CLX_PORT_INVALID - 3)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 90
try:
    CLX_IFMAP_PORT_ID_RC_0 = (CLX_PORT_INVALID - 4)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 91
try:
    CLX_IFMAP_PORT_ID_RC_1 = (CLX_PORT_INVALID - 5)
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 594
def CLX_IFMAP_CPU_PORT(__unit__):
    return (HAL_CPU_PORT (__unit__))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 597
def CLX_IFMAP_CPI_PORT_0(__unit__):
    return (HAL_CPI_PORT (__unit__, 0))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 598
def CLX_IFMAP_CPI_PORT_1(__unit__):
    return (HAL_CPI_PORT (__unit__, 1))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 601
def CLX_IFMAP_RC_PORT_0(__unit__):
    return (HAL_RC_PORT (__unit__, 0))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 602
def CLX_IFMAP_RC_PORT_1(__unit__):
    return (HAL_RC_PORT (__unit__, 1))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 605
def CLX_IFMAP_PBMP(__unit__):
    return (HAL_PORT_BMP (__unit__))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 606
def CLX_IFMAP_PBMP_PP(__unit__):
    return (HAL_PORT_BMP_PP (__unit__))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 607
def CLX_IFMAP_PBMP_ETH(__unit__):
    return (HAL_PORT_BMP_ETH (__unit__))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 608
def CLX_IFMAP_PBMP_PHY(__unit__):
    return (HAL_PORT_BMP_PHY (__unit__))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 609
def CLX_IFMAP_PBMP_TOTAL(__unit__):
    return (HAL_PORT_BMP_TOTAL (__unit__))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 612
def CLX_IFMAP_IS_PORT_VALID(__unit__, __user_port__):
    return (HAL_IS_PORT_VALID (__unit__, __user_port__))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ifmap.h: 614
def CLX_IFMAP_IS_ETH_PORT_VALID(__unit__, __user_port__):
    return (HAL_IS_ETH_PORT_VALID (__unit__, __user_port__))

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ver.h: 53
def CLX_VER_SDK(__major__, __minor__, __rev__):
    return (((__major__ << 16) + (__minor__ << 8)) + __rev__)

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ver.h: 54
def CLX_VER_MAJOR(__ver__):
    return ((__ver__ & 4294901760) >> 16)

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ver.h: 55
def CLX_VER_MINOR(__ver__):
    return ((__ver__ & 65280) >> 8)

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ver.h: 56
def CLX_VER_REVISION(__ver__):
    return (__ver__ & 255)

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ver.h: 57
try:
    CLX_VER_RELEASE_PREV = (CLX_VER_SDK (2, 0, 7))
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ver.h: 58
try:
    CLX_VER_RELEASE = (CLX_VER_SDK (3, 0, 5))
except:
    pass

# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_ver.h: 59
try:
    CLX_VER_BETA = ''
except:
    pass

CLX_IP_U = union_CLX_IP_U# ./clx_system/clx_sdk/include/clx_types.h: 132

CLX_IP_ADDR_S = struct_CLX_IP_ADDR_S# ./clx_system/clx_sdk/include/clx_types.h: 138

CLX_TUNNEL_KEY_S = struct_CLX_TUNNEL_KEY_S# ./clx_system/clx_sdk/include/clx_types.h: 195

CLX_BUM_INFO_S = struct_CLX_BUM_INFO_S# ./clx_system/clx_sdk/include/clx_types.h: 298

CLX_RANGE_INFO_S = struct_CLX_RANGE_INFO_S# ./clx_system/clx_sdk/include/clx_types.h: 336

CLX_FDL_INFO_S = struct_CLX_FDL_INFO_S# ./clx_system/clx_sdk/include/clx_types.h: 342

CLX_QOS_MAPPING_ENTRY_S = struct_CLX_QOS_MAPPING_ENTRY_S# ./clx_system/clx_sdk/include/clx_qos.h: 100

CLX_METER_PARAMETER_S = struct_CLX_METER_PARAMETER_S# ./clx_system/clx_sdk/include/clx_meter.h: 89

CLX_METER_CFG_S = struct_CLX_METER_CFG_S# ./clx_system/clx_sdk/include/clx_meter.h: 103

CLX_METER_PORT_CFG_S = struct_CLX_METER_PORT_CFG_S# ./clx_system/clx_sdk/include/clx_meter.h: 127

CLX_PORT_VLAN_TAG_S = struct_CLX_PORT_VLAN_TAG_S# ./clx_system/clx_sdk/include/clx_port.h: 472

CLX_PORT_ABILITY_S = struct_CLX_PORT_ABILITY_S# ./clx_system/clx_sdk/include/clx_port.h: 485

CLX_PORT_PROFILE_ID_S = struct_CLX_PORT_PROFILE_ID_S# ./clx_system/clx_sdk/include/clx_port.h: 492

CLX_PORT_SEG_SRV_S = struct_CLX_PORT_SEG_SRV_S# ./clx_system/clx_sdk/include/clx_port.h: 556

CLX_PORT_INTF_PROPERTY_S = struct_CLX_PORT_INTF_PROPERTY_S# ./clx_system/clx_sdk/include/clx_port.h: 606

CLX_PORT_TS_ENTRY_S = struct_CLX_PORT_TS_ENTRY_S# ./clx_system/clx_sdk/include/clx_port.h: 626

CLX_PORT_STATUS_S = struct_CLX_PORT_STATUS_S# ./clx_system/clx_sdk/include/clx_port.h: 635

CLX_PORT_TX_COEF_S = struct_CLX_PORT_TX_COEF_S# ./clx_system/clx_sdk/include/clx_port.h: 650

CLX_VLAN_ENTRY_S = struct_CLX_VLAN_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 106

CLX_VLAN_MAC_VLAN_ENTRY_S = struct_CLX_VLAN_MAC_VLAN_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 118

CLX_VLAN_PROTOCOL_GRP_ENTRY_S = struct_CLX_VLAN_PROTOCOL_GRP_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 160

CLX_VLAN_PROTOCOL_GRP_VLAN_ENTRY_S = struct_CLX_VLAN_PROTOCOL_GRP_VLAN_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 172

CLX_VLAN_SUBNET_VLAN_ENTRY_S = struct_CLX_VLAN_SUBNET_VLAN_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 192

CLX_VLAN_CLASSIFY_TYPE_S = struct_CLX_VLAN_CLASSIFY_TYPE_S# ./clx_system/clx_sdk/include/clx_vlan.h: 230

CLX_VLAN_CLASSIFY_ADDR_S = struct_CLX_VLAN_CLASSIFY_ADDR_S# ./clx_system/clx_sdk/include/clx_vlan.h: 272

CLX_VLAN_TAG_ACTION_S = struct_CLX_VLAN_TAG_ACTION_S# ./clx_system/clx_sdk/include/clx_vlan.h: 285

CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_S = struct_CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_S# ./clx_system/clx_sdk/include/clx_vlan.h: 293

CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_S = struct_CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_S# ./clx_system/clx_sdk/include/clx_vlan.h: 300

CLX_VLAN_PVLAN_ENTRY_S = struct_CLX_VLAN_PVLAN_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 311

CLX_VLAN_ISOLATION_ENTRY_S = struct_CLX_VLAN_ISOLATION_ENTRY_S# ./clx_system/clx_sdk/include/clx_vlan.h: 319

CLX_VM_PORT_PRTY_S = struct_CLX_VM_PORT_PRTY_S# ./clx_system/clx_sdk/include/clx_vm.h: 108

CLX_VM_PE_UCAST_ADDR_S = struct_CLX_VM_PE_UCAST_ADDR_S# ./clx_system/clx_sdk/include/clx_vm.h: 119

CLX_VM_PE_MCAST_ADDR_S = struct_CLX_VM_PE_MCAST_ADDR_S# ./clx_system/clx_sdk/include/clx_vm.h: 131

CLX_L3_IP_NETWORK_ADDR_S = struct_CLX_L3_IP_NETWORK_ADDR_S# ./clx_system/clx_sdk/include/clx_l3.h: 131

CLX_L3_INTF_INFO_S = struct_CLX_L3_INTF_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 178

CLX_L3_HOST_INFO_S = struct_CLX_L3_HOST_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 201

CLX_L3_SUBNET_BCAST_INFO_S = struct_CLX_L3_SUBNET_BCAST_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 213

CLX_L3_ROUTE_INFO_S = struct_CLX_L3_ROUTE_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 237

CLX_L3_ECMP_GRP_SW_MODE_INFO_S = struct_CLX_L3_ECMP_GRP_SW_MODE_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 268

CLX_L3_ECMP_DLB_CFG_S = struct_CLX_L3_ECMP_DLB_CFG_S# ./clx_system/clx_sdk/include/clx_l3.h: 280

CLX_L3_ECMP_HASH_CFG_S = struct_CLX_L3_ECMP_HASH_CFG_S# ./clx_system/clx_sdk/include/clx_l3.h: 296

CLX_L3_ECMP_GRP_INFO_S = struct_CLX_L3_ECMP_GRP_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 317

CLX_L3_ECMP_PATH_INFO_S = struct_CLX_L3_ECMP_PATH_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 333

CLX_L3_ROUTER_MAC_INFO_S = struct_CLX_L3_ROUTER_MAC_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 342

CLX_L3_VRF_INFO_S = struct_CLX_L3_VRF_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 367

CLX_L3_MCAST_GROUP_INFO_S = struct_CLX_L3_MCAST_GROUP_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 428

CLX_L3_MCAST_EGR_INTF_NV_S = struct_CLX_L3_MCAST_EGR_INTF_NV_S# ./clx_system/clx_sdk/include/clx_l3.h: 436

CLX_L3_MCAST_EGR_INTF_TRILL_S = struct_CLX_L3_MCAST_EGR_INTF_TRILL_S# ./clx_system/clx_sdk/include/clx_l3.h: 443

CLX_L3_MCAST_EGR_INTF_MPLS_S = struct_CLX_L3_MCAST_EGR_INTF_MPLS_S# ./clx_system/clx_sdk/include/clx_l3.h: 455

CLX_L3_MCAST_EGR_INTF_S = struct_CLX_L3_MCAST_EGR_INTF_S# ./clx_system/clx_sdk/include/clx_l3.h: 480

CLX_L3_BFD_INFO_S = struct_CLX_L3_BFD_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 498

CLX_L3_ADJ_INFO_S = struct_CLX_L3_ADJ_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 546

CLX_L3_OPTION_HEADER_INFO_S = struct_CLX_L3_OPTION_HEADER_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 552

CLX_L3_PIM_REG_INFO_S = struct_CLX_L3_PIM_REG_INFO_S# ./clx_system/clx_sdk/include/clx_l3.h: 568

CLX_MPLS_LSE_S = struct_CLX_MPLS_LSE_S# ./clx_system/clx_sdk/include/clx_mpls.h: 85

CLX_MPLS_ENCAP_KEY_S = struct_CLX_MPLS_ENCAP_KEY_S# ./clx_system/clx_sdk/include/clx_mpls.h: 98

CLX_MPLS_MATCH_KEY_S = struct_CLX_MPLS_MATCH_KEY_S# ./clx_system/clx_sdk/include/clx_mpls.h: 105

CLX_MPLS_INIT_S = struct_CLX_MPLS_INIT_S# ./clx_system/clx_sdk/include/clx_mpls.h: 142

CLX_MPLS_TERM_S = struct_CLX_MPLS_TERM_S# ./clx_system/clx_sdk/include/clx_mpls.h: 183

CLX_MPLS_NHLFE_S = struct_CLX_MPLS_NHLFE_S# ./clx_system/clx_sdk/include/clx_mpls.h: 218

CLX_MPLS_PW_KEY_S = struct_CLX_MPLS_PW_KEY_S# ./clx_system/clx_sdk/include/clx_mpls.h: 246

CLX_MPLS_PW_S = struct_CLX_MPLS_PW_S# ./clx_system/clx_sdk/include/clx_mpls.h: 294

CLX_MPLS_AC_S = struct_CLX_MPLS_AC_S# ./clx_system/clx_sdk/include/clx_mpls.h: 307

CLX_PKT_SDN_PORT_S = struct_CLX_PKT_SDN_PORT_S# ./clx_system/clx_sdk/include/clx_pkt.h: 83

CLX_PKT_SDN_TUNNEL_S = struct_CLX_PKT_SDN_TUNNEL_S# ./clx_system/clx_sdk/include/clx_pkt.h: 95

CLX_PKT_BLK_S = struct_CLX_PKT_BLK_S# ./clx_system/clx_sdk/include/clx_pkt.h: 552

CLX_L2_ADDR_S = struct_CLX_L2_ADDR_S# ./clx_system/clx_sdk/include/clx_l2.h: 97

CLX_L2_MCAST_EGR_INTF_NV_S = struct_CLX_L2_MCAST_EGR_INTF_NV_S# ./clx_system/clx_sdk/include/clx_l2.h: 170

CLX_L2_MCAST_EGR_INTF_TRILL_S = struct_CLX_L2_MCAST_EGR_INTF_TRILL_S# ./clx_system/clx_sdk/include/clx_l2.h: 176

CLX_L2_MCAST_EGR_INTF_MPLS_S = struct_CLX_L2_MCAST_EGR_INTF_MPLS_S# ./clx_system/clx_sdk/include/clx_l2.h: 181

CLX_L2_MCAST_EGR_INTF_S = struct_CLX_L2_MCAST_EGR_INTF_S# ./clx_system/clx_sdk/include/clx_l2.h: 203

CLX_L2_MCAST_ADDR_S = struct_CLX_L2_MCAST_ADDR_S# ./clx_system/clx_sdk/include/clx_l2.h: 221

CLX_L2_IP_MCAST_GROUP_S = struct_CLX_L2_IP_MCAST_GROUP_S# ./clx_system/clx_sdk/include/clx_l2.h: 244

CLX_FCOE_FCID_ADDR_S = struct_CLX_FCOE_FCID_ADDR_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 64

CLX_FCOE_INTF_INFO_S = struct_CLX_FCOE_INTF_INFO_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 92

CLX_FCOE_HOST_INFO_S = struct_CLX_FCOE_HOST_INFO_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 110

CLX_FCOE_ROUTE_INFO_S = struct_CLX_FCOE_ROUTE_INFO_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 128

CLX_FCOE_ZONE_S = struct_CLX_FCOE_ZONE_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 135

CLX_FCOE_CLV_PORT_INFO_S = struct_CLX_FCOE_CLV_PORT_INFO_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 148

CLX_FCOE_FC_FRAME_ACTION_S = struct_CLX_FCOE_FC_FRAME_ACTION_S# ./clx_system/clx_sdk/include/clx_fcoe.h: 160

CLX_ACL_GROUP_PROFILE_S = struct_CLX_ACL_GROUP_PROFILE_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 216

CLX_ACL_PKT_FORMAT_S = struct_CLX_ACL_PKT_FORMAT_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 248

CLX_ACL_PKG_CFG_S = struct_CLX_ACL_PKG_CFG_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 274

CLX_ACL_UDF_KEY_PROFILE_S = struct_CLX_ACL_UDF_KEY_PROFILE_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 317

CLX_ACL_LOU_CFG_S = struct_CLX_ACL_LOU_CFG_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 348

CLX_ACL_MAC_KEY_S = struct_CLX_ACL_MAC_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 369

CLX_ACL_ARP_KEY_S = struct_CLX_ACL_ARP_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 385

CLX_ACL_IPV4_KEY_S = struct_CLX_ACL_IPV4_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 416

CLX_ACL_IPV6_KEY_S = struct_CLX_ACL_IPV6_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 456

CLX_ACL_FCOE_KEY_S = struct_CLX_ACL_FCOE_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 488

CLX_ACL_QOS_KEY_S = struct_CLX_ACL_QOS_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 514

CLX_ACL_PP_INFO_KEY_S = struct_CLX_ACL_PP_INFO_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 580

CLX_ACL_PKG_KEY_S = struct_CLX_ACL_PKG_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 622

CLX_ACL_LOU_KEY_S = struct_CLX_ACL_LOU_KEY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 628

CLX_ACL_CLASSIFY_S = struct_CLX_ACL_CLASSIFY_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 671

CLX_ACL_QOS_ACTION_S = struct_CLX_ACL_QOS_ACTION_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 691

CLX_ACL_REDIRECT_ACTION_S = struct_CLX_ACL_REDIRECT_ACTION_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 716

CLX_ACL_REWRITE_CFG_S = struct_CLX_ACL_REWRITE_CFG_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 736

CLX_ACL_PKT_REWRITE_S = struct_CLX_ACL_PKT_REWRITE_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 742

CLX_ACL_ACTION_S = struct_CLX_ACL_ACTION_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 796

CLX_ACL_GROUP_INFO_S = struct_CLX_ACL_GROUP_INFO_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 804

CLX_ACL_ENTRY_INFO_S = struct_CLX_ACL_ENTRY_INFO_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 821

CLX_ACL_UDF_INFO_S = struct_CLX_ACL_UDF_INFO_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 835

CLX_ACL_LOU_INFO_S = struct_CLX_ACL_LOU_INFO_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_acl.h: 849

CLX_CFG_VALUE_S = struct_CLX_CFG_VALUE_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_cfg.h: 356

CLX_DTEL_DPP_HDR_S = struct_CLX_DTEL_DPP_HDR_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 75

CLX_DTEL_DPP_S = struct_CLX_DTEL_DPP_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 87

CLX_DTEL_CFG_S = struct_CLX_DTEL_CFG_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/clx_dtel.h: 136

CLX_SEC_DOS_PORT_CONFIG_S = struct_CLX_SEC_DOS_PORT_CONFIG_S# ./clx_system/clx_sdk/include/clx_sec.h: 161

CLX_SEC_DOS_CONFIG_S = struct_CLX_SEC_DOS_CONFIG_S# ./clx_system/clx_sdk/include/clx_sec.h: 177

CLX_SEC_STORM_CTRL_ENTRY_S = struct_CLX_SEC_STORM_CTRL_ENTRY_S# ./clx_system/clx_sdk/include/clx_sec.h: 192

CLX_SEC_STORM_CTRL_S = struct_CLX_SEC_STORM_CTRL_S# ./clx_system/clx_sdk/include/clx_sec.h: 214

CLX_SEC_STORM_CTRL_CNT_S = struct_CLX_SEC_STORM_CTRL_CNT_S# ./clx_system/clx_sdk/include/clx_sec.h: 220

CLX_SEC_SG_PORT_CONFIG_S = struct_CLX_SEC_SG_PORT_CONFIG_S# ./clx_system/clx_sdk/include/clx_sec.h: 239

CLX_SEC_SG_ENTRY_S = struct_CLX_SEC_SG_ENTRY_S# ./clx_system/clx_sdk/include/clx_sec.h: 264

CLX_L3T_MAC_INFO_S = struct_CLX_L3T_MAC_INFO_S# ./clx_system/clx_sdk/include/clx_l3t.h: 97

CLX_L3T_INIT_INFO_S = struct_CLX_L3T_INIT_INFO_S# ./clx_system/clx_sdk/include/clx_l3t.h: 207

CLX_L3T_TERM_INFO_S = struct_CLX_L3T_TERM_INFO_S# ./clx_system/clx_sdk/include/clx_l3t.h: 299

CLX_L3T_NVO3_ROUTE_INFO_S = struct_CLX_L3T_NVO3_ROUTE_INFO_S# ./clx_system/clx_sdk/include/clx_l3t.h: 307

CLX_SDN_PORT_S = struct_CLX_SDN_PORT_S# ./clx_system/clx_sdk/include/clx_sdn.h: 110

CLX_SDN_TUNNEL_S = struct_CLX_SDN_TUNNEL_S# ./clx_system/clx_sdk/include/clx_sdn.h: 123

CLX_SDN_TUNNEL_ATTR_S = struct_CLX_SDN_TUNNEL_ATTR_S# ./clx_system/clx_sdk/include/clx_sdn.h: 132

CLX_SDN_SFLOW_S = struct_CLX_SDN_SFLOW_S# ./clx_system/clx_sdk/include/clx_sdn.h: 139

CLX_SDN_NSH_S = struct_CLX_SDN_NSH_S# ./clx_system/clx_sdk/include/clx_sdn.h: 150

CLX_SDN_PPPOE_S = struct_CLX_SDN_PPPOE_S# ./clx_system/clx_sdk/include/clx_sdn.h: 165

CLX_SDN_FIELD_VALUE_U = union_CLX_SDN_FIELD_VALUE_U# ./clx_system/clx_sdk/include/clx_sdn.h: 180

CLX_SDN_FLOW_TABLE_PROP_S = struct_CLX_SDN_FLOW_TABLE_PROP_S# ./clx_system/clx_sdk/include/clx_sdn.h: 217

CLX_SDN_FLOW_TABLE_PROP_HEAD_S = struct_CLX_SDN_FLOW_TABLE_PROP_HEAD_S# ./clx_system/clx_sdk/include/clx_sdn.h: 224

CLX_SDN_FLOW_TABLE_PROP_NEXT_TABLE_S = struct_CLX_SDN_FLOW_TABLE_PROP_NEXT_TABLE_S# ./clx_system/clx_sdk/include/clx_sdn.h: 232

CLX_SDN_MATCH_FIELD_HEADER_S = struct_CLX_SDN_MATCH_FIELD_HEADER_S# ./clx_system/clx_sdk/include/clx_sdn.h: 313

CLX_SDN_FLOW_TABLE_PROP_FIELD_S = struct_CLX_SDN_FLOW_TABLE_PROP_FIELD_S# ./clx_system/clx_sdk/include/clx_sdn.h: 321

CLX_SDN_ACTION_S = struct_CLX_SDN_ACTION_S# ./clx_system/clx_sdk/include/clx_sdn.h: 382

CLX_SDN_INST_S = struct_CLX_SDN_INST_S# ./clx_system/clx_sdk/include/clx_sdn.h: 416

CLX_SDN_INST_DATA_GOTO_TABLE_S = struct_CLX_SDN_INST_DATA_GOTO_TABLE_S# ./clx_system/clx_sdk/include/clx_sdn.h: 423

CLX_SDN_INST_DATA_WRITE_METADATA_S = struct_CLX_SDN_INST_DATA_WRITE_METADATA_S# ./clx_system/clx_sdk/include/clx_sdn.h: 430

CLX_SDN_INST_DATA_WRITE_ACTIONS_S = struct_CLX_SDN_INST_DATA_WRITE_ACTIONS_S# ./clx_system/clx_sdk/include/clx_sdn.h: 437

CLX_SDN_INST_DATA_APPLY_ACTIONS_S = struct_CLX_SDN_INST_DATA_APPLY_ACTIONS_S# ./clx_system/clx_sdk/include/clx_sdn.h: 444

CLX_SDN_INST_DATA_METER_S = struct_CLX_SDN_INST_DATA_METER_S# ./clx_system/clx_sdk/include/clx_sdn.h: 450

CLX_SDN_INST_DATA_CNT_S = struct_CLX_SDN_INST_DATA_CNT_S# ./clx_system/clx_sdk/include/clx_sdn.h: 456

CLX_SDN_MATCH_FIELD_S = struct_CLX_SDN_MATCH_FIELD_S# ./clx_system/clx_sdk/include/clx_sdn.h: 466

CLX_SDN_FLOW_ENTRY_S = struct_CLX_SDN_FLOW_ENTRY_S# ./clx_system/clx_sdk/include/clx_sdn.h: 477

CLX_SDN_FLOW_TABLE_TUNNEL_QLI_CFG_S = struct_CLX_SDN_FLOW_TABLE_TUNNEL_QLI_CFG_S# ./clx_system/clx_sdk/include/clx_sdn.h: 504

CLX_SDN_GROUP_BUCKET_S = struct_CLX_SDN_GROUP_BUCKET_S# ./clx_system/clx_sdk/include/clx_sdn.h: 533

CLX_SDN_GROUP_ENTRY_S = struct_CLX_SDN_GROUP_ENTRY_S# ./clx_system/clx_sdk/include/clx_sdn.h: 542

CLX_SDN_METER_COLOR_POLICY_S = struct_CLX_SDN_METER_COLOR_POLICY_S# ./clx_system/clx_sdk/include/clx_sdn.h: 564

CLX_SDN_METER_BAND_S = struct_CLX_SDN_METER_BAND_S# ./clx_system/clx_sdk/include/clx_sdn.h: 577

CLX_SDN_METER_ENTRY_S = struct_CLX_SDN_METER_ENTRY_S# ./clx_system/clx_sdk/include/clx_sdn.h: 594

CLX_SDN_STAT_S = struct_CLX_SDN_STAT_S# ./clx_system/clx_sdk/include/clx_sdn.h: 602

CLX_SDN_METER_STAT_S = struct_CLX_SDN_METER_STAT_S# ./clx_system/clx_sdk/include/clx_sdn.h: 613

CLX_SDN_LOAD_BALANCE_S = struct_CLX_SDN_LOAD_BALANCE_S# ./clx_system/clx_sdk/include/clx_sdn.h: 632

CLX_LAG_TRAVERSE_INFO_S = struct_CLX_LAG_TRAVERSE_INFO_S# ./clx_system/clx_sdk/include/clx_lag.h: 65

CLX_MIR_ERSPAN_TERM_S = struct_CLX_MIR_ERSPAN_TERM_S# ./clx_system/clx_sdk/include/clx_mir.h: 85

CLX_MIR_ERSPAN_PKT_S = struct_CLX_MIR_ERSPAN_PKT_S# ./clx_system/clx_sdk/include/clx_mir.h: 111

CLX_MIR_SESSION_S = struct_CLX_MIR_SESSION_S# ./clx_system/clx_sdk/include/clx_mir.h: 147

CLX_TM_BUF_OCCUPANCY_S = struct_CLX_TM_BUF_OCCUPANCY_S# ./clx_system/clx_sdk/include/clx_tm.h: 189

CLX_TM_BUF_WATERMARK_S = struct_CLX_TM_BUF_WATERMARK_S# ./clx_system/clx_sdk/include/clx_tm.h: 196

CLX_TM_BUF_THRESHOLD_S = struct_CLX_TM_BUF_THRESHOLD_S# ./clx_system/clx_sdk/include/clx_tm.h: 219

CLX_TM_SCH_TOPOLOGY_ENTRY_S = struct_CLX_TM_SCH_TOPOLOGY_ENTRY_S# ./clx_system/clx_sdk/include/clx_tm.h: 228

CLX_TM_BANDWIDTH_S = struct_CLX_TM_BANDWIDTH_S# ./clx_system/clx_sdk/include/clx_tm.h: 237

CLX_TM_WRED_ENTRY_S = struct_CLX_TM_WRED_ENTRY_S# ./clx_system/clx_sdk/include/clx_tm.h: 245

CLX_TM_WRED_QUEUE_CFG_S = struct_CLX_TM_WRED_QUEUE_CFG_S# ./clx_system/clx_sdk/include/clx_tm.h: 257

CLX_TM_DCTCP_PROFILE_S = struct_CLX_TM_DCTCP_PROFILE_S# ./clx_system/clx_sdk/include/clx_tm.h: 274

CLX_TM_IGR_PORT_BUF_SNAPSHOT_S = struct_CLX_TM_IGR_PORT_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 289

CLX_TM_IGR_BUF_SNAPSHOT_S = struct_CLX_TM_IGR_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 298

CLX_TM_EGR_PORT_BUF_SNAPSHOT_S = struct_CLX_TM_EGR_PORT_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 320

CLX_TM_EGR_CPU_QUEUE_BUF_SNAPSHOT_S = struct_CLX_TM_EGR_CPU_QUEUE_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 327

CLX_TM_EGR_BUF_SNAPSHOT_S = struct_CLX_TM_EGR_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 337

CLX_TM_POOL_BUF_SNAPSHOT_S = struct_CLX_TM_POOL_BUF_SNAPSHOT_S# ./clx_system/clx_sdk/include/clx_tm.h: 344

CLX_SWC_STEERING_ENTRY_S = struct_CLX_SWC_STEERING_ENTRY_S# ./clx_system/clx_sdk/include/clx_swc.h: 267

CLX_SWC_DEVICE_INFO_S = struct_CLX_SWC_DEVICE_INFO_S# ./clx_system/clx_sdk/include/clx_swc.h: 354

CLX_SWC_PORT_CONFIG_S = struct_CLX_SWC_PORT_CONFIG_S# ./clx_system/clx_sdk/include/clx_swc.h: 373

CLX_SWC_CPI_ENCAP_HDR_S = struct_CLX_SWC_CPI_ENCAP_HDR_S# ./clx_system/clx_sdk/include/clx_swc.h: 397

CLX_INIT_PARAM_S = struct_CLX_INIT_PARAM_S# ./clx_system/clx_sdk/include/clx_init.h: 93

CLX_STAT_TM_CNT_S = struct_CLX_STAT_TM_CNT_S# ./clx_system/clx_sdk/include/clx_stat.h: 256

CLX_STAT_DIST_CNT_S = struct_CLX_STAT_DIST_CNT_S# ./clx_system/clx_sdk/include/clx_stat.h: 286

CLX_STAT_CNT_CFG_S = struct_CLX_STAT_CNT_CFG_S# ./clx_system/clx_sdk/include/clx_stat.h: 311

CLX_STAT_CNT_S = struct_CLX_STAT_CNT_S# ./clx_system/clx_sdk/include/clx_stat.h: 316

CLX_TRILL_PKT_HANDLING_S = struct_CLX_TRILL_PKT_HANDLING_S# ./clx_system/clx_sdk/include/clx_trill.h: 78

CLX_TRILL_INIT_INFO_S = struct_CLX_TRILL_INIT_INFO_S# ./clx_system/clx_sdk/include/clx_trill.h: 116

CLX_TRILL_TERM_INFO_S = struct_CLX_TRILL_TERM_INFO_S# ./clx_system/clx_sdk/include/clx_trill.h: 155

CLX_TRILL_ROUTE_INFO_S = struct_CLX_TRILL_ROUTE_INFO_S# ./clx_system/clx_sdk/include/clx_trill.h: 174

CLX_TRILL_TREE_S = struct_CLX_TRILL_TREE_S# ./clx_system/clx_sdk/include/clx_trill.h: 203

CLX_TRILL_ADJ_CHECK_S = struct_CLX_TRILL_ADJ_CHECK_S# ./clx_system/clx_sdk/include/clx_trill.h: 211

CLX_TRILL_RPF_CHECK_S = struct_CLX_TRILL_RPF_CHECK_S# ./clx_system/clx_sdk/include/clx_trill.h: 218

CLX_TRILL_PORT_PROPERTY_S = struct_CLX_TRILL_PORT_PROPERTY_S# ./clx_system/clx_sdk/include/clx_trill.h: 227

CLX_SFC_ENCAP_KEY_S = struct_CLX_SFC_ENCAP_KEY_S# ./clx_system/clx_sdk/include/clx_sfc.h: 70

CLX_SFC_FORWARDER_S = struct_CLX_SFC_FORWARDER_S# ./clx_system/clx_sdk/include/clx_sfc.h: 81

OSAL_TM_S = struct_OSAL_TM_S# ./clx_system/clx_sdk/include/osal/osal.h: 71

OSAL_DMA_MPOOL_CONFIG_S = struct_OSAL_DMA_MPOOL_CONFIG_S# /home/jenkins/workspace/sai/release/202012.clounix/nephos-sai/clx_system/clx_sdk/include/osal/osal_dma.h: 69

# No inserted files

# No prefix-stripping

